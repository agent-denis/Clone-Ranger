# Making a new version of Clone Ranger

Project status: **closed after 1.1.0** (2026-11-19). Git tag `v1.1.0` on `main` (the `windows-port` branch is
merged). Release files: `~/projects/clone-ranger-1.1.0-release/`. This folder has no git remote; Denis uploads to
GitHub by hand (`agent-denis/clone-ranger`). Use this file to start a new version (1.2, 2.0, ...).

## What it is

A duplicate photo and video finder (Python 3.11+, PySide6, Pillow), GPL-3.0-or-later. Runs on Fedora / Linux
(`install.sh` or RPM) and on Windows 10 / 11 (installer or portable zip, built on Windows).

Decisions Denis made:
- English only; colourful orange / light blue / yellow / red look, Inter font.
- Windows: **no code signing and no Microsoft Store**; friends click "More info → Run anyway" once.
- Small screens: only the small fixes (scrolling pages, open maximized). 200 % on an 11" laptop stays cramped;
  a compact layout was offered and not wanted.
- No mock: other Fedora versions are built in a rootless podman container.
- Denis tests on his own machines before anything is called done.

## 0. Before starting

1. `git status` should be clean; latest commits are on `main`.
2. GitHub was uploaded by hand, so it may differ from local `main`. Ask Denis before assuming they match.
3. Agree the feature list with Denis before writing code.

## 1. Run and test

```bash
cd ~/projects/clone-ranger
.venv/bin/python -m clone_ranger --demo    # demo data, touches no files
.venv/bin/python -m pytest                 # 160 passed / 7 skipped at 1.1.0 (sandboxed, never touch real files)
```

Windows-only behaviour is tested on Linux where possible in `tests/core/test_windows.py`; Linux-only tests carry
`linux_only` / `needs_symlinks` marks (`tests/core/conftest.py`). The full suite on Windows was run once
(2026-11-19, 10 failures, all fixed in 97cb264) but **not re-run after the fixes** (Denis stopped testing there).

## 2. Bump the version number (all of these places)

| File | What to change |
|---|---|
| `clone_ranger/__init__.py` | `__version__` (`windows/build.ps1` reads it from here) |
| `packaging/clone-ranger.spec` | `Version:` and the two `clone-ranger-X.Y.Z` in the build comment |
| `packaging/io.github.agent_denis.CloneRanger.metainfo.xml` | new `<release>` at the top of `<releases>` |
| `windows/clone-ranger.iss` | version in the comment at the top |
| `CHANGELOG.md`, `README.md` (Windows installer name) | new entry / file name |
| `docs/RELEASE-NOTES-X.Y.Z.md` | new file, copy the previous one |

Then `.venv/bin/python tools/export_text.py` (refreshes `README.txt` and `clone-ranger-source.txt`; a test checks
README.txt). Check with `grep -rn 'OLD.VERSION' --exclude-dir=.git --exclude-dir=.venv .`

## 3. Build the packages

**Fedora (this machine):**
```bash
rpmdev-setuptree
git archive --prefix=clone-ranger-X.Y.Z/ -o ~/rpmbuild/SOURCES/clone-ranger-X.Y.Z.tar.gz vX.Y.Z
rpmbuild -ba packaging/clone-ranger.spec
```
**Other Fedora version** (an RPM only installs on the Fedora version it was built for): rootless
`podman run --rm --tmpfs /tmp -v DIR:/w:Z registry.fedoraproject.org/fedora:NN`, install rpm-build and the
packages from the spec comment, `dnf builddep` the .src.rpm, then `rpmbuild --rebuild` **as a non-root user**
(the app refuses root).

**Windows:** `git archive --format=zip --prefix=clone-ranger/ -o ../clone-ranger-X.Y.Z-windows-src.zip vX.Y.Z`,
copy to the Windows PC, unzip to `D:\clone-ranger-windows-src\`, run `windows\build.bat` (or
`powershell -ExecutionPolicy Bypass -File windows\build.ps1 -FullTests` for the whole test suite). Output in
`dist-windows\`: `CloneRanger-X.Y.Z-Setup.exe` and `-portable.zip`. Guide: `windows/README-WINDOWS.md`.

## 4. Known open items

- `test_hard_links_are_not_counted` fails when `/tmp` is on Btrfs/XFS (reflink copies); it should not depend on the
  file system of `/tmp`.
- HEIC: works with `install.sh` and on Windows, not in the RPM (Fedora has no python3-pillow-heif).
- HEVC video thumbnails need an FFmpeg that decodes HEVC (`ffmpeg-free` can't). Not tested with a real phone video.
- Untested: KDE Plasma, a real FAT/exFAT stick. First scan of 200 000 files peaks at about 614 MB of memory.
- Publishing to COPR / Fedora: see `docs/PUBLISHING.md` (Denis has no COPR account yet).
