# Publishing Clone Ranger

Three stages, each useful on its own:

1. **GitHub**: the public home of the source code (GPL-3.0-or-later), with release tarballs.
2. **COPR**: Fedora's community build service. Anyone can `dnf install` Clone Ranger within a day, no review needed.
3. **Fedora repositories**: `sudo dnf install clone-ranger` on every Fedora machine. Needs a package review and a
   sponsor; plan for a few weeks.

Everything below must be done by you, with your own accounts. Nothing here can be done for you without them.

---

## 1. GitHub

```bash
# once: create an empty public repository named "clone-ranger" on https://github.com/new
#       (no README / licence / .gitignore - they are already in this folder)
cd ~/projects/clone-ranger
git remote add origin git@github.com:agent-denis/clone-ranger.git
git push -u origin main
git tag -a v1.0.0 -m "Clone Ranger 1.0.0"
git push origin v1.0.0
```

Then on GitHub: **Releases → Draft a new release → tag v1.0.0**, title "Clone Ranger 1.0.0", and paste the
1.0.0 section of `CHANGELOG.md`. GitHub creates the source tarball automatically at
`https://github.com/agent-denis/clone-ranger/archive/v1.0.0/clone-ranger-1.0.0.tar.gz`, which is exactly the
`Source0` the RPM spec uses.

Suggested repository settings: description "Find and clean up duplicate photos and videos", topics
`duplicates`, `photos`, `videos`, `linux`, `fedora`, `qt`, `pyside6`; enable Issues.

The AppStream metadata points at screenshots on the `main` branch
(`raw.githubusercontent.com/agent-denis/clone-ranger/main/docs/screenshots/…`), so they appear in GNOME Software
as soon as the repository is public.

---

## 2. Build and check the RPM locally

```bash
sudo dnf install rpm-build rpmdevtools redhat-rpm-config pyproject-rpm-macros desktop-file-utils \
                 appstream python3-pytest python3-pillow python3-pyside6 rsms-inter-fonts rpmlint fedora-review mock
sudo usermod -aG mock $USER      # then log out and in again (mock builds in a clean Fedora build root)

rpmdev-setuptree
cd ~/projects/clone-ranger
git archive --prefix=clone-ranger-1.0.0/ -o ~/rpmbuild/SOURCES/clone-ranger-1.0.0.tar.gz v1.0.0
rpmbuild -ba packaging/clone-ranger.spec
rpmlint packaging/clone-ranger.spec ~/rpmbuild/SRPMS/clone-ranger-*.src.rpm ~/rpmbuild/RPMS/noarch/clone-ranger-*.rpm
mock -r fedora-rawhide-x86_64 --rebuild ~/rpmbuild/SRPMS/clone-ranger-1.0.0-*.src.rpm   # what Fedora's builders do
sudo dnf install ~/rpmbuild/RPMS/noarch/clone-ranger-1.0.0-*.noarch.rpm                  # try it
```

---

## 3. COPR (quick public RPMs)

1. Log in at <https://copr.fedorainfracloud.org> with a Fedora account (create one at
   <https://accounts.fedoraproject.org>).
2. **New project** `clone-ranger`; chroots: the current Fedora releases and rawhide (x86_64 is enough: the package is
   `noarch`); tick *Internet access during builds* off.
3. **Builds → New build → Upload** the `.src.rpm` from step 2 (or use *SCM* with the GitHub URL and
   `packaging/clone-ranger.spec`, so every tag builds automatically).

Users then install it with:

```bash
sudo dnf copr enable agent-denis/clone-ranger
sudo dnf install clone-ranger
```

---

## 4. Getting into the official Fedora repositories

Fedora only accepts packages that pass a review by an experienced packager, and new packagers need a
**sponsor**. The spec in `packaging/clone-ranger.spec` is already written to the
[Fedora Packaging Guidelines](https://docs.fedoraproject.org/en-US/packaging-guidelines/): free licence
(GPL-3.0-or-later, valid SPDX), no bundled fonts (uses `rsms-inter-fonts`), Python built with the pyproject
macros and generated dependencies, desktop file and AppStream metadata validated in `%check`, the core tests run
in `%check`, `%autorelease`/`%autochangelog`.

Steps (official guide: <https://docs.fedoraproject.org/en-US/package-maintainers/Joining_the_Package_Maintainers/>):

1. **Accounts.** A Fedora account at <https://accounts.fedoraproject.org> and a Red Hat Bugzilla account at
   <https://bugzilla.redhat.com> with the **same e-mail address**. Sign the Fedora Project Contributor Agreement
   in the account settings.
2. **Publish the spec and SRPM** at stable URLs, e.g. attach them to the GitHub release, or use the COPR build
   from step 3 (COPR shows direct links to both).
3. **Run the review tool yourself first** and fix anything it reports:
   ```bash
   fedora-review -n clone-ranger --mock-config fedora-rawhide-x86_64 -m fedora-rawhide-x86_64
   ```
4. **File a Package Review request** in Bugzilla: <https://bugzilla.redhat.com/enter_bug.cgi?product=Fedora&component=Package%20Review>
   - Summary: `Review Request: clone-ranger - Find and clean up duplicate photos and videos`
   - Description: the Spec URL, SRPM URL, the `%description` text, and the COPR link.
   - Because this is your first package, add **FE-NEEDSPONSOR** to the *Blocks* field and say so in the description.
5. **Find a sponsor.** Announce the request on the Fedora devel list / <https://discussion.fedoraproject.org>
   (tag `package-review`), and help review other people's packages - sponsors look for that. Answer review
   comments by updating the spec, bumping nothing (with `%autorelease` the release comes from git), and posting
   new Spec/SRPM URLs in the bug.
6. **After approval** (the reviewer sets `fedora-review+`):
   ```bash
   sudo dnf install fedpkg
   fedpkg request-repo clone-ranger <bug number>
   # when the repository exists:
   fedpkg clone clone-ranger && cd clone-ranger
   fedpkg import ~/rpmbuild/SRPMS/clone-ranger-1.0.0-*.src.rpm
   git commit -m "Initial import (rhbz#<bug number>)" && fedpkg push && fedpkg build
   fedpkg request-branch f44            # and f43 ...: one per supported Fedora release
   # on each branch: git merge rawhide, fedpkg push, fedpkg build, fedpkg update
   ```
7. **Bodhi updates** (`fedpkg update`) move the build to `updates-testing` and, after a few days or enough
   positive karma, to the stable repositories. From then on, on every Fedora machine:
   ```bash
   sudo dnf install clone-ranger
   ```

### New releases later

Bump `__version__` in `clone_ranger/__init__.py`, `Version:` in the spec, add a `<release>` to the metainfo and a
section to `CHANGELOG.md` (a test checks they agree), tag `vX.Y.Z` on GitHub, then in the Fedora repository:
`spectool -g clone-ranger.spec && fedpkg new-sources clone-ranger-X.Y.Z.tar.gz && fedpkg commit && fedpkg push &&
fedpkg build && fedpkg update`.

### Things a reviewer may ask about

- **HEIC support**: not available in the RPM because Fedora has no `python3-pillow-heif`; HEIC files are still found
  and compared, just without previews.
- **BLAKE3**: optional; Fedora has no `python3-blake3`, so the package uses BLAKE2b from the standard library.
- **App ID with capitals** (`io.github.agent_denis.CloneRanger`): allowed; `appstreamcli` only notes it pedantically.
