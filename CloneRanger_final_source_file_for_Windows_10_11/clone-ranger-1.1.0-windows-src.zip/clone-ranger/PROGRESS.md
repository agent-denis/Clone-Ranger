# Clone Ranger — Progress

_Last updated: 2026-11-19 · **project CLOSED after 1.1.0** (tag `v1.1.0` on `main`) · 160 tests passing on Linux_

## Where we are

**Clone Ranger 1.1.0 is the final version; the project is closed.** For a new version read
[`docs/NEW_VERSION.md`](docs/NEW_VERSION.md).

1.1.0 = 1.0.0 + Windows 10/11 support (the `windows-port` branch, merged into `main`) + the fixes from the first
full Windows test run. Denis decided not to run the Windows tests again. Release files in
`~/projects/clone-ranger-1.1.0-release/`: Fedora 45 and Fedora 44 RPMs (both built with the RPM's own tests
passing), `clone-ranger-1.1.0-windows-src.zip` (build the Windows installer from it with `windows\build.bat`)
and the release notes.

```bash
cd ~/projects/clone-ranger
.venv/bin/python -m clone_ranger --demo    # demo data, touches no files
.venv/bin/python -m pytest                 # 160 passed / 7 skipped
./install.sh                               # install / upgrade for your user (app menu + `clone-ranger`)
```

## Windows 10/11 port (started 2026-11-17)

> **Last Windows state (2026-11-19, evening):** first full test run on Windows (`-FullTests`): 136 passed,
> 10 failed, 19 skipped. Fixed in commit 97cb264, new zip made (previous one kept as `.old.zip`). Next: the user runs
> `-FullTests` again on Windows with the new zip and brings back `full-tests.txt`; expect 0 failures.
> Real bugs found: (1) on Windows, renaming a.jpg to b.jpg when b.jpg is a hard link to the same file was let through
> as a "case-only rename" -> new `fsops.is_case_only_rename` (same folder + same name ignoring case + same file);
> (2) the Windows scanner didn't skip Linux `.snapshots` / `.Trash` / `.Trash-*` / `.thumbnails` folders (USB disks
> shared with Linux) -> added to the Windows exclude names; (3) `recommend.temp_score` now splits Windows paths on
> both slashes. The other failures were tests comparing `/` with `\\` paths, and the root test (now fakes `is_admin`).
> 160 passed / 7 skipped on Linux.

Goal: a few friends can use it on Windows. **No code signing and no Microsoft Store** (the user decided);
friends click "More info → Run anyway" once. The user has a real Windows 11 PC to build and test on.

Done (on Linux, not yet run on Windows):
- `core/osinfo.py`: one place for Windows differences (case-insensitive `is_within`, drives, admin check,
  no console window for ffmpeg, bundled ffmpeg lookup). `core/recycle_bin.py`: Move to Recycle Bin via
  SHFileOperationW, then finds the `$R`/`$I` pair so Undo restores like Explorer; drives that aren't fixed disks
  raise TrashUnavailable (USB sticks have no Recycle Bin).
- Scanner: Windows excludes, "entire computer" = all local and USB drives, skips junctions and OneDrive online-only
  files, and uses `os.lstat` for real file IDs (**scandir gives st_ino 0 on Windows: without it every file looked
  like one hard link**). Hasher opens with O_BINARY. Settings and data in %APPDATA% / %LOCALAPPDATA%\Clone Ranger.
  "Trash" reads "Recycle Bin", Explorer "Show in folder", Windows file-name rules in rename.
- `windows/`: `build.bat` → `build.ps1` (Python 3.13 venv, Windows checks, FFmpeg from gyan.dev with SHA-256,
  PyInstaller onedir, portable zip, Inno Setup per-user installer). Guide: `windows/README-WINDOWS.md`.
- Tests: `tests/core/test_windows.py` (runs everywhere) and `tests/core/test_windows_real.py` (Windows only:
  real Recycle Bin round trip, hard links, CRLF hashing, case-insensitive excludes).
- Copy for the Windows PC: `~/projects/clone-ranger-windows-src.zip`.

**Paused 2026-11-18:** user is testing on the Windows 11 PC (zip checked: matches the code).

**First Windows run (2026-11-18):** `build.bat` stopped at "Running the Windows checks": circular import
(`recycle_bin` imported `trash`, which on Windows imports `recycle_bin`). Fixed by moving `Trashed` /
`TrashUnavailable` into `core/trash_types.py`; new test `test_trash_modules_import_in_any_order_on_windows`
fakes WINDOWS=True on Linux. 154 passed / 7 skipped on Linux. Committed on `windows-port`;
new zip `~/projects/clone-ranger-windows-src.zip` (old one kept as `.old.zip`).

**Second Windows run (2026-11-19): build works.** 18/18 Windows checks passed; `dist-windows` has
`CloneRanger-1.0.0-Setup.exe` (100 MB) and `CloneRanger-1.0.0-portable.zip` (142 MB). Installed and tested on two
PCs: all functions work (scan, Recycle Bin, Undo, thumbnails). Screenshots: `~/projects/screenprints_from_win_computer/`.

**Small-screen finding:** the main window's minimum size is **1262 × 704** logical pixels (sidebar 236 + results 704
+ Details 320; height mostly from the Scan locations page, min 570). An 11" laptop (2160×1440) at **200 %** scaling
has only ~1080 × 670, so Windows squeezed the maximized window and texts/buttons were cut off. At the recommended
**150 %** (~1440 × 960) everything looks right (user confirmed). User chose **option 1 (small fixes only)**, done 2026-11-19: tall pages (scan screen, Scan locations,
History) sit in scroll areas (`PageStack` in main_window.py; min height 704 -> 637), the window opens maximized
when its size doesn't fit the screen (`_fit_to_screen`), and the title bar fix below. Width minimum stays 1262,
so 200 % on an 11" laptop is still cramped (accepted). Not done (option 2, only if asked later):
compact layout below ~1300 × 760 (icon-only sidebar and Move/Rename/Compare, tighter header/stat tiles, narrower
Details), scroll areas for the tall pages, open maximized when the saved size doesn't fit the screen.
Also seen: Windows title bar shows "Clone Ranger – Duplicate Photo & Video Finder - Clone Ranger" (Qt appends the
display name unless the title ends with it) -> fixed: the title is now "Duplicate Photo & Video Finder – Clone Ranger".
New zip built and installed over the old version on Windows (2026-11-19): **everything works** (user confirmed).
That build first stopped on "503 Server Unavailable" from gyan.dev (FFmpeg download); a rerun later worked.
`build.ps1` now retries the download 4 times, 30 s apart (commit add0782, not yet run on Windows; in the next zip).
Still to do: full test run on Windows (`full-tests.txt`), then skip marks for Linux-only tests.

**Whole-drive scan crash (found 2026-11-19, fixed):** scanning a whole drive / large volume on Windows failed with
`OverflowError: Python int too large to convert to SQLite INTEGER` (index.py add_files). Windows file IDs (NTFS
sequence number in the top bits; 128-bit ReFS IDs and 64-bit volume serials since Python 3.12) don't fit SQLite's
signed 64-bit INTEGER. Fix: `osinfo.db_int()` (unchanged if it fits, exact 64-bit wrap, hash fold for bigger;
idempotent), used wherever dev/ino are stored (scanner, index add_files / relocate / restore_path, viewmodel) and
compared with stored values (scanner's unchanged-file check). Tests in `tests/core/test_windows.py` (also run by
`build.bat`): the scan test fails without the fix. 158 passed / 7 skipped on Linux. New zip made; needs a rebuild
and a whole-drive scan on Windows.
Third Windows build (2026-11-19) stopped at the checks: 19 passed, 1 error. The new huge-file-ID test builds the
sample library, which makes a symlink, and Windows refuses that without Developer Mode (WinError 1314). Fixed in
`tools/make_sample_library.py` (commit 94f8495): it skips the symlink when Windows refuses. New zip made
(previous one kept as `.old.zip`). **Rebuilt and confirmed on Windows 2026-11-19: checks pass, whole-drive scan works.** Also checked 2026-11-19: no trace of the malicious `agent-framework` 1.26.1 /
1.26.2 PyPI releases on the Linux PC or the Windows PC (Clone Ranger never used that package).

Next (old list): then `-FullTests` (many Linux-only tests
such as chmod/symlink ones will need skip marks on Windows); try a real scan, Recycle Bin + Undo, video thumbnails.

## Done in 1.0.0 (the requests of 2026-11-16)

| # | Request | Result |
|---|---|---|
| 1 | Name Clone Ranger; modern, colourful, commercial look | Done: package `clone_ranger`, command `clone-ranger`, app ID `io.github.agent_denis.CloneRanger`, data in `~/.config\|.cache\|.local/state/clone-ranger`. Orange, light blue, white, yellow and red, Inter font, new logo and icons, Light / Dark / System / Plain themes, English only. |
| 3 | Easily unselect one or all files, with a button in the GUI | Done: **Unselect all** button + selection bar above the results (Ctrl+Shift+A), **Unselect this file** in the Details panel (Ctrl+U), right-click *Unselect this file* / *Unselect this group* on cards, list and grid. |
| 4 | Clear history, cache or both and start from scratch | Done: **File → Clear history & cache…** and **Settings → History & cache**. History = action history (Undo), app log, remembered folders. Cache = scan index + thumbnails. Warns when past actions could still be undone. |
| 5 | Reset to defaults: also clear history and cache, or only reset the search parameters | Done: one dialog with four choices (search settings · all other settings · history · cache). *Reset to defaults…* starts with only search settings ticked. |
| 6 | RPM package, copyleft licence on GitHub, Fedora repositories | RPM spec rewritten to the Fedora Packaging Guidelines (`packaging/clone-ranger.spec`); licence stays **GPL-3.0-or-later** (copyleft). Step-by-step guide for GitHub, COPR and Fedora inclusion: [`docs/PUBLISHING.md`](docs/PUBLISHING.md). |

Details:
- **App icon fix:** `install.sh` no longer writes `~/.local/share/icons/hicolor/icon-theme.cache`. Without an
  `index.theme` next to it that cache lists no icons, and GNOME showed the app without its icon. A stale one
  is removed on install / uninstall (test: `test_no_icon_cache_hides_the_app_icon`).
- **Reset / clear logic** lives in `clone_ranger/core/housekeeping.py` (no Qt). It only removes files inside
  Clone Ranger's own cache / state folders, never follows symlinks, empties log files instead of deleting them
  (the running app keeps one open), and refuses while a scan or action is running.
- **Fonts:** Inter 4.1 (OFL-1.1) is bundled for `install.sh`; the RPM deletes it and requires Fedora's
  `rsms-inter-fonts`. Without Inter the app falls back to Cantarell / Noto Sans and still fits 1366 px.
- **RPM:** dependencies generated from `pyproject.toml` (`PySide6>=6.8`, `pillow>=10`, which Fedora's
  `python3-pyside6` / `python3-pillow` provide), `%check` validates the desktop file and AppStream metadata and
  runs the core tests, `%autorelease` / `%autochangelog`. A wheel built the way `%prep` prepares the sources was
  checked (clean, correct licence metadata).
- **RPMs built (2026-11-16):** `~/rpmbuild/RPMS/noarch/clone-ranger-1.0.0-1.fc45.noarch.rpm` (Fedora 45, Python 3.15)
  and `clone-ranger-1.0.0-1.fc44.noarch.rpm` (Fedora 44, Python 3.14). **An RPM only installs on the Fedora version
  it was built for** (it requires that version's Python). The fc44 one was confirmed working on the user's
  Fedora 44 machine. Install with `sudo dnf install ./file.rpm` (not `rpm -i`; dnf downloads PySide6 etc.).
- **Building for another Fedora version without mock:** rootless podman container `registry.fedoraproject.org/fedora:NN`,
  install rpm-build + pyproject-rpm-macros etc., run `rpmbuild -br` / `dnf builddep` in rounds, then build as a
  **non-root user** (the app refuses root) with **`--tmpfs /tmp`** (see open item about the hard-link test).
- **Tests:** 143 passing: new `tests/core/test_housekeeping.py` (reset/clear/migration incl. a symlink trap) and
  `tests/test_ui_reset.py` (unselect buttons, reset / clear after a real scan, cancel, busy refusal); the
  string test now checks that every `tr()` key exists and no Russian or Cold-War wording is left.

## Next steps (need you)

1. **Look at it:** `.venv/bin/python -m clone_ranger --demo`, and the screenshots in `docs/screenshots/`.
2. **Build the RPM:** `sudo dnf install rpm-build rpmdevtools redhat-rpm-config pyproject-rpm-macros
   desktop-file-utils appstream python3-pytest python3-pillow python3-pyside6 rsms-inter-fonts`, then follow
   `docs/PUBLISHING.md` §2.
3. **Publish:** GitHub repository `agent-denis/clone-ranger`, COPR, then the Fedora package review
   (`docs/PUBLISHING.md` §1, §3, §4). These need your GitHub / Fedora / Bugzilla accounts.

## Open items

- **Fragile test:** `test_hard_links_are_not_counted` fails when `/tmp` is on Btrfs/XFS (copies become reflinks, so
  reclaim is correctly 0). The test should not depend on the filesystem of `/tmp`.

- **HEIC/HEIF:** works with `install.sh` (pillow-heif); not in the RPM (Fedora has no python3-pillow-heif).
- **HEVC video:** thumbnails need an FFmpeg that decodes HEVC (`ffmpeg-free` can't); playback uses Qt's FFmpeg.
  Not yet verified with a real phone video.
- **KDE Plasma** untested (GNOME Wayland and X11 are tested).
- **Memory with 200 000 files:** first scan peaks at about 614 MB.
- Not yet tested on a real FAT/exFAT stick.

## History

| Version | Date | |
|---|---|---|
| 1.1.0 | 2026-11-19 | Windows 10/11 (installer, Recycle Bin), small-screen fixes, whole-drive scan fix |
| 1.0.0 | 2026-11-16 | New design; unselect; clear history & cache; reset dialog; Fedora-style RPM |
| 0.9.0 | 2026-11-14 | development preview: 200k-file performance pass, Help menu, log rotation, README |
| 0.8.0 | 2026-11-14 | development preview: installer, desktop integration, RPM spec, GPL-3.0-or-later |
| 0.1–0.7 | 2026-11-13/14 | development: scanner, window, file operations, viewer, settings |
