#!/usr/bin/env bash
# Remove Clone Ranger (installed by install.sh) for the current user.
#
#   ./uninstall.sh            remove the program; keep settings, scan index and action log
#   ./uninstall.sh --purge    also remove settings (~/.config/clone-ranger), the scan index and thumbnails
#                             (~/.cache/clone-ranger) and the log + history (~/.local/state/clone-ranger)
#
# Never touches your photos or videos, and never empties the Trash.
set -euo pipefail

PURGE=0
YES=0
while [ $# -gt 0 ]; do
    case "$1" in
        --purge) PURGE=1; shift ;;
        -y|--yes) YES=1; shift ;;
        -h|--help) sed -n '2,9p' "$0" | sed 's/^# \{0,1\}//'; exit 0 ;;
        *) echo "Unknown option: $1" >&2; exit 2 ;;
    esac
done

say() { printf '  %s\n' "$*"; }
die() { printf '\nERROR: %s\n' "$*" >&2; exit 1; }
[ "$(id -u)" -ne 0 ] || die "Don't run this as root."

xdg() {  # xdg VAR DEFAULT: an absolute XDG directory
    local v="${!1:-}"
    case "$v" in /*) echo "$v" ;; *) echo "$HOME/$2" ;; esac
}
DATA="$(xdg XDG_DATA_HOME .local/share)"
APPDIR="$DATA/clone-ranger"
MARKER="$APPDIR/.clone-ranger-install"
MANIFEST="$APPDIR/installed-files.txt"
CONFIG="$(xdg XDG_CONFIG_HOME .config)/clone-ranger"
CACHE="$(xdg XDG_CACHE_HOME .cache)/clone-ranger"
STATE="$(xdg XDG_STATE_HOME .local/state)/clone-ranger"

if [ ! -f "$MARKER" ]; then
    echo "Clone Ranger doesn't seem to be installed for $(id -un) (no $MARKER)."
    [ "$PURGE" -eq 1 ] || exit 0
fi

echo "Removing Clone Ranger for user $(id -un)"
if [ -f "$MANIFEST" ]; then
    while IFS= read -r f; do
        # only ever remove files under the user's own folders that install.sh wrote
        case "$f" in
            "$DATA"/*|"$HOME"/.local/bin/clone-ranger) [ -f "$f" ] && rm -f "$f" && say "removed $f" ;;
            *) say "skipped unexpected entry: $f" ;;
        esac
    done < "$MANIFEST"
fi
if [ -f "$MARKER" ]; then
    rm -rf "$APPDIR"
    say "removed $APPDIR (program and its Python environment)"
fi
# empty icon folders left behind
find "$DATA/icons/hicolor" -type d -empty -delete 2>/dev/null || true
if [ ! -f "$DATA/icons/hicolor/index.theme" ]; then        # see install.sh: such a cache hides icons
    rm -f "$DATA/icons/hicolor/icon-theme.cache"
fi
[ -d "$DATA/icons/hicolor" ] && touch "$DATA/icons/hicolor" 2>/dev/null || true
command -v update-desktop-database >/dev/null 2>&1 && [ -d "$DATA/applications" ] && \
    update-desktop-database -q "$DATA/applications" 2>/dev/null || true

if [ "$PURGE" -eq 1 ]; then
    echo
    echo "--purge also removes:"
    for d in "$CONFIG" "$CACHE" "$STATE"; do [ -e "$d" ] && say "$d"; done
    say "(your photos, videos and the Trash are NOT touched)"
    if [ "$YES" -ne 1 ]; then
        printf 'Type "yes" to remove them: '
        read -r answer
        [ "$answer" = "yes" ] || { echo "Kept them."; exit 0; }
    fi
    for d in "$CONFIG" "$CACHE" "$STATE"; do
        case "$d" in */clone-ranger) [ -e "$d" ] && rm -rf "$d" && say "removed $d" ;; esac
    done
else
    kept=()
    for d in "$CONFIG" "$CACHE" "$STATE"; do [ -e "$d" ] && kept+=("$d"); done
    if [ "${#kept[@]}" -gt 0 ]; then
        echo
        echo "Kept your settings, scan index and history:"
        for d in "${kept[@]}"; do say "$d"; done
        echo "Remove them too with: ./uninstall.sh --purge"
    fi
fi
echo "Done."
