# RPM spec for Clone Ranger, written to the Fedora Packaging Guidelines (Python: pyproject macros).
#
# Build locally (needs: sudo dnf install rpm-build rpmdevtools redhat-rpm-config pyproject-rpm-macros
#                                         desktop-file-utils appstream python3-pytest python3-pillow python3-pyside6):
#
#   rpmdev-setuptree
#   git archive --prefix=clone-ranger-1.1.0/ -o ~/rpmbuild/SOURCES/clone-ranger-1.1.0.tar.gz HEAD
#   rpmbuild -ba packaging/clone-ranger.spec
#
# Or in a clean Fedora build root:  mock -r fedora-rawhide-x86_64 --rebuild ~/rpmbuild/SRPMS/clone-ranger-*.src.rpm
#
# Notes for reviewers:
#  * The source tree bundles the Inter font (OFL-1.1) for installs from source; it is removed in %%prep and the
#    system package rsms-inter-fonts is required instead (Fedora font packaging policy: no bundled fonts).
#  * Fedora has no python3-blake3, so the package hashes with BLAKE2b from the standard library.
#  * Python runtime dependencies (python3dist(pyside6), python3dist(pillow)) are generated from pyproject.toml.

%global app_id  io.github.agent_denis.CloneRanger

Name:           clone-ranger
Version:        1.1.0
Release:        %autorelease
Summary:        Find and clean up duplicate photos and videos

# The program, its logo, icons and sounds: GPL-3.0-or-later (the bundled font is removed in %%prep)
License:        GPL-3.0-or-later
URL:            https://github.com/agent-denis/clone-ranger
Source0:        %{url}/archive/v%{version}/%{name}-%{version}.tar.gz

BuildArch:      noarch
BuildRequires:  python3-devel
BuildRequires:  desktop-file-utils
BuildRequires:  appstream
# for %%check (core tests: no display, no network, every file operation locked to a temporary folder)
BuildRequires:  python3dist(pytest)
BuildRequires:  python3dist(pillow)

Requires:       hicolor-icon-theme
Requires:       font(inter)
Requires:       font(interdisplay)
# video thumbnails and durations
Recommends:     ffmpeg-free

%description
Clone Ranger finds exact duplicate photos and videos by their content and helps
you remove the extra copies safely. It shows each set of duplicates side by
side, suggests which copy to keep (with configurable rules, preferred and
protected folders), and lets you move the rest to the Trash, delete, move or
rename them - with a preview before every bulk action, Undo and a history of
every action. It includes a viewer with zoom, side-by-side comparison,
slideshow and video playback, light and dark themes, and options to reset
settings or clear its history and cache to start from scratch.

%prep
%autosetup -n %{name}-%{version} -p1
# use the system Inter font (rsms-inter-fonts) instead of the bundled copy
rm -rf clone_ranger/theme/fonts/inter
sed -i -e 's|^license = .*|license = "GPL-3.0-or-later"|' \
       -e 's|, "clone_ranger/theme/fonts/\*/OFL.txt"||' pyproject.toml

%generate_buildrequires
%pyproject_buildrequires

%build
%pyproject_wheel

%install
%pyproject_install
%pyproject_save_files -l clone_ranger

desktop-file-install --dir=%{buildroot}%{_datadir}/applications packaging/%{app_id}.desktop
install -Dpm 0644 packaging/%{app_id}.metainfo.xml %{buildroot}%{_metainfodir}/%{app_id}.metainfo.xml
for size in 16 22 24 32 48 64 128 256 512; do
    install -Dpm 0644 packaging/icons/hicolor/${size}x${size}/apps/%{app_id}.png \
        %{buildroot}%{_datadir}/icons/hicolor/${size}x${size}/apps/%{app_id}.png
done
install -Dpm 0644 packaging/icons/hicolor/scalable/apps/%{app_id}.svg \
    %{buildroot}%{_datadir}/icons/hicolor/scalable/apps/%{app_id}.svg
install -Dpm 0644 docs/clone-ranger.1 %{buildroot}%{_mandir}/man1/clone-ranger.1

%check
desktop-file-validate %{buildroot}%{_datadir}/applications/%{app_id}.desktop
appstreamcli validate --no-net --explain %{buildroot}%{_metainfodir}/%{app_id}.metainfo.xml
# every module must import (needs no display); __main__ would start the app
%pyproject_check_import -e 'clone_ranger.__main__'
%pytest tests/core

%files -f %{pyproject_files}
%doc README.md CHANGELOG.md PRIVACY.txt
%{_bindir}/clone-ranger
%{_mandir}/man1/clone-ranger.1*
%{_datadir}/applications/%{app_id}.desktop
%{_metainfodir}/%{app_id}.metainfo.xml
%{_datadir}/icons/hicolor/*/apps/%{app_id}.png
%{_datadir}/icons/hicolor/scalable/apps/%{app_id}.svg

%changelog
%autochangelog
