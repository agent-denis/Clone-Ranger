#!/usr/bin/env bash
# Install Clone Ranger for the current user (no root, no sudo).
#
#   ./install.sh              install, or upgrade an existing install (settings and index are kept)
#   ./install.sh --help
#
# Puts everything under your home folder (XDG base directories):
#   ~/.local/share/clone-ranger/venv  its own Python environment (PySide6, Pillow, blake3)
#   ~/.local/share/clone-ranger/app   the program
#   ~/.local/bin/clone-ranger         the command
#   ~/.local/share/applications/io.github.agent_denis.CloneRanger.desktop, icons, AppStream metadata
#                                     (app menu entry)
# Undo with ./uninstall.sh.
set -euo pipefail

usage() {
    cat <<'EOF'
Usage: ./install.sh [--python PATH] [--skip-deps] [--no-heif]

  --python PATH   Python to build the environment from (default: python3; needs 3.11 or newer)
  --skip-deps     don't download packages (for testing the installer itself; the app won't start)
  --no-heif       don't try to add HEIC/HEIF support (pillow-heif)
EOF
}

PYTHON=python3
SKIP_DEPS=0
HEIF=1
while [ $# -gt 0 ]; do
    case "$1" in
        --python) PYTHON="${2:?--python needs a path}"; shift 2 ;;
        --skip-deps) SKIP_DEPS=1; shift ;;
        --no-heif) HEIF=0; shift ;;
        -h|--help) usage; exit 0 ;;
        *) echo "Unknown option: $1" >&2; usage >&2; exit 2 ;;
    esac
done

say()  { printf '  %s\n' "$*"; }
step() { printf '\n>> %s\n' "$*"; }
die()  { printf '\nERROR: %s\n' "$*" >&2; exit 1; }

[ "$(id -u)" -ne 0 ] || die "Don't run the installer as root. Clone Ranger installs for your own user only."

SRC="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
[ -f "$SRC/clone_ranger/__init__.py" ] || die "Run install.sh from the Clone Ranger source folder."
VERSION="$(sed -n 's/^__version__ = "\(.*\)"/\1/p' "$SRC/clone_ranger/__init__.py")"
APP_ID="$(sed -n 's/^APP_ID = "\(.*\)"/\1/p' "$SRC/clone_ranger/__init__.py")"
[ -n "$APP_ID" ] || die "APP_ID missing in clone_ranger/__init__.py"

DATA="${XDG_DATA_HOME:-$HOME/.local/share}"
case "$DATA" in /*) ;; *) DATA="$HOME/.local/share" ;; esac
BIN="$HOME/.local/bin"
APPDIR="$DATA/clone-ranger"
VENV="$APPDIR/venv"
MARKER="$APPDIR/.clone-ranger-install"
MANIFEST="$APPDIR/installed-files.txt"

echo "Clone Ranger $VERSION — installer"
echo "Installing for user $(id -un) into $APPDIR"

# ---------------------------------------------------------------- Python
step "Checking Python"
command -v "$PYTHON" >/dev/null 2>&1 || die "$PYTHON not found. Install it with: sudo dnf install python3"
PYVER="$("$PYTHON" -c 'import sys; print("%d.%d" % sys.version_info[:2])')"
"$PYTHON" -c 'import sys; sys.exit(0 if sys.version_info >= (3, 11) else 1)' \
    || die "Python $PYVER is too old; Clone Ranger needs 3.11 or newer."
"$PYTHON" -c 'import venv, ensurepip' 2>/dev/null \
    || die "Python's venv module is missing. Install it with: sudo dnf install python3"
say "Python $PYVER ($(command -v "$PYTHON"))"

mkdir -p "$APPDIR" "$BIN"
touch "$MARKER"

# ---------------------------------------------------------------- environment
step "Preparing the app's own Python environment"
if [ -x "$VENV/bin/python" ] && [ "$(cat "$APPDIR/python-version" 2>/dev/null)" = "$PYVER" ]; then
    say "reusing $VENV"
else
    [ -d "$VENV" ] && { say "Python version changed: rebuilding the environment"; rm -rf "$VENV"; }
    "$PYTHON" -m venv "$VENV"
    echo "$PYVER" > "$APPDIR/python-version"
    say "created $VENV"
fi

if [ "$SKIP_DEPS" -eq 1 ]; then
    say "skipping downloads (--skip-deps)"
else
    step "Installing packages (PySide6 with QtMultimedia, Pillow, blake3) – about 450 MB the first time"
    "$VENV/bin/python" -m pip install --quiet --upgrade pip
    "$VENV/bin/python" -m pip install --quiet --upgrade -r "$SRC/requirements.txt" \
        || die "Package installation failed (no internet connection?). Nothing was changed outside $APPDIR."
    if [ "$HEIF" -eq 1 ]; then
        if "$VENV/bin/python" -m pip install --quiet --only-binary=:all: pillow-heif >/dev/null 2>&1; then
            say "HEIC/HEIF support: installed"
        else
            say "HEIC/HEIF support: no pillow-heif build for Python $PYVER yet – HEIC files are still found,"
            say "  just without previews. Re-run ./install.sh later to pick it up."
        fi
    fi
fi

# ---------------------------------------------------------------- program
step "Installing the program"
NEW="$APPDIR/app.new"
rm -rf "$NEW"
mkdir -p "$NEW"
cp -R "$SRC/clone_ranger" "$NEW/clone_ranger"
find "$NEW" -name '__pycache__' -type d -prune -exec rm -rf {} +
cp "$SRC/LICENSE" "$SRC/README.md" "$NEW/" 2>/dev/null || true
rm -rf "$APPDIR/app"
mv "$NEW" "$APPDIR/app"
SITE="$("$VENV/bin/python" -c 'import sysconfig; print(sysconfig.get_paths()["purelib"])')"
echo "$APPDIR/app" > "$SITE/clone-ranger-app.pth"     # makes "python -m clone_ranger" find the program
say "$APPDIR/app"

# ---------------------------------------------------------------- command + desktop integration
step "Adding the command and the app menu entry"
PREVIOUS="$APPDIR/installed-files.previous"
if [ -f "$MANIFEST" ]; then mv "$MANIFEST" "$PREVIOUS"; else : > "$PREVIOUS"; fi
: > "$MANIFEST"
put() {  # put SOURCE DEST: copy a file and remember it for uninstall.sh
    mkdir -p "$(dirname "$2")"
    cp "$1" "$2"
    echo "$2" >> "$MANIFEST"
}

LAUNCHER="$BIN/clone-ranger"
cat > "$LAUNCHER" <<EOF
#!/bin/sh
# Clone Ranger launcher (written by install.sh; remove with uninstall.sh)
exec "$VENV/bin/python" -m clone_ranger "\$@"
EOF
chmod 755 "$LAUNCHER"
echo "$LAUNCHER" >> "$MANIFEST"
say "command: $LAUNCHER"

DESKTOP="$DATA/applications/$APP_ID.desktop"
mkdir -p "$(dirname "$DESKTOP")"
sed -e "s|^Exec=clone-ranger|Exec=$LAUNCHER|" -e "s|^TryExec=clone-ranger|TryExec=$LAUNCHER|" \
    "$SRC/packaging/$APP_ID.desktop" > "$DESKTOP"
echo "$DESKTOP" >> "$MANIFEST"
say "menu entry: $DESKTOP"

for f in "$SRC"/packaging/icons/hicolor/*/apps/"$APP_ID".*; do
    rel="${f#"$SRC/packaging/icons/"}"
    put "$f" "$DATA/icons/$rel"
done
say "icons: $DATA/icons/hicolor/*/apps/$APP_ID.*"
put "$SRC/packaging/$APP_ID.metainfo.xml" "$DATA/metainfo/$APP_ID.metainfo.xml"

# ---- remove files the previous install wrote that this version no longer installs
while IFS= read -r f; do
    [ -n "$f" ] || continue
    grep -qxF -- "$f" "$MANIFEST" && continue
    case "$f" in
        "$DATA"/*) [ -f "$f" ] && rm -f -- "$f" && say "removed old $f" ;;
    esac
done < "$PREVIOUS"
rm -f "$PREVIOUS"

# Icons: no icon cache in the user's folder. Without an index.theme next to it, gtk-update-icon-cache writes a
# cache that lists no icons at all, and GNOME then shows the app without its icon. A stale one is removed;
# touching the folder makes the desktop rescan it.
if [ ! -f "$DATA/icons/hicolor/index.theme" ] && [ -f "$DATA/icons/hicolor/icon-theme.cache" ]; then
    rm -f "$DATA/icons/hicolor/icon-theme.cache" && say "removed a stale icon cache that hid the app icon"
fi
touch "$DATA/icons/hicolor" 2>/dev/null || true
command -v update-desktop-database >/dev/null 2>&1 && \
    update-desktop-database -q "$DATA/applications" 2>/dev/null || true

# ---------------------------------------------------------------- self-check
step "Checking the installation"
"$LAUNCHER" --version >/dev/null || die "The installed command doesn't start."
say "$("$LAUNCHER" --version)"
if [ "$SKIP_DEPS" -eq 0 ]; then
    "$VENV/bin/python" -c 'import PySide6.QtWidgets, PySide6.QtMultimedia, PIL, blake3' \
        || die "The environment is incomplete; re-run ./install.sh."
    say "PySide6 (with QtMultimedia), Pillow and blake3: OK"
fi
command -v ffprobe >/dev/null 2>&1 && say "ffmpeg: OK" || \
    say "NOTE: ffmpeg not found – video thumbnails and durations need it: sudo dnf install ffmpeg-free"
case ":$PATH:" in
    *":$BIN:"*) ;;
    *) say "NOTE: $BIN is not in your PATH – start Clone Ranger from the app menu, or run $LAUNCHER" ;;
esac

echo
echo "Done. Start Clone Ranger from the app menu (Graphics) or with: clone-ranger"
echo "Your settings and scan index (if any) were kept. To remove the program: ./uninstall.sh"
