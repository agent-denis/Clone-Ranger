#!/usr/bin/env python3
"""Build a LARGE synthetic media library with known duplicates, for the performance pass.

    .venv/bin/python tools/make_perf_library.py build/perf/library [--files 200000]

Files are small (valid magic bytes for their extension + random bytes), so 200 000 files take
about 1 GB. Contents:
  - unique files, spread over ~2 000 folders (Pictures/<year>/<month>/<event>, Phone/DCIM/..., ...)
  - duplicate sets of 2-4 copies in other folders, some named "(1)" / "copy"
  - hard links (never counted as wasted space)
  - "same size, different content" files that only the partial hash can tell apart
  - a few hundred multi-megabyte files, so full hashing has real work to do
Writes manifest.json with the expected totals. Refuses to write into a folder it didn't create.
"""
import argparse
import json
import os
import random
import shutil
import time
from pathlib import Path

MARKER = ".clone-ranger-perf-library"
MAGIC = {
    ".jpg": b"\xff\xd8\xff\xe0\x00\x10JFIF\x00",
    ".png": b"\x89PNG\r\n\x1a\n\x00\x00\x00\rIHDR",
    ".gif": b"GIF89a",
    ".webp": b"RIFF\x00\x00\x00\x00WEBPVP8 ",
    ".mp4": b"\x00\x00\x00\x18ftypmp42\x00\x00\x00\x00mp42isom",
    ".mov": b"\x00\x00\x00\x14ftypqt  \x00\x00\x00\x00qt  ",
}
EXT_WEIGHTS = [(".jpg", 70), (".png", 12), (".webp", 6), (".gif", 2), (".mp4", 7), (".mov", 3)]


def folders(rnd, n):
    out = []
    for i in range(n):
        kind = rnd.random()
        if kind < 0.55:
            out.append(f"Pictures/{rnd.randint(2008, 2026)}/{rnd.randint(1, 12):02d}/event_{i:04d}")
        elif kind < 0.75:
            out.append(f"Phone/DCIM/Camera_{i:04d}")
        elif kind < 0.85:
            out.append(f"Videos/{rnd.randint(2010, 2026)}/clip_set_{i:04d}")
        elif kind < 0.93:
            out.append(f"Backup/old_laptop/{i:04d}")
        else:
            out.append(f"Downloads/batch_{i:04d}")
    return out


def build(root: Path, total: int, seed: int = 2026) -> dict:
    if root.exists() and any(root.iterdir()) and not (root / MARKER).exists():
        raise SystemExit(f"Refusing to write into non-empty folder {root} (no {MARKER} marker).")
    if (root / MARKER).exists():
        shutil.rmtree(root)
    root.mkdir(parents=True)
    (root / MARKER).write_text("created by tools/make_perf_library.py - safe to delete\n")
    rnd = random.Random(seed)
    dirs = folders(rnd, max(10, total // 100))
    for d in dirs:
        (root / d).mkdir(parents=True, exist_ok=True)
    exts = [e for e, w in EXT_WEIGHTS for _ in range(w)]
    counter = [0]

    def new_name(ext):
        counter[0] += 1
        return f"IMG_{counter[0]:07d}{ext}"

    written = 0
    groups = 0
    duplicate_files = 0
    hard_links = 0
    big_files = 0
    reclaim = 0
    t0 = time.monotonic()

    def write(path: Path, data: bytes):
        nonlocal written
        with open(path, "wb") as f:
            f.write(data)
        written += 1

    # 1. a few hundred big files (1.5-5 MB), half of them duplicated once
    n_big = max(2, total // 600)
    for _ in range(n_big):
        ext = rnd.choice((".jpg", ".mp4", ".mov"))
        data = MAGIC[ext] + rnd.randbytes(rnd.randint(1_500_000, 5_000_000))
        p = root / rnd.choice(dirs) / new_name(ext)
        write(p, data)
        big_files += 1
        if rnd.random() < 0.5:
            write(root / rnd.choice(dirs) / f"{p.stem} (1){ext}", data)
            groups += 1
            duplicate_files += 1
            reclaim += len(data)

    # 2. "same size, different content": 2 000 files sharing 50 sizes
    n_trick = min(2000, total // 100)
    sizes = [rnd.randint(20_000, 60_000) for _ in range(50)]
    for i in range(n_trick):
        ext = ".jpg"
        size = sizes[i % len(sizes)]
        write(root / rnd.choice(dirs) / new_name(ext), MAGIC[ext] + rnd.randbytes(size - len(MAGIC[ext])))

    # 3. duplicate sets: 2-4 copies each, until ~30 % of the library is duplicate copies
    target_dupes = int(total * 0.30)
    while duplicate_files < target_dupes and written < total - 4:
        ext = rnd.choice(exts)
        data = MAGIC[ext] + rnd.randbytes(rnd.randint(1_000, 9_000))
        first = root / rnd.choice(dirs) / new_name(ext)
        write(first, data)
        copies = rnd.choice((1, 1, 1, 2, 2, 3))
        for k in range(copies):
            d = root / rnd.choice(dirs)
            name = rnd.choice((first.name, f"{first.stem} (1){ext}", f"{first.stem} - Copy{ext}",
                               f"{first.stem}_{k + 2}{ext}"))
            target = d / name
            if target.exists():
                target = d / new_name(ext)
            write(target, data)
        groups += 1
        duplicate_files += copies
        reclaim += len(data) * copies
        if rnd.random() < 0.02:                       # sometimes also a hard link (no space wasted)
            link = root / rnd.choice(dirs) / f"{first.stem}_link{ext}"
            if not link.exists():
                os.link(first, link)
                written += 1
                hard_links += 1

    # 4. unique files to fill up to `total`
    while written < total:
        ext = rnd.choice(exts)
        write(root / rnd.choice(dirs) / new_name(ext), MAGIC[ext] + rnd.randbytes(rnd.randint(1_000, 9_000)))

    manifest = {"files": written, "folders": len(dirs), "content_groups": groups, "duplicate_files": duplicate_files,
                "hard_links": hard_links, "big_files": big_files, "reclaim_bytes": reclaim, "seed": seed,
                "seconds": round(time.monotonic() - t0, 1)}
    (root / "manifest.json").write_text(json.dumps(manifest, indent=2))
    return manifest


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("target", nargs="?", default="build/perf/library")
    ap.add_argument("--files", type=int, default=200_000)
    args = ap.parse_args()
    m = build(Path(args.target), args.files)
    print(json.dumps(m, indent=2))


if __name__ == "__main__":
    main()
