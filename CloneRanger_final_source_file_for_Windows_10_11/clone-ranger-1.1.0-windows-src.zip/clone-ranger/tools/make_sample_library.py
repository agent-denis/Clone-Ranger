#!/usr/bin/env python3
"""Build a sample media library with KNOWN duplicates, for demos and tests.

Usage:  .venv/bin/python tools/make_sample_library.py [TARGET_DIR]   (default: ./sample_library)

Refuses to write into a non-empty folder that it didn't create itself (it checks for
its own marker file), so it can never mix into your real files.

Creates:
  - photos (JPEG, PNG, WebP) with exact copies in other folders, under other names
  - a video with a copy (if ffmpeg is installed)
  - a hard link (same file twice on disk -> not a real duplicate)
  - same name, different content in two folders
  - a .jpg that is really text (must be rejected by the magic-byte check)
  - a symlink (must not be followed) and an unreadable file (must be listed as skipped)
  - files inside .git/ and .snapshots/ (must be excluded)
and writes manifest.json describing what a scan should find.
"""
import json
import os
import random
import shutil
import subprocess
import sys
from pathlib import Path

from PIL import Image, ImageDraw

MARKER = ".clone-ranger-sample-library"


def photo(seed: int, w=640, h=480) -> Image.Image:
    rnd = random.Random(seed)
    img = Image.new("RGB", (w, h), tuple(rnd.randrange(256) for _ in range(3)))
    d = ImageDraw.Draw(img)
    for _ in range(40):
        x, y = rnd.randrange(w), rnd.randrange(h)
        r = rnd.randrange(10, 120)
        d.ellipse((x - r, y - r, x + r, y + r), fill=tuple(rnd.randrange(256) for _ in range(3)))
    for _ in range(4000):  # noise so JPEGs are realistically large
        d.point((rnd.randrange(w), rnd.randrange(h)), fill=tuple(rnd.randrange(256) for _ in range(3)))
    return img


def build(root: Path) -> dict:
    if root.exists() and any(root.iterdir()) and not (root / MARKER).exists():
        raise SystemExit(f"Refusing to write into non-empty folder {root} (no {MARKER} marker).")
    if (root / MARKER).exists():
        shutil.rmtree(root)  # our own previous sample library
    root.mkdir(parents=True)
    (root / MARKER).write_text("created by tools/make_sample_library.py - safe to delete\n")

    def p(rel):
        f = root / rel
        f.parent.mkdir(parents=True, exist_ok=True)
        return f

    expected_groups = []

    # 1. JPEG with three copies (one renamed "(1)", one in a backup folder)
    photo(1).save(p("Pictures/2023/Summer/IMG_2041.jpg"), quality=92)
    shutil.copy2(p("Pictures/2023/Summer/IMG_2041.jpg"), p("Downloads/IMG_2041 (1).jpg"))
    shutil.copy2(p("Pictures/2023/Summer/IMG_2041.jpg"), p("Backup/Photos/IMG_2041.jpg"))
    expected_groups.append(["Pictures/2023/Summer/IMG_2041.jpg", "Downloads/IMG_2041 (1).jpg",
                            "Backup/Photos/IMG_2041.jpg"])

    # 2. PNG with a "Copy" duplicate
    photo(2, 800, 600).save(p("Pictures/Family/DSC_0193.png"))
    shutil.copy2(p("Pictures/Family/DSC_0193.png"), p("Desktop/old phone/DSC_0193 - Copy.png"))
    expected_groups.append(["Pictures/Family/DSC_0193.png", "Desktop/old phone/DSC_0193 - Copy.png"])

    # 3. WebP copy + a hard link to the original (hard link = no space wasted)
    photo(3).save(p("Pictures/Pets/cat.webp"), quality=90)
    shutil.copy2(p("Pictures/Pets/cat.webp"), p("Downloads/cat.webp"))
    os.link(p("Pictures/Pets/cat.webp"), p("Pictures/Pets/best/cat_hardlink.webp"))
    expected_groups.append(["Pictures/Pets/cat.webp", "Downloads/cat.webp", "Pictures/Pets/best/cat_hardlink.webp"])
    hard_links = ["Pictures/Pets/best/cat_hardlink.webp"]

    # 4. same size, same first/last bytes, different middle -> NOT duplicates (partial hash catches it)
    big = bytearray(photo(4, 1600, 1200).tobytes())
    head = b"\x89PNG\r\n\x1a\n"
    blob_a = head + bytes(big[:400_000])
    blob_b = bytearray(blob_a)
    blob_b[len(blob_b) // 2] ^= 0xFF
    p("Pictures/Trick/same_size_a.png").write_bytes(blob_a)
    p("Pictures/Trick/same_size_b.png").write_bytes(bytes(blob_b))

    # 5. same name, different content
    photo(5).save(p("Pictures/2022/holiday.jpg"), quality=85)
    photo(6).save(p("Pictures/2024/holiday.jpg"), quality=85)
    same_name_different = ["Pictures/2022/holiday.jpg", "Pictures/2024/holiday.jpg"]

    # 6. traps that must NOT be indexed
    p("Pictures/not_really.jpg").write_text("this is a text file pretending to be a JPEG\n")
    try:
        (root / "Pictures/link_to_family").symlink_to(root / "Pictures/Family", target_is_directory=True)
    except OSError:
        pass  # Windows without Developer Mode / admin may not create symlinks (WinError 1314); skip this trap
    p("project/.git/objects/img.png").write_bytes(p("Pictures/Family/DSC_0193.png").read_bytes())
    p(".snapshots/1/snapshot/IMG_2041.jpg").write_bytes(p("Pictures/2023/Summer/IMG_2041.jpg").read_bytes())
    p("Documents/notes.txt").write_text("not media\n")
    locked = p("Private/locked.jpg")
    photo(7).save(locked)
    locked.chmod(0)
    locked_dir = p("Private/locked_dir/inside.jpg")
    photo(8).save(locked_dir)
    locked_dir.parent.chmod(0)

    # 7. a video and its copy (only if ffmpeg exists)
    videos = False
    if shutil.which("ffmpeg"):
        out = p("Videos/VID_20240512_143022.mp4")
        r = subprocess.run(["ffmpeg", "-loglevel", "error", "-f", "lavfi", "-i", "testsrc=duration=2:size=320x240:rate=15",
                            "-c:v", "mpeg4", "-q:v", "5", "-y", str(out)], capture_output=True)
        if r.returncode == 0:
            shutil.copy2(out, p("Downloads/VID_20240512_143022 (1).mp4"))
            expected_groups.append(["Videos/VID_20240512_143022.mp4", "Downloads/VID_20240512_143022 (1).mp4"])
            videos = True

    manifest = {
        "root": str(root),
        "content_groups": [sorted(g) for g in expected_groups],
        "hard_links": hard_links,
        "same_name_different_content": same_name_different,
        "must_not_index": ["Pictures/not_really.jpg", "Pictures/link_to_family/DSC_0193.png",
                           "project/.git/objects/img.png", ".snapshots/1/snapshot/IMG_2041.jpg",
                           "Documents/notes.txt"],
        "same_size_not_duplicates": ["Pictures/Trick/same_size_a.png", "Pictures/Trick/same_size_b.png"],
        "must_skip": ["Private/locked.jpg", "Private/locked_dir"],
        "videos": videos,
    }
    (root / "manifest.json").write_text(json.dumps(manifest, indent=2))
    return manifest


def make_readable(root: Path):
    """Undo the chmod 000 traps so the folder can be deleted normally."""
    for rel in ("Private/locked_dir", "Private/locked.jpg"):
        f = root / rel
        if f.exists() or f.is_symlink():
            f.chmod(0o755 if f.is_dir() or rel.endswith("dir") else 0o644)


def main():
    target = Path(sys.argv[1] if len(sys.argv) > 1 else "sample_library").resolve()
    if (target / MARKER).exists():
        make_readable(target)
    m = build(target)
    print(f"Sample library: {target}")
    print(f"  {len(m['content_groups'])} duplicate groups expected, videos={'yes' if m['videos'] else 'no (no ffmpeg)'}")
    print(f"  try:  .venv/bin/python -m clone_ranger.core.cli --db /tmp/clone-ranger-demo.sqlite scan {target} --list")


if __name__ == "__main__":
    main()
