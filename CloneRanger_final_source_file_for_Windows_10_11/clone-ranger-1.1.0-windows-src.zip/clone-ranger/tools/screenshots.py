#!/usr/bin/env python3
"""Render the screenshots in docs/screenshots/ (README and the AppStream metainfo use them).

Everything runs offscreen on demo data, with Clone Ranger's folders redirected to a temporary directory:
no real file is read or changed.

    .venv/bin/python tools/screenshots.py
"""
import os
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
OUT = ROOT / "docs" / "screenshots"


def main():
    os.environ["QT_QPA_PLATFORM"] = "offscreen"
    tmp = Path(tempfile.mkdtemp(prefix="clone-ranger-shots-"))
    for var in ("XDG_CONFIG_HOME", "XDG_CACHE_HOME", "XDG_STATE_HOME", "XDG_DATA_HOME"):
        os.environ[var] = str(tmp / var.lower())
    os.environ["CLONE_RANGER_SANDBOX"] = str(tmp)
    sys.path.insert(0, str(ROOT))
    from clone_ranger.app import make_app
    app = make_app([sys.argv[0]], "light")
    from clone_ranger.core.journal import Item, Journal
    from clone_ranger.core.settings import Settings
    from clone_ranger.theme.strings import tr
    from clone_ranger.theme.style import theme
    from clone_ranger.ui.help_dialogs import AboutDialog
    from clone_ranger.ui.main_window import MainWindow
    from clone_ranger.ui.order_dialog import OrderDialog
    from clone_ranger.ui.reset_dialog import ResetDialog
    from clone_ranger.ui.scan_screen import demo_feed
    from clone_ranger.ui.viewer.window import ViewerWindow

    OUT.mkdir(parents=True, exist_ok=True)
    for old in OUT.glob("*.png"):
        old.unlink()

    def settle(n=8):
        for _ in range(n):
            app.processEvents()

    def save(w, name):
        settle()
        w.grab().save(str(OUT / f"{name}.png"))

    # a little history, so the History page has something to show
    j = Journal()
    for op, items in (("trash", 6), ("move", 3), ("rename", 2)):
        o = j.begin(op, dest="/home/you/Pictures/Sorted" if op == "move" else "")
        for i in range(items):
            j.item(o, Item(src=f"/home/you/Downloads/IMG_{2040 + i} (1).jpg", status="ok", size=4_200_000))
        j.end(o, "done")

    win = MainWindow(demo=True, settings=Settings())
    win.showNormal()                    # the offscreen screen is small, so the window would open maximized
    win.resize(1440, 900)
    win.show()
    for key in ("light", "dark"):
        theme().apply(key)
        win.stack.setCurrentWidget(win.results)
        for view in ("cards", "ledger", "grid"):
            win.results.set_view(view)
            save(win, {"cards": "main", "ledger": "list", "grid": "grid"}[view] + f"-{key}")
        win.results.set_view("cards")

        win.start_scan()                          # demo: fills the scan screen with plausible progress
        win.scan_screen.radar.stop()
        save(win, f"scan-{key}")
        win.show_settings()
        save(win, f"settings-{key}")
        win.show_history()
        save(win, f"history-{key}")
        win.stack.setCurrentWidget(win.results)

        for mode in ("clear", "reset"):
            d = ResetDialog(mode, 734_003_200, 11, 3, win)
            d.show()
            save(d, f"reset-{mode}-{key}")
            d.close()

        files = [f"~/Downloads/IMG_{2040 + i} (1).jpg" for i in range(8)]
        d = OrderDialog(12, "move_to_trash", files, "33.6 MB", tr("trash_dest"), note="trash_note_undo")
        d.show()
        save(d, f"confirm-trash-{key}")
        d.close()
        a = AboutDialog(win)
        a.show()
        save(a, f"about-{key}")
        a.close()

        g = next(x for x in win.results.visible if len(x.copies) >= 2)
        for mode in ("compare", "grid"):
            v = ViewerWindow(win.results.visible, g, 0, mode, win.thumbs, win.full_images, demo=True, parent=win)
            v.resize(1366, 800)
            v.show()
            save(v, f"viewer-{mode}-{key}")
            v.close()
    win.close()
    print("saved:", *sorted(p.name for p in OUT.glob("*.png")))


if __name__ == "__main__":
    main()
