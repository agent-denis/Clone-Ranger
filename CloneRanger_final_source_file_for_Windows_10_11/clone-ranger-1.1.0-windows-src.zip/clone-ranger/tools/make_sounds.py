#!/usr/bin/env python3
"""Synthesise Clone Ranger's three short sound effects (original, generated in code - no samples).

    stamp.wav  - a rubber stamp hitting paper (order carried out)
    bell.wav   - a small desk bell (surveillance finished)
    type.wav   - one typewriter key (order signed)

Writes 16-bit mono WAV files to clone_ranger/theme/sounds/. Deterministic (fixed random seed).
"""
import math
import random
import struct
import wave
from pathlib import Path

RATE = 44100
OUT = Path(__file__).resolve().parent.parent / "clone_ranger" / "theme" / "sounds"


def write(name, samples):
    peak = max(1e-9, max(abs(s) for s in samples))
    data = b"".join(struct.pack("<h", int(32767 * 0.8 * s / peak)) for s in samples)
    with wave.open(str(OUT / name), "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(RATE)
        w.writeframes(data)


def stamp():
    rnd = random.Random(7)
    n = int(RATE * 0.22)
    out, lp = [], 0.0
    for i in range(n):
        t = i / RATE
        thud = math.sin(2 * math.pi * (95 - 160 * t) * t) * math.exp(-t * 28)       # body of the hit
        lp += 0.18 * (rnd.uniform(-1, 1) - lp)                                     # muffled paper slap
        slap = lp * math.exp(-t * 60) * 1.6
        out.append(thud + slap)
    return out


def bell():
    n = int(RATE * 1.1)
    partials = ((1420, 1.0, 3.2), (3810, 0.45, 5.5), (5240, 0.25, 8.0), (7600, 0.1, 11.0))
    out = []
    for i in range(n):
        t = i / RATE
        attack = min(1.0, t / 0.004)
        out.append(attack * sum(a * math.sin(2 * math.pi * f * t) * math.exp(-t * d) for f, a, d in partials))
    return out


def typekey():
    rnd = random.Random(11)
    n = int(RATE * 0.07)
    out, hp_prev, x_prev = [], 0.0, 0.0
    for i in range(n):
        t = i / RATE
        x = rnd.uniform(-1, 1)
        hp_prev = 0.85 * (hp_prev + x - x_prev)                                    # bright click
        x_prev = x
        click = hp_prev * math.exp(-t * 180)
        clack = math.sin(2 * math.pi * 1900 * t) * math.exp(-t * 90) * 0.5         # type bar on platen
        out.append(click + clack)
    return out


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    write("stamp.wav", stamp())
    write("bell.wav", bell())
    write("type.wav", typekey())
    print("wrote", ", ".join(sorted(p.name for p in OUT.glob("*.wav"))), "to", OUT)


if __name__ == "__main__":
    main()
