#!/usr/bin/env python3
"""Check bundled fonts: licence is SIL OFL, and every glyph Clone Ranger needs is present.

Usage:  .venv/bin/python tools/check_fonts.py
Needs fontTools (dev dependency only, not needed to run the app).
"""
import sys
from pathlib import Path

from fontTools.ttLib import TTFont

FONT_DIR = Path(__file__).resolve().parent.parent / "clone_ranger" / "theme" / "fonts"

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from clone_ranger.theme.strings import STRINGS  # noqa: E402

# every character any UI text uses, plus digits and a few symbols drawn in code
REQUIRED = "".join(sorted(set("".join(STRINGS.values())
                              + "0123456789#%×▲✓…·–—“”‘’ " + "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
                              + "abcdefghijklmnopqrstuvwxyz") - set("{}\n")))


def main():
    ok = True
    for ttf in sorted(FONT_DIR.glob("*/*.ttf")):
        lic = ttf.parent / "OFL.txt"
        lic_ok = lic.exists() and "SIL OPEN FONT LICENSE" in lic.read_text(errors="replace").upper()
        font = TTFont(ttf, lazy=True)
        cmap = font.getBestCmap()
        missing = [c for c in REQUIRED if ord(c) not in cmap]
        name = font["name"].getDebugName(4)
        status = "OK " if lic_ok and not missing else "BAD"
        ok &= status == "OK "
        print(f"{status} {name:28} licence={'OFL' if lic_ok else 'MISSING'}  "
              f"glyphs={len(cmap):5}  missing={''.join(missing) or '-'}")
    sys.exit(0 if ok else 1)


if __name__ == "__main__":
    main()
