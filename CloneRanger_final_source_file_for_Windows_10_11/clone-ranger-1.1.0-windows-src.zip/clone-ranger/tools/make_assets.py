#!/usr/bin/env python3
"""Generate Clone Ranger's original SVG artwork.

Outputs (committed to git):
  clone_ranger/theme/svg/logo.svg          app logo: two overlapping rounded tiles ("clones"): a light-blue one behind,
                                           the front one in the red -> orange -> yellow brand gradient with a white
                                           ranger star
  clone_ranger/theme/svg/logo-small.svg    the same, simplified for 16-32 px (no back tile outline, bolder star)
  clone_ranger/theme/svg/icons/*.svg       line icons, stroke colour "#000000" is swapped per theme at runtime

All artwork is original and made of generic shapes.

Usage:  .venv/bin/python tools/make_assets.py
"""
import math
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
THEME = ROOT / "clone_ranger" / "theme"
OUT = THEME / "svg"
RED, ORANGE, YELLOW = "#EF4444", "#F97316", "#FACC15"
SKY, SKY_LIGHT = "#38BDF8", "#BAE6FD"


def star(cx, cy, r_out, r_in=None, rot=-90, points=5):
    r_in = r_in if r_in is not None else r_out * .5
    pts = []
    for i in range(points * 2):
        r = r_out if i % 2 == 0 else r_in
        a = math.radians(rot + i * 180 / points)
        pts.append(f"{cx + r * math.cos(a):.2f},{cy + r * math.sin(a):.2f}")
    return " ".join(pts)


GRADIENT_DEF = (f'<linearGradient id="g" x1="0" y1="0" x2="1" y2="1">'
                f'<stop offset="0" stop-color="{RED}"/><stop offset=".5" stop-color="{ORANGE}"/>'
                f'<stop offset="1" stop-color="{YELLOW}"/></linearGradient>')


def logo():
    return f"""<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" width="512" height="512">
  <title>Clone Ranger logo</title>
  <defs>{GRADIENT_DEF}
    <linearGradient id="back" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="{SKY}"/><stop offset="1" stop-color="{SKY_LIGHT}"/></linearGradient>
    <filter id="s" x="-20%" y="-20%" width="140%" height="140%"><feDropShadow dx="0" dy="10" stdDeviation="14" flood-color="#0F172A" flood-opacity=".35"/></filter>
  </defs>
  <rect x="40" y="40" width="300" height="300" rx="78" fill="url(#back)"/>
  <rect x="148" y="148" width="324" height="324" rx="84" fill="url(#g)" filter="url(#s)"/>
  <polygon points="{star(310, 318, 112, 50)}" fill="#FFFFFF" stroke="#FFFFFF" stroke-width="14" stroke-linejoin="round"/>
  <circle cx="310" cy="318" r="22" fill="url(#g)"/>
</svg>
"""


def logo_small():
    return f"""<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64" width="64" height="64">
  <title>Clone Ranger logo (small sizes)</title>
  <defs>{GRADIENT_DEF}</defs>
  <rect x="2" y="2" width="38" height="38" rx="10" fill="{SKY}"/>
  <rect x="14" y="14" width="48" height="48" rx="12" fill="url(#g)"/>
  <polygon points="{star(38, 39.5, 17, 8)}" fill="#FFFFFF" stroke="#FFFFFF" stroke-width="2.5" stroke-linejoin="round"/>
</svg>
"""


ICONS = {
    "scan":      '<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="5"/><path d="M12 12 L18.4 5.6"/><circle cx="15.5" cy="14.5" r="1" fill="#000000"/>',
    "search":    '<circle cx="10.5" cy="10.5" r="6"/><path d="M15 15 L20.5 20.5"/>',
    "folder":    '<path d="M3 7 H9 L11 9 H21 V19 H3 Z"/>',
    "trash":     '<path d="M4 7 H20"/><path d="M9 7 V4.5 H15 V7"/><path d="M6 7 L7 20 H17 L18 7"/><path d="M10 11 V16.5 M14 11 V16.5"/>',
    "delete":    '<path d="M4 7 H20"/><path d="M9 7 V4.5 H15 V7"/><path d="M6 7 L7 20 H17 L18 7"/><path d="M9.5 11 L14.5 17 M14.5 11 L9.5 17"/>',
    "move":      '<path d="M3 7 H9 L11 9 H21 V19 H3 Z"/><path d="M8 14 H16 M13 11 L16 14 L13 17"/>',
    "rename":    '<path d="M4 20 L5 16 L16 5 L19 8 L8 19 Z"/><path d="M14 7 L17 10"/>',
    "undo":      '<path d="M9 14 L4 9 L9 4"/><path d="M4 9 H14 A6 6 0 0 1 14 21 H10"/>',
    "settings":  '<path d="M4 7 H20 M4 17 H20"/><circle cx="9" cy="7" r="2.2" fill="#FFFFFF"/><circle cx="15" cy="17" r="2.2" fill="#FFFFFF"/>',
    "log":       '<rect x="5" y="3" width="14" height="18" rx="1"/><path d="M8 8 H16 M8 12 H16 M8 16 H13"/>',
    "filter":    '<path d="M4 5 H20 L14 12 V18 L10 20 V12 Z"/>',
    "copy":      '<rect x="8" y="8" width="12" height="12" rx="1"/><path d="M16 8 V4 H4 V16 H8"/>',
    "external":  '<path d="M14 4 H20 V10 M20 4 L11 13"/><path d="M18 14 V20 H4 V6 H10"/>',
    "cards":     '<rect x="3" y="5" width="18" height="6" rx="1"/><rect x="3" y="13" width="18" height="6" rx="1"/>',
    "ledger":    '<path d="M8 6 H21 M8 12 H21 M8 18 H21"/><path d="M3.5 6 H5 M3.5 12 H5 M3.5 18 H5"/>',
    "grid":      '<rect x="4" y="4" width="7" height="7"/><rect x="13" y="4" width="7" height="7"/><rect x="4" y="13" width="7" height="7"/><rect x="13" y="13" width="7" height="7"/>',
    "lock":      '<rect x="5.5" y="11" width="13" height="9" rx="1"/><path d="M8.5 11 V8 A3.5 3.5 0 0 1 15.5 8 V11"/><path d="M12 14.5 V16.5"/>',
    "same_content": '<rect x="3" y="5" width="7" height="9" rx="1"/><rect x="14" y="5" width="7" height="9" rx="1"/><path d="M9 18 H15 M9 21 H15"/>',
    "same_name": '<path d="M3 12 L10 5 H19 V14 L12 21 Z"/><circle cx="15.5" cy="8.5" r="1.3"/>',
    "locations": '<path d="M12 21 C12 21 6 14.5 6 10 A6 6 0 0 1 18 10 C18 14.5 12 21 12 21 Z"/><circle cx="12" cy="10" r="2"/>',
    "compare":   '<rect x="3" y="5" width="8" height="14" rx="1"/><rect x="13" y="5" width="8" height="14" rx="1"/>',
    "eye":       '<path d="M2 12 C4 7.5 7.5 5 12 5 C16.5 5 20 7.5 22 12 C20 16.5 16.5 19 12 19 C7.5 19 4 16.5 2 12 Z"/><circle cx="12" cy="12" r="3"/>',
    "pause":     '<path d="M9 5 V19 M15 5 V19"/>',
    "cancel":    '<circle cx="12" cy="12" r="9"/><path d="M8.5 8.5 L15.5 15.5 M15.5 8.5 L8.5 15.5"/>',
    "theme":     '<circle cx="12" cy="12" r="8"/><path d="M12 4 A8 8 0 0 1 12 20 Z" fill="#000000"/>',
    "star":      f'<polygon points="{star(12, 12.6, 9)}"/>',
    "play":      '<path d="M8 5 L19 12 L8 19 Z"/>',
    "step_back": '<path d="M7 5 V19"/><path d="M18 5 L10 12 L18 19 Z"/>',
    "step_fwd":  '<path d="M17 5 V19"/><path d="M6 5 L14 12 L6 19 Z"/>',
    "zoom_in":   '<circle cx="10.5" cy="10.5" r="6"/><path d="M15 15 L20.5 20.5 M8 10.5 H13 M10.5 8 V13"/>',
    "zoom_out":  '<circle cx="10.5" cy="10.5" r="6"/><path d="M15 15 L20.5 20.5 M8 10.5 H13"/>',
    "fit":       '<path d="M4 9 V4 H9 M15 4 H20 V9 M20 15 V20 H15 M9 20 H4 V15"/>',
    "actual":    '<rect x="4" y="5" width="16" height="14" rx="1"/><path d="M8.5 10 L9.5 9 V15 M14 10 L15 9 V15"/>',
    "slideshow": '<rect x="3" y="5" width="18" height="12" rx="1"/><path d="M10 8.5 L14.5 11 L10 13.5 Z M8 21 L12 17 L16 21"/>',
    "volume":    '<path d="M4 9.5 H8 L13 5 V19 L8 14.5 H4 Z"/><path d="M16.5 9 A4 4 0 0 1 16.5 15 M19 6.5 A7.5 7.5 0 0 1 19 17.5"/>',
    "mute":      '<path d="M4 9.5 H8 L13 5 V19 L8 14.5 H4 Z"/><path d="M16.5 9.5 L21 14 M21 9.5 L16.5 14"/>',
    "link":      '<path d="M10 14 L14 10"/><path d="M8.5 11.5 L6.5 13.5 A3 3 0 0 0 10.5 17.5 L12.5 15.5 M11.5 8.5 L13.5 6.5 A3 3 0 0 1 17.5 10.5 L15.5 12.5"/>',
    "flicker":   '<rect x="3" y="6" width="9" height="12" rx="1"/><rect x="12" y="6" width="9" height="12" rx="1" fill="#000000"/>',
    # Clone Ranger additions
    "unselect":  '<rect x="4" y="4" width="16" height="16" rx="4"/><path d="M8.5 12 H15.5"/>',
    "select":    '<rect x="4" y="4" width="16" height="16" rx="4"/><path d="M8 12.5 L11 15.5 L16.5 9"/>',
    "clear":     '<path d="M14.5 3.5 L20.5 9.5"/><path d="M17.5 6.5 L11 13"/><path d="M11 13 C8 11 5 12.5 3.5 16 C5.5 17 6 18.5 6.5 20.5 C10 19 12.5 16 11 13 Z"/><path d="M6 15.5 L8 17.5"/>',
    "reset":     '<path d="M4 4 V9 H9"/><path d="M4.6 9 A8 8 0 1 1 4 13"/>',
    "sparkle":   '<path d="M12 3 L13.8 10.2 L21 12 L13.8 13.8 L12 21 L10.2 13.8 L3 12 L10.2 10.2 Z"/>',
    "shield":    '<path d="M12 3 L19.5 6 V11.5 C19.5 16 16.3 19.4 12 21 C7.7 19.4 4.5 16 4.5 11.5 V6 Z"/>',
    "history":   '<path d="M4 4 V9 H9"/><path d="M4.6 9 A8 8 0 1 1 4 13"/><path d="M12 8 V12 L15 14"/>',
    "chevron":   '<path d="M9 6 L15 12 L9 18"/>',
    "check":     '<path d="M5 12.5 L10 17.5 L19 7"/>',
}


def icon_svg(body):
    return ('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24" fill="none" '
            'stroke="#000000" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round">'
            f'{body}</svg>\n')


def main():
    (OUT / "icons").mkdir(parents=True, exist_ok=True)
    (OUT / "logo.svg").write_text(logo())
    (OUT / "logo-small.svg").write_text(logo_small())
    for name, body in ICONS.items():
        (OUT / "icons" / f"{name}.svg").write_text(icon_svg(body))
    print(f"wrote logo.svg, logo-small.svg and {len(ICONS)} icons to {OUT}")


if __name__ == "__main__":
    main()
