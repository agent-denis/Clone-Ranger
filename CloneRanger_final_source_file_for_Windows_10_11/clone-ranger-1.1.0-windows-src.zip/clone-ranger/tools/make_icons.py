#!/usr/bin/env python3
"""Render the app icon (the Clone Ranger logo) for the desktop: packaging/icons/hicolor/<size>/apps/<APP_ID>.png
plus scalable/apps/<APP_ID>.svg (APP_ID from clone_ranger/__init__.py). Sizes up to 48 px use the simplified small logo so they stay legible.

    .venv/bin/python tools/make_icons.py
"""
import os
import shutil
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
SVG = ROOT / "clone_ranger" / "theme" / "svg"
OUT = ROOT / "packaging" / "icons" / "hicolor"
SIZES = (16, 22, 24, 32, 48, 64, 128, 256, 512)
sys.path.insert(0, str(ROOT))
from clone_ranger import APP_ID  # noqa: E402


def main():
    os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
    from PySide6.QtCore import QRectF, Qt
    from PySide6.QtGui import QGuiApplication, QImage, QPainter
    from PySide6.QtSvg import QSvgRenderer
    app = QGuiApplication.instance() or QGuiApplication(sys.argv[:1])
    for size in SIZES:
        src = SVG / ("logo-small.svg" if size <= 48 else "logo.svg")
        img = QImage(size, size, QImage.Format.Format_ARGB32)
        img.fill(Qt.GlobalColor.transparent)
        p = QPainter(img)
        p.setRenderHints(QPainter.RenderHint.Antialiasing | QPainter.RenderHint.SmoothPixmapTransform)
        QSvgRenderer(str(src)).render(p, QRectF(0, 0, size, size))
        p.end()
        d = OUT / f"{size}x{size}" / "apps"
        d.mkdir(parents=True, exist_ok=True)
        img.save(str(d / f"{APP_ID}.png"), "PNG")
    (OUT / "scalable" / "apps").mkdir(parents=True, exist_ok=True)
    shutil.copyfile(SVG / "logo.svg", OUT / "scalable" / "apps" / f"{APP_ID}.svg")
    del app
    print(f"wrote {len(SIZES)} PNG sizes + scalable SVG to {OUT}")


if __name__ == "__main__":
    main()
