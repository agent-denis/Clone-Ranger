#!/usr/bin/env python3
"""Performance pass on a large library (see tools/make_perf_library.py).

    .venv/bin/python tools/perf_test.py build/perf/library [--skip-scan]

Each stage runs in its own process, so its peak memory (max RSS) is measured cleanly:
  scan-cold   first scan into a fresh index (listing, hashing, grouping)
  scan-warm   rescan: nothing changed, hashes come from the index
  load        start-up path: rebuild case files from the index, no file read
  ui          the real window (offscreen): time until results show, filters, search, sorting,
              view switches, Ctrl+A, same-name mode, memory
Everything (index, settings, thumbnails) lives under build/perf/, never in your real folders.
Checks the results against the library's manifest.json.
"""
import argparse
import json
import os
import subprocess
import sys
import textwrap
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
PY = sys.executable

COMMON = textwrap.dedent("""
    import json, os, resource, sys, time
    sys.path.insert(0, {root!r})
    if os.environ.get("CLONE_RANGER_PERF_TRACE"):          # diagnose slow stages: dump all thread stacks
        import faulthandler
        faulthandler.dump_traceback_later(int(os.environ["CLONE_RANGER_PERF_TRACE"]), repeat=True, file=sys.stderr)
    def rss_mb():
        return round(resource.getrusage(resource.RUSAGE_SELF).ru_maxrss / 1024)
    out = {{}}
""")

SCAN = COMMON + textwrap.dedent("""
    from clone_ranger.core.index import Index
    from clone_ranger.core.pipeline import run
    from clone_ranger.core.scanner import ScanConfig
    marks = {{}}
    t0 = time.monotonic()
    def progress(e):
        ph = e.get("phase")
        if ph and ph not in marks:
            marks[ph] = round(time.monotonic() - t0, 2)
    idx = Index({db!r})
    res = run(idx, ScanConfig(roots=[{lib!r}], excludes=[]), progress=progress)
    out.update(seconds=round(time.monotonic() - t0, 2), phase_starts=marks, files=res.files,
               groups=res.totals["groups"], duplicate_files=res.totals["duplicate_files"],
               hard_links=res.totals["hard_links"], reclaim=res.totals["reclaim"], rss_mb=rss_mb())
    print(json.dumps(out))
""")

LOAD = COMMON + textwrap.dedent("""
    from clone_ranger.core.index import Index
    from clone_ranger.core.duplicates import groups_from_index
    from clone_ranger.ui import viewmodel
    t0 = time.monotonic()
    idx = Index({db!r})
    groups = groups_from_index(idx)
    t1 = time.monotonic()
    ug = viewmodel.from_content_groups(groups)
    t2 = time.monotonic()
    out.update(groups_from_index=round(t1 - t0, 2), viewmodel=round(t2 - t1, 2), groups=len(ug),
               copies=sum(len(g.copies) for g in ug), rss_mb=rss_mb())
    print(json.dumps(out))
""")

UI = COMMON + textwrap.dedent("""
    import signal
    def out_of_time(*_):
        # time budget used up: report what was measured so far instead of being killed
        out["aborted_after_seconds"] = int(os.environ["CLONE_RANGER_PERF_UI_BUDGET"])
        out["rss_peak_mb"] = rss_mb()
        print(json.dumps(out), flush=True)
        os._exit(0)
    if os.environ.get("CLONE_RANGER_PERF_UI_BUDGET"):
        signal.signal(signal.SIGALRM, out_of_time)
        signal.alarm(int(os.environ["CLONE_RANGER_PERF_UI_BUDGET"]))
    os.environ["QT_QPA_PLATFORM"] = "offscreen"
    from clone_ranger.app import make_app
    app = make_app([])
    from clone_ranger.core.settings import Settings
    from clone_ranger.ui import main_window as mw
    def wait(cond, timeout=600):
        end = time.monotonic() + timeout
        while not cond():
            app.processEvents()
            time.sleep(0.005)
            if time.monotonic() > end:
                raise SystemExit("timed out")
    def timed(name, fn):
        t = time.monotonic()
        fn()
        app.processEvents()
        out[name] = round(time.monotonic() - t, 3)
        print(f"   {{name}}: {{out[name]}}", file=sys.stderr, flush=True)
    s = Settings()
    s["roots"] = [{lib!r}]
    t0 = time.monotonic()
    w = mw.MainWindow(settings=s)
    w.resize(1500, 940)
    w.show()
    wait(lambda: w.results.state == "ready")
    app.processEvents()
    out["window_until_results"] = round(time.monotonic() - t0, 2)
    print(f"   window_until_results: {{out['window_until_results']}}", file=sys.stderr, flush=True)
    r = w.results
    out["groups"] = len(r.all_groups)
    out["rss_after_load_mb"] = rss_mb()
    for v in ("ledger", "grid", "cards"):
        timed("view_" + v, lambda v=v: r.set_view(v))
    timed("filter_videos", lambda: r.filters.type.setCurrentIndex(2))
    timed("filter_clear", r.filters.clear)
    timed("search_typed", lambda: r.set_search("event_0042"))
    out["search_hits"] = len(r.visible)
    timed("search_cleared", lambda: r.set_search(""))
    for i in range(r.sort.count()):
        timed("sort_" + r.sort.itemData(i), lambda i=i: r.sort.setCurrentIndex(i))
    timed("select_all", w.select_all)
    timed("select_none", w.select_none)
    timed("scroll_cards", lambda: [r.cards.verticalScrollBar().setValue(v)
                                   for v in range(0, r.cards.verticalScrollBar().maximum(),
                                                  max(1, r.cards.verticalScrollBar().maximum() // 50))])
    t = time.monotonic()
    w.show_mode("name")
    wait(lambda: r.state == "ready" and r.mode == "name")
    out["same_name_mode"] = round(time.monotonic() - t, 2)
    out["same_name_groups"] = len(r.all_groups)
    out["rss_peak_mb"] = rss_mb()
    w.meta_worker and setattr(w.meta_worker, "stop", True)
    w.close()
    print(json.dumps(out))
""")


def check_scan(found: dict, manifest: dict) -> tuple[bool, list[str]]:
    """Compare a scan result with the library's manifest: (all correct, report lines)."""
    pairs = (("files", "files"), ("groups", "content_groups"), ("duplicate_files", "duplicate_files"),
             ("hard_links", "hard_links"), ("reclaim", "reclaim_bytes"))
    ok, lines = True, []
    for key, mkey in pairs:
        same = found.get(key) == manifest[mkey]
        ok &= same
        lines.append(f"{'OK ' if same else 'BAD'} {key}: found {found.get(key)}, expected {manifest[mkey]}")
    return ok, lines


def stage(name, code, env):
    print(f"\n== {name}", flush=True)
    t = time.monotonic()
    trace = os.environ.get("CLONE_RANGER_PERF_TRACE")
    r = subprocess.run([PY, "-c", code], stdout=subprocess.PIPE, stderr=None if trace else subprocess.PIPE,
                       text=True, env=env, timeout=3600)
    if r.returncode != 0:
        print((r.stderr or "")[-3000:])
        raise SystemExit(f"{name} failed")
    line = [ln for ln in r.stdout.splitlines() if ln.startswith("{")][-1]
    data = json.loads(line)
    data["wall_seconds"] = round(time.monotonic() - t, 1)
    for k, v in data.items():
        print(f"   {k:24} {v}")
    return data


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("library", nargs="?", default="build/perf/library")
    ap.add_argument("--skip-scan", action="store_true", help="reuse the existing index")
    ap.add_argument("--fresh-meta", action="store_true",
                    help="with --skip-scan: forget stored metadata, so the window reads it again like after a scan")
    ap.add_argument("--ui-budget", type=int, default=900,
                    help="stop the window stage after this many seconds and report what was measured")
    args = ap.parse_args()
    lib = str(Path(args.library).resolve())
    work = Path(lib).parent
    manifest = json.loads((Path(lib) / "manifest.json").read_text())
    env = dict(os.environ)
    for var, sub in (("XDG_CONFIG_HOME", "config"), ("XDG_CACHE_HOME", "cache"), ("XDG_STATE_HOME", "state"),
                     ("XDG_DATA_HOME", "data")):
        env[var] = str(work / sub)
    env["CLONE_RANGER_SANDBOX"] = str(work)
    env["CLONE_RANGER_PERF_UI_BUDGET"] = str(args.ui_budget)
    db = str(work / "cache" / "clone-ranger" / "index.sqlite")
    os.makedirs(os.path.dirname(db), exist_ok=True)
    fmt = dict(root=str(ROOT), lib=lib, db=db)
    results = {"manifest": manifest}
    if not args.skip_scan:
        for f in (db, db + "-wal", db + "-shm"):
            if os.path.exists(f):
                os.remove(f)
        results["scan_cold"] = stage("scan-cold (fresh index)", SCAN.format(**fmt), env)
        results["scan_warm"] = stage("scan-warm (nothing changed)", SCAN.format(**fmt), env)
    if args.skip_scan and args.fresh_meta:
        import sqlite3
        con = sqlite3.connect(db)
        n = con.execute("UPDATE files SET meta_mtime_ns = NULL WHERE meta_mtime_ns IS NOT NULL").rowcount
        con.commit()
        con.close()
        print(f"forgot stored metadata of {n} files")
    results["load"] = stage("load (start-up, no file read)", LOAD.format(**fmt), env)
    results["ui"] = stage("ui (offscreen window)", UI.format(**fmt), env)

    ok = True
    if "scan_cold" in results:
        ok, lines = check_scan(results["scan_cold"], manifest)
        print("\n".join(lines))
    (work / "perf-results.json").write_text(json.dumps(results, indent=2))
    print(f"\nsaved {work / 'perf-results.json'}")
    sys.exit(0 if ok else 1)


if __name__ == "__main__":
    main()
