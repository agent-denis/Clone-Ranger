"""The viewer in the real window, on a generated sample library (offscreen, tmp_path only)."""
import importlib.util
import time
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parent.parent


def wait(app, cond, timeout=30):
    end = time.monotonic() + timeout
    while not cond():
        app.processEvents()
        time.sleep(0.01)
        assert time.monotonic() < end, "timed out"


@pytest.fixture
def win(tmp_path, monkeypatch):
    for var, sub in (("XDG_CONFIG_HOME", "config"), ("XDG_CACHE_HOME", "cache"), ("XDG_STATE_HOME", "state")):
        monkeypatch.setenv(var, str(tmp_path / sub))
    spec = importlib.util.spec_from_file_location("msl", ROOT / "tools" / "make_sample_library.py")
    tool = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(tool)
    lib = tmp_path / "library"
    manifest = tool.build(lib)
    from clone_ranger.app import make_app
    app = make_app([])
    from clone_ranger.core.settings import Settings
    from clone_ranger.ui import main_window as mw
    monkeypatch.setattr(mw.SummaryDialog, "exec", lambda self: 0)
    settings = Settings()
    settings["roots"] = [str(lib)]
    w = mw.MainWindow(settings=settings)
    w.show()
    wait(app, lambda: w.results.state in ("none", "ready"))
    w.start_scan()
    wait(app, lambda: w.scan_worker is None)
    wait(app, lambda: all(c.has_meta for g in w.results.all_groups for c in g.copies))
    w.app, w.manifest = app, manifest
    yield w
    w.close()
    tool.make_readable(lib)


def image_group(w):
    return next(g for g in w.results.visible if g.kind == "image" and len(g.copies) >= 2)


def test_single_view_loads_full_resolution_and_zooms(win):
    from clone_ranger.viewer.zoom import View
    g = image_group(win)
    v = win.open_viewer("single", g, 0)
    pane = v.panes[0]
    wait(win.app, lambda: pane.has_full)
    c = g.copies[0]
    assert pane.canvas.logical == (c.width, c.height)
    assert pane.canvas.image.width() == c.width            # real pixels, not the thumbnail
    assert pane.canvas.badge == ""
    v._zoom("actual")
    assert pane.canvas.percent() == 100
    v._zoom("step", 1)
    assert pane.canvas.percent() == 150
    v._zoom("fit")
    assert pane.canvas.view == View()
    v.move(+1)
    assert pane.copy is g.copies[1] and "2" in v.counter.text()
    v.close()
    win.app.processEvents()
    assert win.viewer is None


def test_compare_sync_flicker_and_mark(win):
    g = image_group(win)
    v = win.open_viewer("compare", g, 0)
    a, b = v.panes
    assert a.copy is g.copies[0] and b.copy is g.copies[1]
    assert a.subject.text() == "A" and b.subject.text() == "B"
    wait(win.app, lambda: a.has_full and b.has_full)
    a.canvas.actual()                                     # zoom A -> B follows (lock zoom is on)
    assert b.canvas.view.mode == "manual" and b.canvas.percent() == a.canvas.percent()
    v.sync_btn.setChecked(False)
    a.canvas.fit()
    assert b.canvas.view.mode == "manual"                 # unlocked: B stays
    v.flicker()
    assert a.copy is g.copies[1] and b.copy is g.copies[0]
    # X marks the current pane's copy (if it can be marked) and the main window hears about it
    target = next((p for p in v.panes if p.copy.selectable), None)
    if target is not None:
        v.current = v.panes.index(target)
        before = target.copy.selected
        v.toggle_mark()
        assert target.copy.selected is (not before) and g.user_touched


def test_differences_are_highlighted(win):
    from clone_ranger.ui.viewer.window import differing_facts
    g = image_group(win)
    assert "f_hash" not in differing_facts(g.copies)       # same content -> same hash
    holiday = None
    win.show_mode("name")
    wait(win.app, lambda: win.results.state == "ready" and win.results.mode == "name")
    holiday = next(x for x in win.results.all_groups if x.display_name == "holiday.jpg")
    wait(win.app, lambda: all(c.has_meta for c in holiday.copies), 30)
    diff = differing_facts(holiday.copies)
    assert "f_size" in diff or "f_hash" in diff or "f_resolution" in diff
    v = win.open_viewer("compare", holiday, 0)
    assert "▲" in v.panes[0].facts.text()


def test_grid_and_case_navigation(win):
    g = max(win.results.visible, key=lambda x: len(x.copies))
    v = win.open_viewer("grid", g, 0)
    assert len(v.panes) == len(g.copies)
    first = v.group
    v.next_case(+1)
    if len(win.results.visible) > 1:
        assert v.group is not first
    v.set_mode("single")
    assert len(v.panes) == 1


def test_video_plays_inside_the_viewer(win):
    from clone_ranger.ui.viewer.media import MULTIMEDIA
    if not MULTIMEDIA or not win.manifest.get("videos"):
        pytest.skip("needs PySide6-Addons and ffmpeg for the sample video")
    g = next(g for g in win.results.visible if g.kind == "video")
    v = win.open_viewer("compare", g, 0)
    a, b = v.panes
    assert a.controls.isVisible() and a.video is not None and b.muted and not a.muted
    v.toggle_play()                                       # Space: both play together
    wait(win.app, lambda: a.video.player.position() > 300 and b.video.player.position() > 300, 20)
    assert a.has_full and a.canvas.image is not None
    v.toggle_play()
    wait(win.app, lambda: not a.video.playing and not b.video.playing)
    pos = a.video.player.position()
    a.video.step(1)
    wait(win.app, lambda: a.video.player.position() != pos, 10)


def test_slideshow_steps_and_stops(win):
    v = win.open_viewer("single", image_group(win), 0)
    v.start_slideshow()
    s = v.slideshow
    s.fullscreen = False
    first = s.pos
    s.step(+1)
    assert s.pos == (first + 1) % len(s.items)
    s.change_interval(+1)
    assert s.interval == 6
    s.toggle_pause()
    assert s.paused and not s.timer.isActive()
    s.close()
    win.app.processEvents()
    assert v.slideshow is None and v.mode == "single"


def test_demo_mode_viewer_uses_thumbnails_only():
    from clone_ranger.app import make_app
    app = make_app([])
    from clone_ranger.ui.main_window import MainWindow
    w = MainWindow(demo=True)
    w.show()
    v = w.open_viewer("compare")
    app.processEvents()
    assert v is not None and all(p.canvas.image is not None for p in v.panes)
    assert not w.full_images.pending                      # never tries to read the (fake) files
    v.close()
    w.close()


def test_viewer_fits_a_1366_px_screen():
    from clone_ranger.app import make_app
    app = make_app([])
    from clone_ranger.ui.main_window import MainWindow
    w = MainWindow(demo=True)
    for mode in ("single", "compare", "grid"):
        v = w.open_viewer(mode)
        app.processEvents()
        assert v.minimumSizeHint().width() <= 1366, (mode, v.minimumSizeHint().width())
        v.close()
    w.close()


def test_switching_modes_uses_the_full_width():
    from clone_ranger.app import make_app
    app = make_app([])
    from clone_ranger.ui.main_window import MainWindow
    w = MainWindow(demo=True)
    g = next(x for x in w.results.visible if len(x.copies) == 3)     # grid = 3 columns, compare = 2
    v = w.open_viewer("grid", g, 0)
    v.resize(1300, 800)
    app.processEvents()
    assert v.grid.columnCount() == 3
    v.set_mode("compare")
    app.processEvents()
    a, b = v.panes
    assert a.width() + b.width() > 0.9 * v.table.width()     # no empty column left over from the grid
    v.close()
    w.close()
