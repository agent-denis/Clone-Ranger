"""The text table: English only, every key used in the code exists, placeholders work."""
import sys
import re
from pathlib import Path

from clone_ranger.theme.strings import STRINGS, tr

PKG = Path(__file__).resolve().parent.parent / "clone_ranger"
OLD_WORDS = re.compile(r"\b(surveillance|agent|top secret|classified|dossier|teletype|order №|case №|bureau)\b",
                       re.IGNORECASE)


def test_every_entry_is_plain_english():
    for key, text in STRINGS.items():
        assert isinstance(text, str) and text.strip(), key
        assert not any("Ѐ" <= ch <= "ӿ" for ch in text), f"{key}: Cyrillic left in {text!r}"
        assert not OLD_WORDS.search(text), f"{key}: old Cold-War wording in {text!r}"


def test_every_key_used_in_the_code_exists():
    used = set()
    for py in PKG.rglob("*.py"):
        used |= set(re.findall(r"""\btr\(\s*["']([a-z0-9_]+)["']""", py.read_text(encoding="utf-8")))
    missing = sorted(k for k in used if k not in STRINGS)
    assert not missing, missing


def test_no_russian_left_in_the_user_interface():
    for py in PKG.rglob("*.py"):
        if py.name == "recommend.py":       # recognises Russian file / folder names ("копия", "Загрузки")
            continue
        for n, line in enumerate(py.read_text(encoding="utf-8").splitlines(), 1):
            assert not any("Ѐ" <= ch <= "ӿ" for ch in line), f"{py.relative_to(PKG)}:{n}: {line.strip()}"


def test_destructive_wording_is_plain():
    assert tr("delete_perm") == "Delete permanently"
    assert tr("move_to_trash") == ("Move to Recycle Bin" if sys.platform == "win32" else "Move to Trash")
    assert tr("unselect_all") == "Unselect all"


def test_placeholders():
    assert tr("case_no", n="0042") == "Group 0042"
    assert tr("order_no", n=17) == "Action #17"
    assert tr("n_selected", n=3, size="12 MB") == "3 selected · 12 MB"


def test_readme_txt_is_up_to_date():
    """README.txt is generated from README.md by tools/export_text.py - run it after editing README.md."""
    import importlib.util
    root = PKG.parent
    spec = importlib.util.spec_from_file_location("export_text", root / "tools" / "export_text.py")
    tool = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(tool)
    expected = tool.readme_text((root / "README.md").read_text(encoding="utf-8"))
    assert (root / "README.txt").read_text(encoding="utf-8") == expected, "run: tools/export_text.py readme"
