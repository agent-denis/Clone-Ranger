"""End-to-end file operations in the real window, on a generated sample library.

The confirmation dialog is confirmed programmatically; everything runs in pytest's tmp_path with
the sandbox lock on (tests/conftest.py), and the Trash is tmp_path/xdg-data/Trash.
"""
import importlib.util
import os
import sys
import time
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parent.parent


def wait(app, cond, timeout=60):
    end = time.monotonic() + timeout
    while not cond():
        app.processEvents()
        time.sleep(0.01)
        assert time.monotonic() < end, "timed out"


@pytest.fixture
def win(tmp_path, monkeypatch):
    for var, sub in (("XDG_CONFIG_HOME", "config"), ("XDG_CACHE_HOME", "cache"), ("XDG_STATE_HOME", "state")):
        monkeypatch.setenv(var, str(tmp_path / sub))
    spec = importlib.util.spec_from_file_location("msl", ROOT / "tools" / "make_sample_library.py")
    tool = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(tool)
    lib = tmp_path / "library"
    tool.build(lib)
    from clone_ranger.app import make_app
    app = make_app([])
    from clone_ranger.core.settings import Settings
    from clone_ranger.ui import main_window as mw
    from clone_ranger.ui import order_dialog, ops_controller
    monkeypatch.setattr(mw.SummaryDialog, "exec", lambda self: 0)
    shown = []

    def sign(self):
        """Stand-in for the user: read the confirmation, confirm, wait for the report, close."""
        shown.append(self)
        self.show()
        if self.live:
            self._signed()
            wait(app, lambda: self.phase == "report")
        return 1
    monkeypatch.setattr(order_dialog.OrderDialog, "exec", sign)

    def fail_box(self, *a, **k):
        raise AssertionError("message box shown: " + (self.detailedText() or self.text()))
    monkeypatch.setattr(ops_controller.QMessageBox, "exec", fail_box)
    monkeypatch.setattr(mw.QMessageBox, "exec", fail_box)
    settings = Settings()
    settings["roots"] = [str(lib)]
    w = mw.MainWindow(settings=settings)
    w.show()
    wait(app, lambda: w.results.state in ("none", "ready"))
    w.start_scan()
    wait(app, lambda: w.scan_worker is None)
    # metadata can change recommendations: let it finish before acting like a user
    wait(app, lambda: all(c.has_meta for g in w.results.all_groups for c in g.copies))
    w.app, w.lib, w.tmp, w.shown = app, lib, tmp_path, shown
    yield w
    w.close()
    tool.make_readable(lib)


def on_disk(w):
    return {str(p) for p in w.lib.rglob("*") if p.is_file()}


def test_trash_then_undo(win):
    r = win.results
    groups_before = len(r.all_groups)
    sel = [c.path for _, c in r.selected()]
    assert sel and all(os.path.exists(p) for p in sel)
    assert not r.undo_btn.isEnabled()
    rep = win.ops.trash()
    dlg = win.shown[-1]
    assert dlg.values["file_count"].text() == str(len(sel))
    assert rep.counts["ok"] == len(sel) and not rep.cancelled
    assert not any(os.path.exists(p) for p in sel)
    if sys.platform != "win32":     # on Windows they are in the Recycle Bin
        trash_files = list((win.tmp / "xdg-data" / "Trash" / "files").iterdir())
        assert len(trash_files) == len(sel)
    # every case had all its duplicates pre-selected -> every case is closed, without a rescan
    assert len(r.all_groups) < groups_before
    assert not any(c.path in sel for g in r.all_groups for c in g.copies)
    assert r.undo_btn.isEnabled()
    # the History page shows the action
    win.stack.setCurrentWidget(win.log_page)
    assert win.log_page.tree.topLevelItemCount() == 1
    # Ctrl+Z
    win.edit_actions["undo"].trigger()
    wait(win.app, lambda: r.state == "ready")
    assert all(os.path.exists(p) for p in sel)
    assert len(r.all_groups) == groups_before
    assert not r.undo_btn.isEnabled()


def test_move_rename_bulk_rename_and_undo(win):
    from clone_ranger.core.bulk_rename import Options
    r = win.results
    g = next(g for g in r.all_groups if g.kind == "image" and any(c.selected for c in g.copies))
    for other in r.all_groups:                       # only this case's duplicates
        for c in other.copies:
            c.selected = c.selected and other is g
    moved_copies = [c for c in g.copies if c.selected]
    staying = {c.path for c in g.copies if not c.selected}
    moving = [c.path for c in moved_copies]
    dest = win.tmp / "sorted"
    rep = win.ops.move(dest=str(dest), keep_structure=False, conflict="number")
    assert rep.counts["ok"] == len(moving)
    assert all(c.path.startswith(str(dest)) and os.path.exists(c.path) for c in moved_copies)
    assert staying <= {c.path for c in g.copies}
    assert not any(os.path.exists(p) for p in moving)

    # F2 on the kept copy (no confirmation for a single rename)
    keep = next(c for c in g.copies if c.keep)
    old = keep.path
    rep = win.ops.rename_one((g, keep), "the-original.jpg")
    assert rep.counts["ok"] == 1 and keep.path.endswith(os.sep + "the-original.jpg") and os.path.exists(keep.path)
    assert not os.path.exists(old)

    # bulk rename the moved copies
    for c in g.copies:
        c.selected = c.path.startswith(str(dest))
    rep = win.ops.bulk_rename(options=Options(prefix="dup_", numbering=True))
    assert rep.counts["ok"] == len(moving)
    assert all(os.path.basename(c.path).startswith("dup_") for c in g.copies if c.path.startswith(str(dest)))

    # undo all three, newest first
    for _ in range(3):
        win.ops.undo_last()
    assert all(os.path.exists(p) for p in moving) and os.path.exists(old)
    assert not dest.exists() or not any(dest.iterdir())
    assert {c.path for c in g.copies} >= set(moving)


def test_delete_needs_typed_confirmation_for_many_files(win, monkeypatch):
    from clone_ranger.ui.order_dialog import OrderDialog
    files = [f"/x/{i}.jpg" for i in range(25)]
    from clone_ranger.theme.strings import tr
    dlg = OrderDialog(1, "delete_perm", files, "1 MB", "nowhere", danger=True, confirm_word=tr("delete_word"))
    assert not dlg.sign_btn.isEnabled()
    dlg.confirm_edit.setText("delete")
    assert dlg.sign_btn.isEnabled()
    dlg.confirm_edit.setText(" DELETE ")
    assert dlg.sign_btn.isEnabled()
    dlg.confirm_edit.setText("del")
    assert not dlg.sign_btn.isEnabled()
    assert dlg.sign_btn.text() == tr("delete_perm")      # the button says what it does

    # a real permanent delete of one case's duplicates
    r = win.results
    g = next(g for g in r.all_groups if any(c.selected for c in g.copies))
    for other in r.all_groups:
        for c in other.copies:
            c.selected = c.selected and other is g
    victims = [c.path for c in g.copies if c.selected]
    rep = win.ops.delete()
    assert win.shown[-1].danger
    assert rep.counts["ok"] == len(victims) and not any(os.path.exists(p) for p in victims)
    assert not (win.tmp / "xdg-data" / "Trash" / "files").exists()
    assert g not in r.all_groups                     # group resolved
    assert not win.ops.journal.last_undoable()       # permanent: nothing to undo


def test_losing_every_copy_is_warned(win):
    from clone_ranger.theme.strings import tr
    r = win.results
    g = next(g for g in r.all_groups if g.mode == "content")
    pairs = [(g, c) for c in g.copies]               # e.g. via Delete on each copy
    warnings = win.ops.loss_warnings(pairs)
    assert tr("lose_all", n=g.number) in warnings
    keep_one = [(g, c) for c in g.copies if not c.keep]
    assert not win.ops.loss_warnings(keep_one)


def test_changed_file_is_skipped_and_reported(win):
    r = win.results
    g = next(g for g in r.all_groups if any(c.selected for c in g.copies))
    for other in r.all_groups:
        for c in other.copies:
            c.selected = c.selected and other is g
    victim = next(c for c in g.copies if c.selected)
    with open(victim.path, "ab") as f:
        f.write(b"edited after the scan")
    rep = win.ops.trash()
    item = next(i for i in rep.order.items if i.src == victim.path)
    assert item.status == "skipped" and os.path.exists(victim.path)
    assert any("size changed" in win.shown[-1].list.item(i).text() for i in range(win.shown[-1].list.count()))


def test_ctrl_a_selects_duplicates_never_the_keeper(win):
    r = win.results
    win.select_none()
    assert not r.selected()
    win.select_all()
    assert r.selected()
    assert not any(c.selected for g in r.all_groups for c in g.copies if c.keep or c.keep_twin)


def test_protected_folder_is_never_touched(win):
    r = win.results
    g = next(g for g in r.all_groups if any(c.selected for c in g.copies))
    victim = next(c for c in g.copies if c.selected)
    win.settings["protected_folders"] = [os.path.dirname(victim.path)]
    rep = win.ops.delete([(g, victim)])           # even if handed over directly
    assert rep.order.items[0].error == "protected folder" and os.path.exists(victim.path)
