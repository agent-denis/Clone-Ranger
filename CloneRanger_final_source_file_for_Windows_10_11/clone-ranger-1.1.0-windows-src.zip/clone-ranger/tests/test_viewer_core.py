"""Viewer maths and full-resolution loading (no window)."""
import pytest

from clone_ranger.viewer import zoom
from clone_ranger.viewer.zoom import View

IMG, WIN = (4000, 3000), (800, 600)
A = (*IMG, *WIN)


def test_fit_never_enlarges_small_images():
    assert zoom.fit_scale(4000, 3000, 800, 600) == pytest.approx(0.2)
    assert zoom.fit_scale(100, 50, 800, 600) == 1.0
    assert zoom.image_rect(View(), 100, 50, 800, 600) == (350, 275, 100, 50)


def test_zoom_keeps_point_under_cursor():
    v = View()
    x0, y0, w0, h0 = zoom.image_rect(v, *A)
    px, py = 600, 150
    ix, iy = (px - x0) / w0, (py - y0) / h0          # image point under the cursor before
    v2 = zoom.zoom_at(v, 4, px, py, *A)
    x1, y1, w1, h1 = zoom.image_rect(v2, *A)
    assert v2.mode == "manual" and v2.scale == pytest.approx(0.8)
    assert (px - x1) / w1 == pytest.approx(ix) and (py - y1) / h1 == pytest.approx(iy)


def test_actual_size_and_steps():
    v = zoom.actual_size(View(), *A)
    assert zoom.percent(v, *A) == 100
    assert zoom.percent(zoom.step(v, +1, *A), *A) == 150
    assert zoom.percent(zoom.step(v, -1, *A), *A) == 75
    tiny = zoom.step(View("manual", zoom.MIN_SCALE), -1, *A)
    assert tiny.scale == zoom.MIN_SCALE


def test_pan_is_clamped_to_the_image_edges():
    v = zoom.actual_size(View(), *A)
    far = zoom.pan(v, 10**6, 10**6, *A)              # drag far to the right/down
    x, y, w, h = zoom.image_rect(far, *A)
    assert x == pytest.approx(0) and y == pytest.approx(0)   # top-left corner, no gap
    # an image smaller than the window always stays centred
    small = zoom.pan(View("manual", 1.0), 300, 300, 100, 50, 800, 600)
    assert zoom.image_rect(small, 100, 50, 800, 600)[:2] == (350, 275)


def test_transfer_between_resolutions():
    v = zoom.zoom_at(View(), 3, 200, 200, *A)
    other = (2000, 1500, *WIN)                       # same picture at half the resolution
    t = zoom.transfer(v, A, other)
    assert (t.cx, t.cy) == pytest.approx((v.cx, v.cy))
    assert t.scale / zoom.fit_scale(*other) == pytest.approx(v.scale / zoom.fit_scale(*A))
    assert zoom.transfer(View(), A, other) == View()


def test_load_image_rotation_alpha_and_size_cap(tmp_path, monkeypatch):
    from PIL import Image
    from clone_ranger.viewer import loader
    p = tmp_path / "r.jpg"
    img = Image.new("RGB", (60, 40), (200, 10, 10))
    exif = img.getexif()
    exif[0x0112] = 6                                  # "rotate 90° CW" in EXIF
    img.save(p, exif=exif)
    r = loader.load_image(str(p))
    assert (r.width, r.height) == (40, 60) and not r.error and len(r.data) == 40 * 60 * 3
    q = tmp_path / "a.png"
    Image.new("RGBA", (10, 10), (0, 0, 0, 0)).save(q)
    assert loader.load_image(str(q)).mode == "RGBA"
    monkeypatch.setattr(loader, "MAX_PIXELS", 600)
    big = loader.load_image(str(p))
    assert big.reduced and big.width * big.height <= 600 and (big.full_width, big.full_height) == (40, 60)
    bad = tmp_path / "bad.jpg"
    bad.write_text("not an image")
    assert loader.load_image(str(bad)).error
