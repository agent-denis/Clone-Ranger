"""install.sh / uninstall.sh, run for real against a throwaway home folder (offline: --skip-deps)."""
import os
import shutil
import subprocess
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parent.parent
APP_ID = "io.github.agent_denis.CloneRanger"

pytestmark = [pytest.mark.skipif(sys.platform == "win32", reason="install.sh / uninstall.sh are for Linux"),
              pytest.mark.skipif(sys.platform != "win32" and os.geteuid() == 0, reason="the scripts refuse to run as root")]


def run(script, home, *args, input_text=None):
    env = {"HOME": str(home), "PATH": "/usr/local/bin:/usr/bin:/bin", "LANG": "C.UTF-8"}
    return subprocess.run(["bash", str(ROOT / script), *args], env=env, capture_output=True, text=True,
                          input=input_text, timeout=300)


@pytest.fixture
def home(tmp_path):
    h = tmp_path / "home"
    (h / "Pictures").mkdir(parents=True)
    (h / "Pictures" / "holiday.jpg").write_bytes(b"\xff\xd8\xff my photo")
    trash = h / ".local/share/Trash/files"
    trash.mkdir(parents=True)
    (trash / "old.jpg").write_bytes(b"trashed")
    for d in (".config/clone-ranger", ".cache/clone-ranger", ".local/state/clone-ranger"):
        (h / d).mkdir(parents=True)
    (h / ".config/clone-ranger/settings.json").write_text('{"theme": "archive"}')
    (h / ".cache/clone-ranger/index.sqlite").write_bytes(b"index")
    (h / ".local/state/clone-ranger/journal.jsonl").write_text("{}\n")
    return h


def installed_files(home):
    data = home / ".local/share"
    return {
        "launcher": home / ".local/bin/clone-ranger",
        "desktop": data / f"applications/{APP_ID}.desktop",
        "metainfo": data / f"metainfo/{APP_ID}.metainfo.xml",
        "svg": data / f"icons/hicolor/scalable/apps/{APP_ID}.svg",
        "png48": data / f"icons/hicolor/48x48/apps/{APP_ID}.png",
        "app": data / "clone-ranger/app/clone_ranger/__init__.py",
        "venv": data / "clone-ranger/venv/bin/python",
    }


def test_install_upgrade_uninstall_purge(home):
    from clone_ranger import __version__
    r = run("install.sh", home, "--skip-deps")
    assert r.returncode == 0, r.stdout + r.stderr
    f = installed_files(home)
    for name, p in f.items():
        assert p.exists(), name
    # the command works and runs the installed copy, not the source tree
    v = subprocess.run([str(f["launcher"]), "--version"], capture_output=True, text=True,
                       env={"HOME": str(home), "PATH": "/usr/bin:/bin"})
    assert v.stdout.strip() == f"clone-ranger {__version__}"
    assert str(home) in f["launcher"].read_text()
    # menu entry points at the installed command and is valid
    desktop = f["desktop"].read_text()
    assert f"Exec={f['launcher']}" in desktop and f"TryExec={f['launcher']}" in desktop
    if shutil.which("desktop-file-validate"):
        assert subprocess.run(["desktop-file-validate", str(f["desktop"])]).returncode == 0
    icons = list((home / ".local/share/icons/hicolor").glob(f"*/apps/{APP_ID}.*"))
    assert len(icons) == 10
    assert not list((home / ".local/share/clone-ranger/app").rglob("__pycache__"))

    # upgrade in place: user data untouched, program replaced
    (home / ".local/share/clone-ranger/app/clone_ranger/stale.py").write_text("old")
    r = run("install.sh", home, "--skip-deps")
    assert r.returncode == 0, r.stdout + r.stderr
    assert "reusing" in r.stdout
    assert not (home / ".local/share/clone-ranger/app/clone_ranger/stale.py").exists()
    assert (home / ".config/clone-ranger/settings.json").read_text() == '{"theme": "archive"}'

    # plain uninstall: program gone, settings / index / action log kept
    r = run("uninstall.sh", home)
    assert r.returncode == 0, r.stdout + r.stderr
    for name, p in f.items():
        assert not p.exists(), name
    assert not (home / ".local/share/clone-ranger").exists()
    for d in (".config/clone-ranger/settings.json", ".cache/clone-ranger/index.sqlite", ".local/state/clone-ranger/journal.jsonl"):
        assert (home / d).exists(), d

    # purge needs a typed "yes"
    r = run("uninstall.sh", home, "--purge", input_text="no\n")
    assert (home / ".config/clone-ranger").exists() and "Kept them" in r.stdout
    r = run("uninstall.sh", home, "--purge", input_text="yes\n")
    assert r.returncode == 0, r.stdout + r.stderr
    for d in (".config/clone-ranger", ".cache/clone-ranger", ".local/state/clone-ranger"):
        assert not (home / d).exists(), d
    # never touched: photos and the Trash
    assert (home / "Pictures/holiday.jpg").read_bytes() == b"\xff\xd8\xff my photo"
    assert (home / ".local/share/Trash/files/old.jpg").read_bytes() == b"trashed"


def test_uninstall_ignores_manifest_entries_outside_its_folders(home, tmp_path):
    assert run("install.sh", home, "--skip-deps").returncode == 0
    victim = tmp_path / "not-ours.txt"
    victim.write_text("keep me")
    manifest = home / ".local/share/clone-ranger/installed-files.txt"
    manifest.write_text(manifest.read_text() + f"{victim}\n{home}/Pictures/holiday.jpg\n")
    r = run("uninstall.sh", home, "--yes")
    assert r.returncode == 0
    assert victim.read_text() == "keep me"
    assert (home / "Pictures/holiday.jpg").exists()
    assert "skipped unexpected entry" in r.stdout


def test_uninstall_when_not_installed(home):
    r = run("uninstall.sh", home)
    assert r.returncode == 0 and "doesn't seem to be installed" in r.stdout
    assert (home / ".config/clone-ranger/settings.json").exists()


def test_packaging_versions_agree():
    """__version__, the RPM spec and the AppStream release list must move together."""
    import re
    from clone_ranger import __version__
    spec = (ROOT / "packaging/clone-ranger.spec").read_text()
    assert re.search(r"^Version:\s+(\S+)$", spec, re.M).group(1) == __version__
    assert f"clone-ranger-{__version__}/" in spec and "%autochangelog" in spec
    assert f"## {__version__}" in (ROOT / "CHANGELOG.md").read_text()
    meta = (ROOT / f"packaging/{APP_ID}.metainfo.xml").read_text()
    assert f'<release version="{__version__}"' in meta


def test_app_id_is_the_same_everywhere():
    from clone_ranger import APP_ID as code_id
    assert code_id == APP_ID
    desktop = (ROOT / f"packaging/{APP_ID}.desktop").read_text()
    assert f"Icon={APP_ID}\n" in desktop and "StartupWMClass=CloneRanger\n" in desktop
    meta = (ROOT / f"packaging/{APP_ID}.metainfo.xml").read_text()
    assert f"<id>{APP_ID}</id>" in meta and f'<launchable type="desktop-id">{APP_ID}.desktop</launchable>' in meta
    assert "%global app_id  " + APP_ID in (ROOT / "packaging/clone-ranger.spec").read_text()
    icons = sorted(p.name for p in (ROOT / "packaging/icons/hicolor").glob("*/apps/*"))
    assert len(icons) == 10 and set(icons) == {f"{APP_ID}.png", f"{APP_ID}.svg"}
    # settings / cache / log folders use the short name
    from clone_ranger.core import paths
    assert paths.APP == "clone-ranger"


def test_no_icon_cache_hides_the_app_icon(home):
    """gtk-update-icon-cache on ~/.local/share/icons/hicolor (no index.theme) writes a cache listing no icons,
    and GNOME then shows the app without its icon. The installer must not write one, and removes a stale one."""
    hicolor = home / ".local/share/icons/hicolor"
    hicolor.mkdir(parents=True)
    stale = hicolor / "icon-theme.cache"
    stale.write_bytes(b"empty cache from an older install")
    r = run("install.sh", home, "--skip-deps")
    assert r.returncode == 0, r.stdout + r.stderr
    assert not stale.exists()
    assert (hicolor / "256x256/apps" / f"{APP_ID}.png").exists()
    assert run("install.sh", home, "--skip-deps").returncode == 0          # upgrade: still no cache
    assert not stale.exists()
    r = run("uninstall.sh", home)
    assert r.returncode == 0 and not stale.exists()


def test_upgrade_removes_files_the_previous_manifest_listed(home):
    assert run("install.sh", home, "--skip-deps").returncode == 0
    data = home / ".local/share"
    stale = data / "icons/hicolor/32x32/apps/clone-ranger.png"                # e.g. renamed in a later version
    stale.parent.mkdir(parents=True, exist_ok=True)
    stale.write_bytes(b"old")
    manifest = data / "clone-ranger/installed-files.txt"
    manifest.write_text(manifest.read_text() + f"{stale}\n")
    assert run("install.sh", home, "--skip-deps").returncode == 0
    assert not stale.exists()
    assert str(stale) not in manifest.read_text()
