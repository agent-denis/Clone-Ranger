"""End-to-end: the real window scans a generated sample library and shows the results.

All Clone Ranger folders (settings, index, thumbnails, logs) are redirected into pytest's
temporary directory via XDG_* variables - your real ~/.config and ~/.cache are untouched.
"""
import csv
import importlib.util
import time
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parent.parent


@pytest.fixture
def env(tmp_path, monkeypatch):
    for var, sub in (("XDG_CONFIG_HOME", "config"), ("XDG_CACHE_HOME", "cache"), ("XDG_STATE_HOME", "state")):
        monkeypatch.setenv(var, str(tmp_path / sub))
    spec = importlib.util.spec_from_file_location("msl", ROOT / "tools" / "make_sample_library.py")
    tool = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(tool)
    lib = tmp_path / "library"
    manifest = tool.build(lib)
    yield tmp_path, lib, manifest
    tool.make_readable(lib)


def wait(app, cond, timeout=60):
    end = time.monotonic() + timeout
    while not cond():
        app.processEvents()
        time.sleep(0.01)
        assert time.monotonic() < end, "timed out"


def test_scan_show_and_export(env, monkeypatch):
    tmp, lib, manifest = env
    from clone_ranger.app import make_app
    app = make_app([])
    from clone_ranger.core.settings import Settings
    from clone_ranger.ui import main_window as mw
    monkeypatch.setattr(mw.SummaryDialog, "exec", lambda self: 0)   # don't block on the memo

    def fail_box(self, *a, **k):
        raise AssertionError("error dialog shown: " + (self.detailedText() or self.text()))
    monkeypatch.setattr(mw.QMessageBox, "exec", fail_box)

    settings = Settings()
    assert str(settings.path).startswith(str(tmp))
    settings["roots"] = [str(lib)]
    win = mw.MainWindow(settings=settings)
    win.show()
    wait(app, lambda: win.results.state in ("none", "ready"))
    assert win.results.state == "none"                  # no index yet -> "no scan yet" page

    win.start_scan()
    wait(app, lambda: win.scan_worker is None)
    r = win.results
    assert len(r.all_groups) == len(manifest["content_groups"])
    assert r.stack.currentWidget() is r.cards
    # every group has exactly one KEEP, and nothing sharing the kept file's inode is selected
    for g in r.all_groups:
        assert sum(c.keep for c in g.copies) == 1
        keep = next(c for c in g.copies if c.keep)
        assert not any(c.selected for c in g.copies if c.inode == keep.inode)
        assert not any(c.selectable for c in g.copies if c.inode == keep.inode)
    # Downloads copies are never the recommended keeper when another copy exists
    assert not any(c.keep and "/Downloads/" in c.path for g in r.all_groups for c in g.copies)

    # metadata and thumbnails arrive in the background
    wait(app, lambda: all(c.has_meta for g in r.all_groups for c in g.copies))
    wait(app, lambda: not win.thumbs.pending and all(
        win.thumbs.image(g.copies[0]) is not None for g in r.all_groups))
    assert any(c.width for g in r.all_groups for c in g.copies)

    # views share data; filters and search work
    for v in ("ledger", "grid", "cards"):
        r.set_view(v)
        app.processEvents()
    assert r.ledger_model.rowCount() == sum(len(g.copies) for g in r.all_groups)
    r.filters.type.setCurrentIndex(2)                   # videos only
    assert all(g.kind == "video" for g in r.visible)
    r.filters.clear()
    r.set_search("pets")
    assert len(r.visible) == 1
    r.set_search("")

    # selection toggling updates the status bar
    before = len(r.selected())
    g = next(g for g in r.all_groups if any(c.selectable and not c.hard_link for c in g.copies))
    c = next(c for c in g.copies if c.selected)
    c.selected = False
    win._selection_changed(g)
    assert len(r.selected()) == before - 1 and g.user_touched

    # CSV export (bypassing the file dialog)
    out = tmp / "report.csv"
    monkeypatch.setattr(mw.QFileDialog, "getSaveFileName", lambda *a, **k: (str(out), ""))
    win.export_csv()
    rows = list(csv.DictReader(out.open()))
    assert len(rows) == r.ledger_model.rowCount()
    assert {row["recommended_keep"] for row in rows} == {"True", "False"}

    # same-name mode
    win.show_mode("name")
    wait(app, lambda: r.state == "ready" and r.mode == "name")
    names = {g.display_name for g in r.all_groups}
    assert "holiday.jpg" in names
    holiday = next(g for g in r.all_groups if g.display_name == "holiday.jpg")
    assert holiday.content == "different" and not any(c.selected for c in holiday.copies)

    win.close()
    assert (tmp / "config" / "clone-ranger" / "settings.json").exists()
    # nothing in the library was changed
    for group in manifest["content_groups"]:
        for rel in group:
            assert (lib / rel).exists()
