"""New in Clone Ranger: Unselect one / all files from the window, Reset to defaults, Clear history & cache.

Everything runs in pytest's temporary folders (tests/conftest.py); photos are never touched.
"""
import importlib.util
import os
import time
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parent.parent


def wait(app, cond, timeout=60):
    end = time.monotonic() + timeout
    while not cond():
        app.processEvents()
        time.sleep(0.01)
        assert time.monotonic() < end, "timed out"


def selected(win):
    return [c for g in win.results.all_groups for c in g.copies if c.selected]


# --------------------------------------------------------------------------- unselect
def test_unselect_all_button(monkeypatch):
    from clone_ranger.app import make_app
    app = make_app([])
    from clone_ranger.ui.main_window import MainWindow
    win = MainWindow(demo=True)
    win.show()
    r = win.results
    win.select_all()
    n = len(selected(win))
    assert n > 0
    assert r.unselect_all_btn.isEnabled()
    assert f"{n} selected" in r.sel_label.text()
    # a filter hides some groups: Unselect all still clears every group, also the hidden ones
    r.filters.type.setCurrentIndex(2)          # videos only
    app.processEvents()
    r.unselect_all_btn.click()
    app.processEvents()
    assert selected(win) == []
    assert not r.unselect_all_btn.isEnabled()
    assert r.sel_label.text() == "Nothing selected"
    assert "Nothing selected" in win.statusbar.parts[0]
    r.select_all_btn.click()                    # and back
    assert selected(win)
    win.close()


def test_unselect_one_file_from_the_details_panel():
    from clone_ranger.app import make_app
    make_app([])
    from clone_ranger.ui.main_window import MainWindow
    win = MainWindow(demo=True)
    g = next(g for g in win.results.all_groups if any(c.selected for c in g.copies))
    c = next(c for c in g.copies if c.selected)
    win.dossier.show_copy(g, c)
    btn = win.dossier.buttons["select"]
    assert btn.isEnabled() and btn.accessibleName() == "Unselect this file"
    before = len(selected(win))
    btn.click()
    assert not c.selected and len(selected(win)) == before - 1
    assert g.user_touched                      # new metadata won't re-select it
    assert btn.accessibleName() == "Select for removal"
    btn.click()                                # select it again
    assert c.selected
    # the kept copy can't be selected: the button explains why
    keep = next(x for x in g.copies if x.keep)
    win.dossier.show_copy(g, keep)
    assert not btn.isEnabled() and btn.toolTip()
    # Ctrl+U unselects the file shown in the panel
    win.dossier.show_copy(g, c)
    win.unselect_current()
    assert not c.selected
    win.close()


# --------------------------------------------------------------------------- reset / clear
@pytest.fixture
def scanned(tmp_path, monkeypatch):
    """A real window after a real scan of a generated sample library, plus one undoable action."""
    spec = importlib.util.spec_from_file_location("msl", ROOT / "tools" / "make_sample_library.py")
    tool = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(tool)
    lib = tmp_path / "library"
    tool.build(lib)
    from clone_ranger.app import make_app
    app = make_app([])
    from clone_ranger.core.settings import Settings
    from clone_ranger.ui import main_window as mw
    monkeypatch.setattr(mw.SummaryDialog, "exec", lambda self: 0)

    def fail_box(self, *a, **k):                 # an error box would block forever offscreen: fail instead
        raise AssertionError("error dialog shown: " + (self.detailedText() or self.text()))
    monkeypatch.setattr(mw.QMessageBox, "exec", fail_box)
    s = Settings()
    s["roots"] = [str(lib)]
    s["excludes"] = ["*.tmp"]
    s["theme"] = "dark"
    s.save()
    win = mw.MainWindow(settings=s)
    win.show()
    wait(app, lambda: win.results.state in ("none", "ready"))
    win.start_scan()
    wait(app, lambda: win.scan_worker is None)
    wait(app, lambda: win.meta_worker is None or not win.meta_worker.isRunning())
    j = win.ops.journal
    o = j.begin("trash")
    from clone_ranger.core.journal import Item
    j.item(o, Item(src=str(lib / "x.jpg"), dst=str(tmp_path / "Trash" / "x.jpg"), status="ok"))
    j.end(o, "done")
    yield app, win, lib
    win.close()
    tool.make_readable(lib)


def test_reset_search_settings_only(scanned):
    app, win, lib = scanned
    from clone_ranger.core import housekeeping, paths
    win.header.search.setText("IMG")
    win.results.filters.min_size.setValue(5)
    groups = len(win.results.all_groups)
    win.perform_reset(search=True)
    s = win.settings
    assert s["roots"] is None and s["excludes"] is None
    assert s["theme"] == "dark"                                   # other settings kept
    assert win.header.search.text() == "" and not win.results.filters.active
    assert len(win.results.all_groups) == groups                  # results and cache kept
    assert housekeeping.cache_size() > 0 and paths.index_path().exists()
    assert win.ops.journal.last_undoable() is not None            # history kept
    assert "search settings" in win.statusbar.parts[-1]
    assert all(lib.rglob("*"))                                    # photos untouched


def test_clear_history_and_cache_starts_from_scratch(scanned, monkeypatch):
    app, win, lib = scanned
    from clone_ranger.core import housekeeping, paths
    from clone_ranger.ui import reset_dialog
    photos_before = sorted(p for p in lib.rglob("*") if p.is_file())
    assert paths.index_path().exists() and housekeeping.cache_size() > 0

    seen = {}

    def accept(dlg):
        seen["choices"] = dlg.choices()
        seen["warning"] = dlg.options["history"].warning.text()
        return 1
    monkeypatch.setattr(reset_dialog.ResetDialog, "exec", accept)
    win.open_reset("clear")
    assert seen["choices"] == {"search": False, "preferences": False, "history": True, "cache": True}
    assert "can still be undone" in seen["warning"]

    assert not paths.index_path().exists() and housekeeping.cache_size() == 0
    assert not paths.journal_path().exists()
    assert win.ops.journal.last_undoable() is None and not win.results.undo_btn.isEnabled()
    assert win.results.state == "none" and win.results.all_groups == []
    assert win.settings["roots"] == [str(lib)]                    # search settings kept
    assert win.settings["last_roots"] == []                       # remembered folders forgotten
    assert sorted(p for p in lib.rglob("*") if p.is_file()) == photos_before

    # and a fresh scan works again afterwards
    win.start_scan()
    wait(app, lambda: win.scan_worker is None)
    assert win.results.all_groups and paths.index_path().exists()


def test_reset_everything_from_the_settings_page(scanned, monkeypatch):
    app, win, lib = scanned
    from clone_ranger.core.settings import DEFAULTS
    from clone_ranger.theme.style import theme
    from clone_ranger.ui import reset_dialog

    def everything(dlg):
        dlg.set_choices(search=True, preferences=True, history=True, cache=True)
        return 1
    monkeypatch.setattr(reset_dialog.ResetDialog, "exec", everything)
    win.settings_page.reset_btn.click()
    differ = {k: win.settings[k] for k in DEFAULTS if win.settings[k] != DEFAULTS[k]}
    assert not differ
    assert theme().key == "auto"
    assert win.results.state == "none"


def test_cancel_changes_nothing_and_busy_is_refused(scanned, monkeypatch):
    app, win, lib = scanned
    from clone_ranger.core import paths
    from clone_ranger.ui import reset_dialog
    monkeypatch.setattr(reset_dialog.ResetDialog, "exec", lambda dlg: 0)
    win.locations.reset_btn.click()                               # opens the dialog; cancelled
    assert win.settings["roots"] == [str(lib)] and paths.index_path().exists()
    monkeypatch.setattr(type(win.ops), "busy", property(lambda self: True))
    assert win.perform_reset(cache=True) is None
    assert paths.index_path().exists()


def test_reset_dialog_needs_a_choice():
    from clone_ranger.app import make_app
    make_app([])
    from clone_ranger.ui.reset_dialog import ResetDialog
    d = ResetDialog("reset", 1024, 0, 0)
    assert d.choices()["search"] and d.ok_btn.isEnabled()
    d.set_choices(search=False)
    assert not d.ok_btn.isEnabled() and d.hint.text()
    d.set_choices(cache=True)
    assert d.ok_btn.isEnabled() and d.ok_btn.property("variant") == "danger"
    assert "Clear" in ResetDialog("clear").ok_btn.text()
