"""Checks that only mean something on a real Windows PC (skipped elsewhere).

Run on Windows with:  windows\\build.ps1  (it runs these first), or
                      .venv-win\\Scripts\\python -m pytest tests\\core\\test_windows.py tests\\core\\test_windows_real.py
Everything happens in a temporary folder; the one Recycle Bin test recycles and restores
a file it created itself.
"""
import os
import sys

import pytest

pytestmark = pytest.mark.skipif(sys.platform != "win32", reason="Windows only")


def _photo(path, color, size=(64, 48)):
    from PIL import Image
    os.makedirs(os.path.dirname(path), exist_ok=True)
    Image.new("RGB", size, color).save(path, "JPEG", quality=90)


def test_scan_finds_duplicates_and_hard_links(tmp_path, index):
    """scandir reports file ID 0 on Windows: without the fix every file looked like one hard link."""
    from clone_ranger.core.pipeline import run
    from clone_ranger.core.scanner import ScanConfig
    lib = tmp_path / "Pictures"
    _photo(str(lib / "a" / "red.jpg"), "red")
    _photo(str(lib / "b" / "red copy.jpg"), "red")
    _photo(str(lib / "c" / "blue.jpg"), "blue")
    _photo(str(lib / "c" / "green.jpg"), "green")
    os.link(lib / "a" / "red.jpg", lib / "a" / "red hardlink.jpg")
    res = run(index, ScanConfig(roots=[str(lib)], excludes=[]))
    assert res.status == "done"
    assert len(res.groups) == 1
    g = res.groups[0]
    assert len(g.members) == 3 and g.copies == 2
    assert sum(1 for m in g.members if m.hard_link) == 1


def test_hash_reads_bytes_not_text(tmp_path):
    """Without O_BINARY, Windows would turn \\r\\n into \\n while hashing."""
    from clone_ranger.core import hasher
    a, b = tmp_path / "a.bin", tmp_path / "b.bin"
    a.write_bytes(b"line\r\nline\r\n" * 50_000 + b"\x1a end")
    b.write_bytes(b"line\nline\n" * 50_000 + b"\x1a end")
    assert hasher.full_hash(str(a)) != hasher.full_hash(str(b))
    assert hasher.partial_hash(str(a), a.stat().st_size)[0] != hasher.partial_hash(str(b), b.stat().st_size)[0]


def test_excludes_ignore_case_and_slashes(tmp_path):
    from clone_ranger.core.scanner import Excluder, ScanConfig
    ex = Excluder(ScanConfig(roots=[str(tmp_path)], excludes=[str(tmp_path / "Skip").upper().replace("\\", "/")]))
    assert ex.excluded(str(tmp_path / "skip" / "a.jpg"))
    assert not ex.excluded(str(tmp_path / "skipper" / "a.jpg"))
    assert ex.excluded(str(tmp_path / "x" / "$RECYCLE.BIN"))


def test_data_folders_are_in_appdata(monkeypatch):
    from clone_ranger.core import paths
    for var in ("XDG_CONFIG_HOME", "XDG_CACHE_HOME", "XDG_STATE_HOME"):
        monkeypatch.delenv(var, raising=False)
    assert str(paths.config_dir()).lower().startswith(os.environ["APPDATA"].lower())
    assert str(paths.cache_dir()).lower().startswith(os.environ["LOCALAPPDATA"].lower())


def test_not_admin_and_drives():
    from clone_ranger.core import osinfo
    assert not osinfo.is_admin(), "run the tests without 'Run as administrator'"
    assert any(d.upper().startswith(os.environ.get("SystemDrive", "C:").upper()) for d in osinfo.scan_drives())


def test_rename_never_replaces(tmp_path):
    from clone_ranger.core import fsops
    a, b = tmp_path / "a.jpg", tmp_path / "b.jpg"
    a.write_bytes(b"A")
    b.write_bytes(b"B")
    with pytest.raises(FileExistsError):
        fsops.rename_noreplace(str(a), str(b))
    fsops.rename_case_safe(str(a), str(tmp_path / "A.JPG"))            # case-only rename works
    assert sorted(os.listdir(tmp_path)) == ["A.JPG", "b.jpg"]
    assert (tmp_path / "b.jpg").read_bytes() == b"B"


def test_recycle_bin_round_trip(tmp_path):
    """Moves a file it made to the real Recycle Bin, then restores it (like Undo)."""
    from clone_ranger.core import osinfo, trash
    if osinfo.drive_type(str(tmp_path)) != osinfo.DRIVE_FIXED:
        pytest.skip("the temporary folder is not on a local disk")
    f = tmp_path / "clone-ranger-recycle-test.jpg"
    _photo(str(f), "purple")
    data = f.read_bytes()
    t = trash.trash(str(f))
    assert not f.exists()
    assert t.trash_file and os.path.basename(t.trash_file).startswith("$R"), "recycled, but the $R file wasn't found"
    assert os.path.exists(t.trash_file) and os.path.exists(t.info_file)
    trash.restore(t.trash_file, t.info_file, str(f))
    assert f.read_bytes() == data
    assert not os.path.exists(t.trash_file) and not os.path.exists(t.info_file)
