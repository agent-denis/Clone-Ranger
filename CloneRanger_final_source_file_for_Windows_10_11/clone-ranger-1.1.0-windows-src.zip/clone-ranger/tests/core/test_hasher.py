import os

import pytest

from clone_ranger.core import hasher
from clone_ranger.core.control import Cancelled, Control


def write(p, data):
    p.write_bytes(data)
    return str(p)


def test_small_file_partial_is_full(tmp_path):
    data = os.urandom(1000)
    f = write(tmp_path / "small", data)
    partial, is_full = hasher.partial_hash(f, len(data))
    assert is_full
    assert partial == hasher.full_hash(f)
    assert partial.startswith(hasher.ALGO + ":")


def test_boundary_sizes(tmp_path):
    for size in (hasher.SMALL - 1, hasher.SMALL, hasher.SMALL + 1):
        data = os.urandom(size)
        f = write(tmp_path / f"f{size}", data)
        _, is_full = hasher.partial_hash(f, size)
        assert is_full == (size <= hasher.SMALL)


def test_identical_files_identical_hashes(tmp_path):
    data = os.urandom(3 * 1024 * 1024 + 17)
    a, b = write(tmp_path / "a", data), write(tmp_path / "b", data)
    assert hasher.partial_hash(a, len(data)) == hasher.partial_hash(b, len(data))
    assert hasher.full_hash(a) == hasher.full_hash(b)


def test_difference_outside_samples_only_full_hash_sees(tmp_path):
    data = bytearray(os.urandom(2 * 1024 * 1024))
    a = write(tmp_path / "a", bytes(data))
    data[300_000] ^= 1  # not in first / middle / last 64 KB
    b = write(tmp_path / "b", bytes(data))
    assert hasher.partial_hash(a, len(data)) == hasher.partial_hash(b, len(data))
    assert hasher.full_hash(a) != hasher.full_hash(b)


def test_difference_in_middle_partial_hash_sees(tmp_path):
    data = bytearray(os.urandom(2 * 1024 * 1024))
    a = write(tmp_path / "a", bytes(data))
    data[len(data) // 2] ^= 1
    b = write(tmp_path / "b", bytes(data))
    assert hasher.partial_hash(a, len(data)) != hasher.partial_hash(b, len(data))


def test_full_hash_progress_and_cancel(tmp_path):
    data = os.urandom(5 * hasher.FULL_BLOCK)
    f = write(tmp_path / "big", data)
    seen = []
    hasher.full_hash(f, on_bytes=seen.append)
    assert sum(seen) == len(data)

    c = Control()
    c.cancel()
    with pytest.raises(Cancelled):
        hasher.full_hash(f, c)
