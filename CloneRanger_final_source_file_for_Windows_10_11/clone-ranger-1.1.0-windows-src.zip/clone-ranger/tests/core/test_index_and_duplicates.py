import os
import time

import pytest

from clone_ranger.core import duplicates as dup
from clone_ranger.core import hasher
from clone_ranger.core.control import Control
from clone_ranger.core.pipeline import run
from clone_ranger.core.scanner import ScanConfig


def rel(root, p):
    return os.path.relpath(p, root).replace(os.sep, "/")     # "/" like the manifest


def groups_as_sets(root, groups):
    return sorted(sorted(rel(root, m.file.path) for m in g.members) for g in groups)


def test_finds_exactly_the_expected_groups(sample, index):
    root, m = sample
    res = run(index, ScanConfig(roots=[str(root)]))
    assert res.status == "done"
    assert groups_as_sets(root, res.groups) == sorted(m["content_groups"])


def test_hard_links_are_not_counted(sample, index):
    root, m = sample
    res = run(index, ScanConfig(roots=[str(root)]))
    cat = next(g for g in res.groups if any(x.file.name.startswith("cat") for x in g.members))
    links = [x for x in cat.members if x.hard_link]
    assert len(links) == 1 and len(cat.members) == 3
    assert cat.copies == 2
    assert cat.reclaim == cat.size  # 3 paths, 2 real copies -> one copy's worth
    t = res.totals
    assert t["hard_links"] == 1
    assert t["reclaim"] == sum(g.size * (g.copies - 1) for g in res.groups)


def test_same_size_different_content_not_grouped(sample, index):
    root, m = sample
    res = run(index, ScanConfig(roots=[str(root)]))
    grouped = {rel(root, x.file.path) for g in res.groups for x in g.members}
    assert not set(m["same_size_not_duplicates"]) & grouped


def test_rescan_reuses_cached_hashes(sample, index, monkeypatch):
    root, _ = sample
    run(index, ScanConfig(roots=[str(root)]))
    calls = {"partial": 0, "full": 0}
    real_p, real_f = hasher.partial_hash, hasher.full_hash

    def p(*a, **k):
        calls["partial"] += 1
        return real_p(*a, **k)

    def f(*a, **k):
        calls["full"] += 1
        return real_f(*a, **k)

    monkeypatch.setattr(hasher, "partial_hash", p)
    monkeypatch.setattr(hasher, "full_hash", f)
    run(index, ScanConfig(roots=[str(root)]))
    assert calls == {"partial": 0, "full": 0}, "unchanged files must not be re-hashed"

    # change one file's content (same size) -> only that file is hashed again
    target = root / "Downloads" / "IMG_2041 (1).jpg"
    data = bytearray(target.read_bytes())
    data[len(data) // 2] ^= 0xFF
    target.write_bytes(bytes(data))
    os.utime(target, ns=(time.time_ns(), time.time_ns() + 5_000_000_000))
    res = run(index, ScanConfig(roots=[str(root)]))
    assert calls["partial"] == 1
    img = next(g for g in res.groups if any(x.file.name.startswith("IMG_2041") for x in g.members))
    assert len(img.members) == 2


def test_deleted_files_leave_the_index(sample, index):
    root, _ = sample
    run(index, ScanConfig(roots=[str(root)]))
    before = index.count()
    (root / "Backup" / "Photos" / "IMG_2041.jpg").unlink()   # inside the test's own temp folder
    res = run(index, ScanConfig(roots=[str(root)]))
    assert res.removed == 1
    assert index.count() == before - 1


def test_cancelled_scan_keeps_index(sample, index):
    root, _ = sample
    run(index, ScanConfig(roots=[str(root)]))
    before = index.count()
    c = Control()
    c.cancel()
    res = run(index, ScanConfig(roots=[str(root)]), c)
    assert res.status == "cancelled"
    assert index.count() == before


def test_name_groups(sample, index):
    root, m = sample
    run(index, ScanConfig(roots=[str(root)]))
    groups = {g.key: g for g in dup.find_name_groups(index)}
    assert groups["holiday.jpg"].content == "different"
    assert groups["IMG_2041.jpg"].content == "same"
    assert "img_2041.jpg" not in groups
    ci = {g.key for g in dup.find_name_groups(index, ignore_case=True)}
    assert "img_2041.jpg" in ci
    noext = {g.key for g in dup.find_name_groups(index, ignore_ext=True)}
    assert "holiday" in noext


def test_hash_algorithm_is_recorded(sample, index):
    root, _ = sample
    res = run(index, ScanConfig(roots=[str(root)]))
    assert all(g.hash.startswith(hasher.ALGO + ":") for g in res.groups)


def test_hashes_from_another_algorithm_are_forgotten(tmp_path):
    """An index written by an install with BLAKE3 must not be mixed with BLAKE2b hashes (or vice versa)."""
    from clone_ranger.core import hasher
    from clone_ranger.core.index import Index
    other = "b2" if hasher.ALGO == "b3" else "b3"
    idx = Index(tmp_path / "i.sqlite")
    idx.db.execute("INSERT INTO files (path, dir, name, size, mtime_ns, dev, ino, kind, fmt, partial, full, scan_id) "
                   "VALUES ('/a.jpg', '/', 'a.jpg', 5, 1, 1, 1, 'image', 'jpeg', ?, ?, 1)",
                   (f"{other}:aa", f"{other}:bb"))
    idx.db.execute("INSERT INTO files (path, dir, name, size, mtime_ns, dev, ino, kind, fmt, partial, full, scan_id) "
                   "VALUES ('/b.jpg', '/', 'b.jpg', 5, 1, 1, 2, 'image', 'jpeg', ?, ?, 1)",
                   (f"{hasher.ALGO}:cc", f"{hasher.ALGO}:dd"))
    idx.db.commit()
    idx.close()
    idx = Index(tmp_path / "i.sqlite")                  # reopening cleans up
    rows = {r.path: (r.partial, r.full) for r in idx.all_files()}
    assert rows["/a.jpg"] == (None, None)
    assert rows["/b.jpg"] == (f"{hasher.ALGO}:cc", f"{hasher.ALGO}:dd")
    idx.close()
