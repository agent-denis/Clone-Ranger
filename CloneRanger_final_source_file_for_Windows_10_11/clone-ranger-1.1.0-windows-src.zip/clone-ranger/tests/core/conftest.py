"""Fixtures for core tests. EVERYTHING happens inside pytest's own temporary folders."""
import importlib.util
import os
import sys
import tempfile
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[2]


def _load_tool(name):
    spec = importlib.util.spec_from_file_location(name, ROOT / "tools" / f"{name}.py")
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


@pytest.fixture
def sample(tmp_path):
    """A freshly generated sample library inside tmp_path, plus its manifest."""
    tool = _load_tool("make_sample_library")
    root = tmp_path / "library"
    manifest = tool.build(root)
    yield root, manifest
    tool.make_readable(root)  # undo chmod 000 so pytest can clean up


@pytest.fixture
def index(tmp_path):
    from clone_ranger.core.index import Index
    idx = Index(tmp_path / "index.sqlite")
    yield idx
    idx.close()


def is_root():
    return hasattr(os, "geteuid") and os.geteuid() == 0


def can_symlink() -> bool:
    """Windows only lets you create symlinks with Developer Mode on or as administrator (WinError 1314)."""
    if sys.platform != "win32":
        return True
    with tempfile.TemporaryDirectory() as d:
        try:
            os.symlink(d, os.path.join(d, "link"), target_is_directory=True)
            return True
        except OSError:
            return False


linux_only = pytest.mark.skipif(sys.platform == "win32", reason="Linux only")
needs_symlinks = pytest.mark.skipif(not can_symlink(), reason="Windows refuses symlinks without Developer Mode")
