import os

import pytest

from clone_ranger.core.control import Cancelled, Control
from clone_ranger.core.scanner import FileEntry, ScanConfig, Skipped, scan

from .conftest import is_root, linux_only


def run(cfg):
    items = list(scan(cfg))
    return [i for i in items if isinstance(i, FileEntry)], [i for i in items if isinstance(i, Skipped)]


def rel(root, paths):
    return {os.path.relpath(p, root).replace(os.sep, "/") for p in paths}     # "/" like the manifest


def test_finds_media_and_respects_traps(sample):
    root, m = sample
    files, skipped = run(ScanConfig(roots=[str(root)]))
    found = rel(root, [f.path for f in files])
    for group in m["content_groups"]:
        assert set(group) <= found
    for trap in m["must_not_index"]:
        assert trap not in found, trap
    assert all(".git" not in p and ".snapshots" not in p for p in found)
    assert not any(p.startswith("Pictures/link_to_family") for p in found), "symlinks must not be followed"


@linux_only        # Windows: chmod 000 only sets "read-only", the file stays readable
@pytest.mark.skipif(is_root(), reason="root can read chmod 000 files")
def test_unreadable_files_are_skipped_not_fatal(sample):
    root, m = sample
    _, skipped = run(ScanConfig(roots=[str(root)]))
    got = rel(root, [s.path for s in skipped])
    assert set(m["must_skip"]) <= got
    assert all(s.reason for s in skipped)


def test_explicit_root_inside_excluded_location(tmp_path):
    """/tmp is excluded by default, but a folder the user explicitly picks there is scanned."""
    (tmp_path / "a.jpg").write_bytes(b"\xff\xd8\xff\xe0" + b"\0" * 20)
    files, _ = run(ScanConfig(roots=[str(tmp_path)]))
    assert len(files) == 1


def test_exclusions_inside_root_still_apply(tmp_path):
    (tmp_path / "keep").mkdir()
    (tmp_path / "skip").mkdir()
    for d in ("keep", "skip"):
        (tmp_path / d / "a.jpg").write_bytes(b"\xff\xd8\xff\xe0" + b"\0" * 20)
    cfg = ScanConfig(roots=[str(tmp_path)])
    cfg.excludes.append(str(tmp_path / "skip"))
    files, _ = run(cfg)
    assert rel(tmp_path, [f.path for f in files]) == {"keep/a.jpg"}


def test_glob_exclusion_and_names(tmp_path):
    for d in ("Photos/cache", "Photos/real", "Trash-like/.Trash-1000"):
        (tmp_path / d).mkdir(parents=True)
        (tmp_path / d / "a.png").write_bytes(b"\x89PNG\r\n\x1a\n" + b"\0" * 20)
    cfg = ScanConfig(roots=[str(tmp_path)])
    cfg.excludes.append(str(tmp_path) + "/*/cache")
    files, _ = run(cfg)
    assert rel(tmp_path, [f.path for f in files]) == {"Photos/real/a.png"}


def test_empty_files_ignored(tmp_path):
    (tmp_path / "empty.jpg").write_bytes(b"")
    files, _ = run(ScanConfig(roots=[str(tmp_path)]))
    assert files == []


def test_missing_root_reported(tmp_path):
    _, skipped = run(ScanConfig(roots=[str(tmp_path / "nope")]))
    assert len(skipped) == 1


def test_cancel_stops_scan(sample):
    root, _ = sample
    c = Control()
    c.cancel()
    with pytest.raises(Cancelled):
        list(scan(ScanConfig(roots=[str(root)]), c))


@linux_only        # Windows: chmod 000 only sets "read-only", the file stays readable
@pytest.mark.skipif(is_root(), reason="root can read chmod 000 files")
def test_rescan_does_not_open_unchanged_files(tmp_path):
    """A rescan trusts the index for files whose size, mtime and inode are unchanged (no open() at all),
    but re-checks a file that changed."""
    from clone_ranger.core.index import Index
    from clone_ranger.core.pipeline import run
    from clone_ranger.core.scanner import ScanConfig
    lib = tmp_path / "lib"
    lib.mkdir()
    keep = lib / "a.jpg"
    keep.write_bytes(b"\xff\xd8\xff\xe0" + b"x" * 500)
    changed = lib / "b.jpg"
    changed.write_bytes(b"\xff\xd8\xff\xe0" + b"y" * 500)
    idx = Index(tmp_path / "i.sqlite")
    cfg = ScanConfig(roots=[str(lib)], excludes=[])
    assert run(idx, cfg, find_duplicates=False).files == 2
    keep.chmod(0)                       # unreadable now - but unchanged (chmod doesn't touch mtime)
    changed.write_text("now a text file, not a JPEG")
    try:
        res = run(idx, cfg, find_duplicates=False)
        assert res.files == 1 and res.skipped == 0            # a.jpg kept without being opened
        assert {r.name for r in idx.all_files()} == {"a.jpg"}  # b.jpg re-checked and dropped
    finally:
        keep.chmod(0o644)
        idx.close()
