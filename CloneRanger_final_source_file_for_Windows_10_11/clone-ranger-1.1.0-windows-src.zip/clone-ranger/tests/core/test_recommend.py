from clone_ranger.core.recommend import Candidate, has_copy_marker, recommend, temp_score

GiB = 1 << 30


def c(path, mtime=1000, birth=None, w=None, h=None, protected=False):
    return Candidate(path=path, size=GiB, mtime_ns=mtime, birth_ns=birth, width=w, height=h, protected=protected)


def test_copy_markers():
    for name in ("IMG_2041 (1)", "DSC_0193 - Copy", "photo copy", "holiday_2", "Copy of x"[0:0] + "x copy",
                 "фото копия"):
        assert has_copy_marker(name), name
    for name in ("IMG_2041", "holiday", "Summer 2024", "DSC_0193"):
        assert not has_copy_marker(name), name


def test_downloads_loses_even_inside_tmp():
    assert temp_score("/tmp/x/lib/Downloads/a.jpg") > temp_score("/tmp/x/lib/Pictures/a.jpg")
    keep, reason = recommend([c("/tmp/x/lib/Downloads/cat.webp"), c("/tmp/x/lib/Pictures/Pets/cat.webp")])
    assert keep == 1 and "Downloads" in reason


def test_clean_name_beats_copy_name():
    keep, reason = recommend([c("/home/a/x/IMG (1).jpg"), c("/home/a/y/IMG.jpg")])
    assert keep == 1 and "copy" in reason


def test_oldest_uses_creation_date_when_mtimes_match():
    keep, reason = recommend([c("/data/b/IMG.jpg", mtime=5, birth=20), c("/data/a/IMG.jpg", mtime=5, birth=10)])
    assert keep == 1 and "oldest" in reason


def test_highest_resolution_wins_before_age():
    keep, _ = recommend([c("/d/a.jpg", mtime=1, w=100, h=100), c("/d/b.jpg", mtime=9, w=4000, h=3000)])
    assert keep == 1


def test_protected_always_wins():
    keep, reason = recommend([c("/home/u/Pictures/a.jpg"), c("/home/u/Downloads/a (1).jpg", protected=True)])
    assert keep == 1 and "protected" in reason


def test_rule_config_order_and_switches():
    from clone_ranger.core.recommend import build_rules, default_config, normalize_config
    keys = [r.key for r in build_rules()]
    assert keys[0] == "protected" and "newest" not in keys and "oldest" in keys
    # newest before oldest -> the newer copy wins
    cfg = [["newest", True], ["oldest", True]]
    cands = [c("/data/a/IMG.jpg", mtime=10), c("/data/b/IMG.jpg", mtime=20)]
    keep, reason = recommend(cands, build_rules(cfg, preferred=[]))
    assert keep == 1 and "newest" in reason
    keep, _ = recommend(cands, build_rules(default_config(), preferred=[]))
    assert keep == 0
    # the protected rule can't be removed or switched off, junk is dropped, missing rules come back off
    n = normalize_config([["protected", False], ["bogus", True], ["oldest", True], ["oldest", False]])
    assert n[0] == ["protected", True] and ["oldest", True] in n and not any(k == "bogus" for k, _ in n)
    assert len(n) == len(default_config()) and dict(n)["shortest"] is False


def test_preferred_folders_from_settings():
    from clone_ranger.core.recommend import build_rules
    cands = [c("/media/archive/IMG.jpg", mtime=10), c("/srv/photos/IMG.jpg", mtime=20)]
    keep, reason = recommend(cands, build_rules(None, preferred=["/srv/photos"]))
    assert keep == 1 and "preferred" in reason
