"""Reset to defaults / clear history / clear cache.

Everything happens in the temporary XDG folders set up by tests/conftest.py.
"""
import json
import os

from clone_ranger.core import housekeeping, paths
from clone_ranger.core.journal import Item, Journal
from clone_ranger.core.settings import DEFAULTS, Settings

from .conftest import needs_symlinks


def _fill_cache():
    c = paths.ensure(paths.cache_dir())
    for f in housekeeping.INDEX_FILES[:3]:
        (c / f).write_bytes(b"x" * 100)
    t = paths.ensure(paths.thumbs_dir() / "ab")
    (t / "thumb.jpg").write_bytes(b"y" * 50)
    return c


def _fill_history():
    j = Journal()
    paths.ensure(paths.state_dir())
    o = j.begin("trash")
    j.item(o, Item(src="/tmp/a.jpg", status="ok"))
    j.end(o, "done")
    (paths.state_dir() / "journal.old.jsonl").write_text("{}\n")
    (paths.state_dir() / "clone-ranger.log").write_text("log line\n")
    (paths.state_dir() / "clone-ranger.log.1").write_text("old log\n")
    return j


def test_clear_cache_removes_index_and_thumbnails_only(tmp_path):
    c = _fill_cache()
    keep = c / "something-else.txt"          # not ours to delete
    keep.write_text("keep me")
    assert housekeeping.cache_size() == 350
    r = housekeeping.clear_cache()
    assert r.freed == 350
    assert not any((c / f).exists() for f in housekeeping.INDEX_FILES)
    assert not paths.thumbs_dir().exists()
    assert keep.read_text() == "keep me"
    assert housekeeping.cache_size() == 0
    housekeeping.clear_cache()                # nothing left: no error


@needs_symlinks
def test_clear_cache_never_follows_a_symlinked_thumbs_folder(tmp_path):
    photos = tmp_path / "photos"
    photos.mkdir()
    (photos / "IMG_1.jpg").write_bytes(b"precious")
    paths.ensure(paths.cache_dir())
    os.symlink(photos, paths.thumbs_dir())
    housekeeping.clear_cache()
    assert not paths.thumbs_dir().is_symlink()
    assert (photos / "IMG_1.jpg").read_bytes() == b"precious"


def test_clear_history_forgets_actions_logs_and_remembered_folders():
    j = _fill_history()
    assert j.last_undoable() is not None or j.orders()
    s = Settings()
    s["last_roots"] = ["/home/x/Pictures"]
    s["last_move_dest"] = "/home/x/Sorted"
    s["theme"] = "dark"
    r = housekeeping.clear_history(s)
    st = paths.state_dir()
    assert not (st / "journal.jsonl").exists() and not (st / "journal.old.jsonl").exists()
    assert (st / "clone-ranger.log").read_text() == ""        # emptied, not deleted (the app keeps it open)
    assert not (st / "clone-ranger.log.1").exists()
    assert Journal().orders() == [] and Journal().last_undoable() is None
    assert s["last_roots"] == [] and s["last_move_dest"] is None
    assert s["theme"] == "dark"                                # not a history setting
    assert set(r.settings_reset) == {"last_roots", "last_move_dest"}


def test_reset_search_only_touches_search_settings():
    s = Settings()
    s["roots"] = ["/data/photos"]
    s["excludes"] = ["*.tmp"]
    s["entire_computer"] = True
    s["min_size"] = 4096
    s["name_ignore_case"] = False
    s["theme"] = "light"
    s["protected_folders"] = ["/data/keep"]
    s["last_roots"] = ["/data/photos"]
    _fill_cache()
    housekeeping.reset(s, search=True)
    for k in ("roots", "excludes", "entire_computer", "min_size", "name_ignore_case"):
        assert s[k] == DEFAULTS[k], k
    assert s["theme"] == "light" and s["protected_folders"] == ["/data/keep"]
    assert s["last_roots"] == ["/data/photos"]
    assert housekeeping.cache_size() > 0                      # cache untouched
    saved = json.loads(s.path.read_text())
    assert saved["roots"] is None and saved["theme"] == "light"


def test_reset_everything_starts_from_scratch():
    s = Settings()
    s["roots"] = ["/data/photos"]
    s["theme"] = "light"
    s["keep_rules"] = [["oldest", True]]
    s["last_move_dest"] = "/data/sorted"
    _fill_cache()
    _fill_history()
    r = housekeeping.reset(s, search=True, preferences=True, history=True, cache=True)
    assert all(s[k] == DEFAULTS[k] for k in DEFAULTS)
    assert housekeeping.cache_size() == 0
    assert Journal().orders() == []
    assert r.freed > 0 and r.removed


def test_defaults_are_not_shared_mutable_objects():
    s = Settings()
    housekeeping.reset(s, history=True, search=False)
    s["last_roots"].append("/x")
    assert DEFAULTS["last_roots"] == []

