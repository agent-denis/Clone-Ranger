"""The Windows-specific parts, tested on Linux where possible (pure logic, no Windows calls)."""
import os
import time

import pytest

from clone_ranger.core import bulk_rename, osinfo, paths, recycle_bin
from clone_ranger.theme.strings import STRINGS, windows_wording


def test_windows_paths_compare_without_case_and_with_either_slash():
    w = True
    assert osinfo.is_within(r"C:\Users\Ana\Pictures\a.jpg", "c:/users/ana", windows=w)
    assert osinfo.is_within(r"C:\Users\Ana", r"C:\Users\Ana\\", windows=w)
    assert osinfo.is_within("D:\\photo.jpg", "D:\\", windows=w)
    assert not osinfo.is_within(r"C:\Users\Anabel\a.jpg", r"C:\Users\Ana", windows=w)
    assert not osinfo.is_within(r"D:\Users\Ana\a.jpg", r"C:\Users\Ana", windows=w)


def test_linux_paths_stay_case_sensitive():
    assert osinfo.is_within("/home/ana/Pictures/a.jpg", "/home/ana", windows=False)
    assert not osinfo.is_within("/home/Ana/a.jpg", "/home/ana", windows=False)
    assert not osinfo.is_within("/home/anabel", "/home/ana", windows=False)
    assert osinfo.is_within("/x", "/", windows=False)


def test_windows_data_folders(monkeypatch, tmp_path):
    for var in ("XDG_CONFIG_HOME", "XDG_CACHE_HOME", "XDG_STATE_HOME"):
        monkeypatch.delenv(var, raising=False)
    monkeypatch.setattr(paths, "WINDOWS", True)
    monkeypatch.setenv("APPDATA", str(tmp_path / "Roaming"))
    monkeypatch.setenv("LOCALAPPDATA", str(tmp_path / "Local"))
    assert paths.config_dir() == tmp_path / "Roaming" / "Clone Ranger"
    assert paths.cache_dir() == tmp_path / "Local" / "Clone Ranger" / "cache"
    assert paths.state_dir() == tmp_path / "Local" / "Clone Ranger" / "state"
    monkeypatch.setenv("XDG_CACHE_HOME", str(tmp_path / "xdg"))        # the tests' override still wins
    assert paths.cache_dir() == tmp_path / "xdg" / "clone-ranger"


def test_recycle_bin_info_file_round_trip():
    now = time.time_ns() // 100 * 100
    data = recycle_bin.build_info(r"C:\Users\Ana\Pictures\Ünïcode photo.jpg", 4812, now)
    assert recycle_bin.parse_info(data) == (r"C:\Users\Ana\Pictures\Ünïcode photo.jpg", 4812, now)


def test_recycle_bin_info_version_1_and_junk():
    import struct
    path = r"C:\old\a.jpg"
    v1 = struct.pack("<qqq", 1, 10, recycle_bin.FILETIME_EPOCH) + (path + "\0").encode("utf-16-le").ljust(520, b"\0")
    assert recycle_bin.parse_info(v1) == (path, 10, 0)
    assert recycle_bin.parse_info(b"short") is None
    assert recycle_bin.parse_info(struct.pack("<qqq", 7, 0, 0) + b"\0" * 40) is None


def _fake_bin(folder, original, suffix, deleted_ns):
    os.makedirs(folder, exist_ok=True)
    with open(os.path.join(folder, "$I" + suffix), "wb") as f:
        f.write(recycle_bin.build_info(original, 3, deleted_ns))
    with open(os.path.join(folder, "$R" + suffix), "wb") as f:
        f.write(b"abc")


def test_find_recycled_picks_the_newest_pair_for_that_path(tmp_path):
    b = str(tmp_path / "$Recycle.Bin" / "S-1-5-21-1")
    target = str(tmp_path / "Pictures" / "a.jpg")
    _fake_bin(b, target, "AAAAAA.jpg", 1_000)
    _fake_bin(b, target, "BBBBBB.jpg", 2_000)
    _fake_bin(b, str(tmp_path / "other.jpg"), "CCCCCC.jpg", 3_000)
    os.remove(os.path.join(b, "$RAAAAAA.jpg"))
    found = recycle_bin.find_recycled(target, [b, str(tmp_path / "missing")], 0)
    assert found == (os.path.join(b, "$RBBBBBB.jpg"), os.path.join(b, "$IBBBBBB.jpg"))
    assert recycle_bin.find_recycled(str(tmp_path / "nothing.jpg"), [b], 0) is None
    assert recycle_bin.find_recycled(target, [b], time.time_ns() + 10**12) is None   # only recent ones are read


def test_recycle_bin_restore_never_replaces(tmp_path):
    b = str(tmp_path / "$Recycle.Bin" / "S-1")
    original = str(tmp_path / "Pictures" / "deep" / "a.jpg")
    _fake_bin(b, original, "XYZ123.jpg", 1)
    r, i = os.path.join(b, "$RXYZ123.jpg"), os.path.join(b, "$IXYZ123.jpg")
    recycle_bin.restore(r, i, original)
    assert open(original, "rb").read() == b"abc" and not os.path.exists(r) and not os.path.exists(i)
    from clone_ranger.core import fsops
    with pytest.raises(fsops.Changed):
        recycle_bin.restore(r, i, original)
    with pytest.raises(fsops.Changed):
        recycle_bin.restore("", "", original)


def test_windows_wording():
    assert windows_wording(STRINGS["trash_note"]) == \
        "Files go to the Recycle Bin and can be restored from the Recycle Bin."
    assert windows_wording(STRINGS["move_to_trash"]) == "Move to Recycle Bin"
    assert windows_wording(STRINGS["no_trash_title"]) == "No Recycle Bin on this drive"
    assert all("Trash" not in windows_wording(v) for v in STRINGS.values())


def test_windows_file_names(monkeypatch):
    monkeypatch.setattr(bulk_rename, "WINDOWS", True)
    assert "“:”" in bulk_rename.check_name("12:30.jpg")
    assert "“?”" in bulk_rename.check_name("what?.jpg")
    assert bulk_rename.check_name("photo.") == "ends with a dot"
    assert "reserves" in bulk_rename.check_name("con.jpg")
    assert bulk_rename.check_name("console.jpg") == ""
    assert bulk_rename.check_name("IMG 2041 (1).jpg") == ""
    monkeypatch.setattr(bulk_rename, "WINDOWS", False)
    assert bulk_rename.check_name("12:30.jpg") == ""


@pytest.mark.parametrize("first", ["recycle_bin", "trash"])
def test_trash_modules_import_in_any_order_on_windows(first):
    """Regression: on Windows trash.py imports recycle_bin.py; importing recycle_bin first
    used to fail with "partially initialized module" (a circular import)."""
    import subprocess
    import sys
    code = (
        "import clone_ranger.core.osinfo as o; o.WINDOWS = True\n"
        f"import clone_ranger.core.{first}\n"
        "from clone_ranger.core import trash, recycle_bin\n"
        "assert trash.trash is recycle_bin.trash\n"
        "assert trash.restore is recycle_bin.restore\n"
        "assert trash.can_trash is recycle_bin.can_trash\n"
        "assert recycle_bin.TrashUnavailable is trash.TrashUnavailable\n"
    )
    root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    r = subprocess.run([sys.executable, "-c", code], cwd=root, capture_output=True, text=True)
    assert r.returncode == 0, r.stderr


# --------------------------------------------------------------------------- big Windows file IDs
def test_db_int_fits_sqlite_and_leaves_normal_numbers_alone():
    from clone_ranger.core.osinfo import db_int
    lo, hi = -(1 << 63), (1 << 63) - 1
    for v in (0, 1, 123456789, hi, -5, lo):
        assert db_int(v) == v                                  # Linux inodes, existing indexes: unchanged
    ntfs = (0x8001 << 48) | 0x1234                             # NTFS: sequence number in the top 16 bits
    refs = (1 << 127) | 0xABCDEF                               # ReFS: 128-bit file ID (Python 3.12+)
    for v in (ntfs, (1 << 64) - 1, refs, 1 << 200):
        assert lo <= db_int(v) <= hi
        assert db_int(db_int(v)) == db_int(v)                  # safe to apply twice
    assert db_int((1 << 64) - 1) == -1                         # 64-bit IDs wrap exactly, no collisions
    many = [(1 << 127) + i for i in range(5000)] + [(1 << 63) + i for i in range(5000)]
    assert len({db_int(v) for v in many}) == len(many)


def test_scan_with_huge_windows_file_ids(sample, index, monkeypatch):
    """Scanning a whole Windows drive failed with "OverflowError: Python int too large to convert to SQLite
    INTEGER": some file IDs / volume serials don't fit in a signed 64-bit number. Same scan, with every file ID
    and drive ID made that big: it must finish, find the same groups and still recognise hard links."""
    import dataclasses

    from clone_ranger.core import pipeline
    from clone_ranger.core.scanner import FileEntry, ScanConfig

    real_scan = pipeline.scan

    def huge_ids(*a, **kw):
        for item in real_scan(*a, **kw):
            if isinstance(item, FileEntry):
                item = dataclasses.replace(item, dev=item.dev | (1 << 63), ino=item.ino | (1 << 127))
            yield item

    root, m = sample
    normal = pipeline.run(index, ScanConfig(roots=[str(root)]))
    monkeypatch.setattr(pipeline, "scan", huge_ids)
    big = pipeline.run(index, ScanConfig(roots=[str(root)]))
    assert big.status == "done" and big.files == normal.files
    as_sets = sorted(sorted(x.file.path for x in g.members) for g in big.groups)
    assert as_sets == sorted(sorted(x.file.path for x in g.members) for g in normal.groups)
    assert big.totals["hard_links"] == normal.totals["hard_links"]


def test_hard_link_with_another_name_is_not_a_case_rename(monkeypatch, tmp_path):
    """Windows run (2026-11-19): renaming a.jpg to b.jpg, where b.jpg is a hard link to the same file, was let
    through as if it were a case-only rename (photo.JPG -> photo.jpg). The name b.jpg is taken: refuse."""
    from clone_ranger.core import fsops
    monkeypatch.setattr(fsops, "WINDOWS", True)
    monkeypatch.setattr(fsops, "_renameat2", None)          # take the Windows code path
    a = tmp_path / "a.jpg"
    a.write_bytes(b"A")
    os.link(a, tmp_path / "b.jpg")
    # On a case-insensitive drive (Windows) A.JPG already *is* a.jpg; on Linux make it a hard link to fake that.
    case_insensitive = (tmp_path / "A.JPG").exists()
    if not case_insensitive:
        os.link(a, tmp_path / "A.JPG")
    assert not fsops.is_case_only_rename(str(a), str(tmp_path / "b.jpg"))
    assert fsops.is_case_only_rename(str(a), str(tmp_path / "A.JPG"))     # same name, other case, same file
    assert not fsops.is_case_only_rename(str(a), str(a))
    with pytest.raises(FileExistsError):
        fsops.rename_noreplace(str(a), str(tmp_path / "b.jpg"))
    with pytest.raises(FileExistsError):
        fsops.rename_case_safe(str(a), str(tmp_path / "b.jpg"))
    assert a.exists() and (tmp_path / "b.jpg").exists()
    expected = ["a.jpg", "b.jpg"] if case_insensitive else ["A.JPG", "a.jpg", "b.jpg"]
    assert sorted(p.name for p in tmp_path.iterdir()) == expected


def test_temp_folders_found_with_either_slash(monkeypatch):
    from clone_ranger.core import recommend
    assert recommend.temp_score("/x/Downloads/a.jpg") == 1
    monkeypatch.setattr(recommend.os, "sep", "\\")
    assert recommend.temp_score("C:\\Users\\d\\Downloads\\a.jpg") == 1
    assert recommend.temp_score("C:/Users/d/Downloads/a.jpg") == 1
