"""Bulk rename planning: pure, no files touched."""
import os

from clone_ranger.core.bulk_rename import File, Options, check_name, plan


def names(p):
    return [i.new_name for i in p.items]


def F(*paths, **kw):
    return [File(p, **kw) for p in paths]


NONE = lambda _p: False   # noqa: E731 - nothing exists on "disk"


def test_find_replace_plain_and_case():
    files = F("/a/IMG_0001.JPG", "/a/img_0002.jpg")
    assert names(plan(files, Options(find="img_", replace="Trip-"), NONE)) == ["Trip-0001.JPG", "Trip-0002.jpg"]
    assert names(plan(files, Options(find="img_", replace="Trip-", match_case=True), NONE)) == \
        ["IMG_0001.JPG", "Trip-0002.jpg"]


def test_regex_with_groups_and_bad_regex():
    files = F("/a/IMG_0001.jpg")
    p = plan(files, Options(find=r"IMG_(\d+)", replace=r"photo-\1", regex=True), NONE)
    assert names(p) == ["photo-0001.jpg"]
    bad = plan(files, Options(find="(", regex=True), NONE)
    assert bad.error and bad.items[0].status == "invalid"


def test_extension_is_protected_unless_included():
    files = F("/a/pic.jpg")
    assert names(plan(files, Options(find="jpg", replace="png"), NONE)) == ["pic.jpg"]
    assert names(plan(files, Options(find="jpg", replace="png", include_ext=True), NONE)) == ["pic.png"]


def test_prefix_suffix_numbering_case_ext():
    files = F("/a/b.JPEG", "/a/c.JPEG", "/a/d.JPEG")
    o = Options(prefix="Trip ", suffix="!", numbering=True, num_start=9, num_digits=2, num_sep="-",
                case="lower", ext="lower")
    assert names(plan(files, o, NONE)) == ["Trip b!-09.jpeg", "Trip c!-10.jpeg", "Trip d!-11.jpeg"]
    o = Options(numbering=True, num_position="prefix", ext="change", new_ext=".jpg", case="upper")
    assert names(plan(files, o, NONE)) == ["001_B.jpg", "002_C.jpg", "003_D.jpg"]


def test_date_taken_names_with_fallback_and_conflicts():
    files = [File("/a/x.jpg", taken="2024-07-01 18:22:05"), File("/a/y.jpg", taken="2024-07-01 18:22:05"),
             File("/a/z.jpg", mtime_ns=0)]
    p = plan(files, Options(date_name=True), NONE)
    assert p.items[0].new_name == "2024-07-01_18-22-05.jpg" and p.items[0].status == "ok"
    assert p.items[1].status == "conflict"                     # same second
    assert p.items[2].status == "invalid" and p.items[2].reason == "no date taken"
    p = plan(files, Options(date_name=True, auto_number_conflicts=True), NONE)
    assert p.items[1].new_name == "2024-07-01_18-22-05_2.jpg" and p.items[1].status == "ok"


def test_conflicts_with_existing_files_and_swaps():
    existing = {os.path.join("/a", "new.jpg")}
    p = plan(F("/a/old.jpg"), Options(find="old", replace="new"), lambda q: q in existing)
    assert p.items[0].status == "conflict"
    # 1 -> 2 while 2 -> 3: the name 2.jpg is freed by the same order, so it's fine
    on_disk = {os.path.join("/a", "1.jpg"), os.path.join("/a", "2.jpg")}
    p = plan(F("/a/1.jpg", "/a/2.jpg"), Options(find=".*", replace="", regex=True, numbering=True,
                                                num_start=2, num_digits=1, num_sep=""), lambda q: q in on_disk)
    assert names(p) == ["2.jpg", "3.jpg"] and all(i.status == "ok" for i in p.items)


def test_unchanged_and_staying_files_block_their_names():
    p = plan(F("/a/x.jpg", "/a/y.jpg"), Options(find="y", replace="x"), NONE)
    assert p.items[0].status == "unchanged"
    assert p.items[1].status == "conflict"                     # x.jpg keeps its name


def test_check_name():
    assert check_name("a/b.jpg") and check_name("") and check_name("..") and check_name(" x.jpg")
    assert check_name("é" * 200)                               # > 255 bytes in UTF-8
    assert check_name("ok name.jpg") == ""
