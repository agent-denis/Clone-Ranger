"""Btrfs reflink detection. Needs a reflink-capable filesystem; /tmp is usually tmpfs, so the
test makes its own temporary folder under ~/.cache (and removes it again)."""
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

import pytest

from clone_ranger.core.reflink import is_shared

pytestmark = pytest.mark.skipif(sys.platform == "win32", reason="Linux reflinks (FIEMAP, cp --reflink)")


@pytest.fixture
def cow_dir():
    base = Path.home() / ".cache"
    base.mkdir(exist_ok=True)
    d = Path(tempfile.mkdtemp(prefix="clone-ranger-test-", dir=base))
    try:
        yield d
    finally:
        shutil.rmtree(d)


def test_reflink_copies_are_shared(cow_dir):
    a = cow_dir / "a.bin"
    a.write_bytes(b"x" * 300_000)
    r = subprocess.run(["cp", "--reflink=always", str(a), str(cow_dir / "b.bin")], capture_output=True)
    if r.returncode != 0:
        pytest.skip("filesystem does not support reflinks")
    subprocess.run(["cp", "--reflink=never", str(a), str(cow_dir / "c.bin")], check=True)
    subprocess.run(["sync", "-f", str(a)], check=True)
    assert is_shared(str(a)) is True
    assert is_shared(str(cow_dir / "b.bin")) is True
    assert is_shared(str(cow_dir / "c.bin")) is False


def test_missing_file_is_unknown(tmp_path):
    assert is_shared(str(tmp_path / "missing")) is None
