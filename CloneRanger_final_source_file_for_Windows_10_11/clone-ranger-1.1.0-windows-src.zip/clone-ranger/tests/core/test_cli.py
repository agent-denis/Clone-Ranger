import csv

from clone_ranger.core import cli


def test_cli_scan_report_info(sample, tmp_path, capsys):
    root, m = sample
    db = str(tmp_path / "cli.sqlite")
    assert cli.main(["--db", db, "scan", str(root), "--list"]) == 0
    out = capsys.readouterr().out
    assert f"Groups ............. {len(m['content_groups'])}" in out
    assert "hard link of" in out

    report = tmp_path / "report.csv"
    assert cli.main(["--db", db, "report", "--csv", str(report)]) == 0
    rows = list(csv.DictReader(report.open()))
    assert {r["case"] for r in rows} == {str(i) for i in range(1, len(m["content_groups"]) + 1)}
    assert any(r["hard_link_of"] for r in rows)

    assert cli.main(["--db", db, "info"]) == 0
    assert "Media files" in capsys.readouterr().out


def test_cli_refuses_root(monkeypatch, capsys):
    monkeypatch.setattr(cli, "is_admin", lambda: True)      # root on Linux, administrator on Windows
    assert cli.main(["info"]) == 1
    assert "refuses to run as root" in capsys.readouterr().err
