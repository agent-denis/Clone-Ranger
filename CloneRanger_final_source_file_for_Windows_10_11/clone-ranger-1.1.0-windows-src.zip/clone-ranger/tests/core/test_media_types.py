from clone_ranger.core.media_types import classify, sniff

SAMPLES = {
    b"\xff\xd8\xff\xe0\x00\x10JFIF": ("image", "jpeg"),
    b"\x89PNG\r\n\x1a\n" + b"\0" * 8: ("image", "png"),
    b"GIF89a" + b"\0" * 8: ("image", "gif"),
    b"RIFF\0\0\0\0WEBPVP8 ": ("image", "webp"),
    b"RIFF\0\0\0\0AVI LIST": ("video", "avi"),
    b"II*\0\x10\0\0\0CR\x02\0": ("image", "cr2"),
    b"II*\0\x08\0\0\0": ("image", "tiff"),
    b"IIRO\x08\0\0\0": ("image", "orf"),
    b"IIU\0\x18\0\0\0": ("image", "rw2"),
    b"FUJIFILMCCD-RAW 0201": ("image", "raf"),
    b"\0\0\0\x18ftypheic\0\0\0\0mif1heic": ("image", "heif"),
    b"\0\0\0\x1cftypavif\0\0\0\0avifmif1": ("image", "avif"),
    b"\0\0\0\x18ftypcrx \0\0\0\x01crx isom": ("image", "cr3"),
    b"\0\0\0\x20ftypisom\0\0\x02\0isomiso2avc1mp41": ("video", "mp4"),
    b"\0\0\0\x14ftypqt  \0\0\0\0qt  ": ("video", "mov"),
    b"\0\0\0\x14ftyp3gp4\0\0\0\0isom": ("video", "3gp"),
    b"\x1a\x45\xdf\xa3\x9f\x42\x86\x81\x01webm": ("video", "webm"),
    b"\x1a\x45\xdf\xa3\x9f\x42\x86\x81\x01matroska": ("video", "mkv"),
    b"\x30\x26\xb2\x75\x8e\x66\xcf\x11\xa6\xd9": ("video", "wmv"),
    b"FLV\x01\x05": ("video", "flv"),
    b"\0\0\x01\xba\x44\0": ("video", "mpg"),
}


def test_sniff_known_signatures():
    for head, expected in SAMPLES.items():
        assert sniff(head) == expected, head


def test_sniff_transport_streams():
    m2ts = bytearray(400)
    m2ts[4] = m2ts[196] = 0x47
    assert sniff(bytes(m2ts)) == ("video", "m2ts")


def test_bmp_needs_valid_header():
    good = b"BM" + b"\0" * 12 + (40).to_bytes(4, "little")
    assert sniff(good) == ("image", "bmp")
    assert sniff(b"BMW is a car brand, not a bitmap") is None


def test_unknown_and_text():
    assert sniff(b"hello world") is None
    assert sniff(b"") is None


def test_classify_extension_and_magic(tmp_path):
    jpg = tmp_path / "a.jpg"
    jpg.write_bytes(b"\xff\xd8\xff\xe0" + b"\0" * 100)
    assert classify(str(jpg)) == ("image", "jpeg")

    fake = tmp_path / "fake.jpg"
    fake.write_text("not an image")
    assert classify(str(fake)) is None, "extension alone is not enough"

    wrong_kind = tmp_path / "movie.jpg"
    wrong_kind.write_bytes(b"\x1a\x45\xdf\xa3matroska")
    assert classify(str(wrong_kind)) is None

    no_ext = tmp_path / "IMG_0001"
    no_ext.write_bytes(b"\xff\xd8\xff\xe0" + b"\0" * 100)
    assert classify(str(no_ext)) is None
    assert classify(str(no_ext), sniff_unknown=True) == ("image", "jpeg")

    txt = tmp_path / "notes.txt"
    txt.write_bytes(b"\xff\xd8\xff")  # JPEG bytes but non-media extension
    assert classify(str(txt)) is None


def test_extension_case_insensitive(tmp_path):
    f = tmp_path / "PHOTO.JPG"
    f.write_bytes(b"\xff\xd8\xff\xe0" + b"\0" * 10)
    assert classify(str(f)) == ("image", "jpeg")
