"""File operations: sandbox lock, Trash, delete, move (incl. across drives), rename, undo, journal.

Everything happens inside pytest's tmp_path; the sandbox lock (CLONE_RANGER_SANDBOX, set in
tests/conftest.py) makes every operation refuse any other path.
"""
import errno
import os
import urllib.parse

import pytest

from clone_ranger.core import fsops, hasher, sandbox, trash
from clone_ranger.core.control import Control
from clone_ranger.core.index import Index
from clone_ranger.core.journal import Journal
from clone_ranger.core.operations import Engine, Target, lost_groups, plan_move

from .conftest import linux_only, needs_symlinks


def mk(path, data=b"x" * 1000):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(data)
    return path


def target(p):
    st = os.lstat(p)
    return Target(str(p), st.st_size, st.st_mtime_ns, hasher.full_hash(str(p)))


@pytest.fixture
def eng(tmp_path):
    return Engine(Journal(tmp_path / "journal.jsonl"))


# --------------------------------------------------------------------------- sandbox
def test_sandbox_refuses_outside(tmp_path):
    with pytest.raises(sandbox.SandboxViolation):
        sandbox.check(os.path.expanduser("~/Pictures/x.jpg"))
    with pytest.raises(sandbox.SandboxViolation):
        sandbox.check(str(tmp_path / ".." / "escape.jpg"))
    assert sandbox.check(str(tmp_path / "ok.jpg")) == str(tmp_path / "ok.jpg")


@needs_symlinks
def test_sandbox_follows_symlinked_folders(tmp_path):
    outside = tmp_path.parent / f"{tmp_path.name}-outside"
    (tmp_path / "link").symlink_to(outside, target_is_directory=True)
    with pytest.raises(sandbox.SandboxViolation):
        sandbox.check(str(tmp_path / "link" / "file.jpg"))


def test_without_sandbox_under_pytest_everything_is_refused(monkeypatch, tmp_path):
    monkeypatch.delenv("CLONE_RANGER_SANDBOX")
    with pytest.raises(sandbox.SandboxViolation):
        sandbox.check(str(tmp_path / "a.jpg"))


def test_engine_refuses_files_outside_sandbox(eng, tmp_path, monkeypatch):
    f = mk(tmp_path / "a" / "x.jpg")
    monkeypatch.setenv("CLONE_RANGER_SANDBOX", str(tmp_path / "elsewhere"))
    (tmp_path / "elsewhere").mkdir()
    rep = eng.trash([target(f)])
    assert rep.counts["skipped"] == 1 and f.exists()


# --------------------------------------------------------------------------- low level
def test_rename_noreplace_never_overwrites(tmp_path):
    a, b = mk(tmp_path / "a.jpg", b"A"), mk(tmp_path / "b.jpg", b"B")
    with pytest.raises(FileExistsError):
        fsops.rename_noreplace(str(a), str(b))
    assert b.read_bytes() == b"B" and a.exists()


@needs_symlinks
def test_expect_unchanged(tmp_path):
    f = mk(tmp_path / "a.jpg")
    st = os.lstat(f)
    fsops.expect_unchanged(str(f), st.st_size, st.st_mtime_ns)
    with pytest.raises(fsops.Changed):
        fsops.expect_unchanged(str(f), st.st_size + 1, st.st_mtime_ns)
    os.utime(f, ns=(st.st_atime_ns, st.st_mtime_ns + 10**9))
    with pytest.raises(fsops.Changed):
        fsops.expect_unchanged(str(f), st.st_size, st.st_mtime_ns)
    link = tmp_path / "l.jpg"
    link.symlink_to(f)
    with pytest.raises(fsops.Changed):
        fsops.expect_unchanged(str(link), None, None)


def test_cross_device_move_copies_verifies_and_deletes(tmp_path, monkeypatch):
    src = mk(tmp_path / "a" / "x.jpg", os.urandom(3 * 1024 * 1024 + 7))
    data = src.read_bytes()
    os.utime(src, ns=(1_600_000_000_000_000_000, 1_600_000_000_000_000_000))
    real = fsops.rename_noreplace

    def exdev_for_src(s, d):
        if s == str(src):
            raise OSError(errno.EXDEV, "Invalid cross-device link")
        return real(s, d)
    monkeypatch.setattr(fsops, "rename_noreplace", exdev_for_src)
    dst = tmp_path / "b" / "x.jpg"
    dst.parent.mkdir()
    assert fsops.move_file(str(src), str(dst), expected_hash=hasher.full_hash(str(src))) is True
    assert not src.exists() and dst.read_bytes() == data
    assert os.stat(dst).st_mtime_ns == 1_600_000_000_000_000_000       # timestamps kept
    assert not [p for p in dst.parent.iterdir() if p.name.endswith(".part")]


def test_cross_device_move_keeps_source_when_verify_fails(tmp_path, monkeypatch):
    src = mk(tmp_path / "a" / "x.jpg", b"original data" * 1000)
    monkeypatch.setattr(fsops, "rename_noreplace",
                        lambda s, d: (_ for _ in ()).throw(OSError(errno.EXDEV, "x")) if s == str(src) else os.rename(s, d))
    dst = tmp_path / "b" / "x.jpg"
    dst.parent.mkdir()
    with pytest.raises(fsops.VerifyFailed):
        fsops.move_file(str(src), str(dst), expected_hash=f"{hasher.ALGO}:{'0' * 64}")
    assert src.exists() and not dst.exists()
    assert list(dst.parent.iterdir()) == []                              # temp copy removed


def test_cross_device_move_cancel_keeps_source(tmp_path, monkeypatch):
    src = mk(tmp_path / "a" / "x.jpg", os.urandom(2 * 1024 * 1024))
    monkeypatch.setattr(fsops, "rename_noreplace",
                        lambda s, d: (_ for _ in ()).throw(OSError(errno.EXDEV, "x")) if s == str(src) else os.rename(s, d))
    c = Control()
    c.cancel()
    from clone_ranger.core.control import Cancelled
    with pytest.raises(Cancelled):
        fsops.move_file(str(src), str(tmp_path / "x.jpg"), control=c)
    assert src.exists() and not (tmp_path / "x.jpg").exists()


# --------------------------------------------------------------------------- Trash
@linux_only        # Windows: the Recycle Bin, tested in test_windows_real.py
def test_trash_follows_freedesktop_spec(eng, tmp_path):
    f = mk(tmp_path / "lib" / "my photo.jpg")
    g = mk(tmp_path / "lib2" / "my photo.jpg", b"other")
    rep = eng.trash([target(f), target(g)])
    assert rep.counts == {"ok": 2, "skipped": 0, "failed": 0}
    home = tmp_path / "xdg-data" / "Trash"
    names = sorted(p.name for p in (home / "files").iterdir())
    assert names == ["my photo.2.jpg", "my photo.jpg"]
    info = (home / "info" / "my photo.jpg.trashinfo").read_text()
    assert info.startswith("[Trash Info]\n")
    path_line = next(line for line in info.splitlines() if line.startswith("Path="))
    assert urllib.parse.unquote(path_line[5:]) == str(f)
    assert "%20" in path_line                                            # URL-escaped
    assert "DeletionDate=" in info
    assert not f.exists() and not g.exists()


@linux_only
def test_trash_on_other_drive_uses_topdir_trash(tmp_path, monkeypatch):
    drive = tmp_path / "drive"
    f = mk(drive / "DCIM" / "a.jpg")
    monkeypatch.setattr(trash, "mount_points", lambda: ["/", str(drive)])
    t = trash.trash(str(f))
    tdir = drive / f".Trash-{os.getuid()}"
    assert t.trash_file == str(tdir / "files" / "a.jpg")
    assert (tdir / "info" / "a.jpg.trashinfo").read_text().splitlines()[1] == "Path=DCIM/a.jpg"   # relative
    trash.restore(t.trash_file, t.info_file, t.original)
    assert f.exists() and not (tdir / "info" / "a.jpg.trashinfo").exists()


@linux_only
def test_trash_unavailable_leaves_file(tmp_path, monkeypatch, eng):
    drive = tmp_path / "ro-drive"
    f = mk(drive / "a.jpg")
    monkeypatch.setattr(trash, "mount_points", lambda: ["/", str(drive)])
    (drive / f".Trash-{os.getuid()}").write_text("not a folder")       # unusable Trash
    ok, why = trash.can_trash(str(f))
    assert not ok and why
    rep = eng.trash([target(f)])
    assert rep.trash_missing == [str(f)] and f.exists()


def test_undo_trash(eng, tmp_path):
    f = mk(tmp_path / "lib" / "a.jpg")
    eng.trash([target(f)])
    order = eng.journal.last_undoable()
    assert order.op == "trash"
    eng.undo(order)
    assert f.exists()
    assert eng.journal.last_undoable() is None
    assert eng.journal.order(order.n).undone_by is not None


# --------------------------------------------------------------------------- delete
def test_delete_and_changed_files_are_skipped(eng, tmp_path):
    a, b = mk(tmp_path / "a.jpg"), mk(tmp_path / "b.jpg")
    ta, tb = target(a), target(b)
    b.write_bytes(b"edited after the scan, different size")
    rep = eng.delete([ta, tb])
    assert not a.exists() and b.exists()
    items = {i.src: i for i in rep.order.items}
    assert items[str(b)].status == "skipped" and "size" in items[str(b)].error
    assert not rep.order.undoable


def test_protected_folders_are_never_touched(tmp_path):
    f = mk(tmp_path / "Personal" / "passport.jpg")
    e = Engine(Journal(tmp_path / "j.jsonl"), protected_folders=[str(tmp_path / "Personal")])
    rep = e.delete([target(f)])
    assert f.exists() and rep.order.items[0].error == "protected folder"
    t = target(f)
    t.protected = True
    assert Engine(Journal(tmp_path / "j2.jsonl")).trash([t]).counts["skipped"] == 1 and f.exists()


def test_lost_groups(tmp_path):
    a, b = mk(tmp_path / "a.jpg"), mk(tmp_path / "b.jpg")
    groups = [[str(a), str(b)], [str(a), str(tmp_path / "gone.jpg")]]
    assert lost_groups(groups, {str(a)}) == [1]           # group 1's other copy is already gone
    assert lost_groups(groups, {str(a), str(b)}) == [0, 1]


# --------------------------------------------------------------------------- move
def test_plan_move_conflicts(tmp_path):
    a, b = mk(tmp_path / "x" / "p.jpg", b"1"), mk(tmp_path / "y" / "p.jpg", b"2")
    dest = tmp_path / "dest"
    mk(dest / "p.jpg", b"existing")
    ts = [target(a), target(b)]
    skip = plan_move(ts, str(dest), conflict="skip")
    assert [s.status for s in skip] == ["skip", "skip"]
    num = plan_move(ts, str(dest), conflict="number")
    assert [os.path.basename(s.dst) for s in num] == ["p (2).jpg", "p (3).jpg"]
    over = plan_move(ts, str(dest), conflict="overwrite")
    assert [s.status for s in over] == ["overwrite", "skip"]     # second would collide with the first
    keep = plan_move(ts, str(dest), keep_structure=True)
    assert [s.dst for s in keep] == [str(dest / "x" / "p.jpg"), str(dest / "y" / "p.jpg")]


def test_move_keep_structure_and_undo(eng, tmp_path):
    a, b = mk(tmp_path / "lib" / "2020" / "a.jpg"), mk(tmp_path / "lib" / "2021" / "b.jpg")
    dest = tmp_path / "sorted"
    steps = plan_move([target(a), target(b)], str(dest), keep_structure=True)
    rep = eng.move(steps, str(dest))
    assert rep.counts["ok"] == 2
    assert (dest / "2020" / "a.jpg").exists() and (dest / "2021" / "b.jpg").exists()
    assert not a.exists()
    eng.undo(eng.journal.last_undoable())
    assert a.exists() and b.exists()
    assert not dest.exists()                                      # folders we created are removed again


@linux_only        # looks inside the freedesktop Trash folder
def test_move_overwrite_trashes_the_replaced_file_and_undo_restores_it(eng, tmp_path):
    a = mk(tmp_path / "x" / "p.jpg", b"new")
    dest = tmp_path / "dest"
    old = mk(dest / "p.jpg", b"old")
    rep = eng.move(plan_move([target(a)], str(dest), conflict="overwrite"), str(dest))
    assert rep.counts["ok"] == 1 and old.read_bytes() == b"new"
    trashed = list((tmp_path / "xdg-data" / "Trash" / "files").iterdir())
    assert [p.read_bytes() for p in trashed] == [b"old"]
    eng.undo(eng.journal.last_undoable())
    assert a.read_bytes() == b"new" and old.read_bytes() == b"old"


def test_undo_skips_files_changed_after_the_order(eng, tmp_path):
    a = mk(tmp_path / "x" / "p.jpg")
    dest = tmp_path / "dest"
    eng.move(plan_move([target(a)], str(dest)), str(dest))
    moved = dest / "p.jpg"
    st = os.lstat(moved)
    os.utime(moved, ns=(st.st_atime_ns, st.st_mtime_ns + 5 * 10**9))
    rep = eng.undo(eng.journal.last_undoable())
    assert rep.counts["skipped"] == 1 and moved.exists() and not a.exists()


def test_move_cancel_records_the_rest(tmp_path):
    files = [mk(tmp_path / "x" / f"{i}.jpg") for i in range(3)]
    c = Control()
    calls = []

    def progress(e):
        if "done" in e:
            calls.append(e["done"])
            if e["done"] == 1:
                c.cancel()
    eng = Engine(Journal(tmp_path / "j.jsonl"), control=c, progress=progress)
    rep = eng.move(plan_move([target(f) for f in files], str(tmp_path / "d")), str(tmp_path / "d"))
    assert rep.cancelled
    assert rep.counts["ok"] == 2 and rep.counts["skipped"] == 1
    assert files[2].exists()


# --------------------------------------------------------------------------- rename
def test_rename_swap_and_undo(eng, tmp_path):
    from clone_ranger.core.operations import Step
    a, b = mk(tmp_path / "a.jpg", b"A"), mk(tmp_path / "b.jpg", b"B")
    rep = eng.rename([Step(target(a), str(b)), Step(target(b), str(a))])
    assert rep.counts["ok"] == 2
    assert a.read_bytes() == b"B" and b.read_bytes() == b"A"
    eng.undo(eng.journal.last_undoable())
    assert a.read_bytes() == b"A" and b.read_bytes() == b"B"
    assert sorted(p.name for p in tmp_path.iterdir() if p.suffix == ".jpg") == ["a.jpg", "b.jpg"]


def test_rename_into_existing_name_fails_safely(eng, tmp_path):
    from clone_ranger.core.operations import Step
    a, b = mk(tmp_path / "a.jpg", b"A"), mk(tmp_path / "b.jpg", b"B")
    rep = eng.rename([Step(target(a), str(b))])
    assert rep.counts["failed"] == 1 and a.read_bytes() == b"A" and b.read_bytes() == b"B"


# --------------------------------------------------------------------------- index + journal
def test_index_updated_without_rescan(tmp_path):
    from clone_ranger.core.pipeline import run
    from clone_ranger.core.scanner import ScanConfig
    lib = tmp_path / "lib"
    a, b, c = mk(lib / "a.jpg", b"\xff\xd8\xff" + b"1" * 5000), mk(lib / "b.jpg", b"\xff\xd8\xff" + b"1" * 5000), \
        mk(lib / "c.jpg", b"\xff\xd8\xff" + b"1" * 5000)
    idx = Index(tmp_path / "i.sqlite")
    res = run(idx, ScanConfig(roots=[str(lib)], excludes=[]))
    assert len(res.groups) == 1 and res.groups[0].copies == 3
    e = Engine(Journal(tmp_path / "j.jsonl"), idx)
    rows = {r.path: r for r in idx.all_files()}

    def t(p):
        r = rows[str(p)]
        return Target(r.path, r.size, r.mtime_ns, r.full)
    e.trash([t(a)])
    e.move(plan_move([t(b)], str(tmp_path / "moved")), str(tmp_path / "moved"))
    paths_ = {r.path for r in idx.all_files()}
    assert paths_ == {str(c), str(tmp_path / "moved" / "b.jpg")}
    moved = next(r for r in idx.all_files() if r.name == "b.jpg")
    assert moved.full == rows[str(b)].full
    e.undo(e.journal.last_undoable())              # undo the move
    e.undo(e.journal.last_undoable())              # undo the trash
    assert {r.path for r in idx.all_files()} == {str(a), str(b), str(c)}
    from clone_ranger.core.duplicates import groups_from_index
    assert groups_from_index(idx)[0].copies == 3
    idx.close()


def test_journal_survives_a_broken_last_line(tmp_path):
    j = Journal(tmp_path / "j.jsonl")
    o = j.begin("move", dest="/x")
    from clone_ranger.core.journal import Item
    j.item(o, Item(src="/a", dst="/x/a"))
    with open(j.path, "a") as f:
        f.write('{"t": "item", "n": 1, "src": "/b", "ds')              # power cut mid-line
    orders = j.orders()
    assert len(orders) == 1 and orders[0].status == "incomplete" and len(orders[0].items) == 1
    assert j.next_number() == 2


def test_hard_link_target_is_not_mistaken_for_a_case_rename(eng, tmp_path):
    """rename_case_safe only goes via a temporary name when the 'existing' target is the same file
    under a different-case name; a hard link with another name must still count as taken."""
    from clone_ranger.core.operations import Step
    a = mk(tmp_path / "a.jpg", b"A")
    os.link(a, tmp_path / "b.jpg")
    rep = eng.rename([Step(target(a), str(tmp_path / "b.jpg"))])
    assert rep.counts["failed"] == 1
    assert a.exists() and (tmp_path / "b.jpg").exists()
    assert not [p for p in tmp_path.iterdir() if p.name.startswith(".clone-ranger-")]


def test_action_log_rotates_but_keeps_recent_orders_and_numbering(tmp_path, monkeypatch):
    from clone_ranger.core import journal as jmod
    from clone_ranger.core.journal import Item, Journal
    monkeypatch.setattr(jmod, "MAX_BYTES", 5_000)                # ~260 bytes per order: rotates often
    monkeypatch.setattr(jmod, "KEEP_ORDERS", 10)
    j = Journal(tmp_path / "journal.jsonl")
    for i in range(1, 60):
        o = j.begin("move", dest="/x", n=i)
        j.item(o, Item(src=f"/a/{i}.jpg", dst=f"/x/{i}.jpg", size=1))
        j.end(o, "done")
    old = tmp_path / "journal.old.jsonl"
    assert old.exists()                                       # it rotated at least once
    orders = j.orders()
    assert 10 <= len(orders) < 30 and orders[-1].n == 59        # old orders moved out, newest kept
    assert [o.n for o in orders] == list(range(60 - len(orders), 60))
    old_numbers = {int(line.split('"n": ')[1].split(",")[0]) for line in old.read_text().splitlines()
                   if '"t": "order"' in line}
    assert 1 not in {o.n for o in orders} and min(old_numbers) <= 40
    assert all(o.items for o in orders)                       # kept orders are complete
    assert j.next_number() == 60                              # numbering continues
    assert j.last_undoable().n == 59                          # Ctrl+Z still works
    assert (tmp_path / "journal.jsonl").stat().st_size < 5_000 + 1_000
    j2 = Journal(tmp_path / "journal.jsonl")
    assert j2.order(59) is not None
