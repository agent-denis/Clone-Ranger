"""The window builds and switches themes without errors (offscreen, demo data only)."""
import pytest

pytest.importorskip("PySide6")


def test_main_window_all_themes():
    from clone_ranger.app import make_app
    app = make_app([])
    from clone_ranger.theme.style import theme
    from clone_ranger.ui.main_window import MainWindow
    w = MainWindow(demo=True)
    w.show()
    for key in ("dark", "light", "plain", "auto", "dark"):
        theme().apply(key)
        app.processEvents()
        assert not w.grab().isNull()
    assert w.minimumSizeHint().width() <= 1366, "window must fit a 1366 px wide screen"
    w.close()


def test_help_menu_shortcuts_and_about(monkeypatch):
    from clone_ranger import __version__
    from clone_ranger.app import make_app
    app = make_app([])
    from clone_ranger.ui import help_dialogs
    from clone_ranger.ui.main_window import MainWindow
    monkeypatch.setattr(help_dialogs.QDialog, "exec", lambda self: 0)
    w = MainWindow(demo=True)
    dlg = w.show_shortcuts()
    keys = {k for k, _ in dlg.rows}
    for expected in ("Ctrl+Z", "F2", "F3", "F4", "F5", "F1", "Del", "Shift+Del", "Ctrl+A"):
        assert expected in keys, (expected, sorted(keys))
    about = w.show_about()
    assert __version__ in about.version.text()
    app.processEvents()
    w.close()


def test_installed_command_answers_version_and_help_without_a_window(capsys):
    """/usr/bin/clone-ranger (RPM / pip entry point) calls app.main() directly, not python -m clone_ranger."""
    import pytest
    from clone_ranger import __version__
    from clone_ranger.app import main
    for arg, expected in (("--version", f"clone-ranger {__version__}"), ("--help", "--demo")):
        with pytest.raises(SystemExit) as e:
            main([arg])
        assert e.value.code == 0
        assert expected in capsys.readouterr().out


def test_window_title_ends_with_the_app_name():
    """Qt adds " - Clone Ranger" to a title that doesn't end with the app name (seen on Windows as
    "Clone Ranger – … - Clone Ranger")."""
    from clone_ranger.app import make_app
    make_app([])
    from clone_ranger.ui.main_window import MainWindow
    for demo in (False, True):
        w = MainWindow(demo=demo)
        assert w.windowTitle().endswith("Clone Ranger")
        assert w.windowTitle().count("Clone Ranger") == 1
        assert ("[DEMO]" in w.windowTitle()) == demo
        w.close()


def test_small_screen_window_is_maximized_and_tall_pages_scroll():
    """A screen smaller than the window (small laptop, big display scaling): open maximized, and the tall
    pages scroll instead of making the window taller than the screen."""
    from clone_ranger.app import make_app
    app = make_app([])
    from PySide6.QtWidgets import QScrollArea
    from clone_ranger.ui.main_window import MainWindow
    w = MainWindow(demo=True)            # default size 1500 x 940 > the 800 x 800 offscreen screen
    assert w.isMaximized()
    w.show()
    for page in (w.scan_screen, w.locations, w.log_page):
        w.stack.setCurrentWidget(page)
        app.processEvents()
        assert w.stack.currentWidget() is page
        assert isinstance(page.parentWidget().parentWidget(), QScrollArea)
    assert w.stack.minimumSizeHint().height() < 520
    w.close()
