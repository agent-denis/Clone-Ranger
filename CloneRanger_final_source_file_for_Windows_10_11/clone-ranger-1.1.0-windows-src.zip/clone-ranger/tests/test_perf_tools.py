"""The performance tools themselves (small scale; the 200k run is manual: tools/perf_test.py)."""
import importlib.util
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent


def load(name):
    spec = importlib.util.spec_from_file_location(name, ROOT / "tools" / f"{name}.py")
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def test_manifest_check_reports_mismatches():
    perf = load("perf_test")
    manifest = {"files": 10, "content_groups": 2, "duplicate_files": 3, "hard_links": 1, "reclaim_bytes": 99}
    good = {"files": 10, "groups": 2, "duplicate_files": 3, "hard_links": 1, "reclaim": 99}
    ok, lines = perf.check_scan(good, manifest)
    assert ok and all(line.startswith("OK ") for line in lines)
    ok, lines = perf.check_scan({**good, "groups": 1}, manifest)
    assert not ok and any(line.startswith("BAD groups") for line in lines)


def test_small_perf_library_is_found_exactly(tmp_path):
    """A 3 000-file library from the generator: the real pipeline must find exactly what the manifest says."""
    gen = load("make_perf_library")
    lib = tmp_path / "lib"
    m = gen.build(lib, 3000)
    assert json.loads((lib / "manifest.json").read_text()) == m and m["files"] == 3000
    from clone_ranger.core.index import Index
    from clone_ranger.core.pipeline import run
    from clone_ranger.core.scanner import ScanConfig
    idx = Index(tmp_path / "i.sqlite")
    res = run(idx, ScanConfig(roots=[str(lib)], excludes=[]))
    perf = load("perf_test")
    found = {"files": res.files, "groups": res.totals["groups"], "duplicate_files": res.totals["duplicate_files"],
             "hard_links": res.totals["hard_links"], "reclaim": res.totals["reclaim"]}
    ok, lines = perf.check_scan(found, m)
    assert ok, lines
    idx.close()
