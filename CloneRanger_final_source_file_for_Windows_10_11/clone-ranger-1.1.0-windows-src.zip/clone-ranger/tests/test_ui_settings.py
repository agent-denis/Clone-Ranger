"""Settings page in the real window: appearance, keep rules, preferred and protected folders."""
import importlib.util
import os
import time
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parent.parent


def wait(app, cond, timeout=30):
    end = time.monotonic() + timeout
    while not cond():
        app.processEvents()
        time.sleep(0.01)
        assert time.monotonic() < end, "timed out"


@pytest.fixture
def win(tmp_path, monkeypatch):
    for var, sub in (("XDG_CONFIG_HOME", "config"), ("XDG_CACHE_HOME", "cache"), ("XDG_STATE_HOME", "state")):
        monkeypatch.setenv(var, str(tmp_path / sub))
    spec = importlib.util.spec_from_file_location("msl", ROOT / "tools" / "make_sample_library.py")
    tool = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(tool)
    lib = tmp_path / "library"
    tool.build(lib)
    from clone_ranger.app import make_app
    app = make_app([])
    from clone_ranger.core.settings import Settings
    from clone_ranger.theme.style import theme
    from clone_ranger.ui import main_window as mw
    monkeypatch.setattr(mw.SummaryDialog, "exec", lambda self: 0)
    from clone_ranger.ui import order_dialog

    def sign(self):                       # stand-in for the user signing the ORDER
        self.show()
        if self.live:
            self._signed()
            wait(app, lambda: self.phase == "report")
        return 1
    monkeypatch.setattr(order_dialog.OrderDialog, "exec", sign)
    settings = Settings()
    settings["roots"] = [str(lib)]
    w = mw.MainWindow(settings=settings)
    w.show()
    wait(app, lambda: w.results.state in ("none", "ready"))
    w.start_scan()
    wait(app, lambda: w.scan_worker is None)
    wait(app, lambda: all(c.has_meta for g in w.results.all_groups for c in g.copies))
    w.app, w.lib = app, lib
    yield w
    w.close()
    theme().apply("dark")
    theme().reduce_motion = False
    from clone_ranger.ui import viewmodel
    viewmodel.set_rules(None)
    tool.make_readable(lib)


def keep_of(g):
    return next(c for c in g.copies if c.keep)


def test_appearance_applies_at_once(win):
    from clone_ranger.theme.style import theme
    from clone_ranger.ui.sounds import sounds
    page = win.settings_page
    win.show_settings()
    page.theme_radios["light"].setChecked(True)
    assert theme().key == "light" and win.settings["theme"] == "light"
    theme().apply("plain")                                    # changed elsewhere (header) -> page follows
    assert page.theme_radios["plain"].isChecked()
    page.reduce_motion.setChecked(True)
    assert theme().reduce_motion and win.settings["reduce_motion"]
    page.sounds.setChecked(True)
    sounds().played.clear()
    sounds().play("bell")
    assert sounds().played == ["bell"]
    page.sounds.setChecked(False)
    sounds().play("bell")
    assert sounds().played == ["bell"]                       # off: silent
    sounds().enabled = False


def test_rule_order_changes_recommendation_and_is_saved(win):
    from clone_ranger.core.settings import Settings
    page = win.settings_page
    win.show_settings()
    r = win.results
    # Downloads copies lose because "not in Downloads/temp" is on; switch it and "clean name" off and put
    # "deepest folder" right after the protected rule
    for i in range(page.rules.count()):
        item = page.rules.item(i)
        key = item.data(256)
        if key in ("not_temp", "clean_name", "preferred"):
            item.setCheckState(page.rules.item(0).checkState().__class__.Unchecked)
        if key == "longest":
            item.setCheckState(item.checkState().__class__.Checked)
            page.rules.setCurrentRow(i)
    while page.rules.currentRow() > 1:
        page._move_rule(-1)
    assert page.rules.item(1).data(256) == "longest"
    page._move_rule(-1)
    assert page.rules.item(0).data(256) == "protected"       # nothing moves above the locked rule
    changed, total = win.settings_page.impact_fn(page.current_rules(), page.protected.folders())
    assert total == len([g for g in r.all_groups if g.is_duplicate]) and changed >= 1
    assert str(changed) in page.impact.text()
    before = {id(g): keep_of(g).path for g in r.all_groups}
    page.save()
    after = {id(g): keep_of(g).path for g in r.all_groups}
    assert sum(before[k] != after[k] for k in before) == changed
    for g in r.all_groups:                                   # the deepest folder wins now
        depth = max(c.path.count(os.sep) for c in g.copies)
        assert keep_of(g).path.count(os.sep) == depth
    stored = Settings()["keep_rules"]
    assert stored[1] == ["longest", True] and ["not_temp", False] in stored


def test_hand_made_choices_survive_new_rules(win):
    r = win.results
    g = next(g for g in r.all_groups if any(c.selectable for c in g.copies))
    keep = keep_of(g)
    for c in g.copies:
        c.selected = False
    win._selection_changed(g)
    page = win.settings_page
    win.show_settings()
    page._load_rules([["protected", True], ["newest", True], ["shortest", True]])
    page.save()
    assert keep_of(g) is keep and not any(c.selected for c in g.copies)


def test_protected_folder_from_settings(win):
    r = win.results
    g = next(g for g in r.all_groups if any(c.selected for c in g.copies))
    victim = next(c for c in g.copies if c.selected)
    page = win.settings_page
    win.show_settings()
    page.protected.add_folder(os.path.dirname(victim.path))
    page.save()
    assert victim.protected and not victim.selected and not victim.selectable
    assert keep_of(g).protected                              # a protected copy wins the KEEP stamp
    assert win.settings["protected_folders"] == [os.path.dirname(victim.path)]
    # and the engine refuses it even if handed over directly
    rep = win.ops.delete([(g, victim)])
    assert rep.order.items[0].error == "protected folder" and os.path.exists(victim.path)
    # removing the folder again lifts the protection
    win.show_settings()
    page.protected.list.setCurrentRow(0)
    page.protected.list.item(0).setSelected(True)
    page.protected._remove()
    page.save()
    assert not victim.protected


def test_preferred_folders_win(win):
    r = win.results
    g = next(g for g in r.all_groups if len({os.path.dirname(c.path) for c in g.copies}) >= 2 and g.kind == "image")
    loser = next(c for c in g.copies if not c.keep and not c.hard_link)
    page = win.settings_page
    win.show_settings()
    page.preferred.set_folders([os.path.dirname(loser.path)])
    for i in range(page.rules.count()):                      # preferred directly after protected
        if page.rules.item(i).data(256) == "preferred":
            page.rules.setCurrentRow(i)
    while page.rules.currentRow() > 1:
        page._move_rule(-1)
    page.save()
    assert loser.keep


def test_settings_survive_a_restart(win, tmp_path):
    page = win.settings_page
    win.show_settings()
    page.protected.add_folder(str(tmp_path / "vault"))
    page.save()
    from clone_ranger.core.settings import Settings
    from clone_ranger.ui.settings_page import SettingsPage
    again = SettingsPage(Settings())
    assert again.protected.folders() == [str(tmp_path / "vault")]
