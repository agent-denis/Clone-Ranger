"""Every text colour pair in both themes must meet WCAG AA contrast."""
import pytest

from clone_ranger.theme.palettes import BUTTON_GRADIENT, ON_BRAND, PALETTES, check, contrast


@pytest.mark.parametrize("key", sorted(PALETTES))
def test_text_contrast_meets_wcag_aa(key):
    failures = [f"{fg} on {bg}: {r:.2f} < {need}" for fg, bg, r, need, ok in check(PALETTES[key]) if not ok]
    assert not failures, failures


def test_contrast_formula_known_values():
    assert contrast("#000000", "#FFFFFF") == pytest.approx(21.0)
    assert contrast("#777777", "#FFFFFF") == pytest.approx(4.48, abs=0.01)


@pytest.mark.parametrize("stop", BUTTON_GRADIENT)
def test_text_is_readable_on_the_orange_yellow_button_gradient(stop):
    assert contrast(ON_BRAND, stop) >= 4.5


def test_danger_is_never_body_text_on_a_plain_background():
    """Rose may fill buttons and badges; as text only the darker/lighter danger_text variant is used."""
    from clone_ranger.theme.palettes import TEXT_PAIRS
    for fg, bg, large in TEXT_PAIRS:
        assert fg != "danger", f"danger used as text colour on {bg}"
