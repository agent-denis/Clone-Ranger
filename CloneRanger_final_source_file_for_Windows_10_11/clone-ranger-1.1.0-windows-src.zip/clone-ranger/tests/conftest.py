import os
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")


@pytest.fixture(autouse=True)
def _isolated_xdg(tmp_path, monkeypatch):
    """Safety net for EVERY test: Clone Ranger's settings, index, thumbnails, logs and Trash go to a temporary
    folder, never to your real ~/.config, ~/.cache, ~/.local/state or ~/.local/share/Trash, and file
    operations are locked to that folder."""
    for var, sub in (("XDG_CONFIG_HOME", "xdg-config"), ("XDG_CACHE_HOME", "xdg-cache"),
                     ("XDG_STATE_HOME", "xdg-state"), ("XDG_DATA_HOME", "xdg-data")):
        monkeypatch.setenv(var, str(tmp_path / sub))
    # Sandbox lock: every file operation (trash/delete/move/rename/undo) refuses paths outside tmp_path.
    monkeypatch.setenv("CLONE_RANGER_SANDBOX", str(tmp_path))
