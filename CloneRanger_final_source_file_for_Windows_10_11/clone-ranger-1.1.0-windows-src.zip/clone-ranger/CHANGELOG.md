# Changelog

All notable changes to Clone Ranger. Dates are in YYYY-MM-DD.

## 1.1.0 – 2026-11-19

Clone Ranger now also runs on **Windows 10 and 11**.

### New
- **Windows version:** an installer (`CloneRanger-1.1.0-Setup.exe`, per user, no administrator rights) and a
  portable zip, built with `windows\build.bat` (see `windows/README-WINDOWS.md`). FFmpeg for video thumbnails
  is included. Not code-signed: on first start choose *More info → Run anyway*.
- On Windows: *Move to Recycle Bin* with Undo that restores like Explorer, "Show in folder" opens Explorer,
  "Entire computer" scans every local and USB drive, OneDrive online-only files are skipped (no downloads),
  Windows file-name rules when renaming, settings in `%APPDATA%\Clone Ranger`.

### Fixed
- Tall pages (scan screen, Scan locations, History) scroll, and the window opens maximized when it doesn't fit
  the screen, so nothing is cut off on small laptops.
- The window title no longer shows the app name twice.
- Scanning a whole drive no longer stops on very large file IDs (Windows, some network and ReFS drives).
- Renaming a file to a name that is a hard link to the same file is refused (it was let through on Windows).
- Linux trash, snapshot and thumbnail folders on disks shared with Linux are skipped on Windows too.

## 1.0.0 – 2026-11-16

The first public release of **Clone Ranger**.

### New
- **New look:** a modern, colourful design in orange, light blue, white, yellow and red, with rounded
  cards, the Inter font, and a new logo and icons. Light and Dark themes, plus *System* (follows the
  desktop's light/dark setting, the new default) and *Plain*.
- **Unselect:** an *Unselect all* button above the results (Ctrl+Shift+A) clears the selection in every
  group; *Unselect this file* in the Details panel (Ctrl+U) and in the right-click menu of every copy;
  *Unselect this group* in the right-click menu. A selection bar shows how many files are selected and
  their size.
- **Clear history & cache** (File menu and Settings): forget past actions, the app log and remembered
  folders, and/or delete the scan index and thumbnails, to start from scratch.
- **Reset to defaults** (File menu, Settings, Scan locations) now asks what to reset: just the search
  settings, all other settings, the history, the cache, or any combination.

### Changed
- English only; the Cold-War archive theme and the Russian labels are gone.
- Command `clone-ranger`, app ID `io.github.agent_denis.CloneRanger`, folders `~/.config/clone-ranger`,
  `~/.cache/clone-ranger`, `~/.local/state/clone-ranger`.
- The RPM follows the Fedora Packaging Guidelines: system Inter font (rsms-inter-fonts) instead of a bundled
  copy, generated Python dependencies, `%autorelease` / `%autochangelog`.

## 0.9.0 – 2026-11-14 (development preview)
- 200 000-file performance pass: results in ~6 s instead of ~44 s, rescans 3× faster.
- Help menu (About, keyboard shortcuts), action log rotation, full README.

## 0.8.0 – 2026-11-14 (development preview)
- Installer, desktop integration, icons and an RPM spec.
