"""Application setup and entry point."""
import os
import sys

from PySide6.QtCore import Qt
from PySide6.QtGui import QIcon
from PySide6.QtWidgets import QApplication, QMessageBox

from . import APP_ID, __version__
from .core.osinfo import WINDOWS, is_admin
from .theme import art, fonts
from .theme.style import theme

ROOT_MESSAGE = (
    "Clone Ranger refuses to run as root.\n\n"
    "As root it could see and change every file on the system, including other users' files and "
    "system files, and anything it moved to the Trash would end up in root's Trash where you "
    "can't easily restore it. Please start it as your normal user."
)
ADMIN_MESSAGE = (
    "Clone Ranger refuses to run as administrator.\n\n"
    "With administrator rights it could change system files and other users' files. "
    "Please start it normally (not with \"Run as administrator\")."
)


def make_app(argv=None, theme_key: str = "auto") -> QApplication:
    QApplication.setHighDpiScaleFactorRoundingPolicy(Qt.HighDpiScaleFactorRoundingPolicy.PassThrough)
    app = QApplication.instance() or QApplication(argv if argv is not None else sys.argv)
    app.setApplicationName("CloneRanger")            # X11 WM_CLASS class -> StartupWMClass=CloneRanger
    app.setApplicationDisplayName("Clone Ranger")
    app.setOrganizationName("clone-ranger")
    app.setApplicationVersion(__version__)
    # Wayland app_id, and on X11 _GTK_APPLICATION_ID / _KDE_NET_WM_DESKTOP_FILE -> matches <APP_ID>.desktop.
    app.setDesktopFileName(APP_ID)
    fonts.load_fonts()
    app.setWindowIcon(QIcon(art.logo(256)))
    theme().apply(theme_key)
    return app


def setup_logging():
    import logging
    from logging.handlers import RotatingFileHandler
    from .core import paths
    try:
        f = paths.ensure(paths.state_dir()) / "clone-ranger.log"
        h = RotatingFileHandler(f, maxBytes=1_000_000, backupCount=3, encoding="utf-8")
        h.setFormatter(logging.Formatter("%(asctime)s %(levelname)s %(name)s: %(message)s"))
        logging.getLogger("clone_ranger").addHandler(h)
        logging.getLogger("clone_ranger").setLevel(logging.INFO)
    except OSError:
        pass


def main(argv=None):
    import argparse
    ap = argparse.ArgumentParser(prog="clone-ranger", description="Clone Ranger - find and clean up duplicate photos and videos")
    ap.add_argument("--demo", action="store_true", help="show sample data (touches no files)")
    # also here, not only in __main__.py: the installed /usr/bin/clone-ranger calls main() directly
    ap.add_argument("--version", action="version", version=f"clone-ranger {__version__}")
    args, qt_args = ap.parse_known_args(argv)
    if is_admin():
        message = ADMIN_MESSAGE if WINDOWS else ROOT_MESSAGE
        if sys.stderr:                 # None in the Windows app (no console)
            print(message, file=sys.stderr)
        if WINDOWS or os.environ.get("DISPLAY") or os.environ.get("WAYLAND_DISPLAY"):
            app = QApplication(sys.argv)
            QMessageBox.critical(None, "Clone Ranger", message)
        return 1
    setup_logging()
    if WINDOWS:   # own taskbar button and icon, instead of being grouped as "Python"
        try:
            import ctypes
            ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID("agent-denis.CloneRanger")
        except (AttributeError, OSError):
            pass
    from .core.settings import Settings
    settings = Settings()
    app = make_app([sys.argv[0]] + qt_args, settings["theme"])
    theme().reduce_motion = bool(settings["reduce_motion"])
    from .ui.sounds import sounds
    sounds().enabled = bool(settings["sounds"])
    from .ui.main_window import MainWindow
    win = MainWindow(demo=args.demo, settings=settings)
    win.show()
    return app.exec()
