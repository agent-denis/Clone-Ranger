"""SQLite index of every media file found, with cached hashes.

A file's cached hashes are kept only while path + size + mtime + inode (and
device) are unchanged, so a rescan only re-hashes files that changed.
"""
from __future__ import annotations

import os
import sqlite3
import time
from dataclasses import dataclass
from pathlib import Path

from . import paths
from .osinfo import db_int, with_sep

SCHEMA_VERSION = 2

SCHEMA = """
CREATE TABLE IF NOT EXISTS files (
    id        INTEGER PRIMARY KEY,
    path      TEXT NOT NULL UNIQUE,
    dir       TEXT NOT NULL,
    name      TEXT NOT NULL,
    size      INTEGER NOT NULL,
    mtime_ns  INTEGER NOT NULL,
    ctime_ns  INTEGER NOT NULL DEFAULT 0,
    dev       INTEGER NOT NULL,
    ino       INTEGER NOT NULL,
    nlink     INTEGER NOT NULL DEFAULT 1,
    kind      TEXT NOT NULL,
    fmt       TEXT NOT NULL,
    partial   TEXT,              -- "b3:..." hash of first/middle/last 64 KB (+ size)
    full      TEXT,              -- "b3:..." hash of the whole file
    shared    INTEGER,           -- 1 = data shared on disk (Btrfs reflink/snapshot), 0 = not, NULL = unknown
    scan_id   INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS files_size  ON files(size);
CREATE INDEX IF NOT EXISTS files_full  ON files(full);
CREATE INDEX IF NOT EXISTS files_name  ON files(name);
CREATE INDEX IF NOT EXISTS files_inode ON files(dev, ino);
CREATE INDEX IF NOT EXISTS files_dir   ON files(dir);
CREATE TABLE IF NOT EXISTS scans (
    id       INTEGER PRIMARY KEY,
    started  REAL NOT NULL,
    finished REAL,
    roots    TEXT NOT NULL,
    status   TEXT NOT NULL,       -- running | done | cancelled | failed
    files    INTEGER DEFAULT 0,
    skipped  INTEGER DEFAULT 0
);
CREATE TABLE IF NOT EXISTS skipped (
    scan_id INTEGER NOT NULL,
    path    TEXT NOT NULL,
    reason  TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS skipped_scan ON skipped(scan_id);
"""

# Step-by-step upgrades of older index files: {new_version: [statements]}
MIGRATIONS = {
    2: [  # media metadata, valid while meta_mtime_ns == mtime_ns
        "ALTER TABLE files ADD COLUMN width INTEGER",
        "ALTER TABLE files ADD COLUMN height INTEGER",
        "ALTER TABLE files ADD COLUMN duration REAL",
        "ALTER TABLE files ADD COLUMN taken TEXT",
        "ALTER TABLE files ADD COLUMN birth_ns INTEGER",
        "ALTER TABLE files ADD COLUMN codec TEXT",
        "ALTER TABLE files ADD COLUMN meta_error TEXT",
        "ALTER TABLE files ADD COLUMN meta_mtime_ns INTEGER",
    ],
}

# Insert a file, or update it. Cached hashes survive only if size, mtime, inode and device are unchanged.
_SAME =("files.size = excluded.size AND files.mtime_ns = excluded.mtime_ns "
         "AND files.ino = excluded.ino AND files.dev = excluded.dev")
UPSERT = f"""
INSERT INTO files (path, dir, name, size, mtime_ns, ctime_ns, dev, ino, nlink, kind, fmt, scan_id)
VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
ON CONFLICT(path) DO UPDATE SET
    partial  = CASE WHEN {_SAME} THEN files.partial ELSE NULL END,
    full     = CASE WHEN {_SAME} THEN files.full    ELSE NULL END,
    shared   = CASE WHEN {_SAME} THEN files.shared  ELSE NULL END,
    size = excluded.size, mtime_ns = excluded.mtime_ns, ctime_ns = excluded.ctime_ns,
    dev = excluded.dev, ino = excluded.ino, nlink = excluded.nlink,
    kind = excluded.kind, fmt = excluded.fmt, scan_id = excluded.scan_id
"""


@dataclass(slots=True)        # one per indexed file: slots keep 200 000 of them small
class FileRow:
    id: int
    path: str
    dir: str
    name: str
    size: int
    mtime_ns: int
    ctime_ns: int
    dev: int
    ino: int
    nlink: int
    kind: str
    fmt: str
    partial: str | None
    full: str | None
    shared: int | None
    width: int | None = None
    height: int | None = None
    duration: float | None = None
    taken: str | None = None
    birth_ns: int | None = None
    codec: str | None = None
    meta_error: str | None = None
    meta_mtime_ns: int | None = None

    COLUMNS = ("id, path, dir, name, size, mtime_ns, ctime_ns, dev, ino, nlink, kind, fmt, partial, full, shared, "
               "width, height, duration, taken, birth_ns, codec, meta_error, meta_mtime_ns")

    @property
    def has_meta(self) -> bool:
        return self.meta_mtime_ns == self.mtime_ns


class Index:
    def __init__(self, db_path: str | os.PathLike | None = None):
        self.path = Path(db_path) if db_path else paths.index_path()
        paths.ensure(self.path.parent)
        self.db = sqlite3.connect(str(self.path), timeout=30)
        self.db.execute("PRAGMA journal_mode=WAL")
        self.db.execute("PRAGMA synchronous=NORMAL")
        self.db.execute("PRAGMA foreign_keys=ON")
        # Large scans: a bigger page cache and fewer WAL checkpoints made index writes ~4x faster on a
        # 200 000-file library (milestone 9). The WAL may grow to ~40 MB during a scan.
        self.db.execute("PRAGMA cache_size=-32768")          # 32 MB
        self.db.execute("PRAGMA wal_autocheckpoint=10000")   # pages
        self._create_or_upgrade()
        self.forget_foreign_hashes()

    def forget_foreign_hashes(self) -> int:
        """Hashes made with another algorithm (e.g. BLAKE3 by one install, BLAKE2b by another without
        the blake3 module) can never be compared with ours: drop them so the next scan re-hashes those
        files, instead of silently missing duplicates. Returns how many rows were reset."""
        from .hasher import ALGO
        prefix = ALGO + ":"
        cur = self.db.execute(
            "UPDATE files SET partial = NULL, full = NULL, shared = NULL "
            "WHERE (partial IS NOT NULL AND substr(partial, 1, ?) != ?) "
            "   OR (full IS NOT NULL AND substr(full, 1, ?) != ?)", (len(prefix), prefix, len(prefix), prefix))
        self.db.commit()
        return cur.rowcount

    def _create_or_upgrade(self):
        """Create / upgrade the schema under an exclusive write lock, so two threads or two app
        windows opening a new index at the same moment can't both try to add the same columns."""
        db = self.db
        db.commit()
        db.execute("BEGIN IMMEDIATE")
        try:
            version = db.execute("PRAGMA user_version").fetchone()[0]
            if version > SCHEMA_VERSION:
                raise RuntimeError(f"Index {self.path} was made by a newer Clone Ranger (schema {version}).")
            for stmt in SCHEMA.split(";"):
                if stmt.strip():
                    db.execute(stmt)
            version = max(version, 1)  # brand-new file: the base schema is version 1
            for v in range(version + 1, SCHEMA_VERSION + 1):
                cols = {r[1] for r in db.execute("PRAGMA table_info(files)")}
                for stmt in MIGRATIONS[v]:
                    if stmt.startswith("ALTER TABLE files ADD COLUMN") and stmt.split()[5] in cols:
                        continue  # already there
                    db.execute(stmt)
                db.execute(f"PRAGMA user_version={v}")
            db.commit()
        except BaseException:
            db.rollback()
            raise

    def close(self):
        self.db.close()

    # ------------------------------------------------------------------ scans
    def begin_scan(self, roots: list[str]) -> int:
        cur = self.db.execute("INSERT INTO scans (started, roots, status) VALUES (?, ?, 'running')",
                              (time.time(), "\n".join(roots)))
        self.db.commit()
        return cur.lastrowid

    def add_files(self, scan_id: int, entries, commit: bool = True) -> None:
        rows = [(e.path, os.path.dirname(e.path), os.path.basename(e.path), e.size, e.mtime_ns, e.ctime_ns,
                 db_int(e.dev), db_int(e.ino), e.nlink, e.kind, e.fmt, scan_id) for e in entries]
        if rows:
            self.db.executemany(UPSERT, rows)
        if commit:
            self.db.commit()

    def known_in_dir(self, directory: str) -> dict:
        """{file name: (size, mtime_ns, ino, kind, fmt)} for files already indexed in this folder.
        Lets a rescan skip opening files that haven't changed (their type is already known)."""
        return {name: (size, mtime, ino, kind, fmt) for name, size, mtime, ino, kind, fmt in self.db.execute(
            "SELECT name, size, mtime_ns, ino, kind, fmt FROM files WHERE dir = ?", (directory,))}

    def add_skipped(self, scan_id: int, items) -> None:
        rows = [(scan_id, s.path, s.reason) for s in items]
        if rows:
            self.db.executemany("INSERT INTO skipped (scan_id, path, reason) VALUES (?, ?, ?)", rows)
            self.db.commit()

    def finish_scan(self, scan_id: int, roots: list[str], status: str) -> int:
        """Record the result. After a COMPLETE scan, forget files under the scanned roots that
        were not seen again (they were deleted or moved). Returns how many rows were removed."""
        removed = 0
        if status == "done":
            for root in roots:
                root = os.path.normpath(os.path.expanduser(root))
                prefix = with_sep(root)        # "/" and "C:\\" already end with the separator
                cur = self.db.execute(
                    "DELETE FROM files WHERE scan_id != ? AND (path = ? OR substr(path, 1, ?) = ?)",
                    (scan_id, root, len(prefix), prefix))
                removed += cur.rowcount
        n_files = self.db.execute("SELECT COUNT(*) FROM files WHERE scan_id = ?", (scan_id,)).fetchone()[0]
        n_skipped = self.db.execute("SELECT COUNT(*) FROM skipped WHERE scan_id = ?", (scan_id,)).fetchone()[0]
        self.db.execute("UPDATE scans SET finished = ?, status = ?, files = ?, skipped = ? WHERE id = ?",
                        (time.time(), status, n_files, n_skipped, scan_id))
        # keep the skipped log of the last 5 scans only
        self.db.execute("DELETE FROM skipped WHERE scan_id NOT IN (SELECT id FROM scans ORDER BY id DESC LIMIT 5)")
        self.db.commit()
        return removed

    def last_scan(self) -> dict | None:
        row = self.db.execute("SELECT id, started, finished, roots, status, files, skipped FROM scans "
                              "ORDER BY id DESC LIMIT 1").fetchone()
        if not row:
            return None
        return dict(zip(("id", "started", "finished", "roots", "status", "files", "skipped"), row))

    def skipped(self, scan_id: int) -> list[tuple[str, str]]:
        return self.db.execute("SELECT path, reason FROM skipped WHERE scan_id = ? ORDER BY path",
                               (scan_id,)).fetchall()

    # ------------------------------------------------------------------ queries
    def _rows(self, sql, args=()) -> list[FileRow]:
        return [FileRow(*r) for r in self.db.execute(f"SELECT {FileRow.COLUMNS} FROM files {sql}", args)]

    def count(self) -> int:
        return self.db.execute("SELECT COUNT(*) FROM files").fetchone()[0]

    def candidate_sizes(self, min_size: int = 1) -> list[int]:
        """Sizes shared by at least two different inodes (hard links alone don't count)."""
        return [r[0] for r in self.db.execute(
            "SELECT size FROM files WHERE size >= ? GROUP BY size HAVING COUNT(DISTINCT dev || ':' || ino) > 1",
            (min_size,))]

    def files_with_size(self, size: int) -> list[FileRow]:
        return self._rows("WHERE size = ? ORDER BY path", (size,))

    def all_files(self) -> list[FileRow]:
        return self._rows("ORDER BY path")

    def file(self, file_id: int) -> FileRow | None:
        rows = self._rows("WHERE id = ?", (file_id,))
        return rows[0] if rows else None

    # ------------------------------------------------------------------ hashes
    def set_partial(self, items: list[tuple[int, int, str, bool]]) -> None:
        """items: (dev, ino, partial_hash, is_full). Applied to every path of the same inode."""
        self.db.executemany("UPDATE files SET partial = ? WHERE dev = ? AND ino = ?",
                            [(h, dev, ino) for dev, ino, h, _ in items])
        self.db.executemany("UPDATE files SET full = ? WHERE dev = ? AND ino = ?",
                            [(h, dev, ino) for dev, ino, h, is_full in items if is_full])
        self.db.commit()

    def set_full(self, items: list[tuple[int, int, str, int | None]]) -> None:
        """items: (dev, ino, full_hash, shared)."""
        self.db.executemany("UPDATE files SET full = ?, shared = ? WHERE dev = ? AND ino = ?",
                            [(h, sh, dev, ino) for dev, ino, h, sh in items])
        self.db.commit()

    def set_shared(self, items: list[tuple[int, int, int | None]]) -> None:
        self.db.executemany("UPDATE files SET shared = ? WHERE dev = ? AND ino = ?",
                            [(sh, dev, ino) for dev, ino, sh in items])
        self.db.commit()

    def set_meta(self, items) -> None:
        """items: (file_id, mtime_ns, Meta)"""
        self.db.executemany(
            "UPDATE files SET width = ?, height = ?, duration = ?, taken = ?, birth_ns = ?, codec = ?, "
            "meta_error = ?, meta_mtime_ns = ? WHERE id = ?",
            [(m.width, m.height, m.duration, m.taken, m.birth_ns, m.codec, m.error, mt, fid)
             for fid, mt, m in items])
        self.db.commit()

    def files_by_ids(self, ids) -> list[FileRow]:
        ids = list(ids)
        out = []
        for i in range(0, len(ids), 500):
            chunk = ids[i:i + 500]
            out += self._rows(f"WHERE id IN ({','.join('?' * len(chunk))})", chunk)
        return out

    # ------------------------------------------------------------------ after file operations (no rescan)
    def remove_paths(self, paths_) -> int:
        n = 0
        for p in paths_:
            n += self.db.execute("DELETE FROM files WHERE path = ?", (p,)).rowcount
        self.db.commit()
        return n

    def relocate(self, old: str, new: str) -> None:
        """A file was moved or renamed: keep its hashes and metadata (the content is unchanged and,
        for copies across drives, verified), refresh what the file system says about it."""
        try:
            st = os.lstat(new)
        except OSError:
            return
        self.db.execute("DELETE FROM files WHERE path = ? AND path != ?", (new, old))   # overwritten row
        self.db.execute("UPDATE files SET path = ?, dir = ?, name = ?, dev = ?, ino = ?, nlink = ?, "
                        "mtime_ns = ?, ctime_ns = ?, "
                        "meta_mtime_ns = CASE WHEN meta_mtime_ns = mtime_ns THEN ? ELSE meta_mtime_ns END "
                        "WHERE path = ?",
                        (new, os.path.dirname(new), os.path.basename(new), db_int(st.st_dev), db_int(st.st_ino),
                         st.st_nlink,
                         st.st_mtime_ns, st.st_ctime_ns, st.st_mtime_ns, old))
        self.db.commit()

    def restore_path(self, path: str, full_hash: str | None) -> None:
        """A file came back (undo of Move to Trash): list it again with its known hash."""
        from .media_types import classify
        try:
            st = os.lstat(path)
            kind_fmt = classify(path, sniff_unknown=True)
        except OSError:
            return
        if not kind_fmt:
            return
        last = self.last_scan()
        self.db.execute(UPSERT, (path, os.path.dirname(path), os.path.basename(path), st.st_size, st.st_mtime_ns,
                                 st.st_ctime_ns, db_int(st.st_dev), db_int(st.st_ino), st.st_nlink, kind_fmt[0], kind_fmt[1],
                                 last["id"] if last else 0))
        if full_hash:
            self.db.execute("UPDATE files SET full = ? WHERE path = ?", (full_hash, path))
        self.db.commit()

    def stats(self) -> dict:
        r = self.db.execute("SELECT COUNT(*), COALESCE(SUM(size), 0), "
                            "SUM(kind = 'image'), SUM(kind = 'video'), "
                            "SUM(partial IS NOT NULL), SUM(full IS NOT NULL) FROM files").fetchone()
        return dict(zip(("files", "bytes", "images", "videos", "partial_hashed", "full_hashed"),
                        [x or 0 for x in r]))
