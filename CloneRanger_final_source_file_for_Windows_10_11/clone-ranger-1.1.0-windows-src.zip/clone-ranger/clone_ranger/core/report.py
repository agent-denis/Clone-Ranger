"""CSV export of the duplicates report (one row per file)."""
import csv

HEADER = ["case", "kind", "hash", "size_bytes", "copies", "reclaim_bytes", "path", "recommended_keep",
          "selected_for_removal", "hard_link_of", "shared_on_disk", "reason"]


def write_csv(path: str, rows) -> int:
    """rows: iterables of dicts with the HEADER keys (missing keys are left empty). Returns row count."""
    n = 0
    with open(path, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=HEADER, extrasaction="ignore")
        w.writeheader()
        for r in rows:
            w.writerow({k: ("" if r.get(k) is None else r.get(k)) for k in HEADER})
            n += 1
    return n


def rows_from_core_groups(groups):
    for n, g in enumerate(groups, 1):
        for m in g.members:
            yield {"case": n, "kind": g.kind, "hash": g.hash, "size_bytes": g.size, "copies": g.copies,
                   "reclaim_bytes": g.reclaim, "path": m.file.path, "hard_link_of": m.hard_link_of or "",
                   "shared_on_disk": "" if m.file.shared is None else bool(m.file.shared)}
