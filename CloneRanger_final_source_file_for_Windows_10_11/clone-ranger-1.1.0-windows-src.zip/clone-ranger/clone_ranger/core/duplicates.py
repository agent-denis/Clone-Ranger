"""Find duplicates in the index.

Same content:  size  ->  partial hash (3 x 64 KB)  ->  full hash, only for files that still match.
               Hard links (same device + inode) are one file on disk: hashed once, labelled
               "hard link", and never counted in the space to reclaim.
Same name:     identical file names in different folders (optionally ignoring case / extension),
               marked whether their content also matches.
"""
from __future__ import annotations

import os
import time
from collections import defaultdict
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass, field
from typing import Callable

from . import hasher, reflink
from .control import Control
from .index import FileRow, Index


@dataclass
class Member:
    file: FileRow
    hard_link_of: str | None = None   # path of the first file with the same inode in this group

    @property
    def hard_link(self) -> bool:
        return self.hard_link_of is not None


@dataclass
class ContentGroup:
    hash: str
    size: int
    members: list[Member] = field(default_factory=list)

    @property
    def inodes(self) -> int:
        return len({(m.file.dev, m.file.ino) for m in self.members})

    @property
    def copies(self) -> int:
        """Real copies on disk (hard links excluded)."""
        return self.inodes

    @property
    def shared_inodes(self) -> int:
        return len({(m.file.dev, m.file.ino) for m in self.members if m.file.shared})

    @property
    def reclaim(self) -> int:
        """Space freed by keeping one copy. Copies whose data is shared on disk (reflinks/snapshots)
        free (almost) nothing, so at best we can free the unshared ones."""
        removable = self.inodes - 1
        unshared = self.inodes - self.shared_inodes
        return self.size * max(0, min(removable, unshared))

    @property
    def kind(self) -> str:
        return self.members[0].file.kind


@dataclass
class NameGroup:
    key: str
    files: list[FileRow]
    content: str          # "same" | "different" | "unknown"


ProgressFn = Callable[[dict], None]


def _rep_per_inode(rows: list[FileRow]) -> list[FileRow]:
    seen, reps = set(), []
    for r in rows:
        k = (r.dev, r.ino)
        if k not in seen:
            seen.add(k)
            reps.append(r)
    return reps


def find_content_groups(index: Index, control: Control | None = None, progress: ProgressFn | None = None,
                        min_size: int = 1, workers: int = 2, check_shared: bool = True) -> list[ContentGroup]:
    control = control or Control()
    emit = progress or (lambda e: None)
    last = [0.0]

    def tick(event, force=False):
        if force or time.monotonic() - last[0] > .1:
            last[0] = time.monotonic()
            emit(event)

    # 1. candidates: sizes shared by 2+ different inodes
    sizes = index.candidate_sizes(min_size)
    by_size = {s: _rep_per_inode(index.files_with_size(s)) for s in sizes}

    # 2. partial hashes (cheap) for representatives that don't have one yet
    todo = [r for reps in by_size.values() for r in reps if r.partial is None]
    done = 0

    def do_partial(r: FileRow):
        control.checkpoint()
        try:
            return r, hasher.partial_hash(r.path, r.size), None
        except OSError as e:
            return r, None, e.strerror or str(e)

    errors: list[tuple[str, str]] = []
    batch = []
    with ThreadPoolExecutor(max_workers=workers) as pool:
        for r, res, err in pool.map(do_partial, todo):
            done += 1
            if res is None:
                errors.append((r.path, err))
            else:
                r.partial = res[0]
                if res[1]:
                    r.full = res[0]
                batch.append((r.dev, r.ino, res[0], res[1]))
            if len(batch) >= 500:
                index.set_partial(batch)
                batch = []
            tick({"phase": "partial", "done": done, "total": len(todo), "current": r.path})
    index.set_partial(batch)

    # 3. full hashes for files whose (size, partial) still matches another inode
    need_full: list[FileRow] = []
    for size, reps in by_size.items():
        buckets = defaultdict(list)
        for r in reps:
            if r.partial:
                buckets[r.partial].append(r)
        for members in buckets.values():
            if len(members) > 1:
                need_full += [m for m in members if m.full is None]
    total_bytes = sum(r.size for r in need_full)
    hashed = [0]

    def on_bytes(n):
        hashed[0] += n
        tick({"phase": "full", "bytes": hashed[0], "total_bytes": total_bytes})

    def do_full(r: FileRow):
        try:
            return r, hasher.full_hash(r.path, control, on_bytes), None
        except OSError as e:
            return r, None, e.strerror or str(e)

    batch = []
    with ThreadPoolExecutor(max_workers=workers) as pool:
        for r, h, err in pool.map(do_full, need_full):
            if h is None:
                errors.append((r.path, err))
                continue
            r.full = h
            batch.append((r.dev, r.ino, h, None))
            if len(batch) >= 50:
                index.set_full(batch)
                batch = []
    index.set_full(batch)
    tick({"phase": "full", "bytes": hashed[0], "total_bytes": total_bytes}, force=True)

    # 4. group all rows (incl. hard links) by full hash
    groups: list[ContentGroup] = []
    for size in sizes:
        rows = index.files_with_size(size)
        by_hash = defaultdict(list)
        for r in rows:
            if r.full:
                by_hash[r.full].append(r)
        for h, members in by_hash.items():
            if len({(m.dev, m.ino) for m in members}) < 2:
                continue
            g = ContentGroup(hash=h, size=size)
            first_of_inode = {}
            for m in members:
                k = (m.dev, m.ino)
                g.members.append(Member(m, hard_link_of=first_of_inode.get(k)))
                first_of_inode.setdefault(k, m.path)
            groups.append(g)

    # 5. on Btrfs/XFS: which copies share their data on disk (affects space to reclaim)
    if check_shared:
        unknown = [m.file for g in groups for m in g.members if m.file.shared is None and not m.hard_link]
        upd = []
        for r in unknown:
            control.checkpoint()
            s = reflink.is_shared(r.path)
            r.shared = None if s is None else int(s)
            upd.append((r.dev, r.ino, r.shared))
        index.set_shared(upd)

    groups.sort(key=lambda g: (-g.reclaim, -g.size, g.members[0].file.path))
    emit({"phase": "grouped", "groups": len(groups), "errors": errors})
    return groups


def groups_from_index(index: Index, min_size: int = 1) -> list[ContentGroup]:
    """Rebuild groups from hashes already stored in the index (no file is read).
    Used at start-up to show the results of the last scan instantly."""
    rows = [FileRow(*r) for r in index.db.execute(
        f"SELECT {FileRow.COLUMNS} FROM files WHERE full IN ("
        "  SELECT full FROM files WHERE full IS NOT NULL AND size >= ? "
        "  GROUP BY full HAVING COUNT(DISTINCT dev || ':' || ino) > 1) ORDER BY full, path", (min_size,))]
    by_hash = defaultdict(list)
    for r in rows:
        by_hash[r.full].append(r)
    groups = []
    for h, members in by_hash.items():
        g = ContentGroup(hash=h, size=members[0].size)
        first_of_inode = {}
        for m in members:
            k = (m.dev, m.ino)
            g.members.append(Member(m, hard_link_of=first_of_inode.get(k)))
            first_of_inode.setdefault(k, m.path)
        groups.append(g)
    groups.sort(key=lambda g: (-g.reclaim, -g.size, g.members[0].file.path))
    return groups


def name_key(name: str, ignore_case: bool, ignore_ext: bool) -> str:
    if ignore_ext:
        name = os.path.splitext(name)[0]
    return name.casefold() if ignore_case else name


def find_name_groups(index: Index, ignore_case: bool = False, ignore_ext: bool = False) -> list[NameGroup]:
    buckets: dict[str, list[FileRow]] = defaultdict(list)
    for r in index.all_files():
        buckets[name_key(r.name, ignore_case, ignore_ext)].append(r)
    groups = []
    for key, files in buckets.items():
        if len({f.dir for f in files}) < 2:
            continue
        if len({f.size for f in files}) > 1:
            content = "different"
        elif all(f.full for f in files):
            content = "same" if len({f.full for f in files}) == 1 else "different"
        else:
            content = "unknown"
        groups.append(NameGroup(key=key, files=sorted(files, key=lambda f: f.path), content=content))
    groups.sort(key=lambda g: (g.content != "same", g.key))
    return groups


def totals(groups: list[ContentGroup]) -> dict:
    return {
        "groups": len(groups),
        "duplicate_files": sum(g.copies - 1 for g in groups),
        "hard_links": sum(1 for g in groups for m in g.members if m.hard_link),
        "reclaim": sum(g.reclaim for g in groups),
    }
