"""The freedesktop.org Trash (the one Files / Dolphin show and restore from).

Spec: https://specifications.freedesktop.org/trash-spec/latest/
- Files on the same mount as your home folder go to ~/.local/share/Trash.
- Files on other drives go to that drive's own Trash: $topdir/.Trash/$UID (if the
  administrator made a sticky .Trash folder) or $topdir/.Trash-$UID.
- For every file, an info/<name>.trashinfo records where it came from and when.
If a drive has no usable Trash, TrashUnavailable is raised and NOTHING is deleted;
the caller asks the user what to do.

On Windows the same functions (trash, restore, can_trash) use the Recycle Bin instead:
see recycle_bin.py, which replaces them at the end of this file.
"""
from __future__ import annotations

import datetime
import errno
import os
import stat
import urllib.parse

from . import fsops, sandbox
from .osinfo import WINDOWS
from .trash_types import Trashed, TrashUnavailable

__all__ = ["Trashed", "TrashUnavailable", "can_trash", "restore", "trash"]


def home_trash() -> str:
    data = os.environ.get("XDG_DATA_HOME")
    base = data if data and os.path.isabs(data) else os.path.expanduser("~/.local/share")
    return os.path.join(base, "Trash")


def _unescape(s: str) -> str:
    # /proc/self/mountinfo escapes space, tab, newline and backslash as \ooo
    out, i = [], 0
    while i < len(s):
        if s[i] == "\\" and i + 4 <= len(s) and s[i + 1:i + 4].isdigit():
            out.append(chr(int(s[i + 1:i + 4], 8)))
            i += 4
        else:
            out.append(s[i])
            i += 1
    return "".join(out)


def mount_points() -> list[str]:
    try:
        with open("/proc/self/mountinfo", encoding="utf-8", errors="surrogateescape") as f:
            return [_unescape(line.split()[4]) for line in f if len(line.split()) > 4]
    except OSError:
        return ["/"]


def mount_point(path: str) -> str:
    """The mount point a path lives on (longest matching mount point)."""
    real = sandbox.resolve(path)
    if not os.path.isdir(real):
        real = os.path.dirname(real)
    best = "/"
    for mp in mount_points():
        if (real == mp or real.startswith(mp.rstrip("/") + "/")) and len(mp) > len(best):
            best = mp
    return best


def _valid_dir(path: str, owner_only: bool) -> bool:
    try:
        st = os.lstat(path)
    except OSError:
        return False
    if not stat.S_ISDIR(st.st_mode):
        return False   # also rejects symlinks
    if owner_only and st.st_uid != os.getuid():
        return False
    return True


def _writable(path: str) -> bool:
    """Could we create `path`? (the nearest existing folder above it is writable)"""
    p = path
    while not os.path.exists(p):
        parent = os.path.dirname(p)
        if parent == p:
            return False
        p = parent
    return os.path.isdir(p) and os.access(p, os.W_OK)


def _prepare(trash: str, create: bool) -> str:
    for sub in ("files", "info"):
        d = os.path.join(trash, sub)
        sandbox.check(d)
        if create:
            os.makedirs(d, mode=0o700, exist_ok=True)
        elif not _writable(d):
            raise TrashUnavailable(errno.EACCES, "no permission to use the Trash folder", trash)
    return trash


def trash_dir_for(path: str, create: bool = True) -> str:
    """Return the Trash folder for this file (creating it if needed), or raise TrashUnavailable."""
    path = sandbox.check(path)
    home = home_trash()
    if mount_point(path) == mount_point(home):
        sandbox.check(home)
        return _prepare(home, create)
    top = mount_point(path)
    uid = str(os.getuid())
    admin = os.path.join(top, ".Trash")
    try:
        st = os.lstat(admin)
        if stat.S_ISDIR(st.st_mode) and st.st_mode & stat.S_ISVTX:
            user = os.path.join(admin, uid)
            sandbox.check(user)
            if _valid_dir(user, True):
                return _prepare(user, create)
            if create:
                try:
                    os.mkdir(user, 0o700)
                    return _prepare(user, create)
                except OSError:
                    pass
            elif os.access(admin, os.W_OK):
                return user
    except OSError:
        pass
    user = os.path.join(top, f".Trash-{uid}")
    sandbox.check(user)
    if os.path.lexists(user):
        if not _valid_dir(user, True):
            raise TrashUnavailable(errno.EPERM, "the drive's Trash folder is not safe to use", user)
        return _prepare(user, create)
    if not create:
        if not os.access(top, os.W_OK):
            raise TrashUnavailable(errno.EACCES, "this drive has no Trash and can't get one (read-only?)", top)
        return user
    try:
        os.mkdir(user, 0o700)
    except OSError as e:
        raise TrashUnavailable(e.errno or errno.EACCES, f"this drive has no Trash ({e.strerror})", top) from None
    return _prepare(user, create)


def can_trash(path: str) -> tuple[bool, str]:
    try:
        trash_dir_for(path, create=False)
        return True, ""
    except TrashUnavailable as e:
        return False, e.strerror or str(e)
    except OSError as e:
        return False, e.strerror or str(e)


def _info_path_value(trash: str, original: str) -> str:
    # home Trash: absolute path. Drive Trash: path relative to the drive's top folder.
    top = os.path.dirname(trash) if os.path.basename(trash).startswith(".Trash-") else \
        os.path.dirname(os.path.dirname(trash))
    value = original
    if trash != home_trash() and (original + "/").startswith(top.rstrip("/") + "/"):
        value = os.path.relpath(original, top)
    return urllib.parse.quote(value, safe="/")


def trash(path: str) -> Trashed:
    """Move one file to the Trash. Raises TrashUnavailable if the drive has none (file untouched)."""
    path = sandbox.check(path)
    tdir = trash_dir_for(path)
    files, info = os.path.join(tdir, "files"), os.path.join(tdir, "info")
    base = os.path.basename(path)
    stem, ext = os.path.splitext(base)
    when = datetime.datetime.now().strftime("%Y-%m-%dT%H:%M:%S")
    body = f"[Trash Info]\nPath={_info_path_value(tdir, path)}\nDeletionDate={when}\n".encode()
    n = 1
    while True:
        name = base if n == 1 else f"{stem}.{n}{ext}"
        info_file = os.path.join(info, name + ".trashinfo")
        target = os.path.join(files, name)
        sandbox.check(info_file)
        try:
            fd = os.open(info_file, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)   # reserves the name
        except FileExistsError:
            n += 1
            continue
        if os.path.lexists(target):       # stray file without info: pick another name
            os.close(fd)
            os.unlink(info_file)
            n += 1
            continue
        with os.fdopen(fd, "wb") as f:
            f.write(body)
            f.flush()
            os.fsync(f.fileno())
        try:
            fsops.rename_noreplace(path, target)
        except OSError as e:
            os.unlink(info_file)
            if e.errno == errno.EXDEV:
                raise TrashUnavailable(errno.EXDEV, "the Trash is on a different file system "
                                                    "(separate Btrfs subvolume?)", path) from None
            raise
        return Trashed(path, target, info_file)


def restore(trash_file: str, info_file: str, original: str) -> None:
    """Put a trashed file back (never overwriting a file that took its place)."""
    sandbox.check(trash_file)
    sandbox.check(original)
    if not os.path.lexists(trash_file):
        raise fsops.Changed("is no longer in the Trash (emptied or restored already)")
    parent = os.path.dirname(original)
    if not os.path.isdir(parent):
        fsops.makedirs(parent)
    fsops.rename_noreplace(trash_file, original)
    try:
        sandbox.check(info_file)
        os.unlink(info_file)
    except OSError:
        pass


if WINDOWS:   # the Recycle Bin instead of the freedesktop Trash
    from . import recycle_bin as _recycle_bin
    trash = _recycle_bin.trash                # noqa: F811
    restore = _recycle_bin.restore            # noqa: F811
    can_trash = _recycle_bin.can_trash        # noqa: F811
