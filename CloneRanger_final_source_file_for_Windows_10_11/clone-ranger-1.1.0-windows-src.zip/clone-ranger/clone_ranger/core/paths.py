"""Where Clone Ranger keeps its files (XDG base directories, overridable via environment).

    ~/.config/clone-ranger/settings.json         settings
    ~/.cache/clone-ranger/index.sqlite, thumbs/   scan index and thumbnails (the "cache": safe to delete)
    ~/.local/state/clone-ranger/journal.jsonl     action history (Undo) and the app log (the "history")

On Windows (unless the XDG variables are set, as the tests do):
    %APPDATA%\\Clone Ranger\\settings.json
    %LOCALAPPDATA%\\Clone Ranger\\cache\\  (index.sqlite, thumbs\\)
    %LOCALAPPDATA%\\Clone Ranger\\state\\  (journal.jsonl, clone-ranger.log)
"""
import os
from pathlib import Path

from .osinfo import WINDOWS

APP = "clone-ranger"
WIN_APP = "Clone Ranger"


def _xdg(var: str, default: str) -> Path | None:
    value = os.environ.get(var)
    if value and os.path.isabs(value):
        return Path(value) / APP
    return None if WINDOWS else Path.home() / default / APP


def _win(var: str, fallback: str, *sub: str) -> Path:
    value = os.environ.get(var)
    base = Path(value) if value and os.path.isabs(value) else Path.home() / fallback
    return base.joinpath(WIN_APP, *sub)


def config_dir() -> Path:      # settings
    return _xdg("XDG_CONFIG_HOME", ".config") or _win("APPDATA", "AppData/Roaming")


def cache_dir() -> Path:       # scan index + thumbnails (safe to delete; rebuilt on next scan)
    return _xdg("XDG_CACHE_HOME", ".cache") or _win("LOCALAPPDATA", "AppData/Local", "cache")


def state_dir() -> Path:       # logs, action journal / undo history
    return _xdg("XDG_STATE_HOME", ".local/state") or _win("LOCALAPPDATA", "AppData/Local", "state")


def index_path() -> Path:
    return cache_dir() / "index.sqlite"


def thumbs_dir() -> Path:
    return cache_dir() / "thumbs"


def journal_path() -> Path:
    return state_dir() / "journal.jsonl"


def ensure(p: Path) -> Path:
    p.mkdir(parents=True, exist_ok=True)
    return p

