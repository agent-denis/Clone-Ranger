"""One full surveillance run: scan folders -> update index -> find duplicates.

Used by both the command line and the window. Read-only towards your files.
"""
from __future__ import annotations

import time
from dataclasses import dataclass, field

from .control import Cancelled, Control
from .duplicates import ContentGroup, find_content_groups, totals
from .index import Index
from .scanner import FileEntry, ScanConfig, Skipped, scan


@dataclass
class ScanResult:
    status: str                    # done | cancelled
    scan_id: int
    files: int = 0
    skipped: int = 0
    removed: int = 0               # index rows dropped because the file is gone
    seconds: float = 0.0
    groups: list[ContentGroup] = field(default_factory=list)
    hash_errors: list[tuple[str, str]] = field(default_factory=list)

    @property
    def totals(self) -> dict:
        return totals(self.groups)


def run(index: Index, cfg: ScanConfig, control: Control | None = None, progress=None,
        find_duplicates: bool = True, workers: int = 2) -> ScanResult:
    control = control or Control()
    emit = progress or (lambda e: None)
    t0 = time.monotonic()
    scan_id = index.begin_scan(cfg.roots)
    result = ScanResult(status="running", scan_id=scan_id)
    files_buf, skip_buf = [], []
    batches = 0
    try:
        for item in scan(cfg, control, emit, known=index.known_in_dir):
            if isinstance(item, FileEntry):
                files_buf.append(item)
                result.files += 1
                if len(files_buf) >= 1000:
                    batches += 1
                    # commit every 5 000 files: committing each 1 000 cost most of the listing time
                    index.add_files(scan_id, files_buf, commit=batches % 5 == 0)
                    files_buf = []
            elif isinstance(item, Skipped):
                skip_buf.append(item)
                result.skipped += 1
                emit({"phase": "skipped", "path": item.path, "reason": item.reason})
        index.add_files(scan_id, files_buf)
        index.add_skipped(scan_id, skip_buf)
        result.removed = index.finish_scan(scan_id, cfg.roots, "done")
        if find_duplicates:
            def relay(e):
                if e.get("phase") == "grouped":
                    result.hash_errors = e.get("errors", [])
                emit(e)
            result.groups = find_content_groups(index, control, relay, cfg.min_size, workers)
        result.status = "done"
    except Cancelled:
        index.add_files(scan_id, files_buf)
        index.add_skipped(scan_id, skip_buf)
        index.finish_scan(scan_id, cfg.roots, "cancelled")
        result.status = "cancelled"
    result.seconds = time.monotonic() - t0
    return result
