"""Which copy to keep? Suggest one copy per group, with a human-readable reason.

The suggestion only PRE-SELECTS the other copies; nothing happens without the
user's confirmation. Rules are applied in order; each rule narrows the
candidates down to the best ones, and the rules that made a difference become
the reason ("Keep: oldest copy, in ~/Pictures"). Which rules are on, their order
and the preferred folders come from Settings (settings.json: keep_rules, preferred_folders).
"""
from __future__ import annotations

import os
import re
from dataclasses import dataclass
from typing import Callable

from ..util import short_path
from .osinfo import is_within

COPY_MARKERS = re.compile(
    r"(\s*-\s*copy(\s*\(\d+\))?|\s*copy(\s*of)?|\s*\(\d+\)|_\d{1,2}|\s*-\s*kopie|\s*копия)$",
    re.IGNORECASE)
TEMP_FOLDERS = ("downloads", "download", "tmp", "temp", "desktop", "загрузки", "telegram desktop", "whatsapp",
                "cache", ".cache")


@dataclass
class Candidate:
    path: str
    size: int
    mtime_ns: int
    birth_ns: int | None = None
    width: int | None = None
    height: int | None = None
    protected: bool = False

    @property
    def stem(self) -> str:
        return os.path.splitext(os.path.basename(self.path))[0]

    @property
    def age_key(self) -> tuple:
        """Older is smaller: modification time first (copies made with `cp -p` keep it), then the
        creation date, which tells which copy was made first."""
        return (self.mtime_ns or 0, self.birth_ns or self.mtime_ns or 0)


@dataclass
class Rule:
    key: str
    reason: str                      # shown after "Keep: "
    score: Callable[[Candidate], object]  # higher is better (numbers or tuples)


def has_copy_marker(stem: str) -> bool:
    return bool(COPY_MARKERS.search(stem))


def temp_score(path: str) -> int:
    """How many Downloads/temp-like folders the path goes through. Counted (not just yes/no) so that
    inside a folder like /tmp, a copy in Downloads still scores worse than one in Pictures.
    Windows paths may use \\ or / (on Linux \\ is an ordinary character in a name)."""
    if os.sep == "\\":
        path = path.replace("\\", "/")
    parts = [p.casefold() for p in path.split("/")[:-1]]
    return sum(1 for p in parts if p in TEMP_FOLDERS)


def in_temp_folder(path: str) -> bool:
    return temp_score(path) > 0


DEFAULT_PREFERRED = ["~/Pictures", "~/Videos"]

# Every available rule, in the default order, and whether it is on by default.
# "protected" always comes first and can't be switched off (a protected copy is never removed).
CATALOG = ("protected", "preferred", "not_temp", "clean_name", "resolution", "oldest", "newest", "shortest",
           "longest")
DEFAULT_ON = {"protected", "preferred", "not_temp", "clean_name", "resolution", "oldest", "shortest"}
LOCKED = {"protected"}


def default_config() -> list[list]:
    """[[rule key, enabled], ...] in the default order (what settings.json stores)."""
    return [[k, k in DEFAULT_ON] for k in CATALOG]


def normalize_config(config) -> list[list]:
    """Make a stored rule list safe: unknown keys dropped, missing rules appended (off), the locked
    rule first and on, no duplicates."""
    out, seen = [["protected", True]], {"protected"}
    for item in config or []:
        try:
            key, on = item[0], bool(item[1])
        except (TypeError, IndexError, KeyError):
            continue
        if key in CATALOG and key not in seen:
            out.append([key, on])
            seen.add(key)
    for k in CATALOG:
        if k not in seen:
            out.append([k, False if config else k in DEFAULT_ON])
    return out


def _rule(key: str, preferred: list[str]) -> Rule:
    return {
        "protected": Rule("protected", "in a protected folder", lambda c: 1 if c.protected else 0),
        "preferred": Rule("preferred", "in a preferred folder",
                          lambda c: 1 if any(is_within(c.path, p) for p in preferred) else 0),
        "not_temp": Rule("not_temp", "not in Downloads/temp", lambda c: -temp_score(c.path)),
        "clean_name": Rule("clean_name", "name without “copy”/“(1)”", lambda c: 0 if has_copy_marker(c.stem) else 1),
        "resolution": Rule("resolution", "highest resolution", lambda c: (c.width or 0) * (c.height or 0)),
        "oldest": Rule("oldest", "oldest copy", lambda c: tuple(-x for x in c.age_key)),
        "newest": Rule("newest", "newest copy", lambda c: c.age_key),
        "shortest": Rule("shortest", "shortest path", lambda c: -len(c.path)),
        "longest": Rule("longest", "deepest folder", lambda c: (c.path.count(os.sep), len(c.path))),
    }[key]


def build_rules(config=None, preferred: list[str] | None = None) -> list[Rule]:
    """The rules to apply, from settings: config = [[key, enabled], ...] (None = defaults)."""
    pref = [os.path.expanduser(p) for p in (DEFAULT_PREFERRED if preferred is None else preferred)]
    return [_rule(k, pref) for k, on in normalize_config(config if config is not None else default_config()) if on]


_DEFAULT_RULES: list[Rule] | None = None


def default_rules(preferred: list[str] | None = None) -> list[Rule]:
    """The default rules. Built once and reused (building them per case cost seconds on large libraries;
    ~HOME doesn't change while the app runs)."""
    global _DEFAULT_RULES
    if preferred is not None:
        return build_rules(None, preferred)
    if _DEFAULT_RULES is None:
        _DEFAULT_RULES = build_rules(None, None)
    return _DEFAULT_RULES


def recommend(cands: list[Candidate], rules: list[Rule] | None = None) -> tuple[int, str]:
    """Return (index of the copy to keep, reason)."""
    rules = rules if rules is not None else default_rules()
    alive = list(range(len(cands)))
    used = []
    for rule in rules:
        if len(alive) == 1:
            break
        scores = {i: rule.score(cands[i]) for i in alive}
        best = max(scores.values())
        winners = [i for i in alive if scores[i] == best]
        if len(winners) < len(alive):
            alive = winners
            used.append(rule.reason)
    keep = min(alive, key=lambda i: cands[i].path)  # stable tie-break
    folder = short_path(os.path.dirname(cands[keep].path))
    reason = "Keep: " + (", ".join(used) if used else "first by path") + f" – in {folder}"
    return keep, reason
