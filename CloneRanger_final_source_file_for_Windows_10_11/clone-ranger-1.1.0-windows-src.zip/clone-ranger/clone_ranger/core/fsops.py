"""Low-level, careful file system steps used by every operation.

- rename_noreplace: an atomic rename that FAILS if the target exists (never overwrites).
- expect_unchanged: refuse to act on a file that changed since the scan.
- copy_verified: copy to a temporary name, compare hashes, then put the file in place.
Every path passes through the sandbox check.
"""
from __future__ import annotations

import ctypes
import errno
import os
import secrets
import stat
from dataclasses import dataclass
from typing import Callable

from . import hasher, sandbox
from .osinfo import WINDOWS
from .control import Control

AT_FDCWD = -100
RENAME_NOREPLACE = 1
PART_PREFIX = ".clone-ranger-"
PART_SUFFIX = ".part"

_renameat2 = None
if not WINDOWS:   # Windows: os.rename already refuses to replace an existing file
    try:
        _libc = ctypes.CDLL(None, use_errno=True)
        _renameat2 = _libc.renameat2
        _renameat2.argtypes = [ctypes.c_int, ctypes.c_char_p, ctypes.c_int, ctypes.c_char_p, ctypes.c_uint]
        _renameat2.restype = ctypes.c_int
    except (OSError, AttributeError, TypeError):  # pragma: no cover - very old libc
        _renameat2 = None


class Changed(Exception):
    """The file is not what the scan saw (gone, replaced, edited, or now a symlink)."""


class VerifyFailed(OSError):
    """The copy's hash differs from the original's."""


@dataclass
class Stamp:
    size: int
    mtime_ns: int
    dev: int
    ino: int


def stamp(path: str) -> Stamp:
    st = os.lstat(path)
    return Stamp(st.st_size, st.st_mtime_ns, st.st_dev, st.st_ino)


def expect_unchanged(path: str, size: int | None, mtime_ns: int | None) -> os.stat_result:
    """lstat the file; it must be a regular file (not a symlink) with the expected size and mtime."""
    try:
        st = os.lstat(path)
    except FileNotFoundError:
        raise Changed("no longer exists") from None
    if stat.S_ISLNK(st.st_mode):
        raise Changed("is now a symbolic link")
    if not stat.S_ISREG(st.st_mode):
        raise Changed("is not a regular file")
    if size is not None and st.st_size != size:
        raise Changed("size changed since the scan")
    if mtime_ns is not None and st.st_mtime_ns != mtime_ns:
        raise Changed("modified since the scan")
    return st


def rename_noreplace(src: str, dst: str) -> None:
    """Rename src to dst; raise FileExistsError if dst exists. OSError(EXDEV) across file systems."""
    sandbox.check(src)
    sandbox.check(dst)
    if _renameat2 is not None:
        r = _renameat2(AT_FDCWD, os.fsencode(src), AT_FDCWD, os.fsencode(dst), RENAME_NOREPLACE)
        if r == 0:
            return
        e = ctypes.get_errno()
        if e not in (errno.EINVAL, errno.ENOSYS, errno.ENOTSUP):
            raise OSError(e, os.strerror(e), src, None, dst)
    # file system without RENAME_NOREPLACE support (some FUSE / network mounts): check, then rename.
    # On Windows os.rename itself fails with FileExistsError when dst exists, so this is atomic there.
    if os.path.lexists(dst) and not (WINDOWS and is_case_only_rename(src, dst)):
        raise FileExistsError(errno.EEXIST, "File exists", dst)
    os.rename(src, dst)


def same_file(a: str, b: str) -> bool:
    try:
        return os.path.samefile(a, b)
    except OSError:
        return False


def is_case_only_rename(src: str, dst: str) -> bool:
    """photo.JPG -> photo.jpg on a case-insensitive drive: same folder, same name apart from upper/lower case,
    and the 'existing' target really is the source file. A hard link with another name (a.jpg / b.jpg are one
    file) is NOT a case rename: that name is taken."""
    s, d = os.path.abspath(src), os.path.abspath(dst)
    return (os.path.normcase(os.path.dirname(s)) == os.path.normcase(os.path.dirname(d))
            and os.path.basename(s) != os.path.basename(d)
            and os.path.basename(s).casefold() == os.path.basename(d).casefold()
            and same_file(s, d))


def rename_case_safe(src: str, dst: str) -> None:
    """rename_noreplace, plus case-only renames on case-insensitive drives (photo.JPG -> photo.jpg),
    where the 'existing' target is the very same file: go through a temporary name."""
    try:
        rename_noreplace(src, dst)
    except FileExistsError:
        if not is_case_only_rename(src, dst):
            raise
        tmp = os.path.join(os.path.dirname(dst), f"{PART_PREFIX}{secrets.token_hex(4)}{PART_SUFFIX}")
        rename_noreplace(src, tmp)
        try:
            rename_noreplace(tmp, dst)
        except OSError:
            rename_noreplace(tmp, src)
            raise


def unlink(path: str) -> None:
    sandbox.check(path)
    os.unlink(path)


def makedirs(path: str) -> list[str]:
    """Create missing folders; return the ones created (deepest last) so undo can remove them."""
    sandbox.check(path)
    created = []
    p = os.path.abspath(path)
    while not os.path.isdir(p):
        created.append(p)
        parent = os.path.dirname(p)
        if parent == p:
            break
        p = parent
    for d in reversed(created):
        sandbox.check(d)
        os.mkdir(d)
    return list(reversed(created))


def remove_empty_dirs(dirs: list[str]) -> None:
    """Remove folders we created, deepest first, but only while they're empty."""
    for d in sorted(dirs, key=len, reverse=True):
        try:
            sandbox.check(d)
            os.rmdir(d)
        except OSError:
            pass


def part_name(directory: str) -> str:
    return os.path.join(directory, f"{PART_PREFIX}{secrets.token_hex(6)}{PART_SUFFIX}")


def copy_verified(src: str, dst: str, control: Control | None = None,
                  on_bytes: Callable[[int], None] | None = None, expected_hash: str | None = None) -> str:
    """Copy src to dst (which must not exist) and prove the copy is identical.

    1. copy into a hidden temporary file next to dst, hashing the source while reading,
    2. flush it to disk, copy the timestamps and permissions,
    3. read the copy back and hash it; both hashes (and the scan's hash, if known) must match,
    4. only then rename it to dst (without replacing anything).
    Returns the verified hash. On any failure the temporary file is removed and src is untouched.
    """
    sandbox.check(src)
    sandbox.check(dst)
    if os.path.lexists(dst):
        raise FileExistsError(errno.EEXIST, "File exists", dst)
    tmp = part_name(os.path.dirname(dst))
    sandbox.check(tmp)
    size = os.path.getsize(src)
    h = hasher.new()
    h.update(size.to_bytes(8, "little"))
    try:
        with open(src, "rb", buffering=0) as fi, open(tmp, "xb", buffering=0) as fo:
            while True:
                if control:
                    control.checkpoint()
                block = fi.read(hasher.FULL_BLOCK)
                if not block:
                    break
                h.update(block)
                fo.write(block)
                if on_bytes:
                    on_bytes(len(block))
            os.fsync(fo.fileno())
        try:
            st = os.stat(src)
            os.chmod(tmp, stat.S_IMODE(st.st_mode))
            os.utime(tmp, ns=(st.st_atime_ns, st.st_mtime_ns))
        except OSError:
            pass  # e.g. FAT drives can't store permissions; content is what matters
        src_hash = f"{hasher.ALGO}:{h.hexdigest()}"
        copy_hash = hasher.full_hash(tmp, control)
        if copy_hash != src_hash:
            raise VerifyFailed(errno.EIO, "the copy does not match the original (hash differs)", dst)
        if expected_hash and expected_hash.split(":")[0] == hasher.ALGO and expected_hash != src_hash:
            raise VerifyFailed(errno.EIO, "the original changed since the scan (hash differs)", src)
        rename_noreplace(tmp, dst)
        return src_hash
    except BaseException:
        try:
            os.unlink(tmp)
        except OSError:
            pass
        raise


def move_file(src: str, dst: str, control: Control | None = None, on_bytes=None,
              expected_hash: str | None = None) -> bool:
    """Move without ever overwriting. Same file system: atomic rename. Different file system
    (incl. separate Btrfs subvolumes such as / and /home): copy -> verify hash -> delete source.
    Returns True if it was a copy across file systems."""
    try:
        rename_case_safe(src, dst)       # also handles IMG.JPG -> IMG.jpg on case-insensitive drives
        return False
    except OSError as e:
        if e.errno != errno.EXDEV:
            raise
    copy_verified(src, dst, control, on_bytes, expected_hash)
    try:
        unlink(src)
    except OSError:
        # the verified copy exists, but the original couldn't be removed: undo the copy, report
        try:
            unlink(dst)
        except OSError:
            pass
        raise
    return True
