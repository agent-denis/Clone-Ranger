"""clone-ranger-cli: scan and report duplicates from the command line (read-only).

  python -m clone_ranger.core.cli scan [FOLDER ...]      scan (default: home + external drives)
  python -m clone_ranger.core.cli groups                 list same-content groups from the index
  python -m clone_ranger.core.cli names [--ignore-case] [--ignore-ext]
  python -m clone_ranger.core.cli report --csv FILE      export the duplicates report as CSV
  python -m clone_ranger.core.cli skipped                what the last scan could not read
  python -m clone_ranger.core.cli info                   index statistics

Nothing here moves, renames or deletes files.
"""
from __future__ import annotations

import argparse
import json
import os
import sys
import time

from ..util import hms as duration, human
from .control import Control
from .duplicates import find_content_groups, find_name_groups, totals
from .index import Index
from .osinfo import is_admin
from .pipeline import run
from .report import rows_from_core_groups, write_csv
from .scanner import DEFAULT_EXCLUDES, ScanConfig, default_roots

ROOT_MESSAGE = ("Clone Ranger refuses to run as root: as root it could see and change every file on the "
                "system. Please run it as your normal user.")




class Teletype:
    """One live status line on a terminal, plain lines otherwise."""

    def __init__(self, stream=None):
        self.stream = stream = stream or sys.stderr
        self.tty = stream.isatty()
        self.t0 = time.monotonic()
        self.last_phase = None

    def __call__(self, e: dict):
        phase = e.get("phase")
        if phase == "skipped":
            return
        if phase == "listing":
            msg = f"SURVEILLANCE · {e['files']:>7} media files · {e['folders']:>6} folders · {e.get('current', '')}"
        elif phase == "partial":
            msg = f"PARTIAL HASH · {e['done']:>7} / {e['total']} candidates"
        elif phase == "full":
            done, total = e["bytes"], e["total_bytes"] or 1
            el = time.monotonic() - self.t0
            msg = f"FULL HASH    · {human(done)} / {human(total)} ({100 * done / total:.0f}%)"
            if done:
                rate = done / max(el, .001)
                msg += f" · {human(rate)}/s"
        elif phase == "grouped":
            msg = f"GROUPED      · {e['groups']} groups"
        else:
            return
        if phase != self.last_phase:
            self.t0 = time.monotonic() if phase == "full" else self.t0
            if self.tty and self.last_phase:
                self.stream.write("\n")
            self.last_phase = phase
        if self.tty:
            width = os.get_terminal_size(self.stream.fileno()).columns - 1
            self.stream.write("\r" + msg[:width].ljust(width))
        elif e.get("done") or phase == "grouped":
            self.stream.write(msg + "\n")
        self.stream.flush()

    def end(self):
        if self.tty:
            self.stream.write("\n")


def print_groups(groups, limit=None, out=None):
    out = out or sys.stdout
    for n, g in enumerate(groups[:limit] if limit else groups, 1):
        flags = ""
        if g.shared_inodes:
            flags = f"  [{g.shared_inodes} copies share data on disk]"
        print(f"\nCASE № {n:04d} · {g.kind.upper()} · {g.copies} copies · {human(g.size)} each · "
              f"reclaim {human(g.reclaim)}{flags}", file=out)
        print(f"  HASH {g.hash}", file=out)
        for m in g.members:
            note = f"   (hard link of {m.hard_link_of} – no space wasted)" if m.hard_link else ""
            print(f"  - {m.file.path}{note}", file=out)


def print_totals(t: dict, out=None):
    out = out or sys.stdout
    print("\nSCAN SUMMARY", file=out)
    print(f"  Groups ............. {t['groups']}", file=out)
    print(f"  Duplicate files .... {t['duplicate_files']}", file=out)
    print(f"  Hard links ......... {t['hard_links']} (no space wasted)", file=out)
    print(f"  Space to reclaim ... {human(t['reclaim'])}", file=out)


def cmd_scan(a, index):
    if a.entire_computer:
        cfg = ScanConfig.entire_computer()
    else:
        cfg = ScanConfig(roots=[os.path.abspath(os.path.expanduser(p)) for p in a.folders] or default_roots())
    cfg.excludes += a.exclude or []
    cfg.sniff_unknown = a.sniff_unknown
    cfg.min_size = a.min_size
    print("ROOTS: " + ", ".join(cfg.roots), file=sys.stderr)
    tty = Teletype()
    control = Control()
    try:
        result = run(index, cfg, control, tty, find_duplicates=not a.no_hash, workers=a.workers)
    except KeyboardInterrupt:
        control.cancel()
        tty.end()
        print("Cancelled.", file=sys.stderr)
        return 130
    tty.end()
    print(f"\nScan {result.status} in {duration(result.seconds)}: {result.files} media files, "
          f"{result.skipped} skipped, {result.removed} removed from the index (gone from disk).")
    for path, err in result.hash_errors[:20]:
        print(f"  could not hash {path}: {err}")
    if a.no_hash:
        return 0
    if a.list:
        print_groups(result.groups, a.limit)
    print_totals(result.totals)
    return 0


def cmd_groups(a, index):
    groups = find_content_groups(index, Control(), Teletype(), a.min_size, a.workers)
    if a.json:
        json.dump([{"hash": g.hash, "size": g.size, "copies": g.copies, "reclaim": g.reclaim,
                    "files": [{"path": m.file.path, "hard_link_of": m.hard_link_of,
                               "shared": m.file.shared} for m in g.members]} for g in groups],
                  sys.stdout, indent=2)
        print()
        return 0
    print_groups(groups, a.limit)
    print_totals(totals(groups))
    return 0


def cmd_names(a, index):
    groups = find_name_groups(index, a.ignore_case, a.ignore_ext)
    for g in groups[:a.limit] if a.limit else groups:
        print(f"\n{g.key}  ·  content: {g.content.upper()}")
        for f in g.files:
            print(f"  - {f.path}  ({human(f.size)})")
    print(f"\n{len(groups)} same-name groups")
    return 0


def cmd_report(a, index):
    groups = find_content_groups(index, Control(), Teletype(), a.min_size, a.workers)
    write_csv(a.csv, rows_from_core_groups(groups))
    print(f"Wrote {len(groups)} groups to {a.csv}")
    return 0


def cmd_skipped(a, index):
    last = index.last_scan()
    if not last:
        print("No scan yet.")
        return 0
    rows = index.skipped(last["id"])
    for path, reason in rows:
        print(f"{reason:>22}  {path}")
    print(f"{len(rows)} skipped in scan #{last['id']}")
    return 0


def cmd_info(a, index):
    s = index.stats()
    last = index.last_scan()
    print(f"Index ............ {index.path}")
    print(f"Media files ...... {s['files']} ({s['images']} images, {s['videos']} videos), {human(s['bytes'])}")
    print(f"Hashed ........... {s['partial_hashed']} partial, {s['full_hashed']} full")
    if last:
        when = time.strftime("%Y-%m-%d %H:%M", time.localtime(last["started"]))
        print(f"Last scan ........ #{last['id']} {when}, {last['status']}, {last['files']} files, "
              f"{last['skipped']} skipped")
    return 0


def main(argv=None) -> int:
    if is_admin():
        print(ROOT_MESSAGE, file=sys.stderr)
        return 1
    ap = argparse.ArgumentParser(prog="clone-ranger-cli", description="Clone Ranger - find duplicate images and videos "
                                 "(read-only command line).")
    ap.add_argument("--db", help="index file (default: ~/.cache/clone-ranger/index.sqlite)")
    ap.add_argument("--workers", type=int, default=2, help="hashing threads (default 2)")
    ap.add_argument("--min-size", type=int, default=1, help="ignore files smaller than this many bytes")
    sub = ap.add_subparsers(dest="cmd", required=True)

    s = sub.add_parser("scan", help="scan folders and find duplicates")
    s.add_argument("folders", nargs="*", help="folders to scan (default: home + /run/media/$USER/*)")
    s.add_argument("--entire-computer", action="store_true", help="scan / (system folders stay excluded)")
    s.add_argument("--exclude", action="append", help="extra folder/glob to exclude (repeatable)")
    s.add_argument("--sniff-unknown", action="store_true", help="also check files without a media extension")
    s.add_argument("--no-hash", action="store_true", help="only list files, don't look for duplicates")
    s.add_argument("--list", action="store_true", help="print every group, not just the summary")
    s.add_argument("--limit", type=int, help="print at most N groups")
    g = sub.add_parser("groups", help="same-content groups")
    g.add_argument("--json", action="store_true")
    g.add_argument("--limit", type=int)
    n = sub.add_parser("names", help="same-name groups")
    n.add_argument("--ignore-case", action="store_true")
    n.add_argument("--ignore-ext", action="store_true")
    n.add_argument("--limit", type=int)
    r = sub.add_parser("report", help="export duplicates as CSV")
    r.add_argument("--csv", required=True)
    sub.add_parser("skipped", help="list files/folders the last scan could not read")
    sub.add_parser("info", help="index statistics")
    sub.add_parser("excludes", help="show the default exclusion list")
    a = ap.parse_args(argv)
    if a.cmd == "excludes":
        print("\n".join(DEFAULT_EXCLUDES))
        return 0
    index = Index(a.db)
    try:
        return {"scan": cmd_scan, "groups": cmd_groups, "names": cmd_names, "report": cmd_report,
                "skipped": cmd_skipped, "info": cmd_info}[a.cmd](a, index)
    finally:
        index.close()


if __name__ == "__main__":
    sys.exit(main())
