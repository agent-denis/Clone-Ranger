"""What differs between Linux and Windows, in one place.

Paths on Windows use backslashes, drive letters, and ignore upper/lower case
("C:\\Users\\Ana\\Pictures" is the same folder as "c:/users/ana/pictures").
Every "is this path inside that folder?" check goes through is_within().
"""
from __future__ import annotations

import hashlib
import ntpath
import os
import posixpath
import string
import sys

WINDOWS = sys.platform == "win32"

# "Trash" on Linux, "Recycle Bin" on Windows: used in every user-visible text.
TRASH_NAME = "Recycle Bin" if WINDOWS else "Trash"
FILE_MANAGER = "File Explorer" if WINDOWS else "Files"


_I64_MIN, _I64_MAX = -(1 << 63), (1 << 63) - 1


def db_int(value: int) -> int:
    """A file ID or drive ID as a number SQLite can store (signed 64-bit).

    Windows file IDs can be larger: on NTFS the top bits hold a sequence number, and since Python 3.12 st_ino can
    be a 128-bit ReFS file ID (st_dev a 64-bit volume serial). Scanning a whole drive then failed with
    "OverflowError: Python int too large to convert to SQLite INTEGER".
    Numbers that already fit are returned unchanged (so Linux and existing indexes are not affected); 64-bit
    numbers are wrapped exactly (two's complement); bigger ones are folded through a hash. Applying it twice gives
    the same result. Used for everything stored in the index AND for every comparison with stored values.
    """
    if _I64_MIN <= value <= _I64_MAX:
        return value
    if value < 0 or value >= 1 << 64:
        value = int.from_bytes(hashlib.blake2b(str(value).encode(), digest_size=8).digest(), "little")
    return value - (1 << 64) if value > _I64_MAX else value


def path_key(path: str, windows: bool = WINDOWS) -> str:
    """A form of the path for comparing: normalised, and lower-case on Windows."""
    if windows:
        return ntpath.normcase(ntpath.normpath(path))
    return posixpath.normpath(path)


def is_within(path: str, folder: str, windows: bool = WINDOWS) -> bool:
    """True if path is folder itself or anything inside it."""
    p, f = path_key(path, windows), path_key(folder, windows)
    if p == f:
        return True
    sep = "\\" if windows else "/"
    return p.startswith(f if f.endswith(sep) else f + sep)


def with_sep(folder: str) -> str:
    """'C:\\Users\\Ana' -> 'C:\\Users\\Ana\\'; '/' and 'C:\\' stay as they are."""
    return folder if folder.endswith(os.sep) else folder + os.sep


def drives() -> list[str]:
    """Windows: the drive letters that exist right now (C:\\, D:\\, ...). Linux: ['/']."""
    if not WINDOWS:
        return ["/"]
    import ctypes
    mask = ctypes.windll.kernel32.GetLogicalDrives()
    return [f"{c}:\\" for i, c in enumerate(string.ascii_uppercase) if mask >> i & 1]


DRIVE_REMOVABLE, DRIVE_FIXED, DRIVE_REMOTE, DRIVE_CDROM, DRIVE_RAMDISK = 2, 3, 4, 5, 6


def drive_type(path: str) -> int:
    """Windows drive type of the drive this path is on (DRIVE_FIXED, DRIVE_REMOVABLE, ...)."""
    import ctypes
    root = os.path.splitdrive(os.path.abspath(path))[0] + "\\"
    return ctypes.windll.kernel32.GetDriveTypeW(ctypes.c_wchar_p(root))


def scan_drives() -> list[str]:
    """Drives 'Scan entire computer' covers: local disks and USB drives (no CD/DVD, no network)."""
    if not WINDOWS:
        return ["/"]
    out = []
    for d in drives():
        try:
            if drive_type(d) in (DRIVE_FIXED, DRIVE_REMOVABLE) and os.path.isdir(d):
                out.append(d)
        except OSError:
            pass
    return out


def is_admin() -> bool:
    """Linux: running as root. Windows: running elevated ("Run as administrator")."""
    if WINDOWS:
        try:
            import ctypes
            return bool(ctypes.windll.shell32.IsUserAnAdmin())
        except (AttributeError, OSError):
            return False
    return hasattr(os, "geteuid") and os.geteuid() == 0


def no_window() -> dict:
    """subprocess.run(...) arguments that stop a black console window flashing up on Windows."""
    if WINDOWS:
        import subprocess
        return {"creationflags": subprocess.CREATE_NO_WINDOW}
    return {}


def bundled_tool(name: str) -> str | None:
    """ffmpeg / ffprobe: the copy shipped next to Clone Ranger.exe (Windows build), else the one on PATH."""
    import shutil
    exe = name + (".exe" if WINDOWS else "")
    here = os.path.dirname(sys.executable) if getattr(sys, "frozen", False) else None
    for folder in filter(None, [here, here and os.path.join(here, "ffmpeg"),
                                getattr(sys, "_MEIPASS", None)]):
        p = os.path.join(folder, exe)
        if os.path.isfile(p):
            return p
    return shutil.which(name)
