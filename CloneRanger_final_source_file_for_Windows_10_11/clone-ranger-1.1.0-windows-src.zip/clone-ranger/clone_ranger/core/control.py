"""Pause / cancel control shared between a background job and the UI or CLI."""
import threading


class Cancelled(Exception):
    """Raised inside a job when the user pressed Cancel."""


class Control:
    def __init__(self):
        self._run = threading.Event()
        self._run.set()
        self._cancel = threading.Event()

    def pause(self):
        self._run.clear()

    def resume(self):
        self._run.set()

    def cancel(self):
        self._cancel.set()
        self._run.set()  # wake a paused job so it can exit

    @property
    def paused(self) -> bool:
        return not self._run.is_set()

    @property
    def cancelled(self) -> bool:
        return self._cancel.is_set()

    def checkpoint(self):
        """Call often from the job: blocks while paused, raises Cancelled when cancelled."""
        if not self._run.is_set():
            self._run.wait()
        if self._cancel.is_set():
            raise Cancelled()
