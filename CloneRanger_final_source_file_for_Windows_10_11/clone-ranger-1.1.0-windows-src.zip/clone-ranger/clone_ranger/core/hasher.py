"""File hashing: a cheap partial hash (first, middle and last 64 KB) and a full hash.

BLAKE3 is used when available (several times faster on slow CPUs); otherwise
hashlib's BLAKE2b. Every hash string is prefixed with its algorithm
("b3:" / "b2:") so hashes from different algorithms can never be compared.
"""
from __future__ import annotations

import hashlib
import os
from typing import Callable

from .control import Control

try:
    import blake3 as _blake3
    ALGO = "b3"
except ImportError:  # pragma: no cover - depends on the environment
    _blake3 = None
    ALGO = "b2"

CHUNK = 64 * 1024
FULL_BLOCK = 1024 * 1024
SMALL = 3 * CHUNK          # files up to this size: the partial hash already covers everything


def _new():
    return _blake3.blake3() if _blake3 else hashlib.blake2b(digest_size=32)


def new():
    """A fresh hasher of the current algorithm (feed it the 8-byte size first, like full_hash)."""
    return _new()


_RDONLY = os.O_RDONLY | getattr(os, "O_BINARY", 0)   # O_BINARY: Windows would otherwise translate line ends


def _open(path: str):
    fd = os.open(path, _RDONLY | getattr(os, "O_NOATIME", 0)) if _can_noatime(path) else os.open(path, _RDONLY)
    return os.fdopen(fd, "rb", buffering=0)


def _can_noatime(path: str) -> bool:
    # O_NOATIME only works on files we own; avoid EPERM on others. (Linux only.)
    if not hasattr(os, "O_NOATIME") or not hasattr(os, "geteuid"):
        return False
    try:
        return os.stat(path).st_uid == os.geteuid()
    except OSError:
        return False


def partial_hash(path: str, size: int) -> tuple[str, bool]:
    """Hash of the first, middle and last 64 KB (plus the size).

    Returns (hash, is_full). For small files the whole file is read, so the
    partial hash IS the full hash and is_full is True.
    """
    h = _new()
    h.update(size.to_bytes(8, "little"))
    with _open(path) as f:
        if size <= SMALL:
            h.update(f.read())
            return f"{ALGO}:{h.hexdigest()}", True
        for offset in (0, size // 2 - CHUNK // 2, size - CHUNK):
            f.seek(offset)
            h.update(f.read(CHUNK))
    return f"{ALGO}:{h.hexdigest()}", False


def full_hash(path: str, control: Control | None = None,
              on_bytes: Callable[[int], None] | None = None) -> str:
    """Hash of the whole file, read in 1 MB blocks. Checks pause/cancel between blocks."""
    h = _new()
    size = os.path.getsize(path)
    h.update(size.to_bytes(8, "little"))
    with _open(path) as f:
        try:
            os.posix_fadvise(f.fileno(), 0, 0, os.POSIX_FADV_SEQUENTIAL)
        except (AttributeError, OSError):
            pass
        while True:
            if control:
                control.checkpoint()
            block = f.read(FULL_BLOCK)
            if not block:
                break
            h.update(block)
            if on_bytes:
                on_bytes(len(block))
    return f"{ALGO}:{h.hexdigest()}"
