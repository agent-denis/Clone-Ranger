"""Recognise image and video files by extension AND by magic bytes.

A file counts as media only if its content matches a known image/video
signature. The extension decides whether we look at all (fast path); with
`sniff_unknown=True` files with a wrong or missing extension are checked too.
"""
from __future__ import annotations

import os

IMAGE_EXT = {
    "jpg", "jpeg", "jpe", "png", "gif", "webp", "bmp", "tif", "tiff", "heic", "heif", "avif",
    # RAW
    "cr2", "cr3", "nef", "arw", "dng", "orf", "rw2", "raf",
}
VIDEO_EXT = {"mp4", "mov", "mkv", "avi", "webm", "m4v", "wmv", "flv", "3gp", "mts", "m2ts", "mpg", "mpeg"}
MEDIA_EXT = IMAGE_EXT | VIDEO_EXT
HEADER_BYTES = 512

_HEIF_BRANDS = {b"heic", b"heix", b"hevc", b"hevx", b"heim", b"heis", b"mif1", b"msf1"}
_AVIF_BRANDS = {b"avif", b"avis"}
_MOV_ATOMS = {b"moov", b"mdat", b"wide", b"free", b"skip", b"pnot"}


def extension(path: str) -> str:
    return os.path.splitext(path)[1][1:].lower()


def sniff(head: bytes) -> tuple[str, str] | None:
    """Return (kind, format) from the first bytes of a file, or None if not media we know."""
    h = head
    if h[:3] == b"\xff\xd8\xff":
        return "image", "jpeg"
    if h[:8] == b"\x89PNG\r\n\x1a\n":
        return "image", "png"
    if h[:6] in (b"GIF87a", b"GIF89a"):
        return "image", "gif"
    if h[:4] == b"RIFF" and h[8:12] == b"WEBP":
        return "image", "webp"
    if h[:4] == b"RIFF" and h[8:12] == b"AVI ":
        return "video", "avi"
    if h[:2] == b"BM" and len(h) >= 18 and int.from_bytes(h[14:18], "little") in (12, 40, 52, 56, 64, 108, 124):
        return "image", "bmp"  # BITMAPINFOHEADER size must be one of the known values
    if h[:15] == b"FUJIFILMCCD-RAW":
        return "image", "raf"
    if h[:4] in (b"IIRO", b"IIRS"):
        return "image", "orf"
    if h[:4] == b"IIU\x00":
        return "image", "rw2"
    if h[:4] in (b"II*\x00", b"MM\x00*"):
        if h[8:10] == b"CR":
            return "image", "cr2"
        return "image", "tiff"  # also NEF, ARW, DNG (TIFF-based RAW)
    if h[4:8] == b"ftyp":
        brand = h[8:12]
        brands = {brand} | {h[i:i + 4] for i in range(16, min(len(h), 64), 4)}
        if brand == b"crx ":
            return "image", "cr3"
        if brand in _AVIF_BRANDS:
            return "image", "avif"
        if brand in _HEIF_BRANDS or (brands & _HEIF_BRANDS and not brands & {b"isom", b"mp41", b"mp42"}):
            return "image", "heif"
        if brand == b"qt  ":
            return "video", "mov"
        if brand.startswith(b"3g"):
            return "video", "3gp"
        return "video", "mp4"
    if h[4:8] in _MOV_ATOMS:
        return "video", "mov"
    if h[:4] == b"\x1a\x45\xdf\xa3":
        return "video", "webm" if b"webm" in h[:64] else "mkv"
    if h[:8] == b"\x30\x26\xb2\x75\x8e\x66\xcf\x11":
        return "video", "wmv"
    if h[:3] == b"FLV":
        return "video", "flv"
    if h[:4] in (b"\x00\x00\x01\xba", b"\x00\x00\x01\xb3"):
        return "video", "mpg"
    if len(h) > 196 and h[4] == 0x47 and h[196] == 0x47:
        return "video", "m2ts"  # 192-byte packets (AVCHD .mts/.m2ts)
    if len(h) > 188 and h[0] == 0x47 and h[188] == 0x47:
        return "video", "ts"
    return None


def classify(path: str, read_head=None, sniff_unknown: bool = False) -> tuple[str, str] | None:
    """Decide whether `path` is an image or video.

    Returns (kind, format) or None. `read_head(path) -> bytes` can be injected for testing;
    by default the first HEADER_BYTES are read. Raises OSError if the file can't be read.
    """
    ext = extension(path)
    if ext not in MEDIA_EXT and not sniff_unknown:
        return None
    if read_head is None:
        with open(path, "rb") as f:
            head = f.read(HEADER_BYTES)
    else:
        head = read_head(path)
    found = sniff(head)
    if found is None:
        return None
    kind, fmt = found
    if ext in MEDIA_EXT:
        expected = "image" if ext in IMAGE_EXT else "video"
        if kind != expected:
            return None  # e.g. a .jpg that is really a video: don't trust it either way
    return kind, fmt
