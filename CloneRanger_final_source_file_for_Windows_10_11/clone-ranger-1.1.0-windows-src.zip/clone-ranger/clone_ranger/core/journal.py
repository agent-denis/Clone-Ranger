"""Action history: every action and every file it touched.

Stored as JSON lines in ~/.local/state/clone-ranger/journal.jsonl, written AS the
operation runs (one line per file), so even after a crash or power cut the log
says exactly which files were already moved, renamed or trashed.

    {"t": "order", "n": 17, "op": "move", "time": ..., "user": ..., "dest": ...}
    {"t": "item",  "n": 17, "src": ..., "dst": ..., "status": "ok", ...}
    {"t": "end",   "n": 17, "status": "done", "ok": 3, "failed": 0, "skipped": 1}

Undo writes a new order with "undoes": <n>.
"""
from __future__ import annotations

import getpass
import json
import os
import threading
import time
from dataclasses import dataclass, field

from . import paths

UNDOABLE = ("move", "rename", "trash")
MAX_BYTES = 8 * 1024 * 1024      # rotate the log beyond this size (~20 000+ files touched)...
KEEP_ORDERS = 200                # ...keeping the newest orders (so Undo and the log page still work)


@dataclass
class Item:
    src: str
    dst: str | None = None
    status: str = "ok"            # ok | skipped | failed
    error: str = ""
    size: int = 0
    mtime_ns: int | None = None   # of the file at dst, so undo can tell if it changed since
    trash_info: str | None = None
    dirs: list = field(default_factory=list)     # folders created for this file (removed again on undo)
    replaced: dict | None = None  # overwrite: the file that was in the way went to the Trash
    hash: str | None = None

    def to_json(self) -> dict:
        return {k: v for k, v in self.__dict__.items() if v not in (None, "", [], 0) or k == "status"}


@dataclass
class Order:
    n: int
    op: str
    time: float
    user: str = ""
    dest: str = ""
    undoes: int | None = None
    items: list[Item] = field(default_factory=list)
    status: str = "incomplete"    # done | cancelled | failed | incomplete (app stopped mid-way)
    undone_by: int | None = None

    @property
    def ok(self) -> list[Item]:
        return [i for i in self.items if i.status == "ok"]

    @property
    def undoable(self) -> bool:
        return self.op in UNDOABLE and self.undone_by is None and bool(self.ok)

    def counts(self) -> dict:
        c = {"ok": 0, "skipped": 0, "failed": 0}
        for i in self.items:
            c[i.status] = c.get(i.status, 0) + 1
        return c


class Journal:
    def __init__(self, path: str | os.PathLike | None = None):
        self.path = os.fspath(path) if path else str(paths.state_dir() / "journal.jsonl")
        self._lock = threading.Lock()

    # ------------------------------------------------------------------ writing
    def _write(self, rec: dict, sync: bool = False):
        with self._lock:
            paths.ensure(paths.Path(self.path).parent)
            with open(self.path, "a", encoding="utf-8") as f:
                f.write(json.dumps(rec, ensure_ascii=False) + "\n")
                f.flush()
                if sync:
                    os.fsync(f.fileno())

    def next_number(self) -> int:
        return max((o.n for o in self.orders()), default=0) + 1

    def rotate_if_big(self) -> bool:
        """When the log is over MAX_BYTES: the whole old log moves to journal.old.jsonl (replacing an older
        one) and the newest KEEP_ORDERS orders stay in journal.jsonl. Returns True if it rotated."""
        with self._lock:
            try:
                if os.path.getsize(self.path) <= MAX_BYTES:
                    return False
                with open(self.path, encoding="utf-8") as f:
                    lines = f.readlines()
            except OSError:
                return False
            numbers = []
            for line in lines:
                try:
                    rec = json.loads(line)
                    if rec.get("t") == "order":
                        numbers.append(int(rec["n"]))
                except (ValueError, KeyError, TypeError):
                    continue
            keep = set(sorted(numbers)[-KEEP_ORDERS:])
            kept = []
            for line in lines:
                try:
                    if int(json.loads(line)["n"]) in keep:
                        kept.append(line if line.endswith("\n") else line + "\n")
                except (ValueError, KeyError, TypeError):
                    continue                         # a broken line stays only in the old file
            tmp = self.path + ".tmp"
            with open(tmp, "w", encoding="utf-8") as f:
                f.writelines(kept)
                f.flush()
                os.fsync(f.fileno())
            old = self.path[:-len(".jsonl")] + ".old.jsonl" if self.path.endswith(".jsonl") else self.path + ".old"
            os.replace(self.path, old)               # the complete history is kept here
            os.replace(tmp, self.path)
            return True

    def begin(self, op: str, dest: str = "", undoes: int | None = None, n: int | None = None) -> Order:
        self.rotate_if_big()
        order = Order(n=n or self.next_number(), op=op, time=time.time(), user=getpass.getuser(), dest=dest,
                      undoes=undoes)
        rec = {"t": "order", "n": order.n, "op": op, "time": order.time, "user": order.user, "dest": dest}
        if undoes is not None:
            rec["undoes"] = undoes
        self._write(rec, sync=True)
        return order

    def item(self, order: Order, item: Item):
        order.items.append(item)
        self._write({"t": "item", "n": order.n, **item.to_json()})

    def end(self, order: Order, status: str):
        order.status = status
        c = order.counts()
        self._write({"t": "end", "n": order.n, "status": status, **c}, sync=True)

    # ------------------------------------------------------------------ reading
    def orders(self) -> list[Order]:
        """All orders, oldest first. Broken lines (e.g. a half-written last line) are skipped."""
        by_n: dict[int, Order] = {}
        try:
            with open(self.path, encoding="utf-8") as f:
                lines = f.readlines()
        except FileNotFoundError:
            return []
        except OSError:
            return []
        for line in lines:
            try:
                rec = json.loads(line)
                t, n = rec.pop("t"), int(rec.pop("n"))
            except (ValueError, KeyError, TypeError):
                continue
            if t == "order":
                by_n[n] = Order(n=n, op=rec.get("op", "?"), time=rec.get("time", 0), user=rec.get("user", ""),
                                dest=rec.get("dest", ""), undoes=rec.get("undoes"))
            elif t == "item" and n in by_n:
                known = {k: rec[k] for k in Item.__dataclass_fields__ if k in rec}
                if "src" in known:
                    by_n[n].items.append(Item(**known))
            elif t == "end" and n in by_n:
                by_n[n].status = rec.get("status", "done")
        orders = sorted(by_n.values(), key=lambda o: o.n)
        for o in orders:
            if o.undoes is not None and o.undoes in by_n and o.ok:
                by_n[o.undoes].undone_by = o.n
        return orders

    def order(self, n: int) -> Order | None:
        return next((o for o in self.orders() if o.n == n), None)

    def last_undoable(self) -> Order | None:
        """The most recent order that can still be undone (an undo itself is not undone by Ctrl+Z)."""
        for o in reversed(self.orders()):
            if o.op == "undo":
                continue
            if o.undoable:
                return o
        return None
