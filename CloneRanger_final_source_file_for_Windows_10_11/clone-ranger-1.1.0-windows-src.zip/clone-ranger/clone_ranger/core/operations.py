"""File operations: Move to Trash, Delete permanently, Move, Rename, and Undo.

Shared rules for every operation:
- Each file must still be exactly what the scan saw (regular file, same size and
  modification time) - otherwise it's skipped with a reason.
- Files in protected folders are never touched.
- Nothing ever overwrites a file by accident (atomic no-replace renames). An
  overwrite the user confirmed moves the file in the way to the Trash first.
- Moves across drives copy, verify the hash, and only then delete the original.
- Every file is written to the action log as it's done; the index is updated
  on the spot, so the window doesn't need a rescan.
- Pause/Cancel is checked between files (and between 1 MB blocks while copying).
- Every path passes the sandbox check (see sandbox.py).
No Qt here: the window runs this in a background thread.
"""
from __future__ import annotations

import os
import secrets
from dataclasses import dataclass, field
from typing import Callable

from . import fsops, sandbox, trash
from .osinfo import is_within
from .control import Cancelled, Control
from .index import Index
from .journal import Item, Journal, Order

ProgressFn = Callable[[dict], None]


@dataclass
class Target:
    """One file an operation acts on, as the scan saw it."""
    path: str
    size: int | None = None
    mtime_ns: int | None = None
    hash: str | None = None
    protected: bool = False


@dataclass
class Step:
    """One planned move/rename: src -> dst (planned before the ORDER is signed)."""
    target: Target
    dst: str
    status: str = "ok"            # ok | overwrite | skip | unchanged | invalid
    reason: str = ""

    @property
    def src(self) -> str:
        return self.target.path


def is_protected(path: str, folders) -> bool:
    for f in folders or ():
        f = os.path.abspath(os.path.expanduser(f))
        if f and is_within(path, f):
            return True
    return False


def lost_groups(groups: list[list[str]], removing: set[str], exists=os.path.lexists) -> list[int]:
    """Indexes of groups that would have NO copy left on disk if `removing` were removed
    (copies already gone from disk count as lost too)."""
    out = []
    for i, paths_ in enumerate(groups):
        if any(p in removing for p in paths_) and not any(p not in removing and exists(p) for p in paths_):
            out.append(i)
    return out


def numbered(path: str, n: int) -> str:
    """photo.jpg -> photo (2).jpg"""
    d, name = os.path.split(path)
    stem, ext = os.path.splitext(name)
    if not stem:
        stem, ext = name, ""
    return os.path.join(d, f"{stem} ({n}){ext}")


def plan_move(targets: list[Target], dest: str, keep_structure: bool = False, base: str | None = None,
              conflict: str = "skip", exists=os.path.lexists) -> list[Step]:
    """Where each file would go. conflict: skip | number | overwrite."""
    dest = os.path.abspath(os.path.expanduser(dest))
    if keep_structure and base is None:
        dirs = [os.path.dirname(t.path) for t in targets]
        base = os.path.commonpath(dirs) if dirs else dest
    sources = {t.path for t in targets}
    claimed: set[str] = set()
    steps = []
    for t in targets:
        if keep_structure:
            rel = os.path.relpath(os.path.dirname(t.path), base)
            dst = os.path.normpath(os.path.join(dest, rel, os.path.basename(t.path)))
        else:
            dst = os.path.join(dest, os.path.basename(t.path))
        step = Step(t, dst)
        if t.protected:
            step.status, step.reason = "skip", "protected folder"
        elif dst == t.path:
            step.status, step.reason = "unchanged", "already there"
        elif dst in claimed or exists(dst):
            if dst in sources:
                step.status, step.reason = "skip", "another selected file has this name"
            elif fsops.same_file(dst, t.path):
                step.status, step.reason = "skip", "same file (hard link)"
            elif conflict == "number" or dst in claimed:
                if conflict != "number":
                    step.status, step.reason = "skip", "two selected files would get the same name"
                else:
                    n = 2
                    while numbered(dst, n) in claimed or exists(numbered(dst, n)):
                        n += 1
                    step.dst = numbered(dst, n)
                    step.reason = f"renamed to {os.path.basename(step.dst)}"
            elif conflict == "overwrite":
                step.status, step.reason = "overwrite", "replaces the existing file (it goes to the Trash)"
            else:
                step.status, step.reason = "skip", "a file with this name already exists"
        if step.status in ("ok", "overwrite"):
            claimed.add(step.dst)
        steps.append(step)
    return steps


@dataclass
class Report:
    order: Order
    cancelled: bool = False
    trash_missing: list[str] = field(default_factory=list)   # files left alone: their drive has no Trash

    @property
    def counts(self) -> dict:
        return self.order.counts()


class Engine:
    def __init__(self, journal: Journal, index: Index | None = None, protected_folders=(),
                 control: Control | None = None, progress: ProgressFn | None = None):
        self.journal, self.index = journal, index
        self.protected = list(protected_folders or ())
        self.control = control or Control()
        self.emit = progress or (lambda e: None)

    # ------------------------------------------------------------------ helpers
    def _progress(self, done, total, current="", **extra):
        self.emit({"done": done, "total": total, "current": current, **extra})

    def _precheck(self, t: Target) -> str:
        """Why this file must be left alone, or ''."""
        try:
            sandbox.check(t.path)
        except sandbox.SandboxViolation as e:
            return str(e)
        if t.protected or is_protected(t.path, self.protected):
            return "protected folder"
        try:
            fsops.expect_unchanged(t.path, t.size, t.mtime_ns)
        except fsops.Changed as e:
            return str(e)
        except OSError as e:
            return e.strerror or str(e)
        return ""

    def _index(self, fn, *args):
        if self.index is not None:
            try:
                fn(*args)
            except Exception:  # noqa: BLE001 - the file operation itself succeeded; a rescan fixes the index
                pass

    def _finish(self, order: Order, cancelled: bool, rest: list[str]) -> None:
        for p in rest:
            self.journal.item(order, Item(src=p, status="skipped", error="cancelled"))
        self.journal.end(order, "cancelled" if cancelled else "done")

    # ------------------------------------------------------------------ Move to Trash / Delete
    def trash(self, targets: list[Target], n: int | None = None) -> Report:
        order = self.journal.begin("trash", dest="Trash", n=n)
        rep = Report(order)
        for i, t in enumerate(targets):
            try:
                self.control.checkpoint()
            except Cancelled:
                rep.cancelled = True
                self._finish(order, True, [x.path for x in targets[i:]])
                return rep
            self._progress(i, len(targets), t.path)
            why = self._precheck(t)
            if why:
                self.journal.item(order, Item(src=t.path, status="skipped", error=why))
                continue
            try:
                tr_ = trash.trash(t.path)
            except trash.TrashUnavailable as e:
                rep.trash_missing.append(t.path)
                self.journal.item(order, Item(src=t.path, status="skipped", error=e.strerror or str(e)))
                continue
            except OSError as e:
                self.journal.item(order, Item(src=t.path, status="failed", error=e.strerror or str(e)))
                continue
            self.journal.item(order, Item(src=t.path, dst=tr_.trash_file, trash_info=tr_.info_file,
                                          size=t.size or 0, mtime_ns=t.mtime_ns, hash=t.hash))
            self._index(self.index.remove_paths if self.index else None, [t.path])
        self._progress(len(targets), len(targets))
        self._finish(order, False, [])
        return rep

    def delete(self, targets: list[Target], n: int | None = None) -> Report:
        order = self.journal.begin("delete", n=n)
        rep = Report(order)
        for i, t in enumerate(targets):
            try:
                self.control.checkpoint()
            except Cancelled:
                rep.cancelled = True
                self._finish(order, True, [x.path for x in targets[i:]])
                return rep
            self._progress(i, len(targets), t.path)
            why = self._precheck(t)
            if why:
                self.journal.item(order, Item(src=t.path, status="skipped", error=why))
                continue
            try:
                fsops.unlink(t.path)
            except OSError as e:
                self.journal.item(order, Item(src=t.path, status="failed", error=e.strerror or str(e)))
                continue
            self.journal.item(order, Item(src=t.path, size=t.size or 0, hash=t.hash))
            self._index(self.index.remove_paths if self.index else None, [t.path])
        self._progress(len(targets), len(targets))
        self._finish(order, False, [])
        return rep

    # ------------------------------------------------------------------ Move / Rename
    def move(self, steps: list[Step], dest: str = "", n: int | None = None) -> Report:
        return self._relocate("move", steps, dest, n)

    def rename(self, steps: list[Step], n: int | None = None) -> Report:
        return self._relocate("rename", steps, "", n)

    def _relocate(self, op: str, steps: list[Step], dest: str, n: int | None, undoes: int | None = None,
                  undo_items: list[Item] | None = None) -> Report:
        order = self.journal.begin(op if undoes is None else "undo", dest=dest, undoes=undoes, n=n)
        rep = Report(order)
        total_bytes = sum(s.target.size or 0 for s in steps)
        done_bytes = [0]

        def on_bytes(b):
            done_bytes[0] += b
            self.emit({"bytes": done_bytes[0], "total_bytes": total_bytes})

        # Phase 1: files whose new name is another selected file's current name (swaps, chains)
        # step aside to a temporary name first, so nothing is ever overwritten.
        live = [s for s in steps if s.status in ("ok", "overwrite")]
        for s in steps:
            if s not in live:
                self.journal.item(order, Item(src=s.src, dst=s.dst, status="skipped", error=s.reason))
        sources = {s.src for s in live}
        current: dict[int, str] = {}
        for k, s in enumerate(live):
            current[k] = s.src
        why_skip: dict[int, str] = {}
        for k, s in enumerate(live):
            why = self._precheck(s.target) if undo_items is None else self._precheck_undo(s.target)
            if why:
                why_skip[k] = why
        for k, s in enumerate(live):
            if k in why_skip or s.dst not in sources:
                continue
            tmp = os.path.join(os.path.dirname(s.src),
                               f"{fsops.PART_PREFIX}rename-{secrets.token_hex(4)}-{os.path.basename(s.src)}")
            try:
                fsops.rename_noreplace(s.src, tmp)
                current[k] = tmp
            except OSError as e:
                why_skip[k] = e.strerror or str(e)

        # Phase 2: put every file in its place
        cancelled_at = None
        for k, s in enumerate(live):
            if cancelled_at is None:
                try:
                    self.control.checkpoint()
                except Cancelled:
                    cancelled_at = k
            if cancelled_at is not None:
                self._step_back(current[k], s.src)
                self.journal.item(order, Item(src=s.src, dst=s.dst, status="skipped", error="cancelled"))
                continue
            self._progress(k, len(live), s.src)
            if k in why_skip:
                self._step_back(current[k], s.src)
                self.journal.item(order, Item(src=s.src, dst=s.dst, status="skipped", error=why_skip[k]))
                continue
            item = Item(src=s.src, dst=s.dst, size=s.target.size or 0, hash=s.target.hash)
            prev = undo_items[k] if undo_items is not None else None
            try:
                parent = os.path.dirname(s.dst)
                item.dirs = fsops.makedirs(parent) if not os.path.isdir(parent) else []
                if s.status == "overwrite":
                    fsops.expect_unchanged(s.dst, None, None)     # only ever replace a regular file
                    r = trash.trash(s.dst)
                    item.replaced = {"original": r.original, "trash_file": r.trash_file, "info_file": r.info_file}
                try:
                    fsops.move_file(current[k], s.dst, self.control, on_bytes, s.target.hash)
                except BaseException:
                    if item.replaced:     # put the file we moved out of the way back
                        try:
                            trash.restore(item.replaced["trash_file"], item.replaced["info_file"], s.dst)
                        except (OSError, fsops.Changed):
                            pass
                    raise
                item.mtime_ns = os.lstat(s.dst).st_mtime_ns
            except Cancelled:
                self._step_back(current[k], s.src)
                fsops.remove_empty_dirs(item.dirs)
                self.journal.item(order, Item(src=s.src, dst=s.dst, status="skipped", error="cancelled"))
                cancelled_at = k
                continue
            except (OSError, fsops.Changed) as e:
                self._step_back(current[k], s.src)
                fsops.remove_empty_dirs(item.dirs)
                msg = "a file with this name already exists" if isinstance(e, FileExistsError) else \
                    (getattr(e, "strerror", None) or str(e))
                self.journal.item(order, Item(src=s.src, dst=s.dst, status="failed", error=msg))
                continue
            self.journal.item(order, item)
            self._index(self.index.relocate if self.index else None, s.src, s.dst)
            if prev is not None:
                self._after_undo_item(prev)
        rep.cancelled = cancelled_at is not None
        self._progress(len(live), len(live))
        self.journal.end(order, "cancelled" if rep.cancelled else "done")
        return rep

    def _step_back(self, cur: str, src: str):
        """Undo phase 1's temporary name, if this file got one."""
        if cur != src:
            try:
                fsops.rename_noreplace(cur, src)
            except OSError:
                pass

    # ------------------------------------------------------------------ Undo
    def _precheck_undo(self, t: Target) -> str:
        try:
            sandbox.check(t.path)
            fsops.expect_unchanged(t.path, None, t.mtime_ns)
        except sandbox.SandboxViolation as e:
            return str(e)
        except fsops.Changed as e:
            return f"was changed after the action ({e})" if "no longer" not in str(e) else str(e)
        except OSError as e:
            return e.strerror or str(e)
        return ""

    def _after_undo_item(self, prev: Item):
        fsops.remove_empty_dirs(prev.dirs or [])
        if prev.replaced:
            try:
                trash.restore(prev.replaced["trash_file"], prev.replaced["info_file"], prev.replaced["original"])
                self._index(self.index.restore_path if self.index else None, prev.replaced["original"], None)
            except (OSError, fsops.Changed):
                pass

    def undo(self, order: Order, n: int | None = None) -> Report:
        """Reverse a move, rename or trash order. Files changed since are left alone."""
        if not order.undoable:
            raise ValueError(f"order {order.n} can't be undone")
        items = list(reversed(order.ok))
        if order.op == "trash":
            out = self.journal.begin("undo", dest="", undoes=order.n, n=n)
            rep = Report(out)
            for i, it in enumerate(items):
                try:
                    self.control.checkpoint()
                except Cancelled:
                    rep.cancelled = True
                    self._finish(out, True, [x.src for x in items[i:]])
                    return rep
                self._progress(i, len(items), it.src)
                try:
                    if not it.dst or not it.trash_info:
                        raise fsops.Changed("no Trash record")
                    trash.restore(it.dst, it.trash_info, it.src)
                except FileExistsError:
                    self.journal.item(out, Item(src=it.dst or "", dst=it.src, status="failed",
                                                error="a file with the original name exists again"))
                    continue
                except (OSError, fsops.Changed) as e:
                    self.journal.item(out, Item(src=it.dst or "", dst=it.src, status="failed",
                                                error=getattr(e, "strerror", None) or str(e)))
                    continue
                self.journal.item(out, Item(src=it.dst, dst=it.src, size=it.size, hash=it.hash))
                self._index(self.index.restore_path if self.index else None, it.src, it.hash)
            self._finish(out, False, [])
            return rep
        steps = [Step(Target(it.dst, size=None, mtime_ns=it.mtime_ns, hash=it.hash), it.src) for it in items]
        return self._relocate(order.op, steps, "", n, undoes=order.n, undo_items=items)
