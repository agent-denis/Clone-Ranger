"""Reset to defaults, clear history, clear cache - "start from scratch". No Qt.

What each word means (also shown in the app):

* search settings - scan locations, excluded folders, unknown-extension detection, minimum size and the
  same-name options (settings.SEARCH_KEYS). Filters and the search box are window state; the window
  clears them itself.
* other settings  - theme, keep rules, preferred / protected folders, sounds, window layout (everything
  else in settings.DEFAULTS).
* history         - the action history used by Undo (journal.jsonl + journal.old.jsonl), the app log, and
  remembered folders such as the last scan and move destinations (settings.HISTORY_KEYS).
* cache           - the scan index (index.sqlite and its -wal / -shm files) and the thumbnails.

Photos and videos are never touched: only files inside Clone Ranger's own cache / state folders are
removed, symlinks are unlinked rather than followed, and anything unexpected is left alone.
"""
from __future__ import annotations

import os
import shutil
from copy import deepcopy
from dataclasses import dataclass, field
from pathlib import Path

from . import paths
from .settings import DEFAULTS, HISTORY_KEYS, SEARCH_KEYS, Settings

INDEX_FILES = ("index.sqlite", "index.sqlite-wal", "index.sqlite-shm", "index.sqlite-journal")
JOURNAL_FILES = ("journal.jsonl", "journal.old.jsonl")


@dataclass
class Report:
    removed: list[str] = field(default_factory=list)
    freed: int = 0
    settings_reset: list[str] = field(default_factory=list)


def _size(p: Path) -> int:
    try:
        if p.is_symlink() or p.is_file():
            return p.lstat().st_size
        if p.is_dir():
            total = 0
            for root, _dirs, files in os.walk(p):
                for f in files:
                    try:
                        total += os.lstat(os.path.join(root, f)).st_size
                    except OSError:
                        pass
            return total
    except OSError:
        pass
    return 0


def _inside(p: Path, folder: Path) -> bool:
    try:
        return os.path.commonpath([os.path.abspath(p), os.path.abspath(folder)]) == os.path.abspath(folder)
    except ValueError:
        return False


def _remove(p: Path, folder: Path, report: Report):
    """Remove a file or folder that must live inside `folder` (never follows symlinks)."""
    if not _inside(p, folder) or os.path.abspath(p) == os.path.abspath(folder):
        raise RuntimeError(f"refusing to remove {p}: not inside {folder}")
    if not (p.exists() or p.is_symlink()):
        return
    size = _size(p)
    if p.is_symlink() or p.is_file():
        p.unlink()
    else:
        shutil.rmtree(p)
    report.removed.append(str(p))
    report.freed += size


# --------------------------------------------------------------------------- sizes (for the dialog)
def cache_size() -> int:
    c = paths.cache_dir()
    return sum(_size(c / f) for f in INDEX_FILES) + _size(paths.thumbs_dir())


def history_files() -> list[Path]:
    s = paths.state_dir()
    files = [s / f for f in JOURNAL_FILES]
    if s.is_dir():
        files += sorted(p for p in s.iterdir() if p.name.endswith(".log") or ".log." in p.name)
    return [p for p in files if p.exists()]


# --------------------------------------------------------------------------- actions
def clear_cache(report: Report | None = None) -> Report:
    """Delete the scan index and the thumbnails. The caller must close any open Index first."""
    report = report or Report()
    c = paths.cache_dir()
    for f in INDEX_FILES:
        _remove(c / f, c, report)
    _remove(paths.thumbs_dir(), c, report)
    return report


def clear_history(settings: Settings | None = None, report: Report | None = None) -> Report:
    """Delete the action history (Undo becomes impossible for past actions), empty the app log, and forget
    remembered folders. Log files are emptied rather than deleted, because the running app keeps one open."""
    report = report or Report()
    s = paths.state_dir()
    for f in JOURNAL_FILES:
        _remove(s / f, s, report)
    if s.is_dir():
        for p in sorted(s.iterdir()):
            if p.is_symlink() or not p.is_file():
                continue
            if p.name.endswith(".log"):
                report.freed += _size(p)
                with open(p, "w", encoding="utf-8"):
                    pass
                report.removed.append(str(p))
            elif ".log." in p.name:                     # rotated logs: app.log.1, .2 ...
                _remove(p, s, report)
    if settings is not None:
        _reset_keys(settings, HISTORY_KEYS, report)
    return report


def reset_search(settings: Settings, report: Report | None = None) -> Report:
    report = report or Report()
    _reset_keys(settings, SEARCH_KEYS, report)
    return report


def reset_preferences(settings: Settings, report: Report | None = None) -> Report:
    """Every setting that is neither a search setting nor history."""
    report = report or Report()
    _reset_keys(settings, [k for k in DEFAULTS if k not in SEARCH_KEYS and k not in HISTORY_KEYS], report)
    return report


def _reset_keys(settings: Settings, keys, report: Report):
    for k in keys:
        if settings.data.get(k, DEFAULTS[k]) != DEFAULTS[k]:
            report.settings_reset.append(k)
        settings.data[k] = deepcopy(DEFAULTS[k])


def reset(settings: Settings, search=True, preferences=False, history=False, cache=False) -> Report:
    """Run the chosen parts in a safe order and save the settings once."""
    report = Report()
    if search:
        reset_search(settings, report)
    if preferences:
        reset_preferences(settings, report)
    if history:
        clear_history(settings, report)
    if cache:
        clear_cache(report)
    if search or preferences or history:
        settings.save()
    return report
