"""Walk folders and find image/video files. Read-only: never changes anything.

- Never follows symlinks (neither to folders nor to files), nor Windows junctions.
- Windows: OneDrive "online-only" files are skipped (reading them would download them).
- Skips excluded locations (system folders, caches, Trash, .git, Btrfs .snapshots, ...).
- Unreadable folders/files are skipped and reported, never fatal.
"""
from __future__ import annotations

import fnmatch
import getpass
import os
import stat
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable, Iterator

from .control import Control
from .media_types import MEDIA_EXT, classify, extension
from .osinfo import DRIVE_REMOVABLE, WINDOWS, db_int, drive_type, drives, is_within, path_key, scan_drives

HOME = str(Path.home())

# Absolute locations never scanned. "~" is expanded. /run/media is allowed (external drives).
DEFAULT_EXCLUDES = [
    "/proc", "/sys", "/dev", "/run", "/tmp", "/var", "/usr", "/boot",
    "/lost+found", "/snap", "/opt/containerd",
    "~/.cache", "~/.local/share/Trash", "~/.local/share/flatpak", "~/.local/share/containers",
    "~/.var/app/*/cache", "~/.local/share/gnome-boxes", "~/.local/share/libvirt",
    "~/.steam", "~/.local/share/Steam", "~/.mozilla", "~/.thunderbird", "~/.config/google-chrome",
    "~/.config/chromium", "~/.vscode", "~/node_modules",
]
# Folder names skipped wherever they appear.
DEFAULT_EXCLUDE_NAMES = [".git", ".hg", ".svn", ".snapshots", ".Trash", ".Trash-*", "node_modules",
                         "__pycache__", ".venv", ".thumbnails"]
ALWAYS_ALLOWED = ["/run/media"]

if WINDOWS:
    _SYS = (os.environ.get("SystemDrive") or "C:") + "\\"
    DEFAULT_EXCLUDES = [
        _SYS + "Windows", _SYS + "Program Files", _SYS + "Program Files (x86)", _SYS + "ProgramData",
        _SYS + "Recovery", _SYS + "PerfLogs", _SYS + "$WinREAgent", _SYS + "$Windows.~BT", _SYS + "$Windows.~WS",
        _SYS + "Windows.old", _SYS + "MSOCache",
        "~\\AppData", "~\\.vscode", "~\\node_modules",
    ]
    DEFAULT_EXCLUDE_NAMES = ["$Recycle.Bin", "System Volume Information", "$SysReset", "Config.Msi",
                             ".git", ".hg", ".svn", "node_modules", "__pycache__", ".venv",
                             # Linux trash / snapshot / thumbnail folders on disks also used on Linux
                             ".snapshots", ".Trash", ".Trash-*", ".thumbnails"]
    ALWAYS_ALLOWED = []

# Windows file attributes of OneDrive (and other cloud) files that are not on this PC: reading them downloads them.
CLOUD_ONLY = 0x00001000 | 0x00040000 | 0x00400000    # OFFLINE | RECALL_ON_OPEN | RECALL_ON_DATA_ACCESS


def default_roots() -> list[str]:
    """Home folder plus external drives (Linux: /run/media/$USER/*, Windows: USB sticks and memory cards)."""
    roots = [HOME]
    if WINDOWS:
        for d in drives():
            try:
                if drive_type(d) == DRIVE_REMOVABLE and os.path.isdir(d):
                    roots.append(d)
            except OSError:
                pass
        return roots
    media = Path("/run/media") / getpass.getuser()
    if media.is_dir():
        roots += [str(p) for p in sorted(media.iterdir()) if p.is_dir()]
    return roots


@dataclass
class ScanConfig:
    roots: list[str] = field(default_factory=default_roots)
    excludes: list[str] = field(default_factory=lambda: list(DEFAULT_EXCLUDES))
    exclude_names: list[str] = field(default_factory=lambda: list(DEFAULT_EXCLUDE_NAMES))
    sniff_unknown: bool = False      # also check files with no/unknown extension (slower)
    min_size: int = 1                # ignore empty files

    @classmethod
    def entire_computer(cls) -> "ScanConfig":
        return cls(roots=scan_drives())   # Linux: "/"; Windows: every local disk and USB drive

    def expanded_excludes(self) -> list[str]:
        out = []
        for e in self.excludes:
            e = os.path.expanduser(e.strip())
            if e:
                out.append(os.path.normpath(e))
        return out


@dataclass
class FileEntry:
    path: str
    size: int
    mtime_ns: int
    dev: int
    ino: int
    nlink: int
    kind: str          # "image" | "video"
    fmt: str
    ctime_ns: int = 0  # change time; creation time comes from metadata later


@dataclass
class Skipped:
    path: str
    reason: str


class Excluder:
    def __init__(self, cfg: ScanConfig):
        self.prefixes = []
        self.globs = []
        roots = [os.path.normpath(os.path.expanduser(r)) for r in cfg.roots]
        for e in cfg.expanded_excludes():
            if any(ch in e for ch in "*?["):
                self.globs.append(e)
            # A folder the user explicitly chose to scan wins over an exclusion that CONTAINS it
            # (e.g. scanning /tmp/photos). Exclusions inside the chosen folder still apply.
            elif not any(is_within(r, e) for r in roots):
                self.prefixes.append(e)
        # Windows ignores upper/lower case: compare lower-cased keys there
        self.globs = [path_key(g) for g in self.globs]
        self.names = [n.casefold() for n in cfg.exclude_names] if WINDOWS else cfg.exclude_names
        self.allowed = ALWAYS_ALLOWED

    def excluded(self, path: str) -> bool:
        for a in self.allowed:
            if is_within(path, a):
                return False
        for p in self.prefixes:
            if is_within(path, p):
                return True
        if self.globs:
            key = path_key(path)
            for g in self.globs:
                if fnmatch.fnmatchcase(key, g) or fnmatch.fnmatchcase(key, g + os.sep + "*"):
                    return True
        name = os.path.basename(path)
        if WINDOWS:
            name = name.casefold()
        return any(fnmatch.fnmatchcase(name, n) for n in self.names)

    def allows_descent(self, path: str) -> bool:
        """/run is excluded but /run/media must still be reachable when scanning '/'."""
        if not self.excluded(path):
            return True
        return any(is_within(a, path) and path_key(a) != path_key(path) for a in self.allowed)


def scan(cfg: ScanConfig, control: Control | None = None,
         progress: Callable[[dict], None] | None = None,
         known: Callable[[str], dict] | None = None) -> Iterator[FileEntry | Skipped]:
    """Yield FileEntry for every media file found and Skipped for every problem.

    known(folder) -> {name: (size, mtime_ns, ino, kind, fmt)} from the index: a file whose size,
    modification time and inode are unchanged keeps its known type WITHOUT being opened. On a
    200 000-file rescan, opening every file to check its first bytes was most of the time (milestone 9).

    progress(event) is called about 10x per second with
    {"phase": "listing", "files": n, "folders": n, "current": path}.
    """
    control = control or Control()
    ex = Excluder(cfg)
    files = folders = 0
    last = 0.0
    seen_dirs: set[tuple[int, int]] = set()
    stack = []
    for r in cfg.roots:
        r = os.path.normpath(os.path.expanduser(r))
        if os.path.islink(r):
            yield Skipped(r, "symlink (not followed)")
            continue
        if not os.path.isdir(r):
            yield Skipped(r, "not a folder or not found")
            continue
        stack.append(r)

    while stack:
        control.checkpoint()
        d = stack.pop()
        try:
            st = os.stat(d, follow_symlinks=False)
            key = (st.st_dev, st.st_ino)
            if key in seen_dirs:   # overlapping roots / bind mounts
                continue
            seen_dirs.add(key)
            it = os.scandir(d)
        except PermissionError:
            yield Skipped(d, "permission denied")
            continue
        except OSError as e:
            yield Skipped(d, e.strerror or str(e))
            continue
        folders += 1
        subdirs = []
        known_here = known(d) if known else {}
        with it:
            for entry in it:
                path = entry.path
                try:
                    if entry.is_symlink() or (WINDOWS and getattr(entry, "is_junction", bool)()):
                        continue
                    if entry.is_dir(follow_symlinks=False):
                        if ex.allows_descent(path):
                            subdirs.append(path)
                        continue
                    if not entry.is_file(follow_symlinks=False):
                        continue  # sockets, fifos, devices
                    if ex.excluded(path):
                        continue
                    est = entry.stat(follow_symlinks=False)
                    if est.st_size < cfg.min_size or not stat.S_ISREG(est.st_mode):
                        continue
                    if WINDOWS and getattr(est, "st_file_attributes", 0) & CLOUD_ONLY:
                        if extension(path) in MEDIA_EXT:
                            yield Skipped(path, "online-only file (OneDrive): not on this PC, not downloaded")
                        continue
                    k = known_here.get(entry.name)
                    if WINDOWS and k is not None:
                        est = os.lstat(path)          # scandir reports file ID 0 on Windows; lstat has the real one
                    if k is not None and k[0] == est.st_size and k[1] == est.st_mtime_ns and k[2] == db_int(est.st_ino):
                        found = (k[3], k[4])          # unchanged: type already known, don't open the file
                    else:
                        found = classify(path, sniff_unknown=cfg.sniff_unknown)
                    if found is not None and WINDOWS and not est.st_ino:
                        est = os.lstat(path)          # real file ID + drive serial: needed to recognise hard links
                except PermissionError:
                    yield Skipped(path, "permission denied")
                    continue
                except OSError as e:
                    yield Skipped(path, e.strerror or str(e))
                    continue
                if found is None:
                    continue
                files += 1
                yield FileEntry(path=path, size=est.st_size, mtime_ns=est.st_mtime_ns, dev=db_int(est.st_dev),
                                ino=db_int(est.st_ino), nlink=est.st_nlink, kind=found[0], fmt=found[1],
                                ctime_ns=est.st_ctime_ns)
                if progress and time.monotonic() - last > .1:
                    last = time.monotonic()
                    progress({"phase": "listing", "files": files, "folders": folders, "current": path})
        stack.extend(sorted(subdirs, reverse=True))  # depth-first, alphabetical
        if progress and time.monotonic() - last > .1:
            last = time.monotonic()
            progress({"phase": "listing", "files": files, "folders": folders, "current": d})
    if progress:
        progress({"phase": "listing", "files": files, "folders": folders, "current": "", "done": True})
