"""Sandbox lock for everything that changes files.

When the environment variable CLONE_RANGER_SANDBOX is set to a folder, every file
operation (trash, delete, move, rename, undo, and the Trash folder itself)
refuses any path outside that folder. The test suite sets it for every test.

As a second safety net, when running under pytest WITHOUT a sandbox, every
file operation is refused, so a test that forgot the fixture can't touch real files.
"""
from __future__ import annotations

import os

from .osinfo import is_within

ENV = "CLONE_RANGER_SANDBOX"


class SandboxViolation(PermissionError):
    """A file operation tried to touch a path outside the sandbox."""


def root() -> str | None:
    value = os.environ.get(ENV)
    return os.path.realpath(value) if value else None


def resolve(path: str) -> str:
    """Absolute path with the FOLDER resolved (symlinks in parent folders followed), but the last
    part kept as-is, so a symlink file is checked by where it lives, not where it points."""
    path = os.path.abspath(os.path.expanduser(path))
    parent, name = os.path.split(path)
    return os.path.join(os.path.realpath(parent), name) if name else os.path.realpath(parent)


def check(path: str | os.PathLike) -> str:
    """Return the absolute path, or raise SandboxViolation."""
    path = os.fspath(path)
    box = root()
    if box is None:
        if "PYTEST_CURRENT_TEST" in os.environ:
            raise SandboxViolation(f"refusing to touch {path}: running under pytest without {ENV}")
        return os.path.abspath(path)
    real = resolve(path)
    if not is_within(real, box):
        raise SandboxViolation(f"refusing to touch {path}: outside the sandbox {box}")
    return os.path.abspath(path)
