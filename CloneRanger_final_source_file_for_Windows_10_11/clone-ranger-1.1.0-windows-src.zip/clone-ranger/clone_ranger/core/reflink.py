"""Detect files whose data is shared on disk (Btrfs/XFS reflink copies or snapshots).

Deleting such a file frees little or no space, so Clone Ranger leaves it out of
"Space to reclaim". Uses the Linux FIEMAP ioctl; read-only.
"""
from __future__ import annotations

import os
import struct

try:
    import fcntl
except ImportError:      # Windows: no FIEMAP; shared copies are rare there (ReFS block cloning only)
    fcntl = None

FS_IOC_FIEMAP = 0xC020660B
FIEMAP_EXTENT_LAST = 0x1
FIEMAP_EXTENT_SHARED = 0x2000
_HEADER = struct.Struct("=QQLLLL")          # fm_start, fm_length, fm_flags, fm_mapped_extents, fm_extent_count, reserved
_EXTENT = struct.Struct("=QQQQQLLLL")       # logical, physical, length, reserved64[2], flags, reserved[3]
_BATCH = 64


def is_shared(path: str, max_rounds: int = 64) -> bool | None:
    """True if any part of the file's data is shared with another file or snapshot,
    False if none is, None if the filesystem can't tell us."""
    if fcntl is None:
        return None
    try:
        fd = os.open(path, os.O_RDONLY)
    except OSError:
        return None
    try:
        start = 0
        for _ in range(max_rounds):
            buf = bytearray(_HEADER.pack(start, 0xFFFFFFFFFFFFFFFF, 0, 0, _BATCH, 0) + b"\0" * (_EXTENT.size * _BATCH))
            try:
                fcntl.ioctl(fd, FS_IOC_FIEMAP, buf, True)
            except OSError:
                return None
            mapped = _HEADER.unpack_from(buf, 0)[3]
            if mapped == 0:
                return False
            last_end = start
            for i in range(mapped):
                logical, _phys, length, _r1, _r2, flags, *_ = _EXTENT.unpack_from(buf, _HEADER.size + i * _EXTENT.size)
                if flags & FIEMAP_EXTENT_SHARED:
                    return True
                if flags & FIEMAP_EXTENT_LAST:
                    return False
                last_end = logical + length
            start = last_end
        return False
    finally:
        os.close(fd)
