"""Types shared by trash.py (freedesktop Trash) and recycle_bin.py (Windows Recycle Bin).

They live here, not in trash.py, because on Windows trash.py imports recycle_bin.py:
if recycle_bin.py imported them from trash.py, the two files would import each other
and loading recycle_bin first would fail ("partially initialized module").
"""
from __future__ import annotations

from dataclasses import dataclass


class TrashUnavailable(OSError):
    """This drive has no usable Trash."""


@dataclass
class Trashed:
    original: str
    trash_file: str
    info_file: str
