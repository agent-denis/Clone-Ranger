r"""The Windows Recycle Bin (used instead of trash.py's freedesktop Trash on Windows).

Moving a file there uses Windows' own SHFileOperationW, exactly like pressing Delete in
File Explorer, so the file appears in the Recycle Bin and "Restore" works from there.
Windows keeps every recycled file as a pair:

    <drive>:\$Recycle.Bin\<your user SID>\$R1A2B3C.jpg    the file itself
    <drive>:\$Recycle.Bin\<your user SID>\$I1A2B3C.jpg    where it came from, its size, when

Afterwards Clone Ranger finds that pair, so its own Undo can put the file back the same way
Explorer's Restore does: rename $R... to the original path (never over an existing file)
and remove $I....

Drives without a Recycle Bin (USB sticks, memory cards, network drives) raise
TrashUnavailable BEFORE anything happens; there Windows would delete permanently.
"""
from __future__ import annotations

import os
import struct
import time

from . import fsops, sandbox
from .osinfo import DRIVE_FIXED, drive_type, path_key
from .trash_types import Trashed, TrashUnavailable

FO_DELETE = 3
FOF_SILENT = 0x0004
FOF_NOCONFIRMATION = 0x0010
FOF_ALLOWUNDO = 0x0040            # = to the Recycle Bin
FOF_NOERRORUI = 0x0400
FOF_WANTNUKEWARNING = 0x4000      # if Windows can't recycle it after all (too big), ASK before deleting

MAX_PATH = 260
FILETIME_EPOCH = 116444736000000000   # 1601-01-01 -> 1970-01-01 in 100 ns steps


# ----------------------------------------------------------------------------- the $I file
def parse_info(data: bytes) -> tuple[str, int, int] | None:
    """$I file -> (original path, size, deleted at in Unix ns), or None if it isn't one.
    Version 1 (Vista-8.1): fixed 260-character path. Version 2 (Windows 10/11): length + path."""
    if len(data) < 24:
        return None
    version, size, filetime = struct.unpack_from("<qqq", data)
    try:
        if version == 1:
            raw = data[24:24 + 2 * MAX_PATH]
        elif version == 2 and len(data) >= 28:
            n = struct.unpack_from("<i", data, 24)[0]
            raw = data[28:28 + 2 * max(0, n)]
        else:
            return None
        path = raw.decode("utf-16-le").split("\0", 1)[0]
    except UnicodeDecodeError:
        return None
    return (path, size, (filetime - FILETIME_EPOCH) * 100) if path else None


def build_info(path: str, size: int, deleted_ns: int) -> bytes:
    """A version 2 $I file (used by the tests)."""
    name = (path + "\0").encode("utf-16-le")
    return struct.pack("<qqqi", 2, size, deleted_ns // 100 + FILETIME_EPOCH, len(name) // 2) + name


# ----------------------------------------------------------------------------- Windows calls
def _user_sid() -> str | None:
    """The current user's SID ("S-1-5-21-..."), which names their folder inside $Recycle.Bin."""
    import ctypes
    from ctypes import wintypes
    advapi32, kernel32 = ctypes.windll.advapi32, ctypes.windll.kernel32
    kernel32.GetCurrentProcess.restype = wintypes.HANDLE
    advapi32.OpenProcessToken.argtypes = [wintypes.HANDLE, wintypes.DWORD, ctypes.POINTER(wintypes.HANDLE)]
    advapi32.GetTokenInformation.argtypes = [wintypes.HANDLE, ctypes.c_int, ctypes.c_void_p, wintypes.DWORD,
                                             ctypes.POINTER(wintypes.DWORD)]
    advapi32.ConvertSidToStringSidW.argtypes = [ctypes.c_void_p, ctypes.POINTER(wintypes.LPWSTR)]
    kernel32.LocalFree.argtypes = [ctypes.c_void_p]
    kernel32.CloseHandle.argtypes = [wintypes.HANDLE]
    token = wintypes.HANDLE()
    if not advapi32.OpenProcessToken(kernel32.GetCurrentProcess(), 0x0008, ctypes.byref(token)):  # TOKEN_QUERY
        return None
    try:
        size = wintypes.DWORD()
        advapi32.GetTokenInformation(token, 1, None, 0, ctypes.byref(size))      # 1 = TokenUser
        buf = ctypes.create_string_buffer(size.value)
        if not advapi32.GetTokenInformation(token, 1, buf, size, ctypes.byref(size)):
            return None
        psid = ctypes.cast(buf, ctypes.POINTER(ctypes.c_void_p))[0]             # TOKEN_USER.User.Sid
        text = wintypes.LPWSTR()
        if not advapi32.ConvertSidToStringSidW(psid, ctypes.byref(text)):
            return None
        try:
            return text.value
        finally:
            kernel32.LocalFree(text)
    finally:
        kernel32.CloseHandle(token)


_SID: list = []


def user_sid() -> str | None:
    if not _SID:
        try:
            _SID.append(_user_sid())
        except (AttributeError, OSError):
            _SID.append(None)
    return _SID[0]


def _shell_delete(path: str) -> int:
    """SHFileOperationW(FO_DELETE, FOF_ALLOWUNDO): returns 0 on success, else an error code."""
    import ctypes
    from ctypes import wintypes

    class SHFILEOPSTRUCTW(ctypes.Structure):
        _fields_ = [("hwnd", wintypes.HWND), ("wFunc", wintypes.UINT), ("pFrom", wintypes.LPCWSTR),
                    ("pTo", wintypes.LPCWSTR), ("fFlags", ctypes.c_ushort), ("fAnyOperationsAborted", wintypes.BOOL),
                    ("hNameMappings", ctypes.c_void_p), ("lpszProgressTitle", wintypes.LPCWSTR)]

    op = SHFILEOPSTRUCTW()
    op.wFunc = FO_DELETE
    op.pFrom = path + "\0"            # the list must end with two NULs; ctypes adds the second
    op.fFlags = FOF_ALLOWUNDO | FOF_NOCONFIRMATION | FOF_NOERRORUI | FOF_SILENT | FOF_WANTNUKEWARNING
    fn = ctypes.windll.shell32.SHFileOperationW
    fn.argtypes = [ctypes.POINTER(SHFILEOPSTRUCTW)]
    r = fn(ctypes.byref(op))
    if r == 0 and op.fAnyOperationsAborted:
        return 1223                   # ERROR_CANCELLED: the user said No to "delete permanently?"
    return r


# ----------------------------------------------------------------------------- finding the $R/$I pair
def bin_folders(path: str) -> list[str]:
    """$Recycle.Bin folders on this file's drive that could hold it: the user's own first."""
    drive = os.path.splitdrive(os.path.abspath(path))[0]
    top = os.path.join(drive + "\\", "$Recycle.Bin")
    sid = user_sid()
    out = [os.path.join(top, sid)] if sid else []
    try:
        out += [e.path for e in os.scandir(top) if e.is_dir(follow_symlinks=False) and e.path not in out]
    except OSError:
        pass
    return out


def find_recycled(original: str, folders: list[str], since_ns: int) -> tuple[str, str] | None:
    """The newest ($R file, $I file) recorded for `original` since `since_ns` (only recent $I files are read)."""
    want = path_key(original)
    best = None
    for folder in folders:
        try:
            entries = list(os.scandir(folder))
        except OSError:
            continue
        for e in entries:
            if not e.name.upper().startswith("$I"):
                continue
            try:
                if e.stat(follow_symlinks=False).st_mtime_ns < since_ns:
                    continue
                with open(e.path, "rb") as f:
                    info = parse_info(f.read(4096))
            except OSError:
                continue
            if info and path_key(info[0]) == want:
                r_file = os.path.join(folder, "$R" + e.name[2:])
                if os.path.lexists(r_file) and (best is None or info[2] > best[0]):
                    best = (info[2], r_file, e.path)
    return (best[1], best[2]) if best else None


# ----------------------------------------------------------------------------- the trash.py interface
def can_trash(path: str) -> tuple[bool, str]:
    try:
        t = drive_type(path)
    except OSError as e:
        return False, e.strerror or str(e)
    if t != DRIVE_FIXED:
        return False, "this drive has no Recycle Bin (USB stick, memory card or network drive)"
    return True, ""


def trash(path: str) -> Trashed:
    """Move one file to the Recycle Bin. Raises TrashUnavailable if its drive has none (file untouched).
    trash_file / info_file are "" if Windows deleted it permanently after asking (then Undo can't help)."""
    path = os.path.abspath(sandbox.check(path))
    ok, why = can_trash(path)
    if not ok:
        raise TrashUnavailable(19, why, path)
    since = time.time_ns() - 5_000_000_000      # $I mtime is "now"; allow for clock granularity
    r = _shell_delete(path)
    if r == 1223 or os.path.lexists(path):
        raise OSError(r or 5, "Windows did not move the file to the Recycle Bin"
                      + (" (cancelled)" if r == 1223 else f" (error {r})"), path)
    if r != 0:
        raise OSError(r, f"Windows could not move the file to the Recycle Bin (error {r})", path)
    folders = bin_folders(path)
    found = find_recycled(path, folders, since) or find_recycled(path, folders, 0)
    if not found:
        return Trashed(path, "", "")
    return Trashed(path, found[0], found[1])


def restore(trash_file: str, info_file: str, original: str) -> None:
    """Put a recycled file back (never over a file that took its place), like Explorer's Restore."""
    sandbox.check(original)
    if not trash_file or not os.path.lexists(trash_file):
        raise fsops.Changed("is no longer in the Recycle Bin (emptied or restored already)")
    parent = os.path.dirname(original)
    if not os.path.isdir(parent):
        fsops.makedirs(parent)
    os.rename(trash_file, original)              # Windows: fails if original exists, never replaces
    try:
        os.unlink(info_file)
    except OSError:
        pass
