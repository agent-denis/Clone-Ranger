"""Bulk rename: turn a list of files plus options into a checked plan (no file is touched here).

Steps, in this order, applied to the name without its extension (unless
"include extension" is on for find/replace):
  1. date-taken name  (replaces the name with e.g. 2024-07-01_18-22-05)
  2. find / replace   (plain text or regular expression, optionally case-sensitive)
  3. case             (keep / lower / UPPER / Title)
  4. prefix + name + suffix
  5. numbering        (before or after the name, with start, step, digits, separator)
  6. extension        (keep / lower / UPPER / change)
Every new name is then checked: invalid characters, too long, empty, unchanged,
two files getting the same name, or a name already taken on disk.
"""
from __future__ import annotations

import os
import re
import time
from dataclasses import dataclass, field

from .osinfo import WINDOWS

MAX_NAME_BYTES = 255
WIN_BAD_CHARS = '<>:"/\\|?*'
WIN_RESERVED = {"CON", "PRN", "AUX", "NUL", *(f"COM{i}" for i in range(1, 10)), *(f"LPT{i}" for i in range(1, 10))}


@dataclass
class Options:
    find: str = ""
    replace: str = ""
    regex: bool = False
    match_case: bool = False
    include_ext: bool = False
    prefix: str = ""
    suffix: str = ""
    numbering: bool = False
    num_start: int = 1
    num_step: int = 1
    num_digits: int = 3
    num_position: str = "suffix"     # prefix | suffix
    num_sep: str = "_"
    case: str = "keep"               # keep | lower | upper | title
    date_name: bool = False
    date_format: str = "%Y-%m-%d_%H-%M-%S"
    date_fallback: str = "mtime"     # mtime | skip  (files without a date taken)
    ext: str = "keep"                # keep | lower | upper | change
    new_ext: str = ""
    auto_number_conflicts: bool = False   # name taken -> add _2, _3 ...


@dataclass
class File:
    path: str
    taken: str = ""                  # "YYYY-MM-DD HH:MM:SS" or ""
    mtime_ns: int = 0


@dataclass
class PlanItem:
    path: str
    new_name: str
    status: str = "ok"               # ok | unchanged | invalid | conflict
    reason: str = ""

    @property
    def new_path(self) -> str:
        return os.path.join(os.path.dirname(self.path), self.new_name)

    @property
    def old_name(self) -> str:
        return os.path.basename(self.path)


@dataclass
class Plan:
    items: list[PlanItem] = field(default_factory=list)
    error: str = ""                  # e.g. a broken regular expression

    @property
    def ready(self) -> list[PlanItem]:
        return [i for i in self.items if i.status == "ok"]

    @property
    def blocked(self) -> list[PlanItem]:
        return [i for i in self.items if i.status in ("invalid", "conflict")]


def split_ext(name: str) -> tuple[str, str]:
    stem, ext = os.path.splitext(name)
    if not stem:           # ".hidden" has no extension
        return name, ""
    return stem, ext


def _date_text(f: File, opts: Options) -> str | None:
    if f.taken:
        try:
            return time.strftime(opts.date_format, time.strptime(f.taken[:19], "%Y-%m-%d %H:%M:%S"))
        except ValueError:
            pass
    if opts.date_fallback == "mtime" and f.mtime_ns:
        return time.strftime(opts.date_format, time.localtime(f.mtime_ns / 1e9))
    return None


def _case(s: str, mode: str) -> str:
    return {"lower": s.lower(), "upper": s.upper(), "title": s.title()}.get(mode, s)


def check_name(name: str) -> str:
    """Return why a file name is not allowed, or ''."""
    if not name or not name.strip():
        return "empty name"
    if name in (".", ".."):
        return "not a valid name"
    if "/" in name or "\0" in name:
        return "contains “/”"
    if WINDOWS:
        bad = sorted({ch for ch in name if ch in WIN_BAD_CHARS})
        if bad:
            return "contains " + " ".join(f"“{ch}”" for ch in bad)
        if any(ord(ch) < 32 for ch in name):
            return "contains a control character"
        if name.endswith("."):
            return "ends with a dot"
        if name.split(".")[0].upper().strip() in WIN_RESERVED:
            return "a name Windows reserves (CON, NUL, COM1 ...)"
    if len(os.fsencode(name)) > MAX_NAME_BYTES:
        return "name too long"
    if name != name.strip():
        return "starts or ends with a space"
    return ""


def _number(i: int, opts: Options) -> str:
    return str(opts.num_start + i * opts.num_step).zfill(max(1, opts.num_digits))


def new_name(f: File, i: int, opts: Options, pattern: re.Pattern | None) -> tuple[str | None, str]:
    """Return (new name, reason-if-None)."""
    name = os.path.basename(f.path)
    stem, ext = split_ext(name)
    if opts.date_name:
        d = _date_text(f, opts)
        if d is None:
            return None, "no date taken"
        stem = d
    if opts.find:
        target = stem + ext if opts.include_ext else stem
        if pattern is not None:
            target = pattern.sub(opts.replace, target)
        elif opts.match_case:
            target = target.replace(opts.find, opts.replace)
        else:
            target = re.sub(re.escape(opts.find), lambda _m: opts.replace, target, flags=re.IGNORECASE)
        if opts.include_ext:
            stem, ext = split_ext(target)
        else:
            stem = target
    stem = _case(stem, opts.case)
    stem = f"{opts.prefix}{stem}{opts.suffix}"
    if opts.numbering:
        num = _number(i, opts)
        stem = f"{num}{opts.num_sep}{stem}" if opts.num_position == "prefix" else f"{stem}{opts.num_sep}{num}"
    if opts.ext == "lower":
        ext = ext.lower()
    elif opts.ext == "upper":
        ext = ext.upper()
    elif opts.ext == "change":
        e = opts.new_ext.strip().lstrip(".")
        ext = f".{e}" if e else ""
    return stem + ext, ""


def plan(files: list[File], opts: Options, exists=os.path.lexists) -> Plan:
    """Build and check the plan. `exists` is injectable for tests."""
    out = Plan()
    pattern = None
    if opts.find and opts.regex:
        try:
            pattern = re.compile(opts.find, 0 if opts.match_case else re.IGNORECASE)
        except re.error as e:
            out.error = f"regular expression: {e}"
    sources = {os.path.abspath(f.path) for f in files}
    taken: dict[str, int] = {}        # new path -> index of the item that claimed it
    for i, f in enumerate(files):
        if out.error:
            out.items.append(PlanItem(f.path, os.path.basename(f.path), "invalid", out.error))
            continue
        name, why = new_name(f, i, opts, pattern)
        if name is None:
            out.items.append(PlanItem(f.path, os.path.basename(f.path), "invalid", why))
            continue
        item = PlanItem(f.path, name)
        bad = check_name(name)
        if bad:
            item.status, item.reason = "invalid", bad
        elif name == item.old_name:
            item.status, item.reason = "unchanged", "same name"
        else:
            stem, ext = split_ext(name)
            n = 1
            while True:
                candidate = os.path.join(os.path.dirname(f.path), name)
                clash = ""
                if candidate in taken:
                    clash = f"same new name as {os.path.basename(files[taken[candidate]].path)}"
                elif (exists(candidate) and os.path.abspath(candidate) not in sources
                      and not _same_file(candidate, f.path)):
                    clash = "a file with this name already exists"
                if not clash:
                    break
                if not opts.auto_number_conflicts:
                    item.status, item.reason = "conflict", clash
                    break
                n += 1
                name = f"{stem}_{n}{ext}"
            item.new_name = name
            if item.status == "ok":
                taken[os.path.join(os.path.dirname(f.path), name)] = i
        out.items.append(item)
    # a file that stays (unchanged/blocked) keeps its name, so nobody else may take it
    staying = {os.path.abspath(it.path) for it in out.items if it.status != "ok"}
    for it in out.items:
        if it.status == "ok" and os.path.abspath(it.new_path) in staying:
            it.status, it.reason = "conflict", "another selected file keeps this name"
    return out


def _same_file(a: str, b: str) -> bool:
    """Case-only rename on a case-insensitive drive: the 'existing' file is the file itself."""
    try:
        return os.path.samefile(a, b)
    except OSError:
        return False
