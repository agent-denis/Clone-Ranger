"""User settings, stored as JSON in ~/.config/clone-ranger/settings.json.

Unknown keys are kept, missing keys fall back to defaults, and a broken file
is moved aside (settings.json.broken) instead of crashing the app.
"""
from __future__ import annotations

import json
import os
from copy import deepcopy

from . import paths
from .scanner import DEFAULT_EXCLUDES

DEFAULTS = {
    "roots": None,              # None = home folder + external drives (/run/media/$USER/*)
    "entire_computer": False,
    "excludes": None,           # None = DEFAULT_EXCLUDES
    "sniff_unknown": False,
    "min_size": 1,
    "theme": "auto",            # auto (follow the desktop) | light | dark | plain
    "reduce_motion": False,
    "view": "cards",            # cards | ledger | grid
    "mode": "content",          # content | name
    "name_ignore_case": True,
    "name_ignore_ext": False,
    "preview_panel": True,
    "grid_size": 180,
    "window_geometry": None,
    "last_roots": [],
    "protected_folders": [],    # files in here are never selected, moved, renamed or deleted
    "keep_rules": None,         # None = defaults; else [[rule key, enabled], ...] in order (core/recommend.py)
    "preferred_folders": None,  # None = ~/Pictures and ~/Videos
    "sounds": False,
    "last_move_dest": None,
    "move_keep_structure": False,
    "move_conflict": "skip",    # skip | number | overwrite
}


# what "Reset to defaults" calls search settings (core/housekeeping.py)
SEARCH_KEYS = ("roots", "entire_computer", "excludes", "sniff_unknown", "min_size", "name_ignore_case",
               "name_ignore_ext")
# remembered places: cleared with the history
HISTORY_KEYS = ("last_roots", "last_move_dest")


class Settings:
    def __init__(self, path=None):
        self.path = path or (paths.config_dir() / "settings.json")
        self.data = deepcopy(DEFAULTS)
        self.load()

    def load(self):
        try:
            with open(self.path, encoding="utf-8") as f:
                stored = json.load(f)
            if isinstance(stored, dict):
                self.data.update(stored)
        except FileNotFoundError:
            pass
        except (OSError, json.JSONDecodeError):
            try:
                os.replace(self.path, str(self.path) + ".broken")
            except OSError:
                pass

    def save(self):
        paths.ensure(self.path.parent)
        tmp = str(self.path) + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(self.data, f, indent=2, ensure_ascii=False)
        os.replace(tmp, self.path)

    def __getitem__(self, key):
        return self.data.get(key, DEFAULTS.get(key))

    def __setitem__(self, key, value):
        self.data[key] = value

    def excludes(self) -> list[str]:
        return list(self["excludes"]) if self["excludes"] is not None else list(DEFAULT_EXCLUDES)
