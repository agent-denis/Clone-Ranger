"""Read media metadata: resolution, date taken, duration, and the file's creation time.

Images: Pillow (size + EXIF DateTimeOriginal). Videos: ffprobe (size, duration,
creation_time). Creation time: statx birth time where the filesystem records it
(Btrfs, ext4, XFS). Everything is read-only and failure-tolerant.
"""
from __future__ import annotations

import json
import os
import subprocess
from dataclasses import dataclass

from .osinfo import bundled_tool, no_window

FFPROBE = bundled_tool("ffprobe")
FFMPEG = bundled_tool("ffmpeg")

try:  # optional: HEIC/HEIF support
    import pillow_heif  # type: ignore
    pillow_heif.register_heif_opener()
    HEIF = True
except Exception:  # noqa: BLE001 - not installed or no wheel for this Python
    HEIF = False


@dataclass
class Meta:
    width: int | None = None
    height: int | None = None
    duration: float | None = None        # seconds (videos)
    taken: str | None = None             # "YYYY-MM-DD HH:MM:SS" (EXIF / video creation_time)
    birth_ns: int | None = None          # file creation time
    codec: str | None = None
    error: str | None = None             # why something couldn't be read


def birth_ns(path: str) -> int | None:
    if hasattr(os, "statx"):
        try:
            mask = getattr(os, "STATX_BTIME", 0x800)
            st = os.statx(path, mask, follow_symlinks=False)
            ns = getattr(st, "stx_btime_ns", None)
            if ns:
                return int(ns)
        except (OSError, TypeError, ValueError):
            pass
    st = os.stat(path, follow_symlinks=False)
    bt = getattr(st, "st_birthtime", None)
    return int(bt * 1e9) if bt else None


def _exif_date(img) -> str | None:
    try:
        exif = img.getexif()
    except Exception:  # noqa: BLE001
        return None
    raw = None
    try:
        raw = exif.get_ifd(0x8769).get(36867)  # DateTimeOriginal in the Exif IFD
    except Exception:  # noqa: BLE001
        pass
    raw = raw or exif.get(36867) or exif.get(306)  # DateTime
    if not raw or not isinstance(raw, str):
        return None
    raw = raw.strip().replace("\x00", "")
    if len(raw) >= 19 and raw[4] == ":" and raw[7] == ":":
        return f"{raw[0:4]}-{raw[5:7]}-{raw[8:10]} {raw[11:19]}"
    return None


def image_meta(path: str) -> Meta:
    from PIL import Image
    m = Meta()
    try:
        with Image.open(path) as img:
            w, h = img.size
            try:
                orientation = img.getexif().get(0x0112, 1)
            except Exception:  # noqa: BLE001
                orientation = 1
            if orientation in (5, 6, 7, 8):  # stored sideways
                w, h = h, w
            m.width, m.height = w, h
            m.taken = _exif_date(img)
            m.codec = img.format
    except Exception as e:  # noqa: BLE001 - unsupported format (HEIC without plugin, some RAW)
        ext = os.path.splitext(path)[1].lower()
        if ext in (".heic", ".heif") and not HEIF:
            m.error = "HEIC/HEIF support is not installed"
        else:
            m.error = f"cannot read image: {type(e).__name__}"
    return m


def video_meta(path: str) -> Meta:
    m = Meta()
    if not FFPROBE:
        m.error = "ffprobe is not installed"
        return m
    try:
        out = subprocess.run(
            [FFPROBE, "-v", "error", "-print_format", "json", "-show_entries",
             "format=duration:format_tags=creation_time:stream=codec_type,codec_name,width,height:"
             "stream_tags=rotate:stream_side_data=rotation", path],
            capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=20, **no_window())
        data = json.loads(out.stdout or "{}")
    except (subprocess.TimeoutExpired, json.JSONDecodeError, OSError) as e:
        m.error = f"ffprobe failed: {type(e).__name__}"
        return m
    v = next((s for s in data.get("streams", []) if s.get("codec_type") == "video"), None)
    if v:
        m.width, m.height, m.codec = v.get("width"), v.get("height"), v.get("codec_name")
        rot = (v.get("tags") or {}).get("rotate")
        for sd in v.get("side_data_list", []) or []:
            rot = sd.get("rotation", rot)
        try:
            if rot is not None and abs(int(float(rot))) % 180 == 90 and m.width and m.height:
                m.width, m.height = m.height, m.width
        except ValueError:
            pass
    fmt = data.get("format", {})
    try:
        m.duration = float(fmt.get("duration")) if fmt.get("duration") else None
    except ValueError:
        pass
    ct = (fmt.get("tags") or {}).get("creation_time")
    if ct and len(ct) >= 19 and not ct.startswith("1970"):
        m.taken = ct[:10] + " " + ct[11:19]
    if not v:
        m.error = "no video stream found"
    return m


def read(path: str, kind: str) -> Meta:
    m = image_meta(path) if kind == "image" else video_meta(path)
    try:
        m.birth_ns = birth_ns(path)
    except OSError:
        pass
    return m
