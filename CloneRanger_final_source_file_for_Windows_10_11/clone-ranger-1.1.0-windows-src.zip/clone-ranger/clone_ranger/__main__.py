import sys

if "--version" in sys.argv[1:]:          # answered before Qt is imported (used by install.sh's self-check)
    from . import __version__
    print(f"clone-ranger {__version__}")
    sys.exit(0)

from .app import main  # noqa: E402

sys.exit(main())
