"""Clone Ranger - round up your duplicate photos and videos. A duplicate image & video manager."""
__version__ = "1.1.0"

# Desktop identity (reverse-DNS, AppStream style): .desktop file, icon name, metainfo, Wayland app_id.
# The settings / cache / state folders use the short name "clone-ranger" (core/paths.py).
APP_ID = "io.github.agent_denis.CloneRanger"
HOMEPAGE = "https://github.com/agent-denis/clone-ranger"
