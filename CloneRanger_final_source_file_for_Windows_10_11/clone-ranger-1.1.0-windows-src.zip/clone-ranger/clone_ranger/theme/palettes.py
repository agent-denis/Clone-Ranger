"""Colour palettes for the Light and Dark looks, plus a WCAG contrast checker.

Brand colours: orange, light blue, white, yellow and red.
* GRADIENT (red -> orange -> yellow) decorates: the header line, the logo, the progress ring.
* BUTTON_GRADIENT (orange -> yellow) fills primary buttons and the selected navigation item, with dark
  `on_brand` text (white text is not readable on yellow).
* `accent` light blue is used for focus rings, ticks, links and checked states.
* `danger` red only for destructive actions.
`TEXT_PAIRS` lists every foreground/background combination the UI uses for text;
tests/test_palettes.py checks each one meets WCAG AA.
"""

from dataclasses import dataclass, fields

# brand gradient stops (decoration: header line, logo, progress ring)
GRADIENT = ("#EF4444", "#F97316", "#FACC15")
BUTTON_GRADIENT = ("#FB923C", "#FACC15")       # orange -> yellow; ON_BRAND text on both stops passes AA
ON_BRAND = "#1C1917"
WORDMARK_LIGHT = ("#DC2626", "#EA580C", "#D97706")   # the gradient wordmark on white needs deeper stops


@dataclass(frozen=True)
class Palette:
    key: str
    dark: bool
    bg: str              # window background
    surface: str         # cards, panels, dialogs
    surface_alt: str     # inputs, alternate rows, hover
    sidebar: str         # navigation column
    line: str            # borders, dividers
    text: str            # main text
    text_muted: str      # secondary text
    accent: str          # light blue: focus rings, checked states, ticks (as a fill)
    accent_text: str     # blue readable AS text on bg / surface
    accent_soft: str     # pale blue fill (chips, hover, soft buttons)
    on_accent: str       # text drawn ON accent
    on_brand: str        # text / icons drawn ON the orange -> yellow button gradient
    danger: str          # destructive buttons, "Remove" badge
    on_danger: str
    danger_hover: str
    danger_text: str     # rose readable as text on bg / surface
    success: str         # "Keep" badge fill
    on_success: str
    success_text: str
    info: str            # hard-link badge fill
    on_info: str
    warning_text: str    # amber readable as text
    selection: str       # selected row background
    selection_text: str
    shadow: str          # card drop shadow colour (with alpha, #AARRGGBB)
    photo_bg: str        # behind letter-boxed photos


LIGHT = Palette(
    key="light", dark=False,
    bg="#F4F9FF", surface="#FFFFFF", surface_alt="#EAF4FD", sidebar="#FFFFFF", line="#D6E6F5",
    text="#0F172A", text_muted="#475569",
    accent="#0284C7", accent_text="#0369A1", accent_soft="#E0F2FE", on_accent="#FFFFFF", on_brand=ON_BRAND,
    danger="#DC2626", on_danger="#FFFFFF", danger_hover="#B91C1C", danger_text="#B91C1C",
    success="#0369A1", on_success="#FFFFFF", success_text="#0369A1",
    info="#FACC15", on_info=ON_BRAND, warning_text="#A16207",
    selection="#CDEBFC", selection_text="#0F172A",
    shadow="#220F2A44", photo_bg="#E7EEF6",
)

DARK = Palette(
    key="dark", dark=True,
    bg="#0B1220", surface="#131C2E", surface_alt="#1B2740", sidebar="#0E1626", line="#2A3956",
    text="#F8FAFC", text_muted="#A5B4CB",
    accent="#0284C7", accent_text="#7DD3FC", accent_soft="#0E2E4A", on_accent="#FFFFFF", on_brand=ON_BRAND,
    danger="#DC2626", on_danger="#FFFFFF", danger_hover="#EF4444", danger_text="#FCA5A5",
    success="#0369A1", on_success="#FFFFFF", success_text="#7DD3FC",
    info="#FACC15", on_info=ON_BRAND, warning_text="#FDE047",
    selection="#1E3A5F", selection_text="#F8FAFC",
    shadow="#66000000", photo_bg="#070C16",
)

PALETTES = {"light": LIGHT, "dark": DARK}

# (foreground, background, large_text?) for every text combination the UI draws.
TEXT_PAIRS = [
    ("text", "bg", False), ("text", "surface", False), ("text", "surface_alt", False), ("text", "sidebar", False),
    ("text_muted", "bg", False), ("text_muted", "surface", False), ("text_muted", "surface_alt", False),
    ("text_muted", "sidebar", False),
    ("accent_text", "bg", False), ("accent_text", "surface", False), ("accent_text", "accent_soft", False),
    ("text", "accent_soft", False),
    ("on_accent", "accent", True), ("on_danger", "danger", False), ("on_danger", "danger_hover", True),
    ("danger_text", "bg", False), ("danger_text", "surface", False),
    ("on_success", "success", False), ("success_text", "surface", False),
    ("on_info", "info", False), ("warning_text", "surface", False),
    ("selection_text", "selection", False),
]


def _lum(hex_color: str) -> float:
    h = hex_color.lstrip("#")[-6:]
    rgb = [int(h[i:i + 2], 16) / 255 for i in (0, 2, 4)]
    lin = [c / 12.92 if c <= 0.03928 else ((c + 0.055) / 1.055) ** 2.4 for c in rgb]
    return 0.2126 * lin[0] + 0.7152 * lin[1] + 0.0722 * lin[2]


def contrast(a: str, b: str) -> float:
    la, lb = sorted((_lum(a), _lum(b)), reverse=True)
    return (la + 0.05) / (lb + 0.05)


def check(p: Palette):
    """Yield (fg, bg, ratio, needed, ok) for every text pair."""
    for fg, bg, large in TEXT_PAIRS:
        r = contrast(getattr(p, fg), getattr(p, bg))
        need = 3.0 if large else 4.5
        yield fg, bg, r, need, r >= need


if __name__ == "__main__":
    for p in PALETTES.values():
        print(f"\n{p.key}")
        for fg, bg, r, need, ok in check(p):
            print(f"  {'OK ' if ok else 'BAD'} {fg:15} on {bg:12} {r:5.2f} (needs {need})")
    for stop in BUTTON_GRADIENT:
        print(f"{ON_BRAND} on {stop}: {contrast(ON_BRAND, stop):.2f}")
    assert {f.name for f in fields(Palette)}  # keep linters quiet
