"""Painted artwork: the logo, themed line icons, the brand gradient, soft shadows and pill badges.

Everything is generated in code or from our own SVGs, and cached, so painting lists of thousands of
groups stays cheap.
"""
from functools import lru_cache
from pathlib import Path

from PySide6.QtCore import QByteArray, QPointF, QRectF, Qt
from PySide6.QtGui import (QColor, QFont, QFontMetricsF, QIcon, QImage, QLinearGradient, QPainter, QPainterPath,
                           QPen, QPixmap)
from PySide6.QtSvg import QSvgRenderer

from . import fonts
from .palettes import BUTTON_GRADIENT, GRADIENT, ON_BRAND, WORDMARK_LIGHT

SVG_DIR = Path(__file__).resolve().parent / "svg"


# --------------------------------------------------------------------------- icons & logo
@lru_cache(maxsize=None)
def _icon_source(name: str) -> str:
    return (SVG_DIR / "icons" / f"{name}.svg").read_text()


@lru_cache(maxsize=512)
def icon(name: str, color: str, bg: str = "#FFFFFF") -> QIcon:
    """Line icon in any colour. `bg` fills the little circles of e.g. the settings icon."""
    data = _icon_source(name).replace("#000000", color).replace('"#FFFFFF"', f'"{bg}"')
    renderer = QSvgRenderer(QByteArray(data.encode()))
    ic = QIcon()
    for size in (16, 20, 24, 32, 48, 64):
        img = QImage(size, size, QImage.Format.Format_ARGB32_Premultiplied)
        img.fill(Qt.GlobalColor.transparent)
        p = QPainter(img)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        renderer.render(p, QRectF(0, 0, size, size))
        p.end()
        ic.addPixmap(QPixmap.fromImage(img))
    return ic


@lru_cache(maxsize=32)
def logo(size: int, dpr: float = 1.0) -> QPixmap:
    """The app logo (gradient tile with the ranger star)."""
    name = "logo.svg" if size >= 40 else "logo-small.svg"
    renderer = QSvgRenderer(str(SVG_DIR / name))
    px = round(size * dpr)
    img = QImage(px, px, QImage.Format.Format_ARGB32_Premultiplied)
    img.fill(Qt.GlobalColor.transparent)
    p = QPainter(img)
    p.setRenderHints(QPainter.RenderHint.Antialiasing | QPainter.RenderHint.SmoothPixmapTransform)
    renderer.render(p, QRectF(0, 0, px, px))
    p.end()
    pm = QPixmap.fromImage(img)
    pm.setDevicePixelRatio(dpr)
    return pm


# --------------------------------------------------------------------------- gradient & shapes
def gradient(rect, stops=GRADIENT, diagonal=True) -> QLinearGradient:
    """The brand gradient across `rect` (left->right, or top-left->bottom-right)."""
    r = QRectF(rect)
    g = QLinearGradient(r.topLeft(), r.bottomRight() if diagonal else r.topRight())
    n = len(stops) - 1
    for i, c in enumerate(stops):
        g.setColorAt(i / n if n else 0, QColor(c))
    return g


def button_gradient(rect) -> QLinearGradient:
    return gradient(rect, BUTTON_GRADIENT)


def paint_shadow(p: QPainter, rect, radius: float, color: str, spread: int = 6, dy: float = 3):
    """A soft drop shadow: a few stacked translucent rounded rects (cheap, no blur effect)."""
    base = QColor(color)
    if base.alpha() == 0:
        return
    r = QRectF(rect).translated(0, dy)
    p.save()
    p.setPen(Qt.PenStyle.NoPen)
    for i in range(spread, 0, -1):
        c = QColor(base)
        c.setAlpha(max(1, int(base.alpha() * (1 - i / (spread + 1)) / spread * 1.6)))
        p.setBrush(c)
        p.drawRoundedRect(r.adjusted(-i, -i + 1, i, i), radius + i, radius + i)
    p.restore()


def rounded(rect, radius: float) -> QPainterPath:
    path = QPainterPath()
    path.addRoundedRect(QRectF(rect), radius, radius)
    return path


def pill_width(text: str, px: float = 11) -> float:
    return QFontMetricsF(fonts.label(px)).horizontalAdvance(text) + px * 1.8


def paint_pill(p: QPainter, x: float, y: float, text: str, bg, fg: str, px: float = 11, icon_name: str | None = None,
               align_right: bool = False) -> QRectF:
    """A rounded badge ("KEEP", "REMOVE", "PROTECTED") with the label font. `bg` may be a colour string or a
    gradient brush. Returns its rect."""
    f = fonts.label(px)
    fm = QFontMetricsF(f)
    h = px * 2.0
    ic = h * .62 if icon_name else 0
    w = fm.horizontalAdvance(text) + px * 1.8 + (ic + 4 if ic else 0)
    rect = QRectF(x - w if align_right else x, y, w, h)
    p.save()
    p.setRenderHint(QPainter.RenderHint.Antialiasing)
    p.setPen(Qt.PenStyle.NoPen)
    p.setBrush(QColor(bg) if isinstance(bg, str) else bg)
    p.drawRoundedRect(rect, h / 2, h / 2)
    tx = rect.left() + px * .9
    if ic:
        pm = icon(icon_name, fg).pixmap(int(ic * 2), int(ic * 2))
        p.drawPixmap(QRectF(tx - 2, rect.top() + (h - ic) / 2, ic, ic), pm, QRectF(pm.rect()))
        tx += ic + 2
    p.setFont(f)
    p.setPen(QColor(fg))
    p.drawText(QRectF(tx, rect.top(), w, h), Qt.AlignmentFlag.AlignVCenter | Qt.AlignmentFlag.AlignLeft, text)
    p.restore()
    return rect


def paint_check(p: QPainter, rect: QRectF, checked: bool, c, enabled: bool = True):
    """A rounded tick box drawn on photos: white with a border, or filled with the gradient + a dark tick."""
    p.save()
    p.setRenderHint(QPainter.RenderHint.Antialiasing)
    r = QRectF(rect)
    if checked:
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(button_gradient(r))
        p.drawRoundedRect(r, 7, 7)
        p.setPen(QPen(QColor(ON_BRAND), 2.4, Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap,
                      Qt.PenJoinStyle.RoundJoin))
        path = QPainterPath(QPointF(r.left() + r.width() * .24, r.top() + r.height() * .52))
        path.lineTo(r.left() + r.width() * .43, r.top() + r.height() * .71)
        path.lineTo(r.left() + r.width() * .77, r.top() + r.height() * .31)
        p.setBrush(Qt.BrushStyle.NoBrush)
        p.drawPath(path)
    else:
        p.setPen(QPen(QColor(c.line if enabled else c.surface_alt), 2))
        p.setBrush(QColor(255, 255, 255, 235 if enabled else 120))
        p.drawRoundedRect(r.adjusted(1, 1, -1, -1), 7, 7)
    p.restore()


def paint_padlock(p: QPainter, x: float, y: float, s: float, color: str):
    p.save()
    p.setRenderHint(QPainter.RenderHint.Antialiasing)
    p.setPen(QPen(QColor(color), max(1.2, s * .12)))
    p.setBrush(Qt.BrushStyle.NoBrush)
    p.drawArc(QRectF(x + s * .25, y, s * .5, s * .6), 0, 180 * 16)
    p.drawLine(QPointF(x + s * .25, y + s * .3), QPointF(x + s * .25, y + s * .45))
    p.drawLine(QPointF(x + s * .75, y + s * .3), QPointF(x + s * .75, y + s * .45))
    p.setBrush(QColor(color))
    p.drawRoundedRect(QRectF(x + s * .12, y + s * .42, s * .76, s * .58), s * .08, s * .08)
    p.restore()


def gradient_text_pixmap(text: str, font: QFont, dpr: float = 1.0, stops=None) -> QPixmap:
    """Text filled with the brand gradient (used for the wordmark)."""
    fm = QFontMetricsF(font)
    w, h = fm.horizontalAdvance(text) + 4, fm.height() + 2
    img = QImage(round(w * dpr), round(h * dpr), QImage.Format.Format_ARGB32_Premultiplied)
    img.setDevicePixelRatio(dpr)
    img.fill(Qt.GlobalColor.transparent)
    p = QPainter(img)
    p.setRenderHints(QPainter.RenderHint.Antialiasing | QPainter.RenderHint.TextAntialiasing)
    path = QPainterPath()
    path.addText(QPointF(1, fm.ascent()), font, text)
    if stops is None:
        from .style import theme
        stops = GRADIENT if theme().colors.dark else WORDMARK_LIGHT
    p.fillPath(path, gradient(QRectF(0, 0, w, h), stops, diagonal=False))
    p.end()
    pm = QPixmap.fromImage(img)
    pm.setDevicePixelRatio(dpr)
    return pm
