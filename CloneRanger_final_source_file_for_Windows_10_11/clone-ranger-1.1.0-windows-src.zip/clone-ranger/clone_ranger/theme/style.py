"""Theme manager: System (follows the desktop's light/dark setting), Light, Dark and Plain.

Widgets that paint themselves read `theme().colors` and listen to `theme().changed` to repaint.
`theme().plain` is True in Plain mode (the standard system look, no stylesheet).
"""
from PySide6.QtCore import QObject, Qt, Signal
from PySide6.QtGui import QColor, QGuiApplication, QPalette
from PySide6.QtWidgets import QApplication

from . import fonts
from .palettes import BUTTON_GRADIENT, PALETTES, Palette
from pathlib import Path

_SVG = Path(__file__).resolve().parent / "svg"
CHECK = (_SVG / "check.svg").as_posix()
ARROW_UP = (_SVG / "arrow-up.svg").as_posix()
ARROW_DOWN = (_SVG / "arrow-down.svg").as_posix()

THEMES = ("auto", "light", "dark", "plain")


def _grad(stops=BUTTON_GRADIENT) -> str:
    a, b = stops
    return f"qlineargradient(x1:0, y1:0, x2:1, y2:1, stop:0 {a}, stop:1 {b})"


def build_qss(p: Palette) -> str:
    mono = fonts._FALLBACK_MONO[0]
    hover_grad = _grad((QColor(BUTTON_GRADIENT[0]).darker(112).name(), QColor(BUTTON_GRADIENT[1]).darker(112).name()))
    return f"""
/* No font rules on "*": they would override every setFont() call. The base font is set with
   QApplication.setFont() in ThemeManager.apply(). */
QMainWindow, QDialog, QWidget#Centre {{ background: {p.bg}; color: {p.text}; }}
QWidget {{ color: {p.text}; }}
QToolTip {{ background: {p.surface}; color: {p.text}; border: 1px solid {p.line}; border-radius: 6px; padding: 6px 8px; }}
QLabel[role="muted"], QLabel#Subtitle {{ color: {p.text_muted}; }}
QLabel[role="label"] {{ color: {p.text_muted}; }}
QLabel[role="section"], QLabel[role="title"] {{ color: {p.text}; }}
QLabel[role="accent"] {{ color: {p.accent_text}; }}
QLabel[role="danger"] {{ color: {p.danger_text}; }}
QLabel[role="success"] {{ color: {p.success_text}; }}
QLabel[role="warning"] {{ color: {p.warning_text}; }}
QLabel[role="stat"] {{ color: {p.text}; }}
QLabel a {{ color: {p.accent_text}; }}

/* ---------- menus ---------- */
QMenuBar {{ background: {p.surface}; color: {p.text}; border-bottom: 1px solid {p.line}; padding: 2px 6px; }}
QMenuBar::item {{ padding: 5px 10px; background: transparent; border-radius: 6px; }}
QMenuBar::item:selected {{ background: {p.accent_soft}; }}
QMenu {{ background: {p.surface}; color: {p.text}; border: 1px solid {p.line}; border-radius: 10px; padding: 6px; }}
QMenu::item {{ padding: 7px 26px 7px 26px; border-radius: 6px; }}
QMenu::item:selected {{ background: {p.accent_soft}; color: {p.text}; }}
QMenu::item:disabled {{ color: {p.text_muted}; }}
QMenu::separator {{ height: 1px; background: {p.line}; margin: 5px 8px; }}

/* ---------- panels ---------- */
QWidget#Header {{ background: {p.surface}; border-bottom: 1px solid {p.line}; }}
QWidget#Sidebar {{ background: {p.sidebar}; border-right: 1px solid {p.line}; }}
QFrame#Card, QWidget#Card {{ background: {p.surface}; border: 1px solid {p.line}; border-radius: 14px; }}
QFrame#Card QLabel, QWidget#Card QLabel {{ background: transparent; border: none; }}
QWidget#Details {{ background: {p.surface}; border-left: 1px solid {p.line}; }}

/* ---------- buttons ---------- */
QPushButton {{ background: {p.surface}; color: {p.text}; border: 1px solid {p.line}; border-radius: 10px;
    padding: 7px 14px; font-weight: 600; }}
QPushButton:hover {{ background: {p.surface_alt}; border-color: {p.accent}; }}
QPushButton:focus {{ border: 2px solid {p.accent}; }}
QPushButton:pressed {{ background: {p.accent_soft}; }}
QPushButton:checked {{ background: {p.accent_soft}; color: {p.accent_text}; border-color: {p.accent}; }}
QPushButton:disabled {{ color: {p.text_muted}; background: transparent; border: 1px dashed {p.line}; }}
QPushButton[size="small"] {{ padding: 5px 11px; border-radius: 8px; }}
QPushButton[size="large"] {{ padding: 10px 22px; border-radius: 12px; }}
QPushButton[variant="primary"] {{ background: {_grad()}; color: {p.on_brand}; border: none; }}
QPushButton[variant="primary"]:hover {{ background: {hover_grad}; }}
QPushButton[variant="primary"]:focus {{ border: 2px solid {p.text}; }}
QPushButton[variant="danger"] {{ background: {p.danger}; color: {p.on_danger}; border: none; }}
QPushButton[variant="danger"]:hover {{ background: {p.danger_hover}; }}
QPushButton[variant="danger"]:focus {{ border: 2px solid {p.text}; }}
QPushButton[variant="soft"] {{ background: {p.accent_soft}; color: {p.accent_text}; border: 1px solid transparent; }}
QPushButton[variant="soft"]:hover {{ border-color: {p.accent}; }}
QPushButton[variant="ghost"] {{ background: transparent; border: 1px solid transparent; }}
QPushButton[variant="ghost"]:hover {{ background: {p.surface_alt}; border-color: transparent; }}
QPushButton[variant="ghost"]:checked {{ background: {p.accent_soft}; color: {p.accent_text}; }}
QPushButton[variant="primary"]:disabled, QPushButton[variant="danger"]:disabled, QPushButton[variant="soft"]:disabled {{
    background: transparent; color: {p.text_muted}; border: 1px dashed {p.line}; }}

/* ---------- segmented view switch ---------- */
QWidget#Segmented {{ background: {p.surface_alt}; border-radius: 10px; }}
QWidget#Segmented QPushButton {{ background: transparent; border: none; border-radius: 8px; padding: 5px 12px; color: {p.text_muted}; }}
QWidget#Segmented QPushButton:hover {{ color: {p.text}; }}
QWidget#Segmented QPushButton:checked {{ background: {p.surface}; color: {p.accent_text}; }}

/* ---------- inputs ---------- */
QLineEdit, QComboBox, QSpinBox, QDoubleSpinBox, QDateEdit {{ background: {p.surface_alt}; color: {p.text};
    border: 1px solid {p.line}; border-radius: 10px; padding: 6px 10px;
    selection-background-color: {p.selection}; selection-color: {p.selection_text}; }}
QLineEdit:focus, QComboBox:focus, QSpinBox:focus, QDoubleSpinBox:focus, QDateEdit:focus {{ border: 2px solid {p.accent}; }}
QLineEdit#Search {{ border-radius: 14px; padding: 7px 14px; }}
QLineEdit#Search:focus {{ border-radius: 14px; border: 2px solid {p.accent}; padding: 6px 13px; }}
QComboBox::drop-down, QDateEdit::drop-down {{ border: none; width: 24px; subcontrol-origin: padding;
    subcontrol-position: center right; }}
QComboBox::down-arrow, QDateEdit::down-arrow {{ image: url("{ARROW_DOWN}"); width: 12px; height: 12px; }}
QSpinBox, QDoubleSpinBox {{ padding-right: 24px; }}
QSpinBox::up-button, QDoubleSpinBox::up-button {{ subcontrol-origin: border; subcontrol-position: top right;
    width: 22px; border: none; background: transparent; margin-top: 3px; }}
QSpinBox::down-button, QDoubleSpinBox::down-button {{ subcontrol-origin: border; subcontrol-position: bottom right;
    width: 22px; border: none; background: transparent; margin-bottom: 3px; }}
QSpinBox::up-button:hover, QDoubleSpinBox::up-button:hover, QSpinBox::down-button:hover,
QDoubleSpinBox::down-button:hover {{ background: {p.accent_soft}; border-radius: 6px; }}
QSpinBox::up-arrow, QDoubleSpinBox::up-arrow {{ image: url("{ARROW_UP}"); width: 12px; height: 12px; }}
QSpinBox::down-arrow, QDoubleSpinBox::down-arrow {{ image: url("{ARROW_DOWN}"); width: 12px; height: 12px; }}
QComboBox QAbstractItemView {{ background: {p.surface}; color: {p.text}; selection-background-color: {p.accent_soft};
    selection-color: {p.text}; border: 1px solid {p.line}; border-radius: 8px; padding: 4px; outline: none; }}
QPlainTextEdit, QTextEdit {{ background: {p.surface_alt}; color: {p.text}; border: 1px solid {p.line}; border-radius: 10px;
    padding: 6px; selection-background-color: {p.selection}; selection-color: {p.selection_text}; }}
QPlainTextEdit[role="log"] {{ font-family: "{mono}"; font-size: 12px; color: {p.text_muted}; }}
QCheckBox, QRadioButton {{ spacing: 8px; }}
QCheckBox::indicator {{ width: 16px; height: 16px; border: 2px solid {p.line}; border-radius: 6px; background: {p.surface}; }}
QCheckBox::indicator:hover {{ border-color: {p.accent}; }}
QCheckBox::indicator:checked {{ background: {p.accent}; border-color: {p.accent};
    image: url("{CHECK}"); }}
QCheckBox::indicator:disabled {{ background: {p.surface_alt}; }}
QCheckBox::indicator:checked:disabled {{ background: {p.text_muted}; border-color: {p.text_muted};
    image: url("{CHECK}"); }}
QRadioButton::indicator {{ width: 14px; height: 14px; border: 2px solid {p.line}; border-radius: 9px; background: {p.surface}; }}
QRadioButton::indicator:hover {{ border-color: {p.accent}; }}
QRadioButton::indicator:checked {{ width: 8px; height: 8px; border: 5px solid {p.accent}; border-radius: 9px;
    background: {p.on_accent}; }}
QProgressBar {{ background: {p.surface_alt}; border: none; border-radius: 4px; }}
QProgressBar::chunk {{ background: {_grad()}; border-radius: 4px; }}
QSlider::groove:horizontal {{ height: 4px; background: {p.line}; border-radius: 2px; }}
QSlider::sub-page:horizontal {{ background: {p.accent}; border-radius: 2px; }}
QSlider::handle:horizontal {{ background: {p.surface}; border: 2px solid {p.accent}; width: 14px; height: 14px;
    margin: -7px 0; border-radius: 9px; }}

/* ---------- lists ---------- */
QListView, QTableView, QTreeView, QListWidget {{ background: {p.bg}; color: {p.text}; border: none; outline: none;
    selection-background-color: {p.selection}; selection-color: {p.selection_text}; }}
QListWidget#Panel, QTableView#Panel {{ background: {p.surface}; border: 1px solid {p.line}; border-radius: 12px; padding: 4px; }}
QListWidget::item {{ padding: 6px 8px; border-radius: 6px; }}
QListWidget::item:selected {{ background: {p.selection}; color: {p.selection_text}; }}
QTableView {{ gridline-color: {p.line}; alternate-background-color: {p.surface_alt}; }}
QHeaderView::section {{ background: {p.surface}; color: {p.text_muted}; border: none; border-bottom: 1px solid {p.line};
    padding: 7px 8px; font-weight: 600; }}
QTableCornerButton::section {{ background: {p.surface}; border: none; }}

/* ---------- scroll bars ---------- */
QScrollArea {{ background: transparent; border: none; }}
QScrollBar:vertical {{ background: transparent; width: 12px; margin: 2px; }}
QScrollBar::handle:vertical {{ background: {p.line}; min-height: 36px; border-radius: 4px; margin: 0 2px; }}
QScrollBar::handle:vertical:hover {{ background: {p.accent}; }}
QScrollBar:horizontal {{ background: transparent; height: 12px; margin: 2px; }}
QScrollBar::handle:horizontal {{ background: {p.line}; min-width: 36px; border-radius: 4px; margin: 2px 0; }}
QScrollBar::handle:horizontal:hover {{ background: {p.accent}; }}
QScrollBar::add-line, QScrollBar::sub-line {{ width: 0; height: 0; }}
QScrollBar::add-page, QScrollBar::sub-page {{ background: none; }}
QSplitter::handle {{ background: {p.line}; }}
QTabWidget::pane {{ border: none; }}
QTabBar::tab {{ background: transparent; color: {p.text_muted}; padding: 8px 14px; border-bottom: 2px solid transparent; font-weight: 600; }}
QTabBar::tab:selected {{ color: {p.accent_text}; border-bottom: 2px solid {p.accent}; }}
"""


def build_qpalette(p: Palette) -> QPalette:
    pal = QPalette()
    roles = {
        QPalette.ColorRole.Window: p.bg, QPalette.ColorRole.WindowText: p.text,
        QPalette.ColorRole.Base: p.surface_alt, QPalette.ColorRole.AlternateBase: p.surface,
        QPalette.ColorRole.Text: p.text, QPalette.ColorRole.Button: p.surface,
        QPalette.ColorRole.ButtonText: p.text, QPalette.ColorRole.Highlight: p.selection,
        QPalette.ColorRole.HighlightedText: p.selection_text, QPalette.ColorRole.ToolTipBase: p.surface,
        QPalette.ColorRole.ToolTipText: p.text, QPalette.ColorRole.PlaceholderText: p.text_muted,
        QPalette.ColorRole.Link: p.accent_text, QPalette.ColorRole.Mid: p.line,
    }
    for role, color in roles.items():
        pal.setColor(role, QColor(color))
    return pal


def system_is_dark() -> bool:
    app = QGuiApplication.instance()
    try:
        return app.styleHints().colorScheme() == Qt.ColorScheme.Dark
    except AttributeError:                       # Qt < 6.5
        return app.palette().color(QPalette.ColorRole.Window).lightness() < 128


class ThemeManager(QObject):
    changed = Signal()

    def __init__(self):
        super().__init__()
        self.key = "auto"
        self.reduce_motion = False
        self._default_palette = None
        self._default_style = None
        self._default_font = None
        self._watching = False

    @property
    def resolved(self) -> str:
        """light | dark | plain - what is on screen now ('auto' resolved against the desktop setting)."""
        if self.key == "auto":
            return "dark" if system_is_dark() else "light"
        return self.key

    @property
    def palette(self) -> Palette | None:
        """The active palette, or None in Plain mode (standard system look)."""
        return PALETTES.get(self.resolved)

    @property
    def plain(self) -> bool:
        return self.key == "plain"

    @property
    def colors(self) -> Palette:
        """Colours for self-painted widgets. In Plain mode they come from the system palette."""
        if self.palette:
            return self.palette
        src = self._default_palette or QApplication.instance().palette()
        c = lambda role: src.color(role).name()
        R = QPalette.ColorRole
        dark = src.color(R.Window).lightness() < 128
        base = PALETTES["dark" if dark else "light"]
        return Palette(
            key="plain", dark=dark, bg=c(R.Window), surface=c(R.Base), surface_alt=c(R.AlternateBase),
            sidebar=c(R.Window), line=c(R.Mid), text=c(R.WindowText), text_muted=c(R.PlaceholderText),
            accent=c(R.Highlight), accent_text=c(R.Link), accent_soft=c(R.AlternateBase),
            on_accent=c(R.HighlightedText), on_brand=c(R.HighlightedText), danger=base.danger, on_danger=base.on_danger,
            danger_hover=base.danger_hover, danger_text=base.danger_text, success=base.success,
            on_success=base.on_success, success_text=base.success_text, info=base.info, on_info=base.on_info,
            warning_text=base.warning_text, selection=c(R.Highlight), selection_text=c(R.HighlightedText),
            shadow="#00000000", photo_bg=c(R.AlternateBase))

    def apply(self, key: str):
        app = QApplication.instance()
        if self._default_palette is None:
            self._default_palette = app.palette()
            self._default_style = app.style().name()
            self._default_font = app.font()
        self.key = key if key in THEMES else "auto"
        if not self._watching:
            try:
                app.styleHints().colorSchemeChanged.connect(self._system_changed)
            except AttributeError:
                pass
            self._watching = True
        p = self.palette
        if p is None:
            # Plain mode: system look, destructive buttons keep a red label
            red = "#FDA4AF" if self._default_palette.color(QPalette.ColorRole.Window).lightness() < 128 else "#BE123C"
            app.setStyleSheet(f'QPushButton[variant="danger"] {{ color: {red}; font-weight: bold; }}')
            app.setPalette(self._default_palette)
            app.setFont(self._default_font)
        else:
            app.setFont(fonts.body(14))
            app.setPalette(build_qpalette(p))
            app.setStyleSheet(build_qss(p))
        self.changed.emit()

    def _system_changed(self, *_):
        if self.key == "auto":
            self.apply("auto")


_theme = None


def theme() -> ThemeManager:
    global _theme
    if _theme is None:
        _theme = ThemeManager()
    return _theme
