"""Fonts and font helpers.

UI font: Inter (SIL OFL 1.1). It is bundled in theme/fonts/inter for installs from source; the Fedora RPM
removes the bundled copy and uses the system package (rsms-inter-fonts) instead. If neither is present,
Qt falls back to Cantarell / Noto Sans / DejaVu Sans.
Monospace (hashes, paths, logs): the system's monospace font.
"""
from pathlib import Path

from PySide6.QtGui import QFont, QFontDatabase

FONT_DIR = Path(__file__).resolve().parent / "fonts"

BODY = "Inter"
DISPLAY = "Inter Display"
_FALLBACK_SANS = ["Cantarell", "Noto Sans", "DejaVu Sans", "Segoe UI"]
_FALLBACK_MONO = ["JetBrains Mono", "Source Code Pro", "Noto Sans Mono", "DejaVu Sans Mono", "Liberation Mono", "Consolas",
                  "monospace"]

_loaded = False


def load_fonts() -> list[str]:
    """Register bundled fonts (if any) with Qt. Safe to call more than once."""
    global _loaded
    families = []
    if not _loaded:
        for ttf in sorted(FONT_DIR.glob("*/*.ttf")):
            fid = QFontDatabase.addApplicationFont(str(ttf))
            if fid >= 0:
                families += QFontDatabase.applicationFontFamilies(fid)
        _loaded = True
    return families


def _font(families, px, weight=QFont.Weight.Normal, spacing=0.0, caps=False, italic=False):
    f = QFont()
    f.setFamilies(families)
    f.setPixelSize(max(1, round(px)))
    f.setWeight(weight)
    f.setItalic(italic)
    if spacing:
        f.setLetterSpacing(QFont.SpacingType.AbsoluteSpacing, spacing)
    if caps:
        f.setCapitalization(QFont.Capitalization.AllUppercase)
    f.setHintingPreference(QFont.HintingPreference.PreferNoHinting)
    return f


def body(px=14, weight=QFont.Weight.Normal, italic=False) -> QFont:
    """Running text, buttons, inputs."""
    return _font([BODY] + _FALLBACK_SANS, px, weight, italic=italic)


def heading(px=20, weight=QFont.Weight.Bold) -> QFont:
    """Titles: Inter Display, slightly tightened."""
    return _font([DISPLAY, BODY] + _FALLBACK_SANS, px, weight, spacing=-px * .01)


def logo(px=22) -> QFont:
    return _font([DISPLAY, BODY] + _FALLBACK_SANS, px, QFont.Weight.ExtraBold, spacing=-px * .015)


def label(px=11) -> QFont:
    """Small uppercase overline label above values ("SPACE TO FREE")."""
    return _font([BODY] + _FALLBACK_SANS, px, QFont.Weight.DemiBold, spacing=px * .06, caps=True)


def number(px=22, weight=QFont.Weight.Bold) -> QFont:
    """Big figures in stat cards (tabular digits look tidy in Inter)."""
    f = _font([DISPLAY, BODY] + _FALLBACK_SANS, px, weight)
    f.setFeature(QFont.Tag("tnum"), 1) if hasattr(QFont, "Tag") else None
    return f


def mono(px=13, weight=QFont.Weight.Normal) -> QFont:
    f = _font(_FALLBACK_MONO, px, weight)
    f.setStyleHint(QFont.StyleHint.Monospace)
    return f
