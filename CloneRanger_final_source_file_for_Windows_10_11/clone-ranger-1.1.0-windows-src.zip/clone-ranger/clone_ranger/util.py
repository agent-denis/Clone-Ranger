"""Small formatting helpers shared by the command line and the window."""
import os
import sys
import time

HOME = os.path.expanduser("~")


def human(n: float) -> str:
    """1536 -> '1.5 KB'"""
    for unit in ("B", "KB", "MB", "GB", "TB"):
        if abs(n) < 1024 or unit == "TB":
            return f"{n:.0f} {unit}" if unit == "B" else f"{n:.1f} {unit}"
        n /= 1024


def hms(seconds: float) -> str:
    s = max(0, int(round(seconds)))
    return f"{s // 3600:02d}:{s % 3600 // 60:02d}:{s % 60:02d}"


def short_path(path: str) -> str:
    """/home/denis/Pictures -> ~/Pictures. (Windows: unchanged; "~" means nothing to Windows users.)"""
    if sys.platform == "win32":
        return path
    if path == HOME or path.startswith(HOME + "/"):
        return "~" + path[len(HOME):]
    return path


def date_ns(ns: int | None) -> str:
    if not ns:
        return ""
    return time.strftime("%Y-%m-%d %H:%M", time.localtime(ns / 1e9))
