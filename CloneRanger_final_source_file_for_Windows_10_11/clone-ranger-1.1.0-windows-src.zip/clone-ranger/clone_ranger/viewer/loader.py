"""Decode an image at full resolution for the viewer (no Qt; runs in worker threads).

Same rules as thumbnails: EXIF rotation applied, RAW files use Pillow or their
largest embedded JPEG preview, HEIC only with pillow-heif. Very large images
are scaled down to MAX_PIXELS so a 200-megapixel panorama can't eat all memory;
the result says so (`reduced`), and the viewer shows the real resolution.
"""
from __future__ import annotations

import os
from dataclasses import dataclass

from ..core import metadata
from ..thumbs.generate import RAW_EXT, _embedded_jpeg

MAX_PIXELS = 50_000_000          # ~200 MB as RGBA


@dataclass
class Loaded:
    width: int = 0               # pixels delivered
    height: int = 0
    mode: str = "RGB"            # RGB | RGBA
    data: bytes = b""
    full_width: int = 0          # real resolution of the file (after EXIF rotation)
    full_height: int = 0
    error: str = ""
    preview_only: bool = False   # RAW shown from its embedded JPEG

    @property
    def reduced(self) -> bool:
        return self.width < self.full_width


def _finish(img, preview_only=False) -> Loaded:
    from PIL import ImageOps
    img = ImageOps.exif_transpose(img)
    fw, fh = img.size
    if fw * fh > MAX_PIXELS:
        f = (MAX_PIXELS / (fw * fh)) ** 0.5
        img = img.resize((max(1, int(fw * f)), max(1, int(fh * f))))
    if img.mode not in ("RGB", "RGBA"):
        has_alpha = img.mode in ("RGBA", "LA", "PA") or (img.mode == "P" and "transparency" in img.info)
        img = img.convert("RGBA" if has_alpha else "RGB")
    return Loaded(img.width, img.height, img.mode, img.tobytes(), fw, fh, preview_only=preview_only)


def load_image(path: str) -> Loaded:
    from PIL import Image, UnidentifiedImageError
    ext = os.path.splitext(path)[1].lower()
    try:
        with Image.open(path) as img:
            if ext in RAW_EXT and max(img.size) < 1600:
                raise UnidentifiedImageError("tiny RAW thumbnail")
            if img.format == "JPEG" and img.width * img.height > MAX_PIXELS * 4:
                img.draft("RGB", (img.width // 2, img.height // 2))
            img.load()
            return _finish(img)
    except (UnidentifiedImageError, OSError, ValueError, SyntaxError) as e:
        if ext in RAW_EXT:
            try:
                emb = _embedded_jpeg(path)
                if emb:
                    emb.load()
                    return _finish(emb, preview_only=True)
            except OSError:
                pass
            return Loaded(error="RAW file without a readable preview")
        if ext in (".heic", ".heif") and not metadata.HEIF:
            return Loaded(error="HEIC/HEIF needs pillow-heif (not yet available for Python 3.15)")
        return Loaded(error=f"cannot read image ({type(e).__name__})")
    except MemoryError:
        return Loaded(error="image too large to open")
    except Exception as e:  # noqa: BLE001 - never crash on odd files
        return Loaded(error=f"cannot read image ({type(e).__name__})")
