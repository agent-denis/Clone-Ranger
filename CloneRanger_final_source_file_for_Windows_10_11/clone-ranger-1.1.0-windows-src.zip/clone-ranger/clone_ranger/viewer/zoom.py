"""Zoom and pan maths for the viewer (no Qt, unit-tested).

A View says which part of an image is shown:
  mode  "fit"    - the whole image fits the window (never enlarged beyond 100 %)
        "manual" - `scale` image pixels -> window pixels (1.0 = 100 %)
  cx,cy          - the image point (0..1) shown at the window centre
"""
from __future__ import annotations

from dataclasses import dataclass, replace

MIN_SCALE = 0.02
MAX_SCALE = 32.0
STEPS = (0.05, 0.1, 0.125, 0.25, 0.33, 0.5, 0.67, 0.75, 1, 1.5, 2, 3, 4, 6, 8, 12, 16, 24, 32)


@dataclass(frozen=True)
class View:
    mode: str = "fit"
    scale: float = 1.0
    cx: float = 0.5
    cy: float = 0.5


def fit_scale(iw, ih, ww, wh, upscale: bool = False) -> float:
    if iw <= 0 or ih <= 0 or ww <= 0 or wh <= 0:
        return 1.0
    s = min(ww / iw, wh / ih)
    return s if upscale else min(1.0, s)


def effective_scale(v: View, iw, ih, ww, wh) -> float:
    return fit_scale(iw, ih, ww, wh) if v.mode == "fit" else v.scale


def clamp(v: View, iw, ih, ww, wh) -> View:
    """Keep the image on screen: centre it on an axis where it is smaller than the window,
    otherwise don't let it scroll past its edges."""
    if v.mode == "fit":
        return replace(v, cx=0.5, cy=0.5)
    s = max(MIN_SCALE, min(MAX_SCALE, v.scale))

    def axis(c, isz, wsz):
        shown = wsz / (isz * s)          # visible fraction of the image
        if shown >= 1:
            return 0.5
        half = shown / 2
        return max(half, min(1 - half, c))
    return replace(v, scale=s, cx=axis(v.cx, iw, ww), cy=axis(v.cy, ih, wh))


def image_rect(v: View, iw, ih, ww, wh) -> tuple[float, float, float, float]:
    """(x, y, w, h) of the image in window coordinates."""
    v = clamp(v, iw, ih, ww, wh)
    s = effective_scale(v, iw, ih, ww, wh)
    w, h = iw * s, ih * s
    return ww / 2 - v.cx * w, wh / 2 - v.cy * h, w, h


def zoom_at(v: View, factor: float, px, py, iw, ih, ww, wh) -> View:
    """Zoom by `factor` keeping the image point under (px, py) where it is."""
    x, y, w, h = image_rect(v, iw, ih, ww, wh)
    s0 = effective_scale(clamp(v, iw, ih, ww, wh), iw, ih, ww, wh)
    s1 = max(MIN_SCALE, min(MAX_SCALE, s0 * factor))
    ix = (px - x) / w if w else 0.5       # normalized image point under the cursor
    iy = (py - y) / h if h else 0.5
    cx = ix - (px - ww / 2) / (iw * s1)
    cy = iy - (py - wh / 2) / (ih * s1)
    return clamp(View("manual", s1, cx, cy), iw, ih, ww, wh)


def step(v: View, direction: int, iw, ih, ww, wh) -> View:
    """Zoom to the next nicer step (+1 in, -1 out), around the window centre."""
    s0 = effective_scale(clamp(v, iw, ih, ww, wh), iw, ih, ww, wh)
    if direction > 0:
        s1 = next((s for s in STEPS if s > s0 * 1.001), MAX_SCALE)
    else:
        s1 = next((s for s in reversed(STEPS) if s < s0 / 1.001), MIN_SCALE)
    return zoom_at(v, s1 / s0, ww / 2, wh / 2, iw, ih, ww, wh)


def actual_size(v: View, iw, ih, ww, wh, px=None, py=None) -> View:
    """100 %, around (px, py) or the window centre."""
    s0 = effective_scale(clamp(v, iw, ih, ww, wh), iw, ih, ww, wh)
    return zoom_at(v, 1.0 / s0, ww / 2 if px is None else px, wh / 2 if py is None else py, iw, ih, ww, wh)


def pan(v: View, dx, dy, iw, ih, ww, wh) -> View:
    """Drag by (dx, dy) window pixels."""
    if v.mode == "fit":
        v = View("manual", fit_scale(iw, ih, ww, wh), 0.5, 0.5)
    return clamp(replace(v, cx=v.cx - dx / (iw * v.scale), cy=v.cy - dy / (ih * v.scale)), iw, ih, ww, wh)


def transfer(v: View, src: tuple, dst: tuple) -> View:
    """The same view on another image (compare mode): same relative position, and the same zoom
    RELATIVE TO FIT, so two copies of different resolution show the same part of the picture.
    src/dst = (iw, ih, ww, wh)."""
    if v.mode == "fit":
        return View()
    rel = v.scale / fit_scale(*src)
    return clamp(View("manual", rel * fit_scale(*dst), v.cx, v.cy), *dst)


def percent(v: View, iw, ih, ww, wh) -> int:
    return round(100 * effective_scale(clamp(v, iw, ih, ww, wh), iw, ih, ww, wh))
