"""Viewer support code without Qt: zoom maths and full-resolution image loading."""
