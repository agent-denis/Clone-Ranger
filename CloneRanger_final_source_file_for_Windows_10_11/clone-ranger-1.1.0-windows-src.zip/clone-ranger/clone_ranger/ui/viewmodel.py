"""What the window shows: case files (groups) and their copies, built from the index.

The views (cards, ledger, grid) and the dossier all read these objects. They
are plain Python objects owned by the UI thread.
"""
from __future__ import annotations

import os
from dataclasses import dataclass, field

from ..core import recommend
from ..core.duplicates import ContentGroup, NameGroup
from ..core.index import FileRow
from ..core.osinfo import db_int
from ..util import date_ns, hms, short_path


@dataclass(slots=True)        # one per copy on screen; never gets extra attributes
class UiCopy:
    path: str
    size: int
    mtime_ns: int = 0
    kind: str = "image"
    file_id: int | None = None
    inode: tuple = (0, 0)
    keep: bool = False              # recommended copy (KEEP)
    selected: bool = False          # selected for removal (REMOVE)
    protected: bool = False         # in a protected folder
    hard_link_of: str | None = None
    keep_twin: bool = False         # another name (hard link) of the kept file: never selectable
    shared: bool = False            # data shared on disk (Btrfs reflink/snapshot)
    hash: str | None = None
    # metadata (filled in the background)
    width: int | None = None
    height: int | None = None
    duration_s: float | None = None
    taken: str = ""
    birth_ns: int | None = None
    meta_error: str | None = None
    has_meta: bool = False
    seed: int = 0                   # demo data only

    @property
    def name(self) -> str:
        return os.path.basename(self.path)

    @property
    def folder(self) -> str:
        return short_path(os.path.dirname(self.path))

    @property
    def hard_link(self) -> bool:
        return self.hard_link_of is not None

    @property
    def created(self) -> str:
        return date_ns(self.birth_ns) or date_ns(self.mtime_ns)

    @property
    def modified(self) -> str:
        return date_ns(self.mtime_ns)

    @property
    def resolution(self) -> str:
        return f"{self.width} × {self.height}" if self.width and self.height else ""

    @property
    def duration(self) -> str:
        return hms(self.duration_s) if self.duration_s else ""

    @property
    def selectable(self) -> bool:
        return not self.keep and not self.keep_twin and not self.protected

    def apply_row(self, r: FileRow):
        self.width, self.height, self.duration_s = r.width, r.height, r.duration
        self.taken, self.birth_ns, self.meta_error = r.taken or "", r.birth_ns, r.meta_error
        self.has_meta = r.has_meta


@dataclass
class UiGroup:
    number: int
    kind: str
    hash: str
    size: int
    copies: list = field(default_factory=list)
    reason: str = ""
    mode: str = "content"           # content | name
    content: str = "same"           # name groups: same | different | unknown
    seed: int = 0                   # demo data only

    @property
    def inodes(self) -> int:
        return len({c.inode for c in self.copies})

    @property
    def is_duplicate(self) -> bool:
        return self.mode == "content" or self.content == "same"

    @property
    def reclaim(self) -> int:
        """Space freed by keeping one copy (hard links and data shared on disk excluded)."""
        if not self.is_duplicate:
            return 0
        inodes = {c.inode: c for c in self.copies}
        unshared = sum(1 for c in inodes.values() if not c.shared)
        return self.size * max(0, min(len(inodes) - 1, unshared))

    @property
    def selected_size(self) -> int:
        """Space actually freed by removing the selected copies (each inode counted once, and only
        when every path of that inode is selected)."""
        by_inode = {}
        for c in self.copies:
            by_inode.setdefault(c.inode, []).append(c)
        return sum(cs[0].size for cs in by_inode.values() if all(c.selected for c in cs) and not cs[0].shared)

    @property
    def oldest_ns(self) -> int:
        return min((c.birth_ns or c.mtime_ns or 0) for c in self.copies)

    @property
    def display_name(self) -> str:
        keep = next((c for c in self.copies if c.keep), self.copies[0])
        return keep.name


def _copy_from_row(r: FileRow, hard_link_of=None) -> UiCopy:
    c = UiCopy(path=r.path, size=r.size, mtime_ns=r.mtime_ns, kind=r.kind, file_id=r.id, inode=(r.dev, r.ino),
               hard_link_of=hard_link_of, shared=bool(r.shared), hash=r.full)
    c.apply_row(r)
    return c


_RULES = None     # active keep rules (None = defaults); set from Settings by the main window


def set_rules(rules) -> None:
    global _RULES
    _RULES = rules


def recommended_inode(g: UiGroup, rules=None):
    """(inode of the copy the rules would keep, reason) - without changing anything."""
    reps = {}
    for c in g.copies:
        reps.setdefault(c.inode, c)
    cands = [recommend.Candidate(path=c.path, size=c.size, mtime_ns=c.mtime_ns, birth_ns=c.birth_ns,
                                 width=c.width, height=c.height, protected=c.protected) for c in reps.values()]
    keep_i, reason = recommend.recommend(cands, rules if rules is not None else _RULES)
    return list(reps)[keep_i], reason


def count_changes(groups: list[UiGroup], rules, protected_folders=None) -> tuple[int, int]:
    """With these rules (and protected folders): (cases whose recommended copy would change, cases
    looked at). Cases the user changed by hand are not counted - they keep the user's choice."""
    from ..core.operations import is_protected
    changed = total = 0
    for g in groups:
        if not g.is_duplicate or getattr(g, "user_touched", False) or len(g.copies) < 2:
            continue
        total += 1
        current = next((c.inode for c in g.copies if c.keep or c.keep_twin), None)
        saved = [c.protected for c in g.copies]
        if protected_folders is not None:
            for c in g.copies:
                c.protected = is_protected(c.path, protected_folders)
        try:
            new, _ = recommended_inode(g, rules)
        finally:
            for c, p in zip(g.copies, saved):
                c.protected = p
        if new != current:
            changed += 1
    return changed, total


def apply_recommendation(g: UiGroup, preselect: bool = True):
    """Mark the copy to keep and pre-select the others (never acts on files)."""
    for c in g.copies:
        c.keep = c.keep_twin = False
        c.selected = False
    if not g.is_duplicate:
        g.reason = ""
        return
    # one candidate per inode (hard links are the same file)
    keep_inode, g.reason = recommended_inode(g)
    for c in g.copies:
        if c.inode == keep_inode:
            c.keep = c.hard_link_of is None   # the stamp goes on one path...
            c.keep_twin = not c.keep          # ...its hard links can't be selected (would free nothing)
        elif preselect and not c.protected:
            c.selected = True


def from_content_groups(groups: list[ContentGroup], start: int = 1) -> list[UiGroup]:
    out = []
    for n, g in enumerate(groups, start):
        ug = UiGroup(number=n, kind=g.kind, hash=g.hash, size=g.size, mode="content")
        ug.copies = [_copy_from_row(m.file, m.hard_link_of) for m in g.members]
        apply_recommendation(ug)
        out.append(ug)
    return out


def from_name_groups(groups: list[NameGroup], start: int = 1) -> list[UiGroup]:
    out = []
    for n, g in enumerate(groups, start):
        f0 = g.files[0]
        ug = UiGroup(number=n, kind=f0.kind, hash=f0.full or "", size=max(f.size for f in g.files), mode="name",
                     content=g.content)
        ug.copies = [_copy_from_row(f) for f in g.files]
        apply_recommendation(ug, preselect=False)  # same name is not proof: never pre-select
        out.append(ug)
    return out


# --------------------------------------------------------------------------- after file operations
def mark_protected(groups: list[UiGroup], folders) -> set[int]:
    """Flag copies inside protected folders (they can never be selected) and un-flag copies that are no
    longer protected. Returns ids of the groups whose protection changed."""
    from ..core.operations import is_protected
    changed = set()
    for g in groups:
        for c in g.copies:
            p = is_protected(c.path, folders or [])
            if p != c.protected:
                changed.add(id(g))
                c.protected = p
            if p:
                c.selected = False
    return changed


def target(c: UiCopy):
    from ..core.operations import Target
    return Target(c.path, c.size, c.mtime_ns, c.hash, c.protected)


def apply_order(groups: list[UiGroup], order) -> tuple[list[UiGroup], set[int]]:
    """Update the case files in place after an order ran (no rescan, no file read except lstat).

    Returns (groups still open, ids of groups that changed). Closed cases (fewer than two copies
    left, or fewer than two folders for same-name cases) are dropped."""
    by_path: dict[str, list[tuple[UiGroup, UiCopy]]] = {}
    for g in groups:
        for c in g.copies:
            by_path.setdefault(c.path, []).append((g, c))
    op = order.op
    removed, touched = set(), set()
    # look every file up BEFORE changing paths (swaps: a -> b and b -> a in the same order)
    for it, hits in [(it, by_path.get(it.src, [])) for it in order.ok]:
        for g, c in hits:
            touched.add(id(g))
            if op in ("trash", "delete"):
                removed.add(id(c))
            elif it.dst:
                c.path = it.dst
                c.selected = False
                try:
                    st = os.lstat(it.dst)
                    c.inode, c.mtime_ns = (db_int(st.st_dev), db_int(st.st_ino)), st.st_mtime_ns
                except OSError:
                    pass
    out = []
    for g in groups:
        if id(g) not in touched:
            out.append(g)
            continue
        g.copies = [c for c in g.copies if id(c) not in removed]
        if g.mode == "content":
            alive = g.inodes >= 2
        else:
            alive = len({os.path.dirname(c.path) for c in g.copies}) >= 2
        if not alive:
            continue
        # a removed copy may have been another's hard-link "first name"
        paths_ = {c.path for c in g.copies}
        for c in g.copies:
            if c.hard_link_of and c.hard_link_of not in paths_:
                first = next(x for x in g.copies if x.inode == c.inode)
                c.hard_link_of = None if first is c else first.path
        if not any(c.keep for c in g.copies) and g.is_duplicate:
            apply_recommendation(g, preselect=False)
            g.user_touched = True
        out.append(g)
    return out, touched


def selection_state(groups: list[UiGroup]) -> dict:
    """{path: selected} for groups the user changed by hand (to restore after a reload)."""
    return {c.path: c.selected for g in groups if getattr(g, "user_touched", False) for c in g.copies}


def restore_selection(groups: list[UiGroup], state: dict) -> None:
    for g in groups:
        if any(c.path in state for c in g.copies):
            for c in g.copies:
                c.selected = bool(state.get(c.path, False)) and c.selectable
            g.user_touched = True
