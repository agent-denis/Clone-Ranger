"""Full-resolution images for the viewer, decoded in background threads, with a memory budget."""
from __future__ import annotations

from collections import OrderedDict

from PySide6.QtCore import QObject, QRunnable, QThreadPool, Signal
from PySide6.QtGui import QImage

from ...viewer.loader import Loaded, load_image

MEMORY_BUDGET = 600 * 1024 * 1024     # decoded images kept for quick back-and-forth


def key_for(c) -> str:
    return f"{c.path}\0{c.mtime_ns}"


class _Signals(QObject):
    done = Signal(str, QImage, object)    # key, image (null on failure), Loaded (without pixel data)


class _Job(QRunnable):
    def __init__(self, key, path, signals):
        super().__init__()
        self.key, self.path, self.signals = key, path, signals
        self.setAutoDelete(True)

    def run(self):
        try:
            r = load_image(self.path)
        except Exception as e:  # noqa: BLE001
            r = Loaded(error=f"cannot read image ({type(e).__name__})")
        img = QImage()
        if not r.error:
            fmt = QImage.Format.Format_RGBA8888 if r.mode == "RGBA" else QImage.Format.Format_RGB888
            bpl = r.width * (4 if r.mode == "RGBA" else 3)
            img = QImage(r.data, r.width, r.height, bpl, fmt).copy()   # copy: own the pixels
        r.data = b""
        self.signals.done.emit(self.key, img, r)


class FullImages(QObject):
    """get(copy) -> (QImage | None, Loaded | None). None = not ready yet; `ready(key)` fires later."""
    ready = Signal(str)

    def __init__(self, parent=None, threads: int = 2, enabled: bool = True):
        super().__init__(parent)
        self.enabled = enabled                 # False in demo mode (the demo files don't exist)
        self.pool = QThreadPool(self)
        self.pool.setMaxThreadCount(threads)
        self.mem: OrderedDict[str, tuple[QImage, Loaded]] = OrderedDict()
        self.info: dict[str, Loaded] = {}
        self.pending: set[str] = set()
        self._sig = _Signals()
        self._sig.done.connect(self._done)

    def get(self, c):
        key = key_for(c)
        hit = self.mem.get(key)
        if hit is not None:
            self.mem.move_to_end(key)
            return hit
        if key in self.info:                   # failed before
            return None, self.info[key]
        self.request(c)
        return None, None

    def request(self, c):
        key = key_for(c)
        if not self.enabled or c.kind != "image" or key in self.mem or key in self.pending or key in self.info:
            return
        self.pending.add(key)
        self.pool.start(_Job(key, c.path, self._sig))

    def _done(self, key, img, info):
        self.pending.discard(key)
        if img.isNull():
            self.info[key] = info
        else:
            self.mem[key] = (img, info)
            used = 0
            for k in reversed(self.mem):       # newest first; drop the oldest beyond the budget
                used += self.mem[k][0].sizeInBytes()
            while used > MEMORY_BUDGET and len(self.mem) > 1:
                _k, (old, _i) = self.mem.popitem(last=False)
                used -= old.sizeInBytes()
        self.ready.emit(key)

    def wait(self, msecs: int = 5000):
        self.pool.waitForDone(msecs)
