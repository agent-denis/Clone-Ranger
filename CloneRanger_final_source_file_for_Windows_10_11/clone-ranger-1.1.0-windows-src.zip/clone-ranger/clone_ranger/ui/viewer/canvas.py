"""The light table: shows one image (or video frame) with fit / zoom / pan.

- wheel: zoom around the mouse pointer      - drag: pan
- double-click: fit <-> 100 % at the pointer
The logical size is the file's real resolution, so "100 %" means one file pixel per
screen pixel, even while only the thumbnail (or a reduced decode) is on screen.
"""
from __future__ import annotations

from PySide6.QtCore import QPointF, QRectF, Qt, Signal
from PySide6.QtGui import QColor, QFont, QImage, QPainter, QPen
from PySide6.QtWidgets import QSizePolicy, QWidget

from ...theme import fonts
from ...theme.style import theme
from ...viewer import zoom
from ...viewer.zoom import View

TABLE = "#161616"          # neutral grey: never tint the photos you're judging
TABLE_LIGHT = "#2A2A2A"


class ImageCanvas(QWidget):
    viewChanged = Signal(object)        # View, after a user action (for synchronised compare)
    clicked = Signal()

    def __init__(self, parent=None):
        super().__init__(parent)
        self.image: QImage | None = None
        self.logical = (0, 0)           # real resolution of the file
        self.view = View()
        self.message = ""
        self.badge = ""                 # small text in the corner, e.g. "THUMBNAIL"
        self._drag = None
        self._moved = False
        self.setMouseTracking(False)
        self.setFocusPolicy(Qt.FocusPolicy.ClickFocus)
        self.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        self.setMinimumSize(160, 120)
        self.setCursor(Qt.CursorShape.OpenHandCursor)

    # ------------------------------------------------------------------ content
    def set_image(self, img: QImage | None, logical: tuple[int, int] | None = None, keep_view: bool = True,
                  badge: str = ""):
        new_size = logical or ((img.width(), img.height()) if img is not None and not img.isNull() else (0, 0))
        if not keep_view or new_size != self.logical:
            if not keep_view:
                self.view = View()
        self.image = img if img is not None and not img.isNull() else None
        self.logical = new_size
        self.badge = badge
        self.message = "" if self.image is not None else self.message
        self.update()

    def set_message(self, text: str):
        self.message = text
        self.update()

    def clear(self):
        self.image, self.logical, self.message, self.badge = None, (0, 0), "", ""
        self.view = View()
        self.update()

    @property
    def dims(self):
        return (*self.logical, max(1, self.width()), max(1, self.height()))

    def set_view(self, v: View, emit: bool = False):
        if self.logical[0] <= 0:
            self.view = v
            return
        self.view = zoom.clamp(v, *self.dims)
        self.update()
        if emit:
            self.viewChanged.emit(self.view)

    def percent(self) -> int:
        return zoom.percent(self.view, *self.dims) if self.logical[0] > 0 else 0

    # ------------------------------------------------------------------ actions
    def fit(self):
        self.set_view(View(), emit=True)

    def actual(self):
        if self.logical[0]:
            self.set_view(zoom.actual_size(self.view, *self.dims), emit=True)

    def zoom_step(self, direction: int):
        if self.logical[0]:
            self.set_view(zoom.step(self.view, direction, *self.dims), emit=True)

    # ------------------------------------------------------------------ painting
    def paintEvent(self, _):
        p = QPainter(self)
        p.fillRect(self.rect(), QColor(TABLE))
        if self.image is not None and self.logical[0] > 0:
            x, y, w, h = zoom.image_rect(self.view, *self.dims)
            target = QRectF(x, y, w, h)
            scale = w / max(1, self.image.width())
            smooth = scale < 2.0                       # beyond 200 %: crisp pixels for pixel-peeping
            p.setRenderHint(QPainter.RenderHint.SmoothPixmapTransform, smooth)
            if self.image.hasAlphaChannel():           # checkerboard behind transparency
                self._checker(p, target.intersected(QRectF(self.rect())))
            # draw only the visible part (fast at high zoom)
            vis = target.intersected(QRectF(self.rect()))
            if not vis.isEmpty():
                sx = (vis.left() - x) / scale
                sy = (vis.top() - y) / scale
                src = QRectF(sx, sy, vis.width() / scale, vis.height() / scale)
                p.drawImage(vis, self.image, src)
        if self.message:
            p.setPen(QColor("#D6D2E4"))
            p.setFont(fonts.body(14))
            p.drawText(self.rect().adjusted(20, 20, -20, -20), Qt.AlignmentFlag.AlignCenter | Qt.TextFlag.TextWordWrap,
                       self.message)
        if self.badge:
            p.setRenderHint(QPainter.RenderHint.Antialiasing)
            p.setFont(fonts.label(10.5))
            fm = p.fontMetrics()
            r = QRectF(12, self.height() - 36, fm.horizontalAdvance(self.badge) + 22, 24)
            p.setPen(Qt.PenStyle.NoPen)
            p.setBrush(QColor(15, 13, 26, 190))
            p.drawRoundedRect(r, 12, 12)
            p.setPen(QColor("#F3F0FF"))
            p.drawText(r, Qt.AlignmentFlag.AlignCenter, self.badge)
        if self.hasFocus():
            p.setRenderHint(QPainter.RenderHint.Antialiasing)
            p.setPen(QPen(QColor(theme().colors.accent), 2))
            p.setBrush(Qt.BrushStyle.NoBrush)
            p.drawRoundedRect(QRectF(self.rect()).adjusted(1, 1, -1, -1), 10, 10)

    def _checker(self, p, r: QRectF):
        p.save()
        p.setClipRect(r)
        size = 12
        x0, y0 = int(r.left()) // size * size, int(r.top()) // size * size
        for yy in range(y0, int(r.bottom()) + size, size):
            for xx in range(x0, int(r.right()) + size, size):
                if (xx // size + yy // size) % 2:
                    p.fillRect(xx, yy, size, size, QColor(TABLE_LIGHT))
        p.restore()

    # ------------------------------------------------------------------ mouse
    def wheelEvent(self, e):
        if not self.logical[0]:
            return
        steps = e.angleDelta().y() / 120.0
        if not steps:
            return
        pos = e.position()
        self.set_view(zoom.zoom_at(self.view, 1.25 ** steps, pos.x(), pos.y(), *self.dims), emit=True)
        e.accept()

    def mousePressEvent(self, e):
        if e.button() == Qt.MouseButton.LeftButton:
            self._drag = e.position()
            self._moved = False
            self.setCursor(Qt.CursorShape.ClosedHandCursor)
        super().mousePressEvent(e)

    def mouseMoveEvent(self, e):
        if self._drag is not None and self.logical[0]:
            d = e.position() - self._drag
            if abs(d.x()) + abs(d.y()) > 2:
                self._moved = True
            self._drag = e.position()
            self.set_view(zoom.pan(self.view, d.x(), d.y(), *self.dims), emit=True)

    def mouseReleaseEvent(self, e):
        if e.button() == Qt.MouseButton.LeftButton:
            self._drag = None
            self.setCursor(Qt.CursorShape.OpenHandCursor)
            if not self._moved:
                self.clicked.emit()

    def mouseDoubleClickEvent(self, e):
        if not self.logical[0]:
            return
        pos: QPointF = e.position()
        if self.view.mode == "fit":
            self.set_view(zoom.actual_size(self.view, *self.dims, pos.x(), pos.y()), emit=True)
        else:
            self.fit()

    def resizeEvent(self, e):
        super().resizeEvent(e)
        if self.logical[0]:
            self.view = zoom.clamp(self.view, *self.dims)
