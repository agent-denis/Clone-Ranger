"""The viewer window: View (one copy), Compare (A / B side by side), Grid compare (every copy of the
group), and the slideshow.

Keys (shown in the window's help line):
  ← / →            previous / next copy (compare: side B; Shift: side A)
  PgUp / PgDn      previous / next group
  F · 1 · + · −    fit · 100 % · zoom in · zoom out          (wheel, drag, double-click on the image)
  L                lock zoom between panes (compare / grid)
  Tab              flicker: swap A and B in place (compare)
  X                select / unselect the current copy for removal
  Space            play / pause videos      M  mute
  1/2/3 with Ctrl  single / compare / grid  S  slideshow       Esc  close
"""
from __future__ import annotations

import math

from PySide6.QtCore import QSize, Qt, QTimer, Signal
from PySide6.QtGui import QFont, QKeySequence, QShortcut
from PySide6.QtWidgets import QGridLayout, QHBoxLayout, QLabel, QSizePolicy, QToolButton, QVBoxLayout, QWidget

from ...theme import art, fonts
from ...theme.strings import tr
from ...theme.style import theme
from ...viewer import zoom
from .images import FullImages
from .media import FACTS, MediaPane, fact_values
from ..widgets import Button, Segmented

MODES = ("single", "compare", "grid")
MAX_GRID = 9


def differing_facts(copies) -> set[str]:
    """Facts that are not the same for every copy (highlighted with ▲)."""
    out = set()
    vals = [fact_values(c) for c in copies]
    for k in FACTS:
        seen = {v[k] for v in vals if v[k]}
        if len(seen) > 1:
            out.add(k)
    return out


class ViewerWindow(QWidget):
    selectionChanged = Signal(object)      # group
    closed = Signal(object, int)           # group, copy index shown last

    def __init__(self, groups, group, index: int = 0, mode: str = "single", thumbs=None, images=None,
                 demo: bool = False, parent=None):
        super().__init__(parent, Qt.WindowType.Window)
        self.groups = [g for g in groups if g.copies] or [group]
        self.group = group if group in self.groups else self.groups[0]
        self.thumbs = thumbs
        self.images = images or FullImages(self, enabled=not demo)
        self.mode = mode if mode in MODES else "single"
        self.a = 0                              # index of side A / the single copy
        self.b = 1                              # index of side B
        self.sync = True
        self.flipped = False
        self.current = 0                        # pane with the keyboard focus
        self.panes: list[MediaPane] = []
        self.setWindowTitle(f"{tr('viewer')} – {tr('app_name')}")
        self.setWindowModality(Qt.WindowModality.ApplicationModal)
        self.resize(1400, 900)
        self.setObjectName("Viewer")
        self.setAttribute(Qt.WidgetAttribute.WA_StyledBackground)
        self.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose)

        lay = QVBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(0)
        bar = QWidget()
        bar.setObjectName("ViewerBar")
        bar.setAttribute(Qt.WidgetAttribute.WA_StyledBackground)
        bl = QHBoxLayout(bar)
        bl.setContentsMargins(16, 8, 14, 8)
        bl.setSpacing(8)
        self.title = QLabel("")
        self.title.setFont(fonts.heading(18))
        bl.addWidget(self.title, 1)
        self.counter = QLabel("")
        self.counter.setFont(fonts.body(12.5))
        self.counter.setProperty("role", "muted")
        for lab in (self.title, self.counter):        # shrink (cut off) before the window gets too wide
            lab.setSizePolicy(QSizePolicy.Policy.Ignored, QSizePolicy.Policy.Preferred)
            lab.setMinimumWidth(60)
        self.title.setMinimumWidth(90)
        bl.addWidget(self.counter, 1)
        self.modes = Segmented([("single", "viewer", "eye"), ("compare", "identification", "compare"),
                                ("grid", "grid_compare", "grid")])
        self.modes.selected.connect(self.set_mode)
        self.mode_btns = self.modes.buttons
        bl.addWidget(self.modes)
        bl.addSpacing(10)
        self.zoom_label = QLabel("")
        self.zoom_label.setObjectName("ZoomPill")
        self.zoom_label.setFont(fonts.body(12, QFont.Weight.Bold))
        self.zoom_label.setMinimumWidth(58)
        self.zoom_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.zoom_label.hide()
        bl.addWidget(self.zoom_label)
        # compact icon buttons (with tooltips) so the bar fits a 1366 px screen
        self.tools = []
        for key, icon, slot, keys in (("zoom_out", "zoom_out", lambda: self._zoom("step", -1), "−"),
                                      ("zoom_in", "zoom_in", lambda: self._zoom("step", 1), "+"),
                                      ("fit", "fit", lambda: self._zoom("fit"), "F"),
                                      ("actual_size", "actual", lambda: self._zoom("actual"), "1")):
            bl.addWidget(self._tool(key, icon, keys, slot))
        self.sync_btn = self._tool("sync_views", "link", "L", None, checkable=True)
        self.sync_btn.setChecked(True)
        self.sync_btn.toggled.connect(self._set_sync)
        self.sync_btn.toggled.connect(lambda _: self._restyle())
        bl.addWidget(self.sync_btn)
        self.flicker_btn = self._tool("flicker", "flicker", "Tab", self.flicker)
        bl.addWidget(self.flicker_btn)
        self.show_btn = self._tool("slideshow", "slideshow", "S", self.start_slideshow)
        bl.addWidget(self.show_btn)
        bl.addSpacing(8)
        close = Button("close", "cancel", variant="primary", size="small")
        close.clicked.connect(self.close)
        bl.addWidget(close)
        lay.addWidget(bar)

        self.table = QWidget()
        self.grid = QGridLayout(self.table)
        self.grid.setContentsMargins(12, 12, 12, 12)
        self.grid.setSpacing(10)
        lay.addWidget(self.table, 1)
        self.help = QLabel(tr("viewer_keys"))
        self.help.setObjectName("ViewerHelp")
        self.help.setFont(fonts.body(11.5))
        self.help.setContentsMargins(16, 6, 16, 7)
        self.help.setAttribute(Qt.WidgetAttribute.WA_StyledBackground)
        self.help.setWordWrap(True)
        lay.addWidget(self.help)

        self._shortcuts()
        theme().changed.connect(self._restyle)
        self._restyle()
        self.slideshow = None
        self._zoom_timer = QTimer(self, interval=150)
        self._zoom_timer.timeout.connect(self._update_zoom_label)
        self._zoom_timer.start()
        idx = max(0, min(index, len(self.group.copies) - 1))
        self.open_case(self.group, idx)
        self.set_mode(self.mode)

    def _tool(self, key, icon, keys, slot, checkable=False) -> QToolButton:
        t = tr(key)
        b = QToolButton()
        b.setIconSize(QSize(20, 20))
        b.setToolTip(f"{t}  ({keys})")
        b.setAccessibleName(t)
        b.setAutoRaise(True)
        b.setCheckable(checkable)
        b.setCursor(Qt.CursorShape.PointingHandCursor)
        b.setProperty("icon_name", icon)
        if slot is not None:
            b.clicked.connect(slot)
        self.tools.append(b)
        return b

    # ------------------------------------------------------------------ keyboard
    def _shortcuts(self):
        def sc(keys, fn):
            s = QShortcut(QKeySequence(keys), self)
            s.setContext(Qt.ShortcutContext.WindowShortcut)
            s.activated.connect(fn)
        sc("Right", lambda: self.move(+1))
        sc("Left", lambda: self.move(-1))
        sc("Shift+Right", lambda: self.move(+1, subject="a"))
        sc("Shift+Left", lambda: self.move(-1, subject="a"))
        sc("PgDown", lambda: self.next_case(+1))
        sc("PgUp", lambda: self.next_case(-1))
        sc("Home", lambda: self.jump(0))
        sc("End", lambda: self.jump(len(self.group.copies) - 1))
        sc("F", lambda: self._zoom("fit"))
        sc("1", lambda: self._zoom("actual"))
        sc("+", lambda: self._zoom("step", 1))
        sc("=", lambda: self._zoom("step", 1))
        sc("-", lambda: self._zoom("step", -1))
        sc("L", lambda: self.sync_btn.toggle())
        sc("Tab", self.flicker)
        sc("X", self.toggle_mark)
        sc("Space", self.toggle_play)
        sc("M", self.toggle_mute)
        sc("S", self.start_slideshow)
        sc("Ctrl+1", lambda: self.set_mode("single"))
        sc("Ctrl+2", lambda: self.set_mode("compare"))
        sc("Ctrl+3", lambda: self.set_mode("grid"))
        sc("Esc", self.close)

    # ------------------------------------------------------------------ modes & layout
    def set_mode(self, mode: str):
        if mode not in MODES:
            return
        if mode != "single" and len(self.group.copies) < 2:
            mode = "single"
        self.mode = mode
        self.modes.set_current(mode)
        self.sync_btn.setVisible(mode != "single")
        self.flicker_btn.setVisible(mode == "compare")
        self._layout()

    def _clear_panes(self):
        for p in self.panes:
            p.stop_video()
            p.setParent(None)
            p.deleteLater()
        self.panes = []

    def _make_pane(self, label_key=None) -> MediaPane:
        p = MediaPane(self.images, self.thumbs, label_key)
        p.selectionToggled.connect(lambda g, _c: self.selectionChanged.emit(g))
        p.activated.connect(self._activate)
        p.canvas.viewChanged.connect(lambda v, src=p: self._sync_from(src, v))
        return p

    def _layout(self):
        self._clear_panes()
        g = self.group
        n = len(g.copies)
        if self.mode == "single":
            indexes, labels = [self.a], [None]
        elif self.mode == "compare":
            if self.b == self.a:
                self.b = (self.a + 1) % n
            indexes, labels = [self.a, self.b], ["subject_a", "subject_b"]
        else:
            indexes, labels = list(range(min(n, MAX_GRID))), [None] * min(n, MAX_GRID)
        cols = len(indexes) if len(indexes) <= 3 else math.ceil(math.sqrt(len(indexes)))
        rows = math.ceil(len(indexes) / cols)
        for r in range(self.grid.rowCount()):        # forget the previous mode's rows/columns
            self.grid.setRowStretch(r, 1 if r < rows else 0)
        for c in range(self.grid.columnCount()):
            self.grid.setColumnStretch(c, 1 if c < cols else 0)
        for k, (i, lab) in enumerate(zip(indexes, labels)):
            p = self._make_pane(lab)
            self.grid.addWidget(p, k // cols, k % cols)
            p.show_copy(g, g.copies[i])
            if self.mode != "single" and k > 0:
                p.set_muted(True)              # one soundtrack at a time
            self.panes.append(p)
        for r in range(rows):
            self.grid.setRowStretch(r, 1)
        for c in range(cols):
            self.grid.setColumnStretch(c, 1)
        self.current = 0
        self._refresh_facts()
        self._refresh_title()
        self._prefetch()
        if self.panes:
            self.panes[0].canvas.setFocus()

    def _refresh_facts(self):
        shown = [p.copy for p in self.panes if p.copy is not None]
        # in single view, compare with the case's other copies
        diff = differing_facts(shown if len(shown) > 1 else self.group.copies)
        for p in self.panes:
            p.render_facts(diff)

    def _refresh_title(self):
        g = self.group
        self.title.setText(tr("case_no", n=g.number))      # the mode shows on its checked button
        pos = self.groups.index(g) + 1 if g in self.groups else 1
        self.counter.setText(f"{tr('copy_n', i=self.a + 1, n=len(g.copies))}  ·  "
                             f"{tr('case_n_of', i=pos, n=len(self.groups))}")

    def _prefetch(self):
        g = self.group
        for d in (1, -1, 2):
            self.images.request(g.copies[(self.a + d) % len(g.copies)])

    # ------------------------------------------------------------------ navigation
    def open_case(self, group, index=0):
        self.group = group
        self.a = index
        self.b = (index + 1) % len(group.copies) if len(group.copies) > 1 else index
        self.flipped = False

    def move(self, step: int, subject: str = "b"):
        n = len(self.group.copies)
        if n < 1:
            return
        if self.mode == "compare" and n > 1:
            if subject == "a":
                self.a = (self.a + step) % n
                if self.a == self.b:
                    self.a = (self.a + step) % n
                self._swap_into(0, self.a)
            else:
                self.b = (self.b + step) % n
                if self.b == self.a:
                    self.b = (self.b + step) % n
                self._swap_into(1, self.b)
            self._refresh_facts()
        elif self.mode == "single":
            self.a = (self.a + step) % n
            self._swap_into(0, self.a)
            self._refresh_facts()
            self._prefetch()
        else:
            self.current = (self.current + step) % len(self.panes)
            self.panes[self.current].canvas.setFocus()
        self._refresh_title()

    def _swap_into(self, pane_index: int, copy_index: int):
        p = self.panes[pane_index]
        keep = self.sync and self.mode != "single"
        p.show_copy(self.group, self.group.copies[copy_index], keep_view=keep)
        if keep and len(self.panes) > 1:
            other = self.panes[1 - pane_index] if self.mode == "compare" else self.panes[0]
            if other is not p and other.canvas.logical[0] and p.canvas.logical[0]:
                p.canvas.set_view(zoom.transfer(other.canvas.view, other.canvas.dims, p.canvas.dims))

    def jump(self, index: int):
        self.a = max(0, min(index, len(self.group.copies) - 1))
        if self.mode == "compare" and self.b == self.a:
            self.b = (self.a + 1) % len(self.group.copies)
        self._layout()

    def next_case(self, step: int):
        if self.group not in self.groups:
            return
        i = (self.groups.index(self.group) + step) % len(self.groups)
        keep = next((k for k, c in enumerate(self.groups[i].copies) if c.keep), 0)
        self.open_case(self.groups[i], keep)
        self.set_mode(self.mode if len(self.group.copies) > 1 or self.mode == "single" else "single")

    def _activate(self, pane):
        if pane in self.panes:
            self.current = self.panes.index(pane)

    # ------------------------------------------------------------------ zoom & sync
    def _zoom(self, what, arg=None):
        targets = self.panes if self.sync else [self.panes[self.current]] if self.panes else []
        lead = targets[0] if targets else None
        if lead is None:
            return
        cv = self.panes[self.current].canvas if self.panes else lead.canvas
        if what == "fit":
            cv.fit()
        elif what == "actual":
            cv.actual()
        else:
            cv.zoom_step(arg)

    def _set_sync(self, on):
        self.sync = on
        if on and self.panes:
            src = self.panes[self.current].canvas
            self._sync_from(self.panes[self.current], src.view)

    def _sync_from(self, src_pane, v):
        if not self.sync or self.mode == "single":
            return
        for p in self.panes:
            if p is src_pane or not p.canvas.logical[0] or not src_pane.canvas.logical[0]:
                continue
            p.canvas.set_view(zoom.transfer(v, src_pane.canvas.dims, p.canvas.dims))

    def _update_zoom_label(self):
        if self.panes:
            cv = self.panes[min(self.current, len(self.panes) - 1)].canvas
            pct = cv.percent()
            self.zoom_label.setText(f"{pct} %" if pct else "")
            self.zoom_label.setVisible(bool(pct))

    def flicker(self):
        """Swap A and B in place - differences jump out when the picture 'blinks'."""
        if self.mode != "compare" or len(self.panes) < 2:
            return
        self.a, self.b = self.b, self.a
        self.flipped = not self.flipped
        for k, i in ((0, self.a), (1, self.b)):
            self.panes[k].show_copy(self.group, self.group.copies[i], keep_view=True)
        self._refresh_facts()
        self._refresh_title()

    # ------------------------------------------------------------------ marks & video
    def toggle_mark(self):
        if self.panes:
            self.panes[self.current].toggle_mark()

    def toggle_play(self):
        vids = [p for p in self.panes if p.video is not None]
        if not vids:
            return
        play = not any(p.video.playing for p in vids)
        for p in vids:                          # compare: both videos run together
            p.set_playing(play)

    def toggle_mute(self):
        if self.panes:
            p = self.panes[self.current]
            p.set_muted(not p.muted)

    # ------------------------------------------------------------------ slideshow
    def start_slideshow(self):
        from .slideshow import Slideshow
        items = [(g, c) for g in self.groups for c in g.copies]
        start = next((k for k, (g, c) in enumerate(items) if g is self.group and c is self.group.copies[self.a]), 0)
        for p in self.panes:
            p.set_playing(False)
        self.slideshow = Slideshow(items, start, self.images, self.thumbs, parent=self)
        self.slideshow.finished.connect(self._slideshow_done)
        self.slideshow.start()

    def _slideshow_done(self, g, c):
        self.slideshow = None
        if g in self.groups and c in g.copies:
            self.open_case(g, g.copies.index(c))
            self.set_mode("single")

    # ------------------------------------------------------------------ closing & look
    def closeEvent(self, e):
        if self.slideshow is not None:
            self.slideshow.close()
        self._zoom_timer.stop()
        self._clear_panes()
        self.closed.emit(self.group, self.a)
        super().closeEvent(e)

    def _restyle(self):
        # the chrome follows the theme; only the light table under the photos stays neutral grey
        c = theme().colors
        for b in getattr(self, "tools", []):
            b.setIcon(art.icon(b.property("icon_name"), c.accent_text if b.isChecked() else c.text))
        self.setStyleSheet(
            f"#Viewer {{ background: {c.bg}; }}"
            f"#ViewerBar {{ background: {c.surface}; border-bottom: 1px solid {c.line}; }}"
            f"#ViewerHelp {{ background: {c.surface}; color: {c.text_muted}; border-top: 1px solid {c.line}; }}"
            f"#ViewerBar QLabel {{ color: {c.text}; background: transparent; }}"
            f'#ViewerBar QLabel[role="muted"] {{ color: {c.text_muted}; }}'
            f"#ViewerBar QLabel#ZoomPill {{ background: {c.accent_soft}; color: {c.accent_text}; border-radius: 12px;"
            f" padding: 4px 10px; }}"
            f"#ViewerBar QToolButton {{ border: 1px solid transparent; border-radius: 9px; padding: 5px; }}"
            f"#ViewerBar QToolButton:hover {{ background: {c.surface_alt}; }}"
            f"#ViewerBar QToolButton:checked {{ background: {c.accent_soft}; border-color: {c.accent}; }}")
