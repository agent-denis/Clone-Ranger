"""Slideshow: full screen, every copy of the visible case files in turn.

Space pause/resume · ← / → previous / next · + / − slower / faster · X select for removal · Esc stop.
Photos stay `interval` seconds; videos play to the end (at most 30 s). A short fade between
slides, none with "reduce motion".
"""
from __future__ import annotations

from PySide6.QtCore import QEasingCurve, QPropertyAnimation, Qt, QTimer, Signal
from PySide6.QtGui import QFont, QKeySequence, QShortcut
from PySide6.QtWidgets import QGraphicsOpacityEffect, QLabel, QVBoxLayout, QWidget

from ...theme import fonts
from ...theme.strings import tr
from ...theme.style import theme
from .canvas import ImageCanvas
from .images import key_for
from .media import MULTIMEDIA

INTERVALS = (2, 3, 4, 6, 8, 12, 20)
MAX_VIDEO_MS = 30_000


class Slideshow(QWidget):
    finished = Signal(object, object)      # group, copy shown last

    def __init__(self, items, start, images, thumbs, interval: int = 4, fullscreen: bool = True, parent=None):
        super().__init__(parent, Qt.WindowType.Window)
        self.items, self.pos = items, max(0, min(start, len(items) - 1))
        self.images, self.thumbs = images, thumbs
        self.interval = interval if interval in INTERVALS else 4
        self.paused = False
        self.fullscreen = fullscreen
        self.video = None
        self.setWindowTitle(tr("slideshow"))
        self.setStyleSheet("background: #000000;")
        self.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose)
        lay = QVBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        self.canvas = ImageCanvas()
        lay.addWidget(self.canvas)
        self.caption = QLabel(self)
        self.caption.setFont(fonts.body(14, QFont.Weight.Medium))
        self.caption.setStyleSheet("background: rgba(15,13,26,200); color: #F3F0FF; padding: 10px 16px;"
                                   "border-radius: 14px;")
        self.caption.setTextFormat(Qt.TextFormat.RichText)
        self.caption.setWordWrap(False)
        self.timer = QTimer(self, singleShot=True)
        self.timer.timeout.connect(lambda: self.step(+1))
        self.effect = QGraphicsOpacityEffect(self.canvas)
        self.effect.setOpacity(1.0)
        self.canvas.setGraphicsEffect(self.effect)
        self.fade = QPropertyAnimation(self.effect, b"opacity", self)
        self.fade.setDuration(300)
        self.fade.setEasingCurve(QEasingCurve.Type.OutCubic)
        images.ready.connect(self._ready)
        thumbs.ready.connect(lambda _k: self._ready(None))
        for keys, fn in (("Space", self.toggle_pause), ("Right", lambda: self.step(+1)),
                         ("Left", lambda: self.step(-1)), ("+", lambda: self.change_interval(+1)),
                         ("=", lambda: self.change_interval(+1)), ("-", lambda: self.change_interval(-1)),
                         ("X", self.toggle_mark), ("Esc", self.close)):
            s = QShortcut(QKeySequence(keys), self)
            s.activated.connect(fn)

    # ------------------------------------------------------------------ running
    def start(self):
        if self.fullscreen:
            self.showFullScreen()
        else:
            self.show()
        self.show_item()

    @property
    def item(self):
        return self.items[self.pos]

    def show_item(self):
        self.timer.stop()
        self._stop_video()
        g, c = self.item
        self.canvas.clear()
        thumb = self.thumbs.image(c)
        logical = (c.width, c.height) if c.width and c.height else None
        if thumb is not None:
            self.canvas.set_image(thumb, logical or (thumb.width(), thumb.height()))
        if c.kind == "image":
            img, info = self.images.get(c)
            if img is not None:
                self.canvas.set_image(img, (info.full_width, info.full_height) if info else None)
            nxt = self.items[(self.pos + 1) % len(self.items)][1]
            self.images.request(nxt)
            self._arm(self.interval * 1000)
        elif MULTIMEDIA:
            from .media import VideoController
            self.video = VideoController(self.canvas, c.path, self)
            self.video.player.durationChanged.connect(lambda d: self._arm(min(MAX_VIDEO_MS, d or 0) or
                                                                          self.interval * 1000))
            self.video.failed.connect(lambda _m: self._arm(self.interval * 1000))
            if not self.paused:
                self.video.player.play()
        else:
            self._arm(self.interval * 1000)
        self._caption()
        if not theme().reduce_motion:
            self.fade.stop()
            self.fade.setStartValue(0.25)
            self.fade.setEndValue(1.0)
            self.fade.start()

    def _arm(self, ms):
        if not self.paused and ms > 0:
            self.timer.start(ms)

    def _ready(self, key):
        g, c = self.item
        if c.kind != "image":
            return
        if key is None:
            if self.canvas.image is None:
                t = self.thumbs.image(c)
                if t is not None:
                    self.canvas.set_image(t, (c.width, c.height) if c.width else None)
            return
        if key == key_for(c):
            img, info = self.images.get(c)
            if img is not None:
                self.canvas.set_image(img, (info.full_width, info.full_height) if info else None)

    def step(self, d: int):
        self.pos = (self.pos + d) % len(self.items)
        self.show_item()

    def toggle_pause(self):
        self.paused = not self.paused
        if self.paused:
            self.timer.stop()
            if self.video:
                self.video.player.pause()
        else:
            if self.video:
                self.video.player.play()
                self._arm(max(1000, min(MAX_VIDEO_MS, (self.video.player.duration() or 0))
                              - self.video.player.position()))
            else:
                self._arm(self.interval * 1000)
        self._caption()

    def change_interval(self, d: int):
        i = INTERVALS.index(self.interval)
        self.interval = INTERVALS[max(0, min(len(INTERVALS) - 1, i + d))]
        if not self.paused and (self.video is None):
            self._arm(self.interval * 1000)
        self._caption()

    def toggle_mark(self):
        g, c = self.item
        if c.selectable and g.is_duplicate:
            c.selected = not c.selected
            viewer = self.parent()
            if viewer is not None and hasattr(viewer, "selectionChanged"):
                viewer.selectionChanged.emit(g)
            self._caption()

    def _caption(self):
        g, c = self.item
        from html import escape
        if c.keep:
            status = f'<span style="background:#047857; color:#FFFFFF">&nbsp;{tr("keep_original").upper()}&nbsp;</span>'
        elif c.selected:
            status = f'<span style="background:#E11D48; color:#FFFFFF">&nbsp;{tr("duplicate").upper()}&nbsp;</span>'
        else:
            status = ""
        state = f"‖ {tr('pause')}" if self.paused else f"▶ {tr('every_s', s=self.interval)}"
        self.caption.setText(
            f'<b>{escape(tr("case_no", n=g.number))}</b> &nbsp; {escape(c.name)} &nbsp; {status}<br>'
            f'<span style="color:#ADA7C6">{escape(c.folder)} &nbsp;·&nbsp; {self.pos + 1}/{len(self.items)}'
            f' &nbsp;·&nbsp; {escape(state)}</span>')
        self.caption.setMaximumWidth(max(200, self.width() - 32))
        self.caption.adjustSize()
        self.caption.move(16, max(16, self.height() - self.caption.height() - 16))
        self.caption.raise_()

    def resizeEvent(self, e):
        super().resizeEvent(e)
        self._caption()

    def _stop_video(self):
        if self.video is not None:
            self.video.stop()
            self.video.deleteLater()
            self.video = None

    def closeEvent(self, e):
        self.timer.stop()
        self._stop_video()
        g, c = self.item
        self.finished.emit(g, c)
        super().closeEvent(e)
