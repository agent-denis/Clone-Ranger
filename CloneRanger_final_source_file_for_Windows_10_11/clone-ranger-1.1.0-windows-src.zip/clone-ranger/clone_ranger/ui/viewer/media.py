"""One copy on the light table: caption (A/B pill, name, status badge, select toggle), canvas, video controls,
and a facts line.

Videos play inside the viewer through QtMultimedia (PySide6-Addons, Qt's own FFmpeg).
Frames go through a QVideoSink into the same canvas as photos, so zoom/pan/compare work
for video too. Without PySide6-Addons, a video shows its poster frame and a note.
"""
from __future__ import annotations

from PySide6.QtCore import QObject, Qt, QUrl, Signal
from PySide6.QtGui import QFont
from PySide6.QtWidgets import QHBoxLayout, QLabel, QSlider, QToolButton, QVBoxLayout, QWidget

from ...theme import art, fonts
from ...theme.palettes import BUTTON_GRADIENT
from ...theme.strings import tr
from ...theme.style import theme
from ...util import hms, human
from .canvas import ImageCanvas
from .images import key_for
from ..widgets import Button

try:
    from PySide6.QtMultimedia import QAudioOutput, QMediaPlayer, QVideoSink
    MULTIMEDIA = True
except ImportError:  # pragma: no cover - PySide6-Addons not installed
    MULTIMEDIA = False

FACTS = ("f_resolution", "f_size", "f_taken", "f_created", "f_duration", "f_hash")


def fact_values(c) -> dict:
    return {"f_resolution": c.resolution, "f_size": human(c.size), "f_taken": c.taken, "f_created": c.created,
            "f_duration": c.duration if c.kind == "video" else "", "f_hash": (c.hash or "").split(":")[-1][:12]}


class VideoController(QObject):
    """Plays one video into a canvas."""
    stateChanged = Signal()
    positionChanged = Signal(int)
    frameShown = Signal()
    failed = Signal(str)

    def __init__(self, canvas: ImageCanvas, path: str, parent=None):
        super().__init__(parent)
        self.canvas, self.path = canvas, path
        self.fps = 30.0
        self.player = QMediaPlayer(self)
        self.audio = QAudioOutput(self)
        self.player.setAudioOutput(self.audio)
        self.sink = QVideoSink(self)
        self.player.setVideoOutput(self.sink)
        self.sink.videoFrameChanged.connect(self._frame)
        self.player.playbackStateChanged.connect(lambda _s: self.stateChanged.emit())
        self.player.positionChanged.connect(self.positionChanged.emit)
        self.player.errorOccurred.connect(lambda _e, msg: self.failed.emit(msg or "cannot play this video"))
        self.player.metaDataChanged.connect(self._meta)
        self.player.setSource(QUrl.fromLocalFile(path))

    def _meta(self):
        try:
            from PySide6.QtMultimedia import QMediaMetaData
            fr = self.player.metaData().value(QMediaMetaData.Key.VideoFrameRate)
            if fr:
                self.fps = float(fr)
        except Exception:  # noqa: BLE001
            pass

    def _frame(self, frame):
        if frame.isValid():
            img = frame.toImage()
            if not img.isNull():
                self.canvas.set_image(img, (img.width(), img.height()), keep_view=True)
                self.frameShown.emit()

    @property
    def playing(self) -> bool:
        return self.player.playbackState() == QMediaPlayer.PlaybackState.PlayingState

    def toggle(self):
        if self.playing:
            self.player.pause()
        else:
            if self.player.duration() and self.player.position() >= self.player.duration() - 50:
                self.player.setPosition(0)
            self.player.play()

    def step(self, frames: int):
        self.player.pause()
        ms = int(round(1000 * frames / max(1.0, self.fps)))
        self.player.setPosition(max(0, min(self.player.duration() or 0, self.player.position() + ms)))

    def seek(self, ms: int):
        self.player.setPosition(ms)

    def set_muted(self, muted: bool):
        self.audio.setMuted(muted)

    def stop(self):
        self.player.stop()
        self.player.setSource(QUrl())


def _tool(icon: str, tip_key: str, slot, checkable=False) -> QToolButton:
    b = QToolButton()
    b.setIcon(art.icon(icon, theme().colors.text))
    b.setToolTip(tr(tip_key))
    b.setAccessibleName(tr(tip_key))
    b.setAutoRaise(True)
    b.setCheckable(checkable)
    b.clicked.connect(slot)
    return b


class MediaPane(QWidget):
    """Caption + canvas (+ video controls) + facts for one copy."""
    selectionToggled = Signal(object, object)     # group, copy
    activated = Signal(object)                    # self (clicked: becomes the current pane)

    def __init__(self, images, thumbs, label_key: str | None = None, parent=None):
        super().__init__(parent)
        self.images, self.thumbs, self.label_key = images, thumbs, label_key
        self.group = self.copy = None
        self.icon_color = theme().colors.text
        self.has_full = False
        self.video: VideoController | None = None
        self.muted = False
        self.setObjectName("Pane")
        self.setAttribute(Qt.WidgetAttribute.WA_StyledBackground)
        lay = QVBoxLayout(self)
        lay.setContentsMargins(1, 1, 1, 1)
        lay.setSpacing(0)

        cap = QWidget()
        cap.setObjectName("Caption")
        cap.setAttribute(Qt.WidgetAttribute.WA_StyledBackground)
        cl = QHBoxLayout(cap)
        cl.setContentsMargins(12, 8, 10, 8)
        cl.setSpacing(10)
        self.subject = QLabel("")
        self.subject.setFont(fonts.heading(15, QFont.Weight.ExtraBold))
        self.subject.setObjectName("SubjectPill")
        self.subject.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.subject.setFixedSize(30, 30)
        cl.addWidget(self.subject)
        names = QVBoxLayout()
        names.setSpacing(0)
        self.name = QLabel("")
        self.name.setFont(fonts.body(14, QFont.Weight.DemiBold))
        self.folder = QLabel("")
        self.folder.setFont(fonts.mono(11.5))
        self.folder.setProperty("role", "muted")
        for w in (self.name, self.folder):
            w.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
            w.setMinimumWidth(40)
            names.addWidget(w)
        cl.addLayout(names, 1)
        self.stamp = QLabel("")                   # status badge: KEEP / HARD LINK / PROTECTED
        self.stamp.setFont(fonts.label(10.5))
        self.stamp.setObjectName("StatusPill")
        cl.addWidget(self.stamp)
        self.mark = Button("mark_dup", "select", size="small", checkable=True)
        self.mark.setToolTip(tr("mark_dup") + "  (X)")
        self.mark.toggled.connect(self._mark)
        cl.addWidget(self.mark)
        lay.addWidget(cap)

        self.canvas = ImageCanvas()
        self.canvas.clicked.connect(lambda: self.activated.emit(self))
        lay.addWidget(self.canvas, 1)

        self.controls = QWidget()
        self.controls.setObjectName("Caption")
        self.controls.setAttribute(Qt.WidgetAttribute.WA_StyledBackground)
        vl = QHBoxLayout(self.controls)
        vl.setContentsMargins(8, 4, 10, 4)
        self.play_btn = _tool("play", "play", self.toggle_play)
        self.back_btn = _tool("step_back", "frame_back", lambda: self.video and self.video.step(-1))
        self.fwd_btn = _tool("step_fwd", "frame_fwd", lambda: self.video and self.video.step(1))
        self.mute_btn = _tool("volume", "mute", self._toggle_mute)
        self.slider = QSlider(Qt.Orientation.Horizontal)
        self.slider.setAccessibleName(tr("position"))
        self.slider.sliderMoved.connect(lambda ms: self.video and self.video.seek(ms))
        self.time = QLabel("00:00:00 / 00:00:00")
        self.time.setFont(fonts.mono(11))
        for w in (self.back_btn, self.play_btn, self.fwd_btn):
            vl.addWidget(w)
        vl.addWidget(self.slider, 1)
        vl.addWidget(self.time)
        vl.addWidget(self.mute_btn)
        self.controls.hide()
        lay.addWidget(self.controls)

        self.facts = QLabel("")
        self.facts.setObjectName("Facts")
        self.facts.setFont(fonts.body(12))
        self.facts.setTextFormat(Qt.TextFormat.RichText)
        self.facts.setContentsMargins(12, 6, 12, 8)
        self.facts.setWordWrap(True)
        self.facts.setAttribute(Qt.WidgetAttribute.WA_StyledBackground)
        lay.addWidget(self.facts)
        self.differs: set[str] = set()
        images.ready.connect(self._image_ready)
        thumbs.ready.connect(lambda _k: self._thumb_ready())
        theme().changed.connect(self._restyle)
        self._restyle()

    # ------------------------------------------------------------------ content
    def show_copy(self, group, copy, keep_view: bool = False):
        self.stop_video()
        self.group, self.copy = group, copy
        if self.label_key:
            self.subject.setText(tr(self.label_key))
        self.subject.setVisible(bool(self.label_key))
        self.name.setText(copy.name)
        self.name.setToolTip(copy.path)
        self.folder.setText(copy.folder)
        self.folder.setToolTip(copy.path)
        if copy.keep:
            self._set_status(tr("keep_original"), "keep")
        elif copy.hard_link:
            self._set_status(tr("hard_link_short"), "link")
        elif copy.protected:
            self._set_status(tr("protected"), "protected")
        else:
            self._set_status("", "")
        self.mark.blockSignals(True)
        self.mark.setChecked(copy.selected)
        self.mark.setEnabled(copy.selectable and group.is_duplicate)
        self.mark.blockSignals(False)
        self._mark_look()
        view = self.canvas.view
        self.has_full = False
        self.canvas.clear()
        self._thumb_ready()
        if copy.kind == "image":
            img, info = self.images.get(copy)
            if img is not None:
                self._set_full(img, info)
            elif info is not None and info.error:
                self._no_full(info.error)
        else:
            self._start_video()
        if keep_view:
            self.canvas.set_view(view)
        self.controls.setVisible(copy.kind == "video")
        self.render_facts()

    def _thumb_ready(self):
        """Show the thumbnail until the full image (or the first video frame) is there."""
        c = self.copy
        if c is None or self.has_full:
            return
        thumb = self.thumbs.image(c)
        if thumb is not None:
            logical = (c.width, c.height) if c.width and c.height else (thumb.width(), thumb.height())
            badge = tr("thumbnail") if c.kind == "image" else ""
            self.canvas.set_image(thumb, logical, keep_view=True, badge=badge)
        elif self.canvas.image is None:
            err = self.thumbs.error(c)
            self.canvas.set_message(err or f"{tr('loading_full')}…")

    def _image_ready(self, key):
        c = self.copy
        if c is None or c.kind != "image" or key != key_for(c):
            return
        img, info = self.images.get(c)
        if img is not None:
            self._set_full(img, info)
        elif info is not None:
            self._no_full(info.error)

    def _set_full(self, img, info):
        logical = (info.full_width, info.full_height) if info and info.full_width else (img.width(), img.height())
        badge = ""
        if info is not None and info.preview_only:
            badge = tr("preview_only")
        elif info is not None and info.reduced:
            badge = tr("shown_reduced", w=img.width(), h=img.height())
        self.has_full = True
        self.canvas.set_image(img, logical, keep_view=True, badge=badge)

    def _no_full(self, error):
        if self.canvas.image is None:
            self.canvas.set_message(error)
        else:
            self.canvas.badge = f"{tr('thumbnail')} – {error}"
            self.canvas.update()

    def render_facts(self, differs: set | None = None):
        if differs is not None:
            self.differs = differs
        c = self.copy
        if c is None:
            self.facts.setText("")
            return
        col = theme().colors
        warn = col.danger_text
        parts = []
        for k, v in fact_values(c).items():
            if not v:
                continue
            if k in self.differs:
                parts.append(f'<span style="color:{warn}; font-weight:700">▲ {tr(k)}: {v}</span>')
            else:
                parts.append(f'<span style="color:{col.text_muted}">{tr(k)}:</span> {v}')
        self.facts.setText(" &nbsp;&nbsp;·&nbsp;&nbsp; ".join(parts))

    # ------------------------------------------------------------------ selection
    def _mark(self, on):
        c = self.copy
        if c is None or not c.selectable:
            return
        c.selected = on
        self._mark_look()
        self.selectionToggled.emit(self.group, c)

    def toggle_mark(self):
        if self.mark.isEnabled():
            self.mark.setChecked(not self.mark.isChecked())

    # ------------------------------------------------------------------ video
    def _start_video(self):
        if not MULTIMEDIA:
            self.canvas.badge = tr("no_multimedia")
            return
        self.video = VideoController(self.canvas, self.copy.path, self)
        self.video.set_muted(self.muted)
        self.video.stateChanged.connect(self._video_state)
        self.video.positionChanged.connect(self._video_pos)
        self.video.failed.connect(self._video_failed)
        self.video.frameShown.connect(self._first_frame)
        self.video.player.durationChanged.connect(lambda d: self.slider.setRange(0, d))
        # show the first frame without starting playback
        self.video.player.pause()

    def _first_frame(self):
        self.has_full = True

    def _video_state(self):
        if self.video:
            self.play_btn.setIcon(art.icon("pause" if self.video.playing else "play", self.icon_color))

    def _video_pos(self, ms):
        if self.video:
            if not self.slider.isSliderDown():
                self.slider.setValue(ms)
            self.time.setText(f"{hms(ms / 1000)} / {hms((self.video.player.duration() or 0) / 1000)}")

    def _video_failed(self, msg):
        self.canvas.badge = tr("video_error", e=msg)
        self.canvas.update()

    def toggle_play(self):
        if self.video:
            self.video.toggle()

    def set_playing(self, on: bool):
        if self.video and self.video.playing != on:
            self.video.toggle()

    def set_muted(self, muted: bool):
        self.muted = muted
        self.mute_btn.setIcon(art.icon("mute" if muted else "volume", self.icon_color))
        if self.video:
            self.video.set_muted(muted)

    def _toggle_mute(self):
        self.set_muted(not self.muted)

    def stop_video(self):
        if self.video is not None:
            self.video.stop()
            self.video.deleteLater()
            self.video = None

    # ------------------------------------------------------------------ look
    def _set_status(self, text: str, kind: str):
        self.stamp.setText(text)
        self.stamp.setProperty("kind", kind)
        self.stamp.setVisible(bool(text))
        self.stamp.style().unpolish(self.stamp)
        self.stamp.style().polish(self.stamp)

    def _mark_look(self):
        on = self.mark.isChecked()
        self.mark.set_text("Selected for removal" if on else "mark_dup")
        self.mark.variant = "danger" if on else None
        self.mark.setProperty("variant", self.mark.variant)
        self.mark.style().unpolish(self.mark)
        self.mark.style().polish(self.mark)
        self.mark.set_icon("check" if on else "select")

    def _restyle(self):
        c = theme().colors
        plain = theme().plain
        ink, muted = c.text, c.text_muted
        self.icon_color = ink
        for b, name in ((self.back_btn, "step_back"), (self.fwd_btn, "step_fwd")):
            b.setIcon(art.icon(name, ink))
        self._video_state()
        self.set_muted(self.muted)
        a, b = BUTTON_GRADIENT
        pill = c.accent if plain else f"qlineargradient(x1:0, y1:0, x2:1, y2:1, stop:0 {a}, stop:1 {b})"
        self.setStyleSheet(
            f"#Pane {{ background: {c.surface}; border: 1px solid {c.line}; border-radius: 12px; }}"
            f"#Caption {{ background: transparent; border-bottom: 1px solid {c.line}; }}"
            f"#Facts {{ background: transparent; border-top: 1px solid {c.line}; }}"
            f"#Caption QLabel, #Facts {{ color: {ink}; background: transparent; }}"
            f'#Caption QLabel[role="muted"] {{ color: {muted}; }}'
            f"#Caption QLabel#SubjectPill {{ background: {pill}; color: {c.on_accent if plain else c.on_brand}; border-radius: 15px; }}"
            f"#Caption QLabel#StatusPill {{ border-radius: 11px; padding: 3px 10px; }}"
            f'#Caption QLabel#StatusPill[kind="keep"] {{ background: {c.success}; color: {c.on_success}; }}'
            f'#Caption QLabel#StatusPill[kind="link"] {{ background: {c.info}; color: {c.on_info}; }}'
            f'#Caption QLabel#StatusPill[kind="protected"] {{ background: {c.accent_soft}; color: {c.accent_text}; }}'
            f"QToolButton {{ border: none; border-radius: 8px; padding: 4px; }}"
            f"QToolButton:hover {{ background: {c.surface_alt}; }}")
        self.render_facts()
