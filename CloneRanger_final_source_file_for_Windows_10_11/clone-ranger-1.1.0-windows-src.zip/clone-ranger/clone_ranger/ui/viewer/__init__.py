"""The viewer: single view, compare (A / B), grid compare, slideshow, video."""
