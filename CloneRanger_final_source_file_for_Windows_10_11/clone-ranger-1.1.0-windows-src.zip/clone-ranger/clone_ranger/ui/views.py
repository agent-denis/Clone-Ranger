"""The two alternative result views: a list (table) and a thumbnail grid.

Both list every copy of every visible group and share the selection state
with the group cards (UiCopy.selected).
"""
from __future__ import annotations

from PySide6.QtCore import (QAbstractListModel, QAbstractTableModel, QEvent, QModelIndex, QRectF, QSize,
                            Qt, Signal)
from PySide6.QtGui import QColor, QFont, QFontMetricsF, QPainter, QPen
from PySide6.QtWidgets import QAbstractItemView, QHeaderView, QListView, QStyle, QStyledItemDelegate, QTableView

from ..theme import art, fonts
from ..theme.strings import tr
from ..theme.style import CHECK, theme
from ..util import human
from .case_cards import copy_menu, crop_to, paint_badges, paint_play_glyph, paint_placeholder

SortRole = Qt.ItemDataRole.UserRole + 10
CopyRole = Qt.ItemDataRole.UserRole + 11


def flatten(groups):
    return [(g, c) for g in groups for c in g.copies]


def status_text(g, c) -> str:
    if c.keep:
        return tr("keep_original")
    if c.hard_link:
        return tr("hard_link_short")
    if c.selected:
        return tr("duplicate")
    if c.protected:
        return tr("protected")
    return ""


# --------------------------------------------------------------------------- ledger
# (display text, sort key) per column - computed only for the column that's asked for
_CELLS = {
    "case_col": lambda g, c: (f"{g.number:04d}", g.number),
    "status": lambda g, c: (status_text(g, c), (not c.keep, not c.selected)),
    "f_name": lambda g, c: (c.name, c.name.casefold()),
    "folder": lambda g, c: (c.folder, c.folder.casefold()),
    "f_size": lambda g, c: (human(c.size), c.size),
    "f_created": lambda g, c: (c.created, c.birth_ns or c.mtime_ns),
    "f_taken": lambda g, c: (c.taken, c.taken),
    "f_resolution": lambda g, c: (c.resolution, (c.width or 0) * (c.height or 0)),
    "f_duration": lambda g, c: (c.duration, c.duration_s or 0),
    "f_hash": lambda g, c: ((c.hash or "").split(":")[-1][:16], c.hash or ""),
}


class LedgerModel(QAbstractTableModel):
    """Every copy of every visible case file, one row each. Sorting happens here, in one Python sort
    (no QSortFilterProxyModel: with ~100 000 rows its per-comparison callbacks took seconds, and it
    re-sorted on every value change)."""
    selectionToggled = Signal(object)   # group
    COLS = ["", "case_col", "status", "f_name", "folder", "f_size", "f_created", "f_taken", "f_resolution",
            "f_duration", "f_hash"]

    def __init__(self, parent=None):
        super().__init__(parent)
        self.rows = []
        self.sort_column, self.sort_order = 1, Qt.SortOrder.AscendingOrder

    def set_groups(self, groups):
        self.beginResetModel()
        self.rows = flatten(groups)
        self._sort_rows()
        self.endResetModel()

    def _sort_rows(self):
        col = self.COLS[self.sort_column] if 0 <= self.sort_column < len(self.COLS) else ""
        cell = _CELLS.get(col)
        if cell is None:
            return
        # stable: ties keep the case-file order; None-safe keys
        self.rows.sort(key=lambda gc: cell(*gc)[1], reverse=self.sort_order == Qt.SortOrder.DescendingOrder)

    def sort(self, column, order=Qt.SortOrder.AscendingOrder):
        self.sort_column, self.sort_order = column, order
        self.layoutAboutToBeChanged.emit()
        self._sort_rows()
        self.layoutChanged.emit()

    def rowCount(self, parent=QModelIndex()):
        return 0 if parent.isValid() else len(self.rows)

    def columnCount(self, parent=QModelIndex()):
        return len(self.COLS)

    def headerData(self, section, orientation, role=Qt.ItemDataRole.DisplayRole):
        if orientation == Qt.Orientation.Horizontal and self.COLS[section]:
            if role in (Qt.ItemDataRole.DisplayRole, Qt.ItemDataRole.ToolTipRole):
                return tr(self.COLS[section])
        return None

    def flags(self, index):
        f = Qt.ItemFlag.ItemIsEnabled | Qt.ItemFlag.ItemIsSelectable
        if index.column() == 0:
            g, c = self.rows[index.row()]
            if c.selectable and g.is_duplicate:
                f |= Qt.ItemFlag.ItemIsUserCheckable
        return f

    def data(self, index, role=Qt.ItemDataRole.DisplayRole):
        if not index.isValid():
            return None
        g, c = self.rows[index.row()]
        col = self.COLS[index.column()]
        if role == CopyRole:
            return g, c
        if role == Qt.ItemDataRole.CheckStateRole and index.column() == 0:
            return Qt.CheckState.Checked if c.selected else Qt.CheckState.Unchecked
        if role == Qt.ItemDataRole.DisplayRole:
            cell = _CELLS.get(col)
            return cell(g, c)[0] if cell else None
        if role == SortRole:
            cell = _CELLS.get(col)
            return cell(g, c)[1] if cell else None
        if role == Qt.ItemDataRole.ToolTipRole and col in ("folder", "f_name"):
            return c.path
        if role == Qt.ItemDataRole.ForegroundRole and col == "status":
            t = theme().colors
            if c.keep:
                return QColor(t.success_text)
            if c.selected:
                return QColor(t.danger_text)
            if c.hard_link or c.protected:
                return QColor(t.text_muted)
        if role == Qt.ItemDataRole.FontRole and col == "status":
            return fonts.body(12.5, QFont.Weight.Bold)
        if role == Qt.ItemDataRole.FontRole and col in ("f_hash", "case_col"):
            return fonts.mono(12.5)
        return None

    def setData(self, index, value, role=Qt.ItemDataRole.EditRole):
        if role == Qt.ItemDataRole.CheckStateRole and index.column() == 0:
            g, c = self.rows[index.row()]
            if not c.selectable:
                return False
            c.selected = Qt.CheckState(value) == Qt.CheckState.Checked
            self.dataChanged.emit(index, index.siblingAtColumn(2))
            self.selectionToggled.emit(g)
            return True
        return False

    def refresh(self):
        """Values changed (selection, metadata): repaint. Cheap - the view only re-reads visible rows.
        The row ORDER is kept as is, so rows don't jump around while you look at them."""
        if self.rows:
            self.dataChanged.emit(self.index(0, 0), self.index(len(self.rows) - 1, len(self.COLS) - 1))


class LedgerView(QTableView):
    copyActivated = Signal(object, object)   # group, copy
    openRequested = Signal(object, object)   # Enter / double-click -> viewer

    def __init__(self, model: LedgerModel, parent=None):
        super().__init__(parent)
        self.setObjectName("Ledger")
        self.source = model
        self.setModel(model)
        self.setSortingEnabled(True)          # header clicks call model.sort()
        self.sortByColumn(1, Qt.SortOrder.AscendingOrder)
        self.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
        self.setWordWrap(False)
        self.setShowGrid(False)
        self.setAlternatingRowColors(True)
        self.verticalHeader().hide()
        self.verticalHeader().setDefaultSectionSize(34)
        h = self.horizontalHeader()
        h.setSectionResizeMode(QHeaderView.ResizeMode.Interactive)
        h.setStretchLastSection(True)
        h.setHighlightSections(False)
        for col, w in enumerate((38, 70, 110, 240, 240, 90, 140, 150, 110, 80)):
            self.setColumnWidth(col, w)
        self.setFont(fonts.body(13))
        self.setContextMenuPolicy(Qt.ContextMenuPolicy.DefaultContextMenu)
        self.selectionModel().currentRowChanged.connect(self._current)
        theme().changed.connect(self._restyle)
        self._restyle()

    def _current(self, cur, _prev):
        if cur.isValid():
            g, c = self.source.data(cur, CopyRole)
            self.copyActivated.emit(g, c)

    def keyPressEvent(self, e):
        cur = self.currentIndex()
        if cur.isValid() and e.key() in (Qt.Key.Key_Return, Qt.Key.Key_Enter):
            self.openRequested.emit(*self.source.data(cur, CopyRole))
            return
        super().keyPressEvent(e)

    def mouseDoubleClickEvent(self, e):
        idx = self.indexAt(e.position().toPoint())
        if idx.isValid() and idx.column() != 0:          # column 0 is the checkbox
            self.openRequested.emit(*self.source.data(idx, CopyRole))
            return
        super().mouseDoubleClickEvent(e)

    def contextMenuEvent(self, e):
        idx = self.indexAt(e.pos())
        if not idx.isValid():
            return
        self.setCurrentIndex(idx)
        g, c = self.source.data(idx, CopyRole)
        copy_menu(self, e.globalPos(), g, c, self._menu_changed)

    def _menu_changed(self, g):
        self.source.refresh()
        self.source.selectionToggled.emit(g)

    def _restyle(self):
        c = theme().colors
        if theme().plain:
            self.setStyleSheet("")
            return
        self.setStyleSheet(
            f"QTableView#Ledger {{ background: {c.surface}; color: {c.text}; alternate-background-color: {c.surface_alt};"
            f" selection-background-color: {c.selection}; selection-color: {c.selection_text};"
            f" border: 1px solid {c.line}; border-radius: 12px; }}"
            f"QTableView#Ledger::item {{ padding: 0 6px; border: none; }}"
            f"QTableView#Ledger::indicator {{ width: 16px; height: 16px; border: 2px solid {c.line}; border-radius: 5px;"
            f" background: {c.surface}; }}"
            f"QTableView#Ledger::indicator:checked {{ background: {c.accent}; border-color: {c.accent};"
            f" image: url(\"{CHECK}\"); }}"
            f"QTableView#Ledger QHeaderView::section {{ background: {c.surface}; color: {c.text_muted};"
            f" border: none; border-bottom: 1px solid {c.line}; padding: 8px 6px; font-weight: 600; }}")


# --------------------------------------------------------------------------- grid
class GridModel(QAbstractListModel):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.rows = []

    def set_groups(self, groups):
        self.beginResetModel()
        self.rows = flatten(groups)
        self.endResetModel()

    def rowCount(self, parent=QModelIndex()):
        return 0 if parent.isValid() else len(self.rows)

    def data(self, index, role=Qt.ItemDataRole.DisplayRole):
        if not index.isValid():
            return None
        g, c = self.rows[index.row()]
        if role == CopyRole:
            return g, c
        if role in (Qt.ItemDataRole.DisplayRole, Qt.ItemDataRole.AccessibleTextRole):
            return f"{c.name}, {tr('case_no', n=f'{g.number:04d}')}, {status_text(g, c)}"
        if role == Qt.ItemDataRole.ToolTipRole:
            return c.path
        return None


class GridDelegate(QStyledItemDelegate):
    selectionToggled = Signal(object)   # group

    def __init__(self, thumbs, parent=None):
        super().__init__(parent)
        self.thumbs = thumbs
        self.tile = 180

    def sizeHint(self, option, index):
        return QSize(self.tile + 16, int(self.tile * .75) + 70)

    def _cb(self, r: QRectF) -> QRectF:
        return QRectF(r.left() + 14, r.top() + 14, 22, 22)

    def paint(self, p, option, index):
        g, c = index.data(CopyRole)
        col = theme().colors
        plain = theme().plain
        p.save()
        p.setRenderHints(QPainter.RenderHint.Antialiasing | QPainter.RenderHint.SmoothPixmapTransform |
                         QPainter.RenderHint.TextAntialiasing)
        r = QRectF(option.rect).adjusted(8, 8, -8, -8)
        sel = bool(option.state & QStyle.StateFlag.State_Selected)
        if not plain:
            art.paint_shadow(p, r, 14, col.shadow, 4, 2)
        p.setPen(QPen(QColor(col.accent if sel else col.line), 2 if sel else 1))
        p.setBrush(QColor(col.surface))
        p.drawRoundedRect(r.adjusted(.5, .5, -.5, -.5), 14, 14)
        photo = QRectF(r.left() + 6, r.top() + 6, r.width() - 12, (r.width() - 12) * .75)
        src = g.copies[0] if g.mode == "content" else c
        img = self.thumbs.image(src)
        p.save()
        p.setClipPath(art.rounded(photo, 10))
        if img is not None:
            p.drawImage(photo, img, crop_to(img, photo.width(), photo.height()))
            if c.kind == "video":
                paint_play_glyph(p, photo.center(), 15)
        else:
            paint_placeholder(p, photo, c.kind, self.thumbs.error(src), self.thumbs.is_pending(src))
        p.restore()
        if c.selected:
            p.setPen(QPen(QColor(col.danger), 3))
            p.setBrush(Qt.BrushStyle.NoBrush)
            p.drawRoundedRect(photo.adjusted(1.5, 1.5, -1.5, -1.5), 9, 9)
        # group number chip (top right) unless the PROTECTED badge sits there
        if not c.protected:
            f = fonts.body(11, QFont.Weight.Bold)
            label = f"#{g.number:04d}"
            w = QFontMetricsF(f).horizontalAdvance(label) + 14
            chip = QRectF(photo.right() - w - 6, photo.top() + 6, w, 20)
            p.setPen(Qt.PenStyle.NoPen)
            p.setBrush(QColor(0, 0, 0, 150))
            p.drawRoundedRect(chip, 10, 10)
            p.setFont(f)
            p.setPen(QColor("#FFFFFF"))
            p.drawText(chip, Qt.AlignmentFlag.AlignCenter, label)
        if g.is_duplicate and c.selectable:
            art.paint_check(p, self._cb(r), c.selected, col)
        paint_badges(p, photo.adjusted(-2, 0, 2, 2), c, 9.5 if self.tile < 160 else 10.5)
        # name + size · folder
        tw = r.width() - 16
        nf = fonts.body(12.5, QFont.Weight.DemiBold)
        p.setFont(nf)
        p.setPen(QColor(col.text))
        p.drawText(QRectF(r.left() + 8, photo.bottom() + 8, tw, 17), Qt.AlignmentFlag.AlignLeft,
                   QFontMetricsF(nf).elidedText(c.name, Qt.TextElideMode.ElideMiddle, tw))
        sf = fonts.body(11.5)
        p.setFont(sf)
        p.setPen(QColor(col.text_muted))
        p.drawText(QRectF(r.left() + 8, photo.bottom() + 26, tw, 15), Qt.AlignmentFlag.AlignLeft,
                   QFontMetricsF(sf).elidedText(f"{human(c.size)} · {c.folder}", Qt.TextElideMode.ElideMiddle, tw))
        p.restore()

    def editorEvent(self, event, model, option, index):
        if event.type() == QEvent.Type.MouseButtonRelease:
            g, c = index.data(CopyRole)
            r = QRectF(option.rect).adjusted(8, 8, -8, -8)
            if g.is_duplicate and c.selectable and self._cb(r).adjusted(-4, -4, 4, 4).contains(event.position()):
                c.selected = not c.selected
                self.selectionToggled.emit(g)
                return True
        return False


class GridView(QListView):
    copyActivated = Signal(object, object)
    openRequested = Signal(object, object)   # Enter / double-click -> viewer

    def __init__(self, model: GridModel, thumbs, parent=None):
        super().__init__(parent)
        self.setModel(model)
        self.delegate = GridDelegate(thumbs, self)
        self.setItemDelegate(self.delegate)
        self.setViewMode(QListView.ViewMode.IconMode)
        self.setResizeMode(QListView.ResizeMode.Adjust)
        self.setMovement(QListView.Movement.Static)
        self.setUniformItemSizes(True)
        self.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
        self.setVerticalScrollMode(QAbstractItemView.ScrollMode.ScrollPerPixel)
        self.verticalScrollBar().setSingleStep(30)
        self.setFrameShape(QListView.Shape.NoFrame)
        self.setSpacing(0)
        self.setContextMenuPolicy(Qt.ContextMenuPolicy.DefaultContextMenu)
        self.delegate.selectionToggled.connect(lambda _g: self.viewport().update())
        self.selectionModel().currentChanged.connect(self._current)
        theme().changed.connect(self.viewport().update)

    def set_tile(self, px: int):
        self.delegate.tile = px
        self.setGridSize(self.delegate.sizeHint(None, None))
        self.doItemsLayout()

    def _current(self, cur, _prev):
        if cur.isValid():
            self.copyActivated.emit(*cur.data(CopyRole))

    def keyPressEvent(self, e):
        cur = self.currentIndex()
        if cur.isValid() and e.key() in (Qt.Key.Key_Return, Qt.Key.Key_Enter):
            self.openRequested.emit(*cur.data(CopyRole))
            return
        super().keyPressEvent(e)

    def mouseDoubleClickEvent(self, e):
        idx = self.indexAt(e.position().toPoint())
        if idx.isValid():
            self.openRequested.emit(*idx.data(CopyRole))
            return
        super().mouseDoubleClickEvent(e)

    def contextMenuEvent(self, e):
        idx = self.indexAt(e.pos())
        if not idx.isValid():
            return
        self.setCurrentIndex(idx)
        g, c = idx.data(CopyRole)
        copy_menu(self, e.globalPos(), g, c, self.delegate.selectionToggled.emit)
