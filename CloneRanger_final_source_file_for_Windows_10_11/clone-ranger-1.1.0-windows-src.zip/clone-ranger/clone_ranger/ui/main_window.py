"""Main window: gradient accent line, header (logo, search, theme, Scan), sidebar navigation, results,
details panel and status bar.

Results come from the scan index; file actions go through ops_controller.py; the viewer lives in ui/viewer/;
the Settings page in settings_page.py; "Reset to defaults" / "Clear history & cache" in reset_dialog.py.
"""
from __future__ import annotations

import logging
import os
import time

from PySide6.QtCore import QByteArray, Qt, QTimer
from PySide6.QtGui import QAction, QActionGroup, QFont, QKeySequence
from PySide6.QtWidgets import (QCheckBox, QComboBox, QFileDialog, QFrame, QHBoxLayout, QLabel, QLineEdit,
                               QMainWindow, QMenu, QMessageBox, QScrollArea, QSlider, QSplitter, QStackedWidget,
                               QVBoxLayout, QWidget)

from .. import __version__
from ..core import housekeeping, paths, recommend
from ..core.index import Index
from ..core.report import write_csv
from ..core.scanner import ScanConfig, default_roots
from ..core.settings import Settings
from ..theme import art, fonts
from ..theme.strings import tr
from ..theme.style import theme
from ..thumbs.service import DemoThumbs, ThumbService
from ..util import hms, human, short_path
from . import viewmodel
from .action_log import ActionLogPage
from .case_cards import CaseList, GroupsModel
from .demo_data import demo_groups
from .dossier import DossierPanel
from .ops_controller import OpsController
from .pages import EmptyState, FilterBar, LocationsPage, SummaryDialog
from .scan_screen import ScanScreen
from .settings_page import SettingsPage
from .viewer.images import FullImages
from .views import GridModel, GridView, LedgerModel, LedgerView
from .widgets import AccentBar, Button, NavItem, SectionTitle, Segmented, Stat, StatusBar, field_label, muted
from .workers import LoadWorker, MetaWorker, ScanWorker

log = logging.getLogger("clone_ranger")

THEME_LABELS = (("auto", "theme_auto"), ("light", "theme_light"), ("dark", "theme_dark"), ("plain", "plain_mode"))


# =========================================================================== header & sidebar
class Header(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName("Header")
        self.setAttribute(Qt.WidgetAttribute.WA_StyledBackground)
        lay = QHBoxLayout(self)
        lay.setContentsMargins(18, 10, 18, 10)
        lay.setSpacing(14)
        self.emblem = QLabel()
        lay.addWidget(self.emblem)
        titles = QVBoxLayout()
        titles.setSpacing(0)
        self.wordmark = QLabel()
        self.wordmark.setAccessibleName(tr("app_name"))
        sub = QLabel(tr("app_subtitle"))
        sub.setObjectName("Subtitle")
        sub.setFont(fonts.body(12.5, QFont.Weight.Medium))
        titles.addStretch(1)
        titles.addWidget(self.wordmark)
        titles.addWidget(sub)
        titles.addStretch(1)
        lay.addLayout(titles)
        lay.addStretch(1)

        self.search = QLineEdit()
        self.search.setObjectName("Search")
        self.search.setPlaceholderText(tr("search_hint"))
        self.search.setClearButtonEnabled(True)
        self.search.setMinimumWidth(200)
        self.search.setMaximumWidth(380)
        self.search.setAccessibleName(tr("search"))
        self._search_action = self.search.addAction(art.icon("search", "#888888"),
                                                    QLineEdit.ActionPosition.LeadingPosition)
        lay.addWidget(self.search, 1)
        self.theme_btn = Button("theme_auto", "theme", variant="ghost", size="small")
        self.theme_menu = QMenu(self)
        self.theme_actions = {}
        for key, label in THEME_LABELS:
            act = self.theme_menu.addAction(tr(label))
            act.setCheckable(True)
            act.triggered.connect(lambda _=False, k=key: theme().apply(k))
            self.theme_actions[key] = act
        self.theme_btn.setMenu(self.theme_menu)
        lay.addWidget(self.theme_btn)
        self.scan = Button("scan", "scan", variant="primary", size="large")
        self.scan.setToolTip(f"{tr('scan')} (F5)")
        lay.addWidget(self.scan)
        theme().changed.connect(self._restyle)
        self._restyle()

    def _restyle(self):
        c = theme().colors
        dpr = self.devicePixelRatioF()
        self.emblem.setPixmap(art.logo(42, dpr))
        if theme().plain:
            self.wordmark.setText(tr("app_name"))
            self.wordmark.setFont(fonts.logo(22))
        else:
            self.wordmark.setPixmap(art.gradient_text_pixmap(tr("app_name"), fonts.logo(23), dpr))
        self._search_action.setIcon(art.icon("search", c.text_muted))
        key = dict(THEME_LABELS)[theme().key]
        self.theme_btn.set_text(key)
        self.theme_btn.setToolTip(f"{tr('theme')}: {tr(key)}")
        for k, a in self.theme_actions.items():
            a.setChecked(k == theme().key)


class Sidebar(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName("Sidebar")
        self.setAttribute(Qt.WidgetAttribute.WA_StyledBackground)
        self.setFixedWidth(236)
        lay = QVBoxLayout(self)
        lay.setContentsMargins(12, 16, 12, 14)
        lay.setSpacing(4)
        from PySide6.QtWidgets import QButtonGroup
        self.group = QButtonGroup(self)
        self.tabs = {}
        sections = (("nav_library", (("same_content", "same_content"), ("same_name", "same_name"),
                                     ("filters", "filter"))),
                    ("nav_manage", (("scan_locations", "locations"), ("action_log", "history"),
                                    ("settings", "settings"))))
        for i, (title, items) in enumerate(sections):
            if i:
                lay.addSpacing(14)
            head = field_label(title)
            head.setContentsMargins(12, 0, 0, 4)
            lay.addWidget(head)
            for key, icon in items:
                t = NavItem(key, icon)
                self.tabs[key] = t
                lay.addWidget(t)
                if key != "filters":           # Filters is a toggle, independent of the pages
                    self.group.addButton(t)
        self.tabs["same_content"].setChecked(True)
        lay.addStretch(1)
        ver = muted(f"{tr('app_name')} {__version__}", wrap=False, px=12)
        ver.setContentsMargins(12, 0, 0, 0)
        lay.addWidget(ver)

    def set_count(self, key, n):
        self.tabs[key].count = "" if n is None else f"{n:,}".replace(",", " ")
        self.tabs[key].update()


# =========================================================================== results page
class ResultsPage(QWidget):
    def __init__(self, thumbs, settings, demo=False, parent=None):
        super().__init__(parent)
        self.thumbs, self.settings, self.demo = thumbs, settings, demo
        self.all_groups: list[viewmodel.UiGroup] = []
        self.visible: list[viewmodel.UiGroup] = []
        self.mode = "content"
        self.search = ""
        self.state = "none"           # none | loading | ready

        lay = QVBoxLayout(self)
        lay.setContentsMargins(22, 18, 16, 8)
        lay.setSpacing(12)

        top = QHBoxLayout()
        top.setSpacing(10)
        self.title = SectionTitle("same_content", px=26)
        top.addWidget(self.title, 1)
        self.name_opts = QWidget()
        no = QHBoxLayout(self.name_opts)
        no.setContentsMargins(0, 0, 0, 0)
        self.ignore_case = QCheckBox(tr("ignore_case"))
        self.ignore_ext = QCheckBox(tr("ignore_ext"))
        self.ignore_case.setChecked(settings["name_ignore_case"])
        self.ignore_ext.setChecked(settings["name_ignore_ext"])
        no.addWidget(self.ignore_case)
        no.addWidget(self.ignore_ext)
        self.name_opts.hide()
        top.addWidget(self.name_opts)
        self.view_switch = Segmented([("view_cards", "view_cards", "cards"), ("view_ledger", "view_ledger", "ledger"),
                                      ("view_grid", "view_grid", "grid")])
        self.views = self.view_switch.buttons
        top.addWidget(self.view_switch)
        self.undo_btn = Button("undo", "undo", variant="ghost", size="small")
        top.addWidget(self.undo_btn)
        lay.addLayout(top)

        stats = QHBoxLayout()
        stats.setSpacing(12)
        self.stat_groups = Stat("0", "groups", icon="same_content")
        self.stat_files = Stat("0", "dup_files", icon="copy")
        self.stat_reclaim = Stat("0 B", "space_reclaim", accent=True, icon="sparkle")
        for w in (self.stat_groups, self.stat_files, self.stat_reclaim):
            stats.addWidget(w, 1)
        sort_box = QVBoxLayout()
        sort_box.setSpacing(4)
        sort_box.addWidget(field_label("sort_by"))
        self.sort = QComboBox()
        for k in ("space_reclaim", "f_size", "copies", "f_name", "f_created"):
            self.sort.addItem(tr(k), k)
        self.sort.setAccessibleName(tr("sort_by"))
        self.sort.setMinimumWidth(150)
        sort_box.addWidget(self.sort)
        stats.addLayout(sort_box)
        lay.addLayout(stats)

        # selection bar: how much is selected, and one click to select or unselect everything
        sel = QHBoxLayout()
        sel.setSpacing(8)
        self.sel_label = QLabel(tr("nothing_selected"))
        self.sel_label.setFont(fonts.body(13.5, QFont.Weight.DemiBold))
        self.sel_label.setProperty("role", "muted")
        sel.addWidget(self.sel_label)
        self.select_all_btn = Button("select_all_short", "select", variant="ghost", size="small")
        self.select_all_btn.setToolTip(f"{tr('select_all')} (Ctrl+A)")
        self.unselect_all_btn = Button("unselect_all", "unselect", variant="soft", size="small")
        self.unselect_all_btn.setToolTip(f"{tr('unselect_all')} (Ctrl+Shift+A)")
        self.unselect_all_btn.setEnabled(False)
        sel.addWidget(self.select_all_btn)
        sel.addWidget(self.unselect_all_btn)
        sel.addStretch(1)
        self.grid_slider_box = QWidget()
        gs = QHBoxLayout(self.grid_slider_box)
        gs.setContentsMargins(0, 0, 0, 0)
        gs.addWidget(muted("thumb_size", wrap=False))
        self.grid_slider = QSlider(Qt.Orientation.Horizontal)
        self.grid_slider.setRange(110, 340)
        self.grid_slider.setValue(settings["grid_size"])
        self.grid_slider.setFixedWidth(140)
        self.grid_slider.setAccessibleName(tr("thumb_size"))
        gs.addWidget(self.grid_slider)
        sel.addWidget(self.grid_slider_box)
        lay.addLayout(sel)

        actions = QHBoxLayout()
        actions.setSpacing(8)
        self.trash_btn = Button("move_to_trash", "trash", variant="primary", size="small")
        self.delete_btn = Button("delete_perm", "delete", variant="danger", size="small")
        self.move_btn = Button("move", "move", size="small")
        self.rename_btn = Button("rename", "rename", size="small")
        self.compare_btn = Button("identification", "compare", size="small")
        for b in (self.trash_btn, self.delete_btn, self.move_btn, self.rename_btn):
            actions.addWidget(b)
        actions.addSpacing(10)
        actions.addWidget(self.compare_btn)
        actions.addStretch(1)
        lay.addLayout(actions)
        for b, keys in ((self.trash_btn, "Delete"), (self.delete_btn, "Shift+Delete"), (self.rename_btn, "F2"),
                        (self.undo_btn, "Ctrl+Z"), (self.compare_btn, "F4")):
            b.setToolTip(f"{b.accessibleName()}  ({keys})")

        self.filters = FilterBar()
        self.filters.hide()
        lay.addWidget(self.filters)

        self.stack = QStackedWidget()
        self.cards_model = GroupsModel([])
        self.cards = CaseList(self.cards_model, thumbs)
        self.ledger_model = LedgerModel()
        self.ledger = LedgerView(self.ledger_model)
        self.grid_model = GridModel()
        self.grid = GridView(self.grid_model, thumbs)
        self.grid.set_tile(self.grid_slider.value())
        self.empty = EmptyState()
        for w in (self.cards, self.ledger, self.grid, self.empty):
            self.stack.addWidget(w)
        lay.addWidget(self.stack, 1)

        self.view_switch.selected.connect(lambda k: self.set_view(k.split("_")[1]))
        self.sort.currentIndexChanged.connect(self.apply)
        self.filters.changed.connect(self.apply)
        self.grid_slider.valueChanged.connect(self.grid.set_tile)
        self.set_view(settings["view"])

    # ------------------------------------------------------------------ data
    def set_groups(self, groups, mode):
        self.all_groups, self.mode = groups, mode
        self.state = "ready"
        self.title.set_text("same_content" if mode == "content" else "same_name")
        self.name_opts.setVisible(mode == "name")
        self.apply()

    def set_state(self, state):
        self.state = state
        self.apply()

    def set_search(self, text):
        self.search = text.strip().casefold()
        self.apply()

    def apply(self):
        groups = [g for g in self.all_groups if self.filters.accepts(g)]
        if self.search:
            groups = [g for g in groups if any(self.search in c.path.casefold() for c in g.copies)]
        key = self.sort.currentData()
        sorters = {
            "space_reclaim": lambda g: (-g.reclaim, -g.size),
            "f_size": lambda g: (-g.size, g.number),
            "copies": lambda g: (-len(g.copies), -g.reclaim),
            "f_name": lambda g: (g.display_name.casefold(), g.number),
            "f_created": lambda g: (g.oldest_ns, g.number),
        }
        groups.sort(key=sorters.get(key, sorters["space_reclaim"]))
        self.visible = groups
        # only the view on screen is refilled now; the others when you switch to them (with ~100 000
        # copies, refilling all three views on every filter / search keystroke took seconds)
        self._stale = {"cards", "ledger", "grid"}
        self._fill(self.view)
        dup = [g for g in groups if g.is_duplicate]
        self.stat_groups.value.setText(f"{len(groups):,}".replace(",", " "))
        self.stat_files.value.setText(f"{sum(g.inodes - 1 for g in dup):,}".replace(",", " "))
        self.stat_reclaim.value.setText(human(sum(g.reclaim for g in dup)))
        self._show_current_view()

    def _show_current_view(self):
        if self.state == "loading":
            self.empty.show_mode("loading")
            self.stack.setCurrentWidget(self.empty)
        elif self.state == "none":
            self.empty.show_mode("none")
            self.stack.setCurrentWidget(self.empty)
        elif not self.all_groups:
            self.empty.show_mode("clean", "" if self.mode == "content" else tr("same_name"))
            self.stack.setCurrentWidget(self.empty)
        elif not self.visible:
            self.empty.show_mode("filtered", "")
            self.stack.setCurrentWidget(self.empty)
        else:
            self.stack.setCurrentWidget({"cards": self.cards, "ledger": self.ledger, "grid": self.grid}[self.view])

    def _fill(self, view):
        if view in getattr(self, "_stale", ()):
            self._stale.discard(view)
            {"cards": self.cards_model, "ledger": self.ledger_model, "grid": self.grid_model}[view].set_groups(
                self.visible)

    def set_view(self, view):
        self.view = view if view in ("cards", "ledger", "grid") else "cards"
        self._fill(self.view)
        self.view_switch.set_current(f"view_{self.view}")
        self.grid_slider_box.setVisible(self.view == "grid")
        self._show_current_view()

    def refresh_views(self):
        """Selection / metadata / recommendation changed: repaint the view on screen (cheap)."""
        if self.view == "ledger":
            self.ledger_model.refresh()
        self.repaint_views()

    def repaint_views(self):
        """Only pixels changed (thumbnails arrived)."""
        self.cards.viewport().update()
        self.grid.viewport().update()

    # ------------------------------------------------------------------ selection
    def selected(self):
        return [(g, c) for g in self.all_groups for c in g.copies if c.selected]

    def selected_bytes(self) -> int:
        return sum(g.selected_size for g in self.all_groups)

    def show_selection(self, n: int, size: int):
        if n:
            self.sel_label.setText(tr("n_selected", n=f"{n:,}".replace(",", " "), size=human(size)))
            self.sel_label.setProperty("role", "accent")
        else:
            self.sel_label.setText(tr("nothing_selected"))
            self.sel_label.setProperty("role", "muted")
        self.sel_label.style().unpolish(self.sel_label)
        self.sel_label.style().polish(self.sel_label)
        self.unselect_all_btn.setEnabled(n > 0)


# =========================================================================== page stack
class PageStack(QStackedWidget):
    """The pages next to the sidebar. Tall pages sit in a scroll area, so on a small screen (or with large
    Windows display scaling) they get a scroll bar instead of making the window taller than the screen.
    setCurrentWidget() / currentWidget() take and return the page itself, not its scroll area."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self._wrappers: dict[QWidget, QScrollArea] = {}

    def add_page(self, page: QWidget, scroll: bool = False):
        if not scroll:
            self.addWidget(page)
            return
        area = QScrollArea()
        area.setWidgetResizable(True)
        area.setFrameShape(QFrame.Shape.NoFrame)
        area.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)
        area.setWidget(page)
        self._wrappers[page] = area
        self.addWidget(area)

    def setCurrentWidget(self, page):
        super().setCurrentWidget(self._wrappers.get(page, page))

    def currentWidget(self):
        w = super().currentWidget()
        return w.widget() if isinstance(w, QScrollArea) and w in self._wrappers.values() else w


# =========================================================================== main window
class MainWindow(QMainWindow):
    def __init__(self, demo: bool = False, settings: Settings | None = None):
        super().__init__()
        self.demo = demo
        self.settings = settings or Settings()
        # the title ends with the app name, so Windows / Linux don't append "- Clone Ranger" a second time
        self.setWindowTitle(tr("app_title", demo="  [DEMO]" if demo else ""))
        self.resize(1500, 940)
        self.db_path = paths.index_path()
        self._index = None
        self.scan_worker = self.load_worker = self.meta_worker = None
        self.last_scan = None
        self.thumbs = DemoThumbs(self) if demo else ThumbService(self)
        self.ops = OpsController(self)
        viewmodel.set_rules(recommend.build_rules(self.settings["keep_rules"], self.settings["preferred_folders"]))
        self.full_images = FullImages(self, enabled=not demo)
        self.viewer = None
        self._restore_sel = None

        central = QWidget()
        central.setObjectName("Centre")
        v = QVBoxLayout(central)
        v.setContentsMargins(0, 0, 0, 0)
        v.setSpacing(0)
        v.addWidget(AccentBar())
        self.header = Header()
        v.addWidget(self.header)
        self.split = QSplitter(Qt.Orientation.Horizontal)
        self.split.setHandleWidth(1)
        self.split.setChildrenCollapsible(False)
        self.sidebar = Sidebar()
        self.split.addWidget(self.sidebar)
        self.stack = PageStack()
        self.results = ResultsPage(self.thumbs, self.settings, demo)
        self.scan_screen = ScanScreen()
        self.locations = LocationsPage(self.settings)
        self.log_page = ActionLogPage(self.ops.journal)
        self.settings_page = SettingsPage(self.settings)
        self.settings_page.impact_fn = lambda rules, prot: viewmodel.count_changes(self.results.all_groups, rules,
                                                                                  prot)
        self.settings_page.data_info_fn = self.data_info
        self.stack.add_page(self.results)                  # its lists scroll by themselves
        for w in (self.scan_screen, self.locations, self.log_page):
            self.stack.add_page(w, scroll=True)
        self.stack.add_page(self.settings_page)            # has its own scroll area
        self.split.addWidget(self.stack)
        self.dossier = DossierPanel(self.thumbs)
        self.split.addWidget(self.dossier)
        self.split.setStretchFactor(1, 1)
        self.split.setSizes([236, 900, 350])
        v.addWidget(self.split, 1)
        self.statusbar = StatusBar()
        v.addWidget(self.statusbar)
        self.setCentralWidget(central)

        self._menus()
        self._connect()
        self._restore()
        self.update_status()
        self.update_undo()
        if demo:
            groups = demo_groups()
            self.results.set_groups(groups, "content")
            self.sidebar.set_count("same_content", len(groups))
            self._select_first()
            self.update_status()
        else:
            QTimer.singleShot(0, self.load_results)

    # ------------------------------------------------------------------ setup
    def _connect(self):
        r = self.results
        self.header.scan.clicked.connect(self.start_scan)
        self.header.search.textChanged.connect(r.set_search)
        r.empty.scanRequested.connect(self.start_scan)
        r.trash_btn.clicked.connect(lambda: self.ops.trash())
        r.delete_btn.clicked.connect(lambda: self.ops.delete())
        r.move_btn.clicked.connect(lambda: self.ops.move())
        r.rename_btn.clicked.connect(lambda: self.ops.rename())
        r.undo_btn.clicked.connect(lambda: self.ops.undo_last())
        self.log_page.undoRequested.connect(self.ops.undo)
        r.compare_btn.clicked.connect(lambda: self.open_viewer("compare"))
        r.cards.openRequested.connect(lambda g, i: self.open_viewer("single", g, i))
        r.ledger.openRequested.connect(lambda g, c: self.open_viewer("single", g, g.copies.index(c)))
        r.grid.openRequested.connect(lambda g, c: self.open_viewer("single", g, g.copies.index(c)))
        self.dossier.viewRequested.connect(lambda g, c: self.open_viewer("single", g, g.copies.index(c)))
        r.cards.delegate.copyClicked.connect(self._copy_clicked)
        r.cards.copyChanged.connect(self.dossier.show_copy)
        r.ledger.copyActivated.connect(self.dossier.show_copy)
        r.grid.copyActivated.connect(self.dossier.show_copy)
        for sig in (r.cards.delegate.selectionToggled, r.grid.delegate.selectionToggled):
            sig.connect(self._selection_changed)
        r.ledger_model.selectionToggled.connect(self._selection_changed)
        r.ignore_case.toggled.connect(self._name_options)
        r.ignore_ext.toggled.connect(self._name_options)
        self.scan_screen.pauseRequested.connect(self._pause)
        self.scan_screen.cancelRequested.connect(self._cancel_scan)
        self.dossier.message.connect(self.flash)
        self.locations.saved.connect(lambda: self.flash(f"{tr('scan_locations')}: {tr('save')} ✓"))
        self.locations.resetRequested.connect(lambda: self.open_reset("reset"))
        self.settings_page.clearRequested.connect(lambda: self.open_reset("clear"))
        self.settings_page.resetRequested.connect(lambda: self.open_reset("reset"))
        r.select_all_btn.clicked.connect(self.select_all)
        r.unselect_all_btn.clicked.connect(self.select_none)
        self.dossier.selectionToggled.connect(self._selection_changed)
        tabs = self.sidebar.tabs
        tabs["same_content"].clicked.connect(lambda: self.show_mode("content"))
        tabs["same_name"].clicked.connect(lambda: self.show_mode("name"))
        tabs["filters"].toggled.connect(self._toggle_filters)
        tabs["scan_locations"].clicked.connect(lambda: self.stack.setCurrentWidget(self.locations))
        tabs["action_log"].clicked.connect(self.show_history)
        tabs["settings"].clicked.connect(self.show_settings)
        self.settings_page.saved.connect(self.apply_settings)
        self._repaint_timer = QTimer(self, singleShot=True, interval=80)
        self._repaint_timer.timeout.connect(self.results.repaint_views)
        self.thumbs.ready.connect(lambda _k: self._repaint_timer.start())
        self._status_timer = QTimer(self, singleShot=True, interval=200)
        self._status_timer.timeout.connect(self.update_status)
        theme().changed.connect(self._sync_theme_actions)

    def _menus(self):
        mb = self.menuBar()
        f = mb.addMenu(tr("file_menu"))
        a = QAction(tr("scan"), self)
        a.setShortcut(QKeySequence("F5"))
        a.triggered.connect(self.start_scan)
        f.addAction(a)
        e = QAction(tr("export_csv"), self)
        e.setShortcut(QKeySequence("Ctrl+E"))
        e.triggered.connect(self.export_csv)
        f.addAction(e)
        f.addSeparator()
        cd = QAction(tr("clear_data").replace("&", "&&"), self)
        cd.triggered.connect(lambda: self.open_reset("clear"))
        f.addAction(cd)
        rd = QAction(tr("reset_defaults"), self)
        rd.triggered.connect(lambda: self.open_reset("reset"))
        f.addAction(rd)
        self.data_actions = {"clear": cd, "reset": rd}
        f.addSeparator()
        q = QAction(tr("quit"), self)
        q.setShortcut(QKeySequence.StandardKey.Quit)
        q.triggered.connect(self.close)
        f.addAction(q)

        ed = mb.addMenu(tr("edit_menu"))
        self.edit_actions = {}
        for key, keys, fn in (("undo", "Ctrl+Z", lambda: self.ops.undo_last()),
                              (None, None, None),
                              ("move_to_trash", "Delete", lambda: self.ops.trash()),
                              ("delete_perm", "Shift+Delete", lambda: self.ops.delete()),
                              ("move", "", lambda: self.ops.move()),
                              ("rename", "F2", lambda: self.ops.rename_one()),
                              ("bulk_rename", "Ctrl+F2", lambda: self.ops.bulk_rename()),
                              (None, None, None),
                              ("select_all", "Ctrl+A", self.select_all),
                              ("select_none", "Ctrl+Shift+A", self.select_none),
                              ("unselect_file", "Ctrl+U", self.unselect_current)):
            if key is None:
                ed.addSeparator()
                continue
            act = QAction(tr(key) + ("…" if key in ("move", "bulk_rename") else ""), self)
            if keys:
                act.setShortcut(QKeySequence(keys))
            act.triggered.connect(fn)
            ed.addAction(act)
            self.edit_actions[key] = act

        view = mb.addMenu(tr("view_menu"))
        self.theme_actions = {}
        ag = QActionGroup(self)
        tm = view.addMenu(tr("theme"))
        for key, label in THEME_LABELS:
            act = QAction(tr(label), self, checkable=True)
            act.triggered.connect(lambda _=False, k=key: theme().apply(k))
            ag.addAction(act)
            tm.addAction(act)
            self.theme_actions[key] = act
        view.addSeparator()
        for i, (key, name) in enumerate((("view_cards", "cards"), ("view_ledger", "ledger"), ("view_grid", "grid")), 1):
            act = QAction(tr(key), self)
            act.setShortcut(QKeySequence(f"Ctrl+{i}"))
            act.triggered.connect(lambda _=False, n=name: self._set_view(n))
            view.addAction(act)
        view.addSeparator()
        for key, keys, mode in (("viewer", "F3", "single"), ("identification", "F4", "compare"),
                                ("grid_compare", "Shift+F4", "grid"), ("slideshow", "F11", "slideshow")):
            act = QAction(tr(key), self)
            act.setShortcut(QKeySequence(keys))
            act.triggered.connect(lambda _=False, m=mode: self.open_viewer(m))
            view.addAction(act)
        view.addSeparator()
        self.preview_action = QAction(tr("preview_panel"), self, checkable=True)
        self.preview_action.setShortcut(QKeySequence("F9"))
        self.preview_action.toggled.connect(self.dossier.setVisible)
        view.addAction(self.preview_action)
        hm = mb.addMenu(tr("help_menu"))
        sc = QAction(tr("shortcuts"), self)
        sc.setShortcut(QKeySequence("F1"))
        sc.triggered.connect(self.show_shortcuts)
        hm.addAction(sc)
        ab = QAction(tr("about"), self)
        ab.triggered.connect(self.show_about)
        hm.addAction(ab)
        self._sync_theme_actions()

    def _restore(self):
        geo = self.settings["window_geometry"]
        if geo:
            self.restoreGeometry(QByteArray.fromBase64(geo.encode()))
        self._fit_to_screen()
        self.preview_action.setChecked(bool(self.settings["preview_panel"]))
        self.dossier.setVisible(bool(self.settings["preview_panel"]))

    def _fit_to_screen(self):
        """The default (or saved) size is bigger than the screen - e.g. a small laptop, or a big Windows display
        scaling: open maximized instead of running past the screen edges."""
        screen = self.screen()
        if screen is None or self.isMaximized() or self.isFullScreen():
            return
        avail = screen.availableGeometry()
        frame = self.frameGeometry()
        extra_w, extra_h = max(0, frame.width() - self.width()), max(0, frame.height() - self.height())
        if self.width() + extra_w > avail.width() or self.height() + extra_h > avail.height():
            self.setWindowState(self.windowState() | Qt.WindowState.WindowMaximized)

    def closeEvent(self, e):
        if self.viewer is not None:
            self.viewer.close()
        self.full_images.wait(3000)
        if self.ops.worker is not None:
            self.ops.worker.control.cancel()
            self.ops.worker.wait(30000)
        if self.scan_worker and self.scan_worker.isRunning():
            self.scan_worker.control.cancel()
            self.scan_worker.wait(5000)
        if self.meta_worker and self.meta_worker.isRunning():
            self.meta_worker.stop = True
            self.meta_worker.wait(3000)
        s = self.settings
        s["window_geometry"] = bytes(self.saveGeometry().toBase64()).decode()
        s["theme"] = theme().key
        s["view"] = self.results.view
        s["preview_panel"] = self.preview_action.isChecked()
        s["grid_size"] = self.results.grid_slider.value()
        s["name_ignore_case"] = self.results.ignore_case.isChecked()
        s["name_ignore_ext"] = self.results.ignore_ext.isChecked()
        if not self.demo:
            try:
                s.save()
            except OSError:
                log.exception("could not save settings")
        if self._index:
            self._index.close()
        self._index = False            # closed for good (see _meta_batch)
        super().closeEvent(e)

    def _sync_theme_actions(self):
        for k, a in self.theme_actions.items():
            a.setChecked(theme().key == k)

    def index(self) -> Index:
        if not self._index:
            self._index = Index(self.db_path)
        return self._index

    # ------------------------------------------------------------------ status
    def update_status(self, extra: str | None = None):
        sel = self.results.selected()
        if self.demo:
            idx = "Demo data"
        elif self.scan_worker and self.scan_worker.isRunning():
            idx = tr("surveillance")
        elif not self.last_scan:
            idx = tr("index_none")
        elif self.last_scan["status"] == "cancelled":
            idx = tr("index_cancelled")
        else:
            when = time.strftime("%Y-%m-%d %H:%M", time.localtime(self.last_scan["started"]))
            idx = f"{tr('index_ok')} · {when}"
        if self.ops.busy:
            idx = tr("busy")
        size = self.results.selected_bytes()
        self.results.show_selection(len(sel), size)
        parts = [tr("n_selected", n=len(sel), size=human(size)) if sel else tr("nothing_selected"), idx]
        if extra:
            parts.append(extra)
        self.statusbar.set_parts(parts)

    def flash(self, text: str):
        self.update_status(text)
        QTimer.singleShot(4000, self.update_status)

    # ------------------------------------------------------------------ loading results
    def load_results(self, mode: str | None = None):
        mode = mode or self.results.mode
        if not os.path.exists(self.db_path):
            self.results.set_state("none")
            self.update_status()
            return
        self.results.set_state("loading")
        w = LoadWorker(self.db_path, mode, self.results.ignore_case.isChecked(), self.results.ignore_ext.isChecked(),
                       self.settings["min_size"], self)
        w.done.connect(self._loaded)
        w.failed.connect(self._failed)
        w.finished.connect(w.deleteLater)
        self.load_worker = w
        w.start()

    def _loaded(self, mode, groups, last):
        self.last_scan = last
        if not last:
            self.results.set_state("none")
            self.update_status()
            return
        ug = viewmodel.from_content_groups(groups) if mode == "content" else viewmodel.from_name_groups(groups)
        self._prepare_groups(ug)
        current = self.dossier.group
        self.results.set_groups(ug, mode)
        self.sidebar.set_count("same_content" if mode == "content" else "same_name", len(ug))
        if self._restore_sel is not None:
            viewmodel.restore_selection(ug, self._restore_sel)
            self._restore_sel = None
            self.reselect(current)
        else:
            self._select_first()
        self.update_status()
        self.update_undo()
        self._start_metadata(ug)

    def show_mode(self, mode):
        self.stack.setCurrentWidget(self.results)
        if self.demo:
            return
        if mode != self.results.mode or self.results.state != "ready":
            self.results.mode = mode
            self.load_results(mode)

    def _name_options(self):
        if self.results.mode == "name":
            self.load_results("name")

    def _prepare_groups(self, groups):
        """Protected folders: never selectable (and the recommendation prefers them)."""
        changed = viewmodel.mark_protected(groups, self.settings["protected_folders"] or [])
        for g in groups:
            if id(g) in changed:
                viewmodel.apply_recommendation(g, preselect=g.mode == "content")

    # ------------------------------------------------------------------ settings
    def show_settings(self):
        self.settings_page.load()          # fresh preview against the current case files
        self.stack.setCurrentWidget(self.settings_page)

    def apply_settings(self):
        """Settings saved: new keep rules / preferred / protected folders, applied without a rescan.
        Case files the user changed by hand keep their selection (protected copies are still unticked)."""
        s = self.settings
        viewmodel.set_rules(recommend.build_rules(s["keep_rules"], s["preferred_folders"]))
        groups = self.results.all_groups
        prot_changed = viewmodel.mark_protected(groups, s["protected_folders"] or [])
        updated = 0
        for g in groups:
            if getattr(g, "user_touched", False) and id(g) not in prot_changed:
                continue
            before = next((c.inode for c in g.copies if c.keep or c.keep_twin), None)
            if getattr(g, "user_touched", False):
                # keep the user's ticks, but a newly protected copy must win the KEEP stamp
                sel = {c.path: c.selected for c in g.copies}
                viewmodel.apply_recommendation(g, preselect=False)
                for c in g.copies:
                    c.selected = sel.get(c.path, False) and c.selectable
            else:
                viewmodel.apply_recommendation(g, preselect=g.mode == "content")
            if next((c.inode for c in g.copies if c.keep or c.keep_twin), None) != before:
                updated += 1
        self.results.apply()
        self.results.refresh_views()
        self.dossier.refresh()
        self.update_status()
        self.flash(tr("settings_applied", n=updated))
        self.settings_page.load()

    def reload_keep_selection(self):
        """Re-read the case files from the index (no file is read), keeping hand-made selections."""
        if self.demo:
            return
        self._restore_sel = viewmodel.selection_state(self.results.all_groups)
        self.load_results(self.results.mode)

    def reselect(self, group):
        """After the list changed: show the same case file again if it's still open, else the first."""
        r = self.results
        if group is not None and group in r.visible:
            row = r.visible.index(group)
            r.cards.setCurrentIndex(r.cards_model.index(row))
            copy = self.dossier.copy
            self.dossier.show_copy(group, copy if copy in group.copies else 0)
        else:
            self._select_first()

    def update_undo(self):
        if self.demo:
            return
        o = self.ops.journal.last_undoable()
        self.results.undo_btn.setEnabled(o is not None)
        self.edit_actions["undo"].setEnabled(True)   # Ctrl+Z always answers (says "Nothing to undo")
        tip = f"{tr('undo')}: {tr('order_no', n=o.n)}  (Ctrl+Z)" if o else tr("nothing_to_undo")
        self.results.undo_btn.setToolTip(tip)

    # ------------------------------------------------------------------ history page
    def show_history(self):
        self.log_page.reload()
        self.stack.setCurrentWidget(self.log_page)

    # ------------------------------------------------------------------ reset / clear history & cache
    def data_info(self) -> tuple[int, int]:
        """(cache bytes, number of actions in the history) for the Settings page and the reset dialog."""
        try:
            actions = len(self.ops.journal.orders())
        except OSError:
            actions = 0
        return housekeeping.cache_size(), actions

    def _undoable_count(self) -> int:
        try:
            return sum(1 for o in self.ops.journal.orders() if o.undoable)
        except OSError:
            return 0

    def open_reset(self, mode: str = "reset"):
        """mode "reset": Reset to defaults (search settings ticked); "clear": Clear history & cache."""
        from .reset_dialog import ResetDialog
        if self._busy_for_reset():
            QMessageBox.information(self, tr("clear_data_title"), tr("clear_busy"))
            return None
        cache_bytes, actions = self.data_info()
        dlg = ResetDialog(mode, cache_bytes, actions, self._undoable_count(), self)
        if dlg.exec():
            self.perform_reset(**dlg.choices())
        return dlg

    def _busy_for_reset(self) -> bool:
        return bool(self.ops.busy or (self.scan_worker and self.scan_worker.isRunning()))

    def perform_reset(self, search=False, preferences=False, history=False, cache=False):
        """Carry out a reset. Photos and videos are never touched (see core/housekeeping.py)."""
        if not (search or preferences or history or cache):
            return None
        if self._busy_for_reset():
            self.flash(tr("clear_busy"))
            return None
        if cache:
            if self.viewer is not None:
                self.viewer.close()
            for w in (self.meta_worker, self.load_worker):
                try:
                    running = w is not None and w.isRunning()
                except RuntimeError:              # finished workers delete themselves (deleteLater)
                    running = False
                if running:
                    if hasattr(w, "stop"):
                        w.stop = True
                    w.wait(5000)
            self.meta_worker = None        # batches still queued from it are ignored (see _meta_batch)
            self._copies_by_id = {}
            if self._index:
                self._index.close()
            self._index = None
            self.thumbs.clear()
        if self.demo:                     # demo mode never writes anything
            report = housekeeping.Report()
        else:
            report = housekeeping.reset(self.settings, search=search, preferences=preferences, history=history,
                                        cache=cache)
        s = self.settings
        if search:
            self.locations.load()
            self.results.filters.clear()
            self.header.search.clear()
            for box, key in ((self.results.ignore_case, "name_ignore_case"), (self.results.ignore_ext, "name_ignore_ext")):
                box.blockSignals(True)
                box.setChecked(bool(s[key]))
                box.blockSignals(False)
        if preferences:
            theme().reduce_motion = bool(s["reduce_motion"])
            theme().apply(s["theme"])
            from .sounds import sounds
            sounds().enabled = bool(s["sounds"])
            self.results.grid_slider.setValue(s["grid_size"])
            self.results.set_view(s["view"])
            self.preview_action.setChecked(bool(s["preview_panel"]))
            self.apply_settings()          # keep rules, preferred and protected folders
        if history:
            self.log_page.reload()
            self.update_undo()
        if cache and not self.demo:
            self.last_scan = None
            self.results.all_groups = []
            self.results.set_state("none")
            self.sidebar.set_count("same_content", None)
            self.sidebar.set_count("same_name", None)
            self.dossier.clear()
        elif search and self.results.mode == "name" and self.results.state == "ready":
            self.load_results("name")      # the same-name options changed
        self.settings_page.load()
        self.update_status()
        what = [tr(k) for k, on in (("w_search", search), ("w_prefs", preferences), ("w_history", history),
                                    ("w_cache", cache)) if on]
        self.flash(tr("reset_done", what=", ".join(what)))
        return report

    # ------------------------------------------------------------------ help
    def show_shortcuts(self):
        from .help_dialogs import ShortcutsDialog
        dlg = ShortcutsDialog(self)
        dlg.exec()
        return dlg

    def show_about(self):
        from .help_dialogs import AboutDialog
        dlg = AboutDialog(self)
        dlg.exec()
        return dlg

    # ------------------------------------------------------------------ viewer
    def open_viewer(self, mode: str = "single", group=None, index: int | None = None):
        """Open the viewer on a copy (default: the one in the dossier). mode: single | compare | grid |
        slideshow."""
        from .viewer.window import ViewerWindow
        r = self.results
        if group is None:
            group = self.dossier.group if self.dossier.group in r.visible else (r.visible[0] if r.visible else None)
            if group is not None and index is None:
                copy = self.dossier.copy
                index = group.copies.index(copy) if copy in group.copies else 0
        if group is None:
            self.flash(tr("nothing_selected"))
            return None
        if self.viewer is not None:
            self.viewer.close()
        groups = r.visible if group in r.visible else [group]
        v = ViewerWindow(groups, group, index or 0, "single" if mode == "slideshow" else mode, self.thumbs,
                         self.full_images, demo=self.demo, parent=self)
        v.selectionChanged.connect(self._viewer_selection)
        v.closed.connect(self._viewer_closed)
        self.viewer = v
        v.show()
        if mode == "slideshow":
            v.start_slideshow()
        return v

    def _viewer_selection(self, group):
        group.user_touched = True
        self.results.refresh_views()
        self.update_status()

    def _viewer_closed(self, group, index):
        self.viewer = None
        self.results.refresh_views()
        if group in self.results.visible:
            self.reselect(group)
            if 0 <= index < len(group.copies):
                self.dossier.show_copy(group, index)
        self.update_status()

    def select_all(self):
        """Ctrl+A: select every duplicate in the visible case files (never the kept copy or protected files)."""
        for g in self.results.visible:
            if not g.is_duplicate:
                continue
            for c in g.copies:
                if c.selectable:
                    c.selected = True
            g.user_touched = True
        self.results.refresh_views()
        self.update_status()

    def select_none(self) -> int:
        """Unselect every file (in all groups, also ones hidden by a filter or search). Returns how many."""
        n = 0
        for g in self.results.all_groups:
            for c in g.copies:
                if c.selected:
                    c.selected = False
                    g.user_touched = True
                    n += 1
        self.results.refresh_views()
        self.dossier.refresh()
        self.update_status()
        if n:
            self.flash(tr("unselected_n", n=n))
        return n

    def unselect_current(self):
        """Ctrl+U: unselect the file shown in the details panel."""
        g, c = self.dossier.group, self.dossier.copy
        if g is None or c is None or not c.selected:
            self.flash(tr("nothing_selected"))
            return
        c.selected = False
        self.dossier.refresh()
        self._selection_changed(g)

    def _select_first(self):
        r = self.results
        if r.visible:
            r.cards.setCurrentIndex(r.cards_model.index(0))
            self.dossier.show_copy(r.visible[0], 0)
        else:
            self.dossier.clear()

    # ------------------------------------------------------------------ metadata in the background
    def _start_metadata(self, groups):
        if self.demo:
            return
        if self.meta_worker and self.meta_worker.isRunning():
            self.meta_worker.stop = True
            self.meta_worker.wait(2000)
        self._copies_by_id = {}
        items = []
        for g in groups:
            for c in g.copies:
                if c.file_id is None:
                    continue
                self._copies_by_id.setdefault(c.file_id, []).append((g, c))
                if not c.has_meta:
                    items.append((c.file_id, c.path, c.kind, c.mtime_ns))
        if not items:
            return
        self.meta_worker = MetaWorker(items, self)
        self.meta_worker.batch.connect(self._meta_batch)
        self.meta_worker.start()

    def _meta_batch(self, batch):
        if self._index is False:       # window closed; late batches from the worker are dropped
            return
        if self.sender() is not None and self.sender() is not self.meta_worker:
            return                     # from a worker that was stopped (e.g. the cache was cleared meanwhile)
        try:
            self.index().set_meta(batch)
        except Exception:  # noqa: BLE001
            log.exception("could not store metadata")
        touched = {}
        for fid, mtime_ns, m in batch:
            for g, c in self._copies_by_id.get(fid, []):
                c.width, c.height, c.duration_s = m.width, m.height, m.duration
                c.taken, c.birth_ns, c.meta_error, c.has_meta = m.taken or "", m.birth_ns, m.error, True
                touched[id(g)] = g
        # better information may change the recommendation - but never override the user's own choices
        for g in touched.values():
            if not getattr(g, "user_touched", False):
                viewmodel.apply_recommendation(g, preselect=g.mode == "content")
        self.results.refresh_views()
        if self.dossier.group is not None and id(self.dossier.group) in touched:
            self.dossier.refresh()
        self._status_timer.start()          # counting the selection walks every copy: once per 200 ms

    # ------------------------------------------------------------------ selection
    def _copy_clicked(self, group, i):
        self.dossier.show_copy(group, i)

    def _selection_changed(self, group, *_):
        group.user_touched = True   # from now on, new metadata won't change this group's selection
        self.results.refresh_views()
        self.update_status()

    def _toggle_filters(self, on):
        self.results.filters.setVisible(on)
        if not on:
            self.results.filters.clear()

    def _set_view(self, name):
        self.stack.setCurrentWidget(self.results)
        self.results.set_view(name)

    # ------------------------------------------------------------------ scanning
    def scan_config(self) -> ScanConfig:
        s = self.settings
        if s["entire_computer"]:
            cfg = ScanConfig.entire_computer()
        else:
            cfg = ScanConfig(roots=s["roots"] if s["roots"] else default_roots())
        cfg.excludes = s.excludes()
        cfg.sniff_unknown = bool(s["sniff_unknown"])
        cfg.min_size = int(s["min_size"] or 1)
        return cfg

    def start_scan(self):
        if self.demo:
            from .scan_screen import demo_feed
            self.stack.setCurrentWidget(self.scan_screen)
            if not self.scan_screen.log.toPlainText():
                demo_feed(self.scan_screen)
            self.scan_screen.radar.start()
            return
        if self.scan_worker and self.scan_worker.isRunning():
            self.stack.setCurrentWidget(self.scan_screen)
            return
        cfg = self.scan_config()
        ss = self.scan_screen
        ss.log.clear()
        ss.pause_btn.setChecked(False)
        ss.set_stats("0", "0 B", "—", tr("listing"), 0, "")
        ss.log_line(f"{time.strftime('%H:%M:%S')}  Scan started")
        for r in cfg.roots:
            ss.log_line(f"{time.strftime('%H:%M:%S')}  Looking in {short_path(r)}")
        self.stack.setCurrentWidget(ss)
        ss.radar.start()
        self._scan_t0 = time.monotonic()
        self._last_line = 0.0
        self._last_folder = ""
        w = ScanWorker(self.db_path, cfg, self)
        w.progress.connect(self._scan_progress)
        w.done.connect(self._scan_done)
        w.failed.connect(self._failed)
        w.finished.connect(w.deleteLater)
        self.scan_worker = w
        if self.meta_worker and self.meta_worker.isRunning():
            self.meta_worker.stop = True
        w.start()
        self.update_status()

    def _scan_progress(self, e):
        ss = self.scan_screen
        now = time.monotonic()
        stamp = hms(now - self._scan_t0)[3:]
        phase = e.get("phase")
        if phase == "listing":
            ss.set_stats(f"{e['files']:,}".replace(",", " "), "—", "—", tr("listing"), 5,
                         short_path(e.get("current", "")))
            folder = os.path.dirname(e.get("current", ""))
            if folder and folder != self._last_folder and now - self._last_line > .35:
                self._last_line, self._last_folder = now, folder
                ss.log_line(f"{stamp}  {e['files']:>7} files so far · {short_path(folder)}")
                ss.radar.contact()
        elif phase == "skipped":
            ss.log_line(f"{stamp}  Skipped {short_path(e['path'])} ({e['reason']})")
        elif phase == "partial":
            pct = 10 + int(30 * e["done"] / max(1, e["total"]))
            ss.set_stats(ss.stat_files.value.text(), "—", "—", tr("hashing"), pct, short_path(e.get("current", "")))
            if now - self._last_line > 1:
                self._last_line = now
                ss.log_line(f"{stamp}  Quick check {e['done']} of {e['total']} same-size files")
                ss.radar.contact()
        elif phase == "full":
            done, total = e["bytes"], max(1, e["total_bytes"])
            el = now - self._scan_t0
            rate = done / max(.5, el)
            eta = hms((total - done) / rate) if rate > 0 and done else "—"
            ss.set_stats(ss.stat_files.value.text(), human(done), eta, tr("hashing"),
                         40 + int(58 * done / total), "")
            if now - self._last_line > 1:
                self._last_line = now
                ss.log_line(f"{stamp}  Comparing contents · {human(done)} of {human(total)}")
        elif phase == "grouped":
            ss.log_line(f"{stamp}  Found {e['groups']} groups of duplicates")

    def _scan_done(self, res):
        ss = self.scan_screen
        ss.radar.stop()
        self.scan_worker = None
        self.last_scan = self.index().last_scan()
        if res.status == "cancelled":
            ss.log_line("Scan cancelled")
            self.stack.setCurrentWidget(self.results)
            self.update_status()
            return
        ss.set_stats(f"{res.files:,}".replace(",", " "), ss.stat_hashed.value.text(), "00:00:00",
                     tr("summary_report"), 100, "")
        self.settings["last_roots"] = self.scan_config().roots
        ug = viewmodel.from_content_groups(res.groups)
        self._prepare_groups(ug)
        self.results.set_groups(ug, "content")
        self.sidebar.tabs["same_content"].setChecked(True)
        self.sidebar.set_count("same_content", len(ug))
        self.sidebar.set_count("same_name", None)
        self.stack.setCurrentWidget(self.results)
        self._select_first()
        self.update_status()
        from .sounds import sounds
        sounds().play("bell")
        SummaryDialog(res, self).exec()
        self._start_metadata(ug)

    def _pause(self, paused):
        w = self.scan_worker
        if not w:
            return
        if paused:
            w.control.pause()
            self.scan_screen.pause_btn.set_text("resume")
            self.scan_screen.radar.stop()
        else:
            w.control.resume()
            self.scan_screen.pause_btn.set_text("pause")
            self.scan_screen.radar.start()

    def _cancel_scan(self):
        if self.scan_worker and self.scan_worker.isRunning():
            self.scan_worker.control.cancel()
        else:
            self.stack.setCurrentWidget(self.results)

    def _failed(self, details):
        log.error(details)
        self.scan_worker = None
        self.scan_screen.radar.stop()
        self.stack.setCurrentWidget(self.results)
        if self.results.state == "loading":
            self.results.set_state("none")
        box = QMessageBox(QMessageBox.Icon.Critical, "Something went wrong",
                          "Something went wrong. Nothing was changed on disk.\n"
                          f"Details were written to {paths.state_dir() / 'clone-ranger.log'}", parent=self)
        box.setDetailedText(details)
        box.exec()

    # ------------------------------------------------------------------ export
    def export_csv(self):
        groups = self.results.visible
        if not groups:
            self.flash(tr("no_duplicates"))
            return
        default = os.path.join(os.path.expanduser("~"), f"clone-ranger-report-{time.strftime('%Y-%m-%d')}.csv")
        path, _ = QFileDialog.getSaveFileName(self, tr("export_csv"), default, "CSV (*.csv)")
        if not path:
            return
        rows = ({"case": g.number, "kind": g.kind, "hash": g.hash, "size_bytes": c.size, "copies": g.inodes,
                 "reclaim_bytes": g.reclaim, "path": c.path, "recommended_keep": c.keep,
                 "selected_for_removal": c.selected, "hard_link_of": c.hard_link_of or "",
                 "shared_on_disk": c.shared, "reason": g.reason} for g in groups for c in g.copies)
        n = write_csv(path, rows)
        self.flash(f"{tr('export_csv').rstrip('…')}: {n} → {short_path(path)}")
