"""Settings page.

Appearance (theme, reduce motion, sounds) takes effect at once. Keep rules, preferred folders
and protected folders take effect on "Apply & save", with a live preview of how many groups
would get a different suggestion. Hand-made choices are never overridden.
"History & cache" shows what Clone Ranger remembers and offers Clear / Reset (carried out by the window).
"""
from __future__ import annotations

import os

from PySide6.QtCore import Qt, Signal
from PySide6.QtGui import QFont
from PySide6.QtWidgets import (QAbstractItemView, QButtonGroup, QCheckBox, QFileDialog, QHBoxLayout, QLabel,
                               QListWidget, QListWidgetItem, QRadioButton, QScrollArea, QVBoxLayout, QWidget)

from ..core import recommend
from ..theme import fonts
from ..theme.strings import tr
from ..theme.style import theme
from ..util import short_path
from .sounds import sounds
from .widgets import Button, Card, SectionTitle, field_label, muted


def _note(key: str) -> QLabel:
    return muted(key, px=13)


def _section(lay, key, icon=None) -> Card:
    card = Card(padding=(20, 16, 20, 18), spacing=8)
    card.lay.addWidget(SectionTitle(key, px=18))
    lay.addWidget(card)
    return card


class FolderList(QWidget):
    """A list of folders with Add / Remove (and optionally Reset)."""
    changed = Signal()

    def __init__(self, defaults: list[str] | None = None, parent=None):
        super().__init__(parent)
        self.defaults = defaults
        lay = QVBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        self.list = QListWidget()
        self.list.setObjectName("Panel")
        self.list.setFont(fonts.mono(13))
        self.list.setMaximumHeight(120)
        self.list.setSelectionMode(QAbstractItemView.SelectionMode.ExtendedSelection)
        lay.addWidget(self.list)
        row = QHBoxLayout()
        add = Button("add_folder", "folder", size="small")
        rem = Button("remove", "cancel", size="small")
        add.clicked.connect(self._add)
        rem.clicked.connect(self._remove)
        row.addWidget(add)
        row.addWidget(rem)
        if defaults is not None:
            reset = Button("Restore default", "reset", variant="ghost", size="small")
            reset.clicked.connect(lambda: self.set_folders(defaults) or self.changed.emit())
            row.addWidget(reset)
        row.addStretch(1)
        lay.addLayout(row)

    def set_folders(self, folders):
        self.list.clear()
        for f in folders:
            item = QListWidgetItem(short_path(os.path.expanduser(f)))
            item.setData(Qt.ItemDataRole.UserRole, os.path.expanduser(f))
            item.setToolTip(os.path.expanduser(f))
            self.list.addItem(item)

    def folders(self) -> list[str]:
        return [self.list.item(i).data(Qt.ItemDataRole.UserRole) for i in range(self.list.count())]

    def add_folder(self, d: str):
        d = os.path.abspath(os.path.expanduser(d))
        if d not in self.folders():
            item = QListWidgetItem(short_path(d))
            item.setData(Qt.ItemDataRole.UserRole, d)
            item.setToolTip(d)
            self.list.addItem(item)
            self.changed.emit()

    def _add(self):
        d = QFileDialog.getExistingDirectory(self, tr("add_folder"), os.path.expanduser("~"))
        if d:
            self.add_folder(d)

    def _remove(self):
        for item in self.list.selectedItems():
            self.list.takeItem(self.list.row(item))
        self.changed.emit()


class SettingsPage(QWidget):
    saved = Signal()
    clearRequested = Signal()        # "Clear history & cache…"
    resetRequested = Signal()        # "Reset to defaults…"

    def __init__(self, settings, parent=None):
        super().__init__(parent)
        self.settings = settings
        self.impact_fn = None        # (rules, protected_folders) -> (changed, total); set by the window
        self.data_info_fn = None     # () -> (cache_bytes, history_actions); set by the window
        outer = QVBoxLayout(self)
        outer.setContentsMargins(28, 22, 28, 14)
        outer.setSpacing(10)
        outer.addWidget(SectionTitle("settings", px=26))
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QScrollArea.Shape.NoFrame)
        body = QWidget()
        body.setObjectName("SettingsBody")
        lay = QVBoxLayout(body)
        lay.setContentsMargins(0, 4, 12, 4)
        lay.setSpacing(14)
        scroll.setWidget(body)
        scroll.viewport().setAutoFillBackground(False)
        body.setAutoFillBackground(False)
        outer.addWidget(scroll, 1)

        # ---------------------------------------------------------------- appearance
        card = _section(lay, "appearance")
        card.lay.addWidget(field_label("theme"))
        row = QHBoxLayout()
        row.setSpacing(18)
        self.theme_group = QButtonGroup(self)
        self.theme_radios = {}
        for key, label in (("auto", "theme_auto"), ("light", "theme_light"), ("dark", "theme_dark"),
                           ("plain", "plain_mode")):
            rb = QRadioButton(tr(label))
            rb.toggled.connect(lambda on, k=key: on and self._set_theme(k))
            self.theme_group.addButton(rb)
            self.theme_radios[key] = rb
            row.addWidget(rb)
        row.addStretch(1)
        card.lay.addLayout(row)
        card.lay.addSpacing(4)
        self.reduce_motion = QCheckBox(tr("reduce_motion"))
        self.reduce_motion.toggled.connect(self._set_motion)
        card.lay.addWidget(self.reduce_motion)
        card.lay.addWidget(_note("reduce_motion_note"))
        srow = QHBoxLayout()
        self.sounds = QCheckBox(tr("sounds"))
        self.sounds.toggled.connect(self._set_sounds)
        srow.addWidget(self.sounds)
        self.test_sound = Button("test_sound", "volume", variant="ghost", size="small")
        self.test_sound.clicked.connect(lambda: sounds().play("stamp", force=True))
        srow.addWidget(self.test_sound)
        srow.addStretch(1)
        card.lay.addLayout(srow)

        # ---------------------------------------------------------------- keep rules
        card = _section(lay, "keep_rules")
        card.lay.addWidget(_note("keep_rules_note"))
        rules_row = QHBoxLayout()
        self.rules = QListWidget()
        self.rules.setObjectName("Panel")
        self.rules.setFont(fonts.body(14))
        self.rules.setMinimumHeight(250)
        self.rules.setDragDropMode(QAbstractItemView.DragDropMode.InternalMove)
        self.rules.itemChanged.connect(lambda _i: self._update_impact())
        self.rules.model().rowsMoved.connect(lambda *_: self._fix_locked())
        rules_row.addWidget(self.rules, 1)
        btns = QVBoxLayout()
        self.up_btn = Button("move_up", None, size="small")
        self.down_btn = Button("move_down", None, size="small")
        self.rules_reset = Button("Restore default", "reset", variant="ghost", size="small")
        self.up_btn.clicked.connect(lambda: self._move_rule(-1))
        self.down_btn.clicked.connect(lambda: self._move_rule(+1))
        self.rules_reset.clicked.connect(lambda: self._load_rules(recommend.default_config()))
        for b in (self.up_btn, self.down_btn, self.rules_reset):
            btns.addWidget(b)
        btns.addStretch(1)
        rules_row.addLayout(btns)
        card.lay.addLayout(rules_row)
        card.lay.addSpacing(6)
        card.lay.addWidget(field_label("preferred_folders"))
        card.lay.addWidget(_note("preferred_note"))
        self.preferred = FolderList(defaults=recommend.DEFAULT_PREFERRED)
        self.preferred.changed.connect(self._update_impact)
        card.lay.addWidget(self.preferred)

        # ---------------------------------------------------------------- protected folders
        card = _section(lay, "protected_folders")
        card.lay.addWidget(_note("protected_note"))
        self.protected = FolderList()
        self.protected.changed.connect(self._update_impact)
        card.lay.addWidget(self.protected)

        # ---------------------------------------------------------------- history & cache
        card = _section(lay, "data_privacy")
        card.lay.addWidget(_note("data_privacy_note"))
        self.data_info = QLabel("")
        self.data_info.setProperty("role", "accent")
        self.data_info.setFont(fonts.body(13.5, QFont.Weight.DemiBold))
        card.lay.addWidget(self.data_info)
        drow = QHBoxLayout()
        self.clear_btn = Button("clear_data", "clear", variant="soft")
        self.reset_btn = Button("reset_defaults", "reset")
        self.clear_btn.clicked.connect(self.clearRequested)
        self.reset_btn.clicked.connect(self.resetRequested)
        drow.addWidget(self.clear_btn)
        drow.addWidget(self.reset_btn)
        drow.addStretch(1)
        card.lay.addLayout(drow)
        lay.addStretch(1)

        save_row = QHBoxLayout()
        info = QVBoxLayout()
        self.impact = QLabel("")                   # live preview, always visible next to the button
        self.impact.setFont(fonts.body(13))
        self.impact.setWordWrap(True)
        self.status = QLabel("")
        self.status.setProperty("role", "muted")
        info.addWidget(self.impact)
        info.addWidget(self.status)
        save_row.addLayout(info, 1)
        self.save_btn = Button("apply_save", "check", variant="primary")
        self.save_btn.clicked.connect(self.save)
        save_row.addWidget(self.save_btn)
        outer.addLayout(save_row)
        theme().changed.connect(self._sync_theme)
        theme().changed.connect(self._restyle)
        self._restyle()
        self.load()

    def _restyle(self):
        """Visible tick boxes in the rule list in every theme (on: filled, off: empty frame)."""
        c = theme().colors
        if theme().plain:
            self.rules.setStyleSheet("")
            return
        from ..theme.style import CHECK
        self.rules.setStyleSheet(
            f"QListWidget::item {{ padding: 7px 6px; }}"
            f"QListWidget::indicator {{ width: 16px; height: 16px; border: 2px solid {c.line}; "
            f"border-radius: 5px; background: {c.surface}; }}"
            f"QListWidget::indicator:checked {{ background: {c.accent}; border-color: {c.accent}; "
            f"image: url(\"{CHECK}\"); }}")
        self.findChild(QWidget, "SettingsBody").setStyleSheet("QWidget#SettingsBody { background: transparent; }")

    # ------------------------------------------------------------------ load / save
    def load(self):
        s = self.settings
        self._sync_theme()
        self.reduce_motion.blockSignals(True)
        self.reduce_motion.setChecked(bool(s["reduce_motion"]))
        self.reduce_motion.blockSignals(False)
        self.sounds.blockSignals(True)
        self.sounds.setChecked(bool(s["sounds"]))
        self.sounds.blockSignals(False)
        self._load_rules(s["keep_rules"] if s["keep_rules"] is not None else recommend.default_config())
        self.preferred.set_folders(s["preferred_folders"] if s["preferred_folders"] is not None
                                   else recommend.DEFAULT_PREFERRED)
        self.protected.set_folders(s["protected_folders"] or [])
        self.status.setText("")
        self._update_impact()
        self.update_data_info()

    def update_data_info(self):
        if self.data_info_fn is None:
            self.data_info.setText("")
            return
        from ..util import human
        cache_bytes, actions = self.data_info_fn()
        self.data_info.setText(f"{tr('cache_size', size=human(cache_bytes))}   ·   {tr('history_size', n=actions)}")

    def _load_rules(self, config):
        self.rules.blockSignals(True)
        self.rules.clear()
        for key, on in recommend.normalize_config(config):
            item = QListWidgetItem(tr(f"rule_{key}"))
            item.setData(Qt.ItemDataRole.UserRole, key)
            flags = Qt.ItemFlag.ItemIsEnabled | Qt.ItemFlag.ItemIsSelectable
            if key in recommend.LOCKED:
                item.setToolTip(tr("rule_locked"))
            else:
                flags |= Qt.ItemFlag.ItemIsUserCheckable | Qt.ItemFlag.ItemIsDragEnabled
            item.setFlags(flags)
            item.setCheckState(Qt.CheckState.Checked if on else Qt.CheckState.Unchecked)
            self.rules.addItem(item)
        self.rules.blockSignals(False)
        self._update_impact()

    def rule_config(self) -> list[list]:
        out = []
        for i in range(self.rules.count()):
            item = self.rules.item(i)
            out.append([item.data(Qt.ItemDataRole.UserRole), item.checkState() == Qt.CheckState.Checked])
        return recommend.normalize_config(out)

    def preferred_folders(self) -> list[str]:
        return self.preferred.folders()

    def current_rules(self):
        return recommend.build_rules(self.rule_config(), self.preferred_folders())

    def save(self):
        s = self.settings
        cfg = self.rule_config()
        s["keep_rules"] = None if cfg == recommend.normalize_config(recommend.default_config()) else cfg
        pref = self.preferred_folders()
        defaults = [os.path.expanduser(p) for p in recommend.DEFAULT_PREFERRED]
        s["preferred_folders"] = None if pref == defaults else pref
        s["protected_folders"] = self.protected.folders()
        try:
            s.save()
        except OSError as e:
            self.status.setText(str(e))
            return
        self.saved.emit()

    # ------------------------------------------------------------------ appearance (instant)
    def _sync_theme(self):
        rb = self.theme_radios.get(theme().key)
        if rb is not None and not rb.isChecked():
            rb.blockSignals(True)
            rb.setChecked(True)
            rb.blockSignals(False)

    def _set_theme(self, key):
        if theme().key != key:
            theme().apply(key)
        self.settings["theme"] = key

    def _set_motion(self, on):
        theme().reduce_motion = on
        self.settings["reduce_motion"] = on
        theme().changed.emit()          # running animations (progress ring) re-check the setting

    def _set_sounds(self, on):
        sounds().enabled = on
        self.settings["sounds"] = on

    # ------------------------------------------------------------------ rules
    def _move_rule(self, step):
        row = self.rules.currentRow()
        new = row + step
        if row < 1 or new < 1 or new >= self.rules.count():     # row 0 (protected) stays first
            return
        item = self.rules.takeItem(row)
        self.rules.insertItem(new, item)
        self.rules.setCurrentRow(new)
        self._update_impact()

    def _fix_locked(self):
        """Drag-and-drop can't move another rule above the protected-folder rule."""
        for i in range(self.rules.count()):
            if self.rules.item(i).data(Qt.ItemDataRole.UserRole) in recommend.LOCKED and i != 0:
                self.rules.insertItem(0, self.rules.takeItem(i))
                break
        self._update_impact()

    def _update_impact(self, *_):
        if self.impact_fn is None:
            self.impact.setText("")
            return
        changed, total = self.impact_fn(self.current_rules(), self.protected.folders())
        self.impact.setText(tr("rules_impact", n=changed, total=total))
