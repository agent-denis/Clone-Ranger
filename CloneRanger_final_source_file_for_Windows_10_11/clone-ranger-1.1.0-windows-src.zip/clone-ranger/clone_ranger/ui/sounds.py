"""Optional sound effects (Settings → Sounds; off by default).

Internal ids (the file names): stamp - an action finished ("All done") · bell - a scan finished ·
type - an action was confirmed.
Uses QSoundEffect (PySide6-Addons). Without it, or without an audio device, it stays silent.
"""
from __future__ import annotations

from pathlib import Path

SOUND_DIR = Path(__file__).resolve().parent.parent / "theme" / "sounds"
NAMES = ("stamp", "bell", "type")


class SoundBoard:
    def __init__(self):
        self.enabled = False
        self.volume = 0.6
        self._effects = {}
        self.played: list[str] = []      # what was played (for tests)

    def _effect(self, name):
        if name in self._effects:
            return self._effects[name]
        eff = None
        try:
            from PySide6.QtCore import QUrl
            from PySide6.QtMultimedia import QSoundEffect
            eff = QSoundEffect()
            eff.setSource(QUrl.fromLocalFile(str(SOUND_DIR / f"{name}.wav")))
            eff.setVolume(self.volume)
        except Exception:  # noqa: BLE001 - no multimedia: silent
            eff = None
        self._effects[name] = eff
        return eff

    def play(self, name: str, force: bool = False):
        """Play a sound if sounds are on (force: the Settings 'Test' button)."""
        if not (self.enabled or force) or name not in NAMES:
            return
        self.played.append(name)
        eff = self._effect(name)
        if eff is not None:
            eff.play()


_board = None


def sounds() -> SoundBoard:
    global _board
    if _board is None:
        _board = SoundBoard()
    return _board
