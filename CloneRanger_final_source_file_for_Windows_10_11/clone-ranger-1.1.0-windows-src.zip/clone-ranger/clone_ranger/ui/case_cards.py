"""Group cards: each duplicate group painted as a rounded card with a row of photo tiles.

Cards are drawn by a delegate inside a QListView, so only visible cards cost anything - this is what
keeps 200,000+ files smooth. The photo tiles (rounded, clipped picture) are cached in QPixmapCache;
badges, tick boxes and text are painted on top each time (cheap).
"""
from PySide6.QtCore import QAbstractListModel, QEvent, QModelIndex, QPointF, QRectF, QSize, Qt, Signal
from PySide6.QtGui import QColor, QFont, QFontMetricsF, QPainter, QPainterPath, QPen, QPixmap, QPixmapCache
from PySide6.QtWidgets import QAbstractItemView, QListView, QMenu, QStyle, QStyledItemDelegate

from ..theme import art, fonts
from ..theme.strings import tr
from ..theme.style import theme
from ..util import human

FRAME_W, FRAME_H = 168, 126      # photo tile (4:3)
PHOTO_W, PHOTO_H = FRAME_W, FRAME_H
TEXT_H = 56                      # name / folder / size under each tile
COL_GAP = 18
HEADER_H = 64                    # title row inside the card
FOOTER_H = 44                    # suggestion row
PAD = 22                         # inner padding of the card
CARD_H = 10 + HEADER_H + 16 + FRAME_H + TEXT_H + FOOTER_H + 14
RADIUS = 16
GroupRole = Qt.ItemDataRole.UserRole + 1


class GroupsModel(QAbstractListModel):
    def __init__(self, groups, parent=None):
        super().__init__(parent)
        self.groups = groups

    def set_groups(self, groups):
        self.beginResetModel()
        self.groups = groups
        self.endResetModel()

    def rowCount(self, parent=QModelIndex()):
        return 0 if parent.isValid() else len(self.groups)

    def data(self, index, role=Qt.ItemDataRole.DisplayRole):
        if not index.isValid():
            return None
        g = self.groups[index.row()]
        if role == GroupRole:
            return g
        if role in (Qt.ItemDataRole.DisplayRole, Qt.ItemDataRole.AccessibleTextRole):
            return (f"{tr('case_no', n=f'{g.number:04d}')}: {len(g.copies)} copies of {g.copies[0].name}, "
                    f"{tr('space_reclaim').lower()} {human(g.reclaim)}")
        return None


# --------------------------------------------------------------------------- shared helpers
def _elide(text, font, width, mode=Qt.TextElideMode.ElideMiddle):
    return QFontMetricsF(font).elidedText(text, mode, max(0, width))


def crop_to(img, w: float, h: float) -> QRectF:
    """Centre crop of `img` with the aspect ratio w:h."""
    iw, ih = img.width(), img.height()
    if iw * h > ih * w:
        cw = ih * w / h
        return QRectF((iw - cw) / 2, 0, cw, ih)
    ch = iw * h / w
    return QRectF(0, (ih - ch) / 2, iw, ch)


def paint_placeholder(p: QPainter, r: QRectF, kind: str, error: str | None, pending: bool):
    """'No picture' tile: pending (three dots) or failed (icon + NO PREVIEW + the reason)."""
    c = theme().colors
    p.save()
    p.setRenderHint(QPainter.RenderHint.Antialiasing)
    p.fillRect(r, QColor(c.surface_alt))
    if pending:
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(QColor(c.text_muted))
        for i in (-1, 0, 1):
            p.drawEllipse(QPointF(r.center().x() + i * 14, r.center().y()), 3.5, 3.5)
    else:
        ic = art.icon("play" if kind == "video" else "eye", c.text_muted).pixmap(QSize(26, 26))
        p.drawPixmap(QPointF(r.center().x() - 13, r.top() + max(6, r.height() * .18)), ic)
        p.setFont(fonts.label(10.5))
        p.setPen(QColor(c.text_muted))
        p.drawText(r.adjusted(0, r.height() * .18 + 32, 0, 0), Qt.AlignmentFlag.AlignHCenter | Qt.AlignmentFlag.AlignTop,
                   tr("no_preview"))
        if error:
            p.setFont(fonts.body(10))
            p.drawText(r.adjusted(8, r.height() * .18 + 50, -8, -4),
                       Qt.AlignmentFlag.AlignHCenter | Qt.TextFlag.TextWordWrap, error)
    p.restore()


def paint_play_glyph(p: QPainter, ctr: QPointF, r: float = 17):
    p.save()
    p.setRenderHint(QPainter.RenderHint.Antialiasing)
    p.setPen(Qt.PenStyle.NoPen)
    p.setBrush(QColor(0, 0, 0, 120))
    p.drawEllipse(ctr, r, r)
    p.setBrush(QColor("#FFFFFF"))
    tri = QPainterPath()
    tri.moveTo(ctr.x() - r * .32, ctr.y() - r * .5)
    tri.lineTo(ctr.x() + r * .55, ctr.y())
    tri.lineTo(ctr.x() - r * .32, ctr.y() + r * .5)
    tri.closeSubpath()
    p.drawPath(tri)
    p.restore()


def status_badge(c):
    """(text, background, foreground, icon) of the badge for a copy, or None."""
    col = theme().colors
    if c.keep:
        return tr("keep_original"), col.success, col.on_success, "check"
    if c.selected:
        return tr("duplicate"), col.danger, col.on_danger, "trash"
    if c.hard_link:
        return tr("hard_link_short"), col.info, col.on_info, "link"
    return None


def paint_badges(p: QPainter, photo: QRectF, c, px: float = 10.5):
    """Status badge bottom-left and PROTECTED badge top-right, on top of a photo tile."""
    b = status_badge(c)
    if b:
        text, bg, fg, ic = b
        h = px * 2.0
        art.paint_pill(p, photo.left() + 8, photo.bottom() - h - 8, text, bg, fg, px, ic)
    if c.protected:
        art.paint_pill(p, photo.right() - 8, photo.top() + 8, tr("protected"), "#D7141024", "#FFFFFF", px, "lock",
                       align_right=True)


def unselect_reason(c) -> str:
    """Why a copy can't be selected ("" if it can)."""
    if c.keep:
        return tr("cant_select_keep")
    if c.protected:
        return tr("cant_select_protected")
    if c.keep_twin:
        return tr("cant_select_link")
    return ""


def copy_menu(parent, pos, g, c, changed):
    """Right-click menu on a copy: select / unselect this file, unselect the whole group.
    `changed(group)` is called after the selection changed."""
    m = QMenu(parent)
    a_file = m.addAction(art.icon("unselect" if c.selected else "select", theme().colors.text),
                         tr("unselect_file") if c.selected else tr("select_file"))
    a_file.setEnabled(c.selectable)
    if not c.selectable:
        a_file.setToolTip(unselect_reason(c))
    a_group = m.addAction(art.icon("unselect", theme().colors.text), tr("unselect_group"))
    a_group.setEnabled(any(x.selected for x in g.copies))
    chosen = m.exec(pos)
    if chosen is a_file and c.selectable:
        c.selected = not c.selected
        changed(g)
    elif chosen is a_group:
        for x in g.copies:
            x.selected = False
        changed(g)


# --------------------------------------------------------------------------- the card delegate
class CaseCardDelegate(QStyledItemDelegate):
    copyClicked = Signal(object, int)     # group, copy index
    selectionToggled = Signal(object, int)

    def __init__(self, thumbs, parent=None):
        super().__init__(parent)
        self.thumbs = thumbs
        self.current = (None, 0)      # (group, copy index) with keyboard focus

    def sizeHint(self, option, index):
        return QSize(max(400, option.rect.width()), CARD_H)

    # ------------------------------------------------------------------ geometry
    @staticmethod
    def _body(rect: QRectF) -> QRectF:
        return QRectF(rect).adjusted(14, 6, -16, -8)

    def _columns(self, rect: QRectF, n: int):
        """Rects of the visible copy columns (tile + text) and how many copies are hidden."""
        body = self._body(rect)
        x0, y0 = body.left() + PAD, body.top() + HEADER_H + 16
        avail = body.width() - 2 * PAD
        fit = max(1, int((avail + COL_GAP) // (FRAME_W + COL_GAP)))
        shown = n if n <= fit else max(1, fit - 1)   # leave room for the "+N" tile
        cols = [QRectF(x0 + i * (FRAME_W + COL_GAP), y0, FRAME_W, FRAME_H + TEXT_H) for i in range(shown)]
        return cols, n - shown

    @staticmethod
    def checkbox_rect(col: QRectF) -> QRectF:
        return QRectF(col.left() + 9, col.top() + 9, 24, 24)

    def copy_at(self, rect: QRectF, g, pos) -> int:
        cols, _ = self._columns(rect, len(g.copies))
        for i, col in enumerate(cols):
            if col.contains(pos):
                return i
        return -1

    # ------------------------------------------------------------------ painting
    def paint(self, p: QPainter, option, index):
        g = index.data(GroupRole)
        c = theme().colors
        plain = theme().plain
        dpr = p.device().devicePixelRatioF() if p.device() else 1.0
        p.save()
        p.setRenderHints(QPainter.RenderHint.Antialiasing | QPainter.RenderHint.TextAntialiasing |
                         QPainter.RenderHint.SmoothPixmapTransform)
        rect = QRectF(option.rect)
        body = self._body(rect)
        selected = bool(option.state & QStyle.StateFlag.State_Selected)

        # card surface
        if not plain:
            art.paint_shadow(p, body, RADIUS, c.shadow)
        p.setPen(QPen(QColor(c.accent if selected else c.line), 2 if selected else 1))
        p.setBrush(QColor(c.surface))
        p.drawRoundedRect(body.adjusted(.5, .5, -.5, -.5), RADIUS, RADIUS)
        # gradient accent on the left edge
        accent = QRectF(body.left() + 1, body.top() + 18, 4, HEADER_H - 22)
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(QColor(c.accent) if plain else art.button_gradient(accent))
        p.drawRoundedRect(accent, 2, 2)

        self._paint_header(p, c, body, g)

        # copies
        cols, hidden = self._columns(rect, len(g.copies))
        for i, col in enumerate(cols):
            self._paint_copy(p, c, plain, dpr, g, i, col)
        cur_g, cur_i = self.current
        if cur_g is g and cur_i < len(cols) and option.state & QStyle.StateFlag.State_HasFocus:
            p.setPen(QPen(QColor(c.accent), 2))
            p.setBrush(Qt.BrushStyle.NoBrush)
            p.drawRoundedRect(cols[cur_i].adjusted(-6, -6, 6, 2), 14, 14)
        if hidden > 0:
            last = cols[-1]
            box = QRectF(last.right() + COL_GAP, last.top(), min(110, FRAME_W), FRAME_H)
            p.setPen(Qt.PenStyle.NoPen)
            p.setBrush(QColor(c.accent_soft))
            p.drawRoundedRect(box, 12, 12)
            p.setFont(fonts.heading(24))
            p.setPen(QColor(c.accent_text))
            p.drawText(box.adjusted(0, -12, 0, 0), Qt.AlignmentFlag.AlignCenter, f"+{hidden}")
            p.setFont(fonts.label(10))
            p.drawText(box.adjusted(0, 30, 0, 0), Qt.AlignmentFlag.AlignCenter, tr("copies"))

        self._paint_footer(p, c, body, g)
        p.restore()

    def _paint_header(self, p, c, body, g):
        x = body.left() + PAD
        top = body.top() + 14
        # title: Group 0042 · Photos
        tf = fonts.heading(17)
        title = tr("case_no", n=f"{g.number:04d}")
        p.setFont(tf)
        p.setPen(QColor(c.text))
        tw = QFontMetricsF(tf).horizontalAdvance(title)
        p.drawText(QRectF(x, top, tw + 4, 24), Qt.AlignmentFlag.AlignVCenter, title)
        kind = tr("images" if g.kind == "image" else "videos")
        p.setFont(fonts.body(13.5, QFont.Weight.Medium))
        p.setPen(QColor(c.text_muted))
        p.drawText(QRectF(x + tw + 8, top, 120, 24), Qt.AlignmentFlag.AlignVCenter, f"·  {kind}")
        # second line: copies pill + name (+ fingerprint / content status)
        y2 = top + 28
        pill = art.paint_pill(p, x, y2, f"{len(g.copies)} {tr('copies')}", c.accent_soft, c.accent_text, 10)
        right_w = 200
        info_x = pill.right() + 12
        avail = body.right() - PAD - right_w - info_x
        extra = ""
        if g.mode == "name":
            word = tr({"same": "content_same", "different": "content_different"}.get(g.content, "content_unknown"))
            extra = f"{tr('content')}: {word}"
        elif g.hash and avail > 420:
            h = g.hash.split(":")[-1]
            extra = f"{tr('f_hash')} {h[:8]}…{h[-6:]}"
        nf = fonts.body(13.5, QFont.Weight.DemiBold)
        ef = fonts.mono(12)
        extra_w = QFontMetricsF(ef).horizontalAdvance(extra) + 24 if extra else 0
        p.setFont(nf)
        p.setPen(QColor(c.text))
        name = _elide(g.display_name, nf, avail - extra_w)
        nw = QFontMetricsF(nf).horizontalAdvance(name)
        p.drawText(QRectF(info_x, y2, nw + 4, pill.height()), Qt.AlignmentFlag.AlignVCenter, name)
        if extra:
            p.setFont(ef)
            p.setPen(QColor(c.text_muted))
            p.drawText(QRectF(info_x + nw + 16, y2, extra_w, pill.height()), Qt.AlignmentFlag.AlignVCenter, extra)
        # right: SPACE TO FREE + value
        rx = body.right() - PAD - right_w
        p.setFont(fonts.label(10.5))
        p.setPen(QColor(c.text_muted))
        p.drawText(QRectF(rx, top + 2, right_w, 16), Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter,
                   tr("space_reclaim"))
        p.setFont(fonts.number(22))
        p.setPen(QColor(c.accent_text))
        p.drawText(QRectF(rx, top + 18, right_w, 30), Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter,
                   human(g.reclaim) if g.is_duplicate else "—")
        # divider
        p.setPen(QPen(QColor(c.line), 1))
        p.drawLine(QPointF(body.left() + PAD, body.top() + HEADER_H + 4),
                   QPointF(body.right() - PAD, body.top() + HEADER_H + 4))

    def _paint_footer(self, p, c, body, g):
        fy = body.bottom() - FOOTER_H + 2
        band = QRectF(body.left() + PAD - 8, fy, body.width() - 2 * PAD + 16, FOOTER_H - 14)
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(QColor(c.surface_alt))
        p.drawRoundedRect(band, 10, 10)
        ic = art.icon("sparkle", c.accent_text).pixmap(QSize(16, 16), p.device().devicePixelRatioF()
                                                       if p.device() else 1.0)
        p.drawPixmap(QPointF(band.left() + 10, band.center().y() - 8), ic)
        lf = fonts.label(10.5)
        p.setFont(lf)
        p.setPen(QColor(c.accent_text))
        rec = tr("recommendation")
        lw = QFontMetricsF(lf).horizontalAdvance(rec)
        p.drawText(QRectF(band.left() + 32, band.top(), lw + 4, band.height()), Qt.AlignmentFlag.AlignVCenter, rec)
        bf = fonts.body(13)
        p.setFont(bf)
        p.setPen(QColor(c.text))
        tx = band.left() + 44 + lw
        reason = g.reason or tr("same_name_reason")
        p.drawText(QRectF(tx, band.top(), band.right() - tx - 10, band.height()), Qt.AlignmentFlag.AlignVCenter,
                   _elide(reason, bf, band.right() - tx - 10, Qt.TextElideMode.ElideRight))

    def _tile_pixmap(self, c, plain, dpr, g, i) -> QPixmap:
        """The rounded, clipped photo tile. Same-content groups share one picture (cached once)."""
        src = g.copies[0] if g.mode == "content" else g.copies[i]
        img = self.thumbs.image(src)
        state = "ok" if img is not None else ("wait" if self.thumbs.is_pending(src) else "err")
        key = f"tile:{theme().key}:{c.key}:{self.thumbs.key_for(src)}:{state}:{g.kind}:{dpr}"
        pm = QPixmapCache.find(key)
        if pm:
            return pm
        pm = QPixmap(round(FRAME_W * dpr), round(FRAME_H * dpr))
        pm.setDevicePixelRatio(dpr)
        pm.fill(Qt.GlobalColor.transparent)
        q = QPainter(pm)
        q.setRenderHints(QPainter.RenderHint.Antialiasing | QPainter.RenderHint.SmoothPixmapTransform)
        photo = QRectF(0, 0, FRAME_W, FRAME_H)
        q.setClipPath(art.rounded(photo, 12))
        if img is not None:
            q.drawImage(photo, img, crop_to(img, FRAME_W, FRAME_H))
            if g.kind == "video":
                paint_play_glyph(q, photo.center())
        else:
            paint_placeholder(q, photo, src.kind, self.thumbs.error(src), state == "wait")
        q.end()
        QPixmapCache.insert(key, pm)
        return pm

    def _paint_copy(self, p, c, plain, dpr, g, i, col: QRectF):
        cp = g.copies[i]
        photo = QRectF(col.left(), col.top(), FRAME_W, FRAME_H)
        p.drawPixmap(photo.topLeft(), self._tile_pixmap(c, plain, dpr, g, i))
        if cp.selected:     # rose ring around a tile marked for removal
            p.setPen(QPen(QColor(c.danger), 3))
            p.setBrush(Qt.BrushStyle.NoBrush)
            p.drawRoundedRect(photo.adjusted(1.5, 1.5, -1.5, -1.5), 11, 11)
        elif cp.keep:
            p.setPen(QPen(QColor(c.success), 3))
            p.setBrush(Qt.BrushStyle.NoBrush)
            p.drawRoundedRect(photo.adjusted(1.5, 1.5, -1.5, -1.5), 11, 11)
        if g.kind == "video" and cp.duration:
            f = fonts.body(11, QFont.Weight.DemiBold)
            w = QFontMetricsF(f).horizontalAdvance(cp.duration) + 14
            badge = QRectF(photo.right() - w - 8, photo.bottom() - 28, w, 20)
            p.setPen(Qt.PenStyle.NoPen)
            p.setBrush(QColor(0, 0, 0, 170))
            p.drawRoundedRect(badge, 10, 10)
            p.setFont(f)
            p.setPen(QColor("#FFFFFF"))
            p.drawText(badge, Qt.AlignmentFlag.AlignCenter, cp.duration)
        if cp.selectable and not cp.hard_link:
            art.paint_check(p, self.checkbox_rect(col), cp.selected, c)
        paint_badges(p, photo, cp)

        # name, folder, size under the tile
        ty = photo.bottom() + 8
        nf = fonts.body(13, QFont.Weight.DemiBold)
        p.setFont(nf)
        p.setPen(QColor(c.text))
        p.drawText(QRectF(col.left() + 2, ty, FRAME_W - 4, 18), Qt.AlignmentFlag.AlignLeft, _elide(cp.name, nf, FRAME_W - 4))
        sf = fonts.body(12)
        p.setFont(sf)
        p.setPen(QColor(c.text_muted))
        p.drawText(QRectF(col.left() + 2, ty + 18, FRAME_W - 4, 16), Qt.AlignmentFlag.AlignLeft,
                   _elide(cp.folder, sf, FRAME_W - 4))
        p.drawText(QRectF(col.left() + 2, ty + 34, FRAME_W - 4, 16), Qt.AlignmentFlag.AlignLeft, human(cp.size))

    # ------------------------------------------------------------------ mouse
    def editorEvent(self, event, model, option, index):
        if event.type() != QEvent.Type.MouseButtonRelease or event.button() != Qt.MouseButton.LeftButton:
            return False
        g = index.data(GroupRole)
        cols, _ = self._columns(QRectF(option.rect), len(g.copies))
        pos = event.position()
        for i, col in enumerate(cols):
            if self.checkbox_rect(col).adjusted(-5, -5, 5, 5).contains(pos):
                cp = g.copies[i]
                if cp.selectable and not cp.hard_link:
                    cp.selected = not cp.selected
                    self.selectionToggled.emit(g, i)
                return True
            if col.contains(pos):
                self.copyClicked.emit(g, i)
                return False
        return False


class CaseList(QListView):
    copyChanged = Signal(object, int)   # group, copy index (keyboard / current card)
    openRequested = Signal(object, int)  # group, copy index (Enter / double-click -> viewer)

    def __init__(self, model, thumbs, parent=None):
        super().__init__(parent)
        self.setModel(model)
        self.delegate = CaseCardDelegate(thumbs, self)
        self.setItemDelegate(self.delegate)
        self.setUniformItemSizes(True)
        self.setVerticalScrollMode(QAbstractItemView.ScrollMode.ScrollPerPixel)
        self.verticalScrollBar().setSingleStep(24)
        self.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
        self.setMouseTracking(True)
        self.setSpacing(4)
        self.setFrameShape(QListView.Shape.NoFrame)
        self.setMinimumWidth(420)
        self.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.setContextMenuPolicy(Qt.ContextMenuPolicy.DefaultContextMenu)
        self.delegate.selectionToggled.connect(lambda *_: self.viewport().update())
        self.delegate.copyClicked.connect(self._clicked_copy)
        theme().changed.connect(self.viewport().update)

    def currentChanged(self, current, previous):
        super().currentChanged(current, previous)
        if current.isValid():
            g = current.data(GroupRole)
            i = self.delegate.current[1] if self.delegate.current[0] is g else 0
            self.delegate.current = (g, i)
            self.copyChanged.emit(g, i)

    def _clicked_copy(self, g, i):
        self.delegate.current = (g, i)
        self.viewport().update()

    def contextMenuEvent(self, e):
        idx = self.indexAt(e.pos())
        if not idx.isValid():
            return
        g = idx.data(GroupRole)
        i = self.delegate.copy_at(QRectF(self.visualRect(idx)), g, QPointF(e.pos()))
        if i < 0:
            i = self.delegate.current[1] if self.delegate.current[0] is g else 0
        self.setCurrentIndex(idx)
        self.delegate.current = (g, i)
        self.copyChanged.emit(g, i)
        copy_menu(self, e.globalPos(), g, g.copies[i], lambda grp: self.delegate.selectionToggled.emit(grp, i))

    def keyPressEvent(self, e):
        """Left / Right move between the copies inside the current group."""
        g, i = self.delegate.current
        if g is not None and e.key() in (Qt.Key.Key_Return, Qt.Key.Key_Enter):
            self.openRequested.emit(g, i)
            return
        if g is not None and e.key() in (Qt.Key.Key_Left, Qt.Key.Key_Right):
            i = max(0, min(len(g.copies) - 1, i + (1 if e.key() == Qt.Key.Key_Right else -1)))
            self.delegate.current = (g, i)
            self.copyChanged.emit(g, i)
            self.viewport().update()
            return
        super().keyPressEvent(e)

    def mouseDoubleClickEvent(self, e):
        super().mouseDoubleClickEvent(e)
        g, i = self.delegate.current
        if g is not None and self.indexAt(e.position().toPoint()).isValid():
            self.openRequested.emit(g, i)

    def resizeEvent(self, e):
        super().resizeEvent(e)
        self.doItemsLayout()
