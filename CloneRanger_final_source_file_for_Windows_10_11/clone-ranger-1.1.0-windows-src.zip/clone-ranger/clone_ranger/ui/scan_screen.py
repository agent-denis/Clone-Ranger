"""The scanning screen: an animated progress ring in the brand gradient, live numbers, an activity log,
and Pause / Cancel.
"""
import math
import random

from PySide6.QtCore import QPointF, QRectF, Qt, QTimer, Signal
from PySide6.QtGui import QColor, QConicalGradient, QFont, QPainter, QPen
from PySide6.QtWidgets import (QGridLayout, QHBoxLayout, QLabel, QPlainTextEdit, QProgressBar, QSizePolicy,
                               QVBoxLayout, QWidget)

from ..theme import fonts
from ..theme.palettes import GRADIENT
from ..theme.strings import tr
from ..theme.style import theme
from .widgets import Button, Card, SectionTitle, Stat, field_label


class ProgressRing(QWidget):
    """A round progress gauge: a gradient arc for the percentage, a gently spinning highlight while running,
    and short-lived sparkles when files are found. Respects 'reduce motion' (and reacts to it live)."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.angle = 0.0                      # spinner position, degrees
        self.percent = 0
        self.sparks: list[list[float]] = []   # [angle_deg, age]
        self.setMinimumSize(190, 190)
        self.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        self.timer = QTimer(self)
        self.timer.timeout.connect(self._tick)
        self.running = False
        theme().changed.connect(self._motion_changed)

    def _motion_changed(self):
        """'Reduce motion' switched while scanning: stop or restart the animation."""
        if self.running:
            if theme().reduce_motion:
                self.timer.stop()
            elif not self.timer.isActive():
                self.timer.start(33)
        self.update()

    def start(self):
        self.running = True
        if not theme().reduce_motion:
            self.timer.start(33)
        self.update()

    def stop(self):
        self.running = False
        self.timer.stop()
        self.update()

    def set_percent(self, pct: int):
        self.percent = max(0, min(100, int(pct)))
        self.update()

    def contact(self):
        """A little sparkle on the ring (called when files are found)."""
        self.sparks.append([self.angle + random.uniform(-25, 25), 0.0])
        self.sparks = self.sparks[-24:]

    def _tick(self):
        self.angle = (self.angle + 4.0) % 360
        for s in self.sparks:
            s[1] += .04
        self.sparks = [s for s in self.sparks if s[1] < 1.0]
        self.update()

    def paintEvent(self, _):
        c = theme().colors
        p = QPainter(self)
        p.setRenderHints(QPainter.RenderHint.Antialiasing | QPainter.RenderHint.TextAntialiasing)
        side = min(self.width(), self.height(), 380) - 24
        rect = QRectF((self.width() - side) / 2, (self.height() - side) / 2, side, side)
        ctr, R = rect.center(), side / 2
        thick = max(12.0, side * .075)
        ring = rect.adjusted(thick / 2, thick / 2, -thick / 2, -thick / 2)

        # soft halo + inner disc
        p.setPen(Qt.PenStyle.NoPen)
        halo = QColor(c.accent)
        halo.setAlpha(28 if c.dark else 18)
        p.setBrush(halo)
        p.drawEllipse(ctr, R + 8, R + 8)
        p.setBrush(QColor(c.surface))
        p.drawEllipse(ctr, R - thick, R - thick)

        # track
        p.setPen(QPen(QColor(c.surface_alt), thick, Qt.PenStyle.SolidLine, Qt.PenCapStyle.FlatCap))
        p.setBrush(Qt.BrushStyle.NoBrush)
        p.drawEllipse(ring)

        # progress arc in the brand gradient (starts at 12 o'clock, clockwise)
        grad = QConicalGradient(ctr, 100)           # Qt's conical gradient runs counter-clockwise:
        for i, col in enumerate(GRADIENT):          # reverse it so the arc goes red -> orange -> yellow clockwise
            grad.setColorAt(1 - i / (len(GRADIENT) - 1) * .999, QColor(col))
        if theme().plain:
            pen = QPen(QColor(c.accent), thick, Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap)
        else:
            pen = QPen(grad, thick, Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap)
        if self.percent > 0:
            p.setPen(pen)
            p.drawArc(ring, 90 * 16, -int(360 * 16 * self.percent / 100))

        # spinning highlight while running
        if self.running and not theme().reduce_motion:
            hl = QColor("#FFFFFF")
            hl.setAlpha(150 if c.dark else 200)
            p.setPen(QPen(hl, thick * .34, Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap))
            p.drawArc(ring, int((90 - self.angle) * 16), -40 * 16)
            p.setPen(Qt.PenStyle.NoPen)
            for ang, age in self.sparks:
                col = QColor(GRADIENT[1])
                col.setAlpha(int(220 * (1 - age)))
                p.setBrush(col)
                a = math.radians(ang - 90)
                rr = R + 4 + age * 18
                p.drawEllipse(QPointF(ctr.x() + rr * math.cos(a), ctr.y() + rr * math.sin(a)), 3.5 * (1 - age) + 1,
                              3.5 * (1 - age) + 1)

        # the number
        p.setPen(QColor(c.text))
        p.setFont(fonts.number(max(26, side * .2), QFont.Weight.ExtraBold))
        p.drawText(QRectF(rect.left(), ctr.y() - side * .2, side, side * .26), Qt.AlignmentFlag.AlignCenter,
                   f"{self.percent}%")
        p.setPen(QColor(c.text_muted))
        p.setFont(fonts.label(max(10, side * .036)))
        state = "Scanning" if self.running else ("Done" if self.percent >= 100 else "Paused")
        p.drawText(QRectF(rect.left(), ctr.y() + side * .07, side, side * .1), Qt.AlignmentFlag.AlignCenter, state)


class ScanScreen(QWidget):
    pauseRequested = Signal(bool)
    cancelRequested = Signal()

    def __init__(self, parent=None):
        super().__init__(parent)
        lay = QHBoxLayout(self)
        lay.setContentsMargins(24, 22, 24, 22)
        lay.setSpacing(22)

        left = Card(padding=(18, 18, 18, 18))
        self.ring = ProgressRing()
        self.radar = self.ring                 # historical name used by main_window / tools
        left.lay.addWidget(self.ring, 1)
        self.current = QLabel("…")
        self.current.setFont(fonts.mono(12))
        self.current.setProperty("role", "muted")
        self.current.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.current.setSizePolicy(QSizePolicy.Policy.Ignored, QSizePolicy.Policy.Preferred)
        left.lay.addWidget(self.current)
        lay.addWidget(left, 5)

        right = QVBoxLayout()
        right.setSpacing(14)
        self.title = SectionTitle("surveillance", subtitle="Nothing is changed while scanning – files are only read.",
                                  px=28)
        right.addWidget(self.title)

        stats = QGridLayout()
        stats.setHorizontalSpacing(12)
        stats.setVerticalSpacing(12)
        self.stat_files = Stat("0", "files_found", icon="search")
        self.stat_hashed = Stat("0 B", "data_hashed", icon="same_content")
        self.stat_eta = Stat("—", "time_left", icon="history")
        self.stat_phase = Stat(tr("listing"), "phase", accent=True, icon="sparkle")
        self.stat_phase.value.setFont(fonts.body(15.5, QFont.Weight.Bold))   # a phrase, not a number
        self.stat_phase.value.setWordWrap(True)
        for i, w in enumerate((self.stat_files, self.stat_hashed, self.stat_eta, self.stat_phase)):
            stats.addWidget(w, i // 2, i % 2)
        right.addLayout(stats)
        self.progress = QProgressBar()
        self.progress.setTextVisible(False)
        self.progress.setFixedHeight(8)
        right.addWidget(self.progress)

        right.addWidget(field_label("scan_log"))
        self.log = QPlainTextEdit()
        self.log.setReadOnly(True)
        self.log.setProperty("role", "log")
        self.log.setMaximumBlockCount(400)
        self.log.setLineWrapMode(QPlainTextEdit.LineWrapMode.NoWrap)
        self.log.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        right.addWidget(self.log, 1)

        btns = QHBoxLayout()
        btns.addStretch(1)
        self.pause_btn = Button("pause", "pause", checkable=True)
        self.cancel_btn = Button("cancel", "cancel", variant="danger")
        self.pause_btn.toggled.connect(self.pauseRequested)
        self.cancel_btn.clicked.connect(self.cancelRequested)
        btns.addWidget(self.pause_btn)
        btns.addWidget(self.cancel_btn)
        right.addLayout(btns)
        lay.addLayout(right, 7)

    # --- API used by the main window ---
    def set_stats(self, files: str, hashed: str, eta: str, phase: str, percent: int, current: str):
        self.stat_files.value.setText(files)
        self.stat_hashed.value.setText(hashed)
        self.stat_eta.value.setText(eta)
        self.stat_phase.value.setText(phase)
        self.progress.setValue(percent)
        self.ring.set_percent(percent)
        self.current.setText(current)

    def log_line(self, line: str):
        self.log.appendPlainText(line)

    teletype = log_line                         # historical name


def demo_feed(screen: ScanScreen, steps: int = 60):
    """Fill the scan screen with plausible fake progress (demo mode - nothing is read from disk)."""
    folders = ["~/Pictures/2023/Summer", "~/Pictures/Family", "~/Pictures/Trips", "~/Downloads", "~/Videos",
               "~/Desktop/old phone", "~/Documents/print", "/run/media/me/BACKUP/Photos/2023",
               "~/Pictures/Archive 2021", "~/Pictures/Pets/best"]
    rnd = random.Random(5)
    files, hashed = 0, 0.0
    for i in range(steps):
        f = folders[i % len(folders)]
        n = rnd.randrange(8, 140)
        files += n
        hashed += n * rnd.uniform(1.5, 6.0)
        screen.log_line(f"{i * 2 // 60:02d}:{i * 2 % 60:02d}  Found {n} files in {f}")
        if i % 3 == 0:
            screen.ring.contact()
    screen.log_line("02:00  Comparing 1 284 files that have the same size")
    screen.set_stats(f"{files:,}".replace(",", " "), f"{hashed / 1024:.1f} GB", "00:02:41",
                     tr("hashing"), 64, "~/Pictures/2023/Summer/IMG_2041.jpg")
