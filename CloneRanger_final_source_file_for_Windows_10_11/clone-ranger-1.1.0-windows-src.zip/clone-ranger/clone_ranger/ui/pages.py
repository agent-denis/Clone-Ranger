"""Supporting pages and panels: filters, empty states, scan locations, the scan summary."""
from __future__ import annotations

import datetime
import os

from PySide6.QtCore import QDate, Qt, Signal
from PySide6.QtGui import QFont
from PySide6.QtWidgets import (QCheckBox, QComboBox, QDateEdit, QDialog, QDoubleSpinBox, QFileDialog, QGridLayout,
                               QHBoxLayout, QLabel, QLineEdit, QListWidget, QPlainTextEdit, QVBoxLayout, QWidget)

from ..core.osinfo import WINDOWS
from ..core.scanner import DEFAULT_EXCLUDES, default_roots
from ..theme import art, fonts
from ..theme.strings import tr
from ..theme.style import theme
from ..util import hms, human, short_path
from .widgets import Button, Card, SectionTitle, field_label, muted

__all__ = ["FilterBar", "EmptyState", "LocationsPage", "PlaceholderPage", "SummaryDialog", "field_label"]


# --------------------------------------------------------------------------- filters
class FilterBar(Card):
    changed = Signal()

    def __init__(self, parent=None):
        super().__init__(parent, padding=(16, 12, 16, 12), spacing=8)
        lay = QHBoxLayout()          # row 1: type, size, folder
        lay.setSpacing(14)
        row2 = QHBoxLayout()         # row 2: dates, clear
        row2.setSpacing(10)
        self.lay.addLayout(lay)
        self.lay.addLayout(row2)

        def col(key, widget):
            box = QVBoxLayout()
            box.setSpacing(4)
            box.addWidget(field_label(key))
            box.addWidget(widget)
            lay.addLayout(box)

        self.type = QComboBox()
        self.type.addItem(tr("all_types"), "")
        self.type.addItem(tr("images"), "image")
        self.type.addItem(tr("videos"), "video")
        col("f_type", self.type)
        self.min_size = QDoubleSpinBox()
        self.min_size.setRange(0, 100_000)
        self.min_size.setDecimals(1)
        self.min_size.setSuffix(" MB")
        col("min_size", self.min_size)
        self.folder = QLineEdit()
        self.folder.setPlaceholderText(os.path.expanduser("~\\Pictures") if WINDOWS else "~/Pictures")
        self.folder.setClearButtonEnabled(True)
        self.folder.setMinimumWidth(140)
        col("folder", self.folder)
        lay.setStretch(2, 1)
        self.use_dates = QCheckBox(tr("f_created"))
        self.date_from = QDateEdit(QDate.currentDate().addYears(-5))
        self.date_to = QDateEdit(QDate.currentDate())
        for d in (self.date_from, self.date_to):
            d.setCalendarPopup(True)
            d.setDisplayFormat("yyyy-MM-dd")
        row2.addWidget(self.use_dates)
        row2.addWidget(muted("date_from", wrap=False))
        row2.addWidget(self.date_from)
        row2.addWidget(muted("date_to", wrap=False))
        row2.addWidget(self.date_to)
        row2.addStretch(1)
        self.clear_btn = Button("clear_filters", "cancel", variant="ghost", size="small")
        row2.addWidget(self.clear_btn)

        self.type.currentIndexChanged.connect(self.changed)
        self.min_size.valueChanged.connect(self.changed)
        self.folder.textChanged.connect(self.changed)
        self.use_dates.toggled.connect(self.changed)
        self.date_from.dateChanged.connect(self.changed)
        self.date_to.dateChanged.connect(self.changed)
        self.clear_btn.clicked.connect(self.clear)

    def clear(self):
        self.type.setCurrentIndex(0)
        self.min_size.setValue(0)
        self.folder.clear()
        self.use_dates.setChecked(False)
        self.date_from.setDate(QDate.currentDate().addYears(-5))
        self.date_to.setDate(QDate.currentDate())

    def accepts(self, g) -> bool:
        kind = self.type.currentData()
        if kind and g.kind != kind:
            return False
        if g.size < self.min_size.value() * 1024 * 1024:
            return False
        folder = os.path.expanduser(self.folder.text().strip())
        if folder and not any(folder.casefold() in c.path.casefold() for c in g.copies):
            return False
        if self.use_dates.isChecked():
            start = datetime.datetime.combine(self.date_from.date().toPython(), datetime.time.min).timestamp()
            end = datetime.datetime.combine(self.date_to.date().toPython(), datetime.time.max).timestamp()
            if not start <= g.oldest_ns / 1e9 <= end:
                return False
        return True

    @property
    def active(self) -> bool:
        return bool(self.type.currentData() or self.min_size.value() or self.folder.text().strip()
                    or self.use_dates.isChecked())


# --------------------------------------------------------------------------- empty states
class EmptyState(QWidget):
    """Large centred welcome / "all clean" / "no match" message."""
    scanRequested = Signal()

    def __init__(self, parent=None):
        super().__init__(parent)
        lay = QVBoxLayout(self)
        lay.addStretch(2)
        self.emblem = QLabel()
        self.emblem.setAlignment(Qt.AlignmentFlag.AlignCenter)
        lay.addWidget(self.emblem)
        lay.addSpacing(10)
        self.title = QLabel()
        self.title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.title.setFont(fonts.heading(30, QFont.Weight.ExtraBold))
        self.title.setProperty("role", "title")
        self.title.setWordWrap(True)
        lay.addWidget(self.title)
        self.body = QLabel()
        self.body.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.body.setWordWrap(True)
        self.body.setFont(fonts.body(15.5))
        self.body.setProperty("role", "muted")
        lay.addSpacing(4)
        lay.addWidget(self.body)
        lay.addSpacing(18)
        btn_row = QHBoxLayout()
        btn_row.addStretch(1)
        self.scan_btn = Button("scan", "scan", variant="primary", size="large")
        self.scan_btn.clicked.connect(self.scanRequested)
        btn_row.addWidget(self.scan_btn)
        btn_row.addStretch(1)
        lay.addLayout(btn_row)
        lay.addStretch(3)
        self._mode = "none"
        theme().changed.connect(lambda: self.show_mode(self._mode, self._detail))
        self._detail = ""

    def show_mode(self, mode: str, detail: str = ""):
        """mode: none (no scan yet) | clean (no duplicates) | filtered | loading"""
        self._mode, self._detail = mode, detail
        self.emblem.setPixmap(art.logo(112, self.devicePixelRatioF()))
        self.scan_btn.setVisible(mode in ("none", "clean"))
        if mode == "clean":
            self.title.setText(tr("archive_clean"))
            self.body.setText(detail or tr("no_duplicates"))
        elif mode == "filtered":
            self.title.setText(tr("no_match"))
            self.body.setText(detail)
        elif mode == "loading":
            self.title.setText(tr("loading") + "…")
            self.body.setText("")
        else:
            self.title.setText(tr("no_scan_yet"))
            self.body.setText(tr("press_scan"))


# --------------------------------------------------------------------------- scan locations
class LocationsPage(QWidget):
    """Choose what to scan. Saved to settings; used by the next scan."""
    saved = Signal()
    resetRequested = Signal()        # "Reset to defaults…": the window opens the reset dialog

    def __init__(self, settings, parent=None):
        super().__init__(parent)
        self.settings = settings
        lay = QVBoxLayout(self)
        lay.setContentsMargins(28, 22, 28, 18)
        lay.setSpacing(14)
        lay.addWidget(SectionTitle("scan_locations", subtitle="default_locations", px=26))
        self.title_sub = lay.itemAt(0).widget()

        folders = Card()
        folders.lay.addWidget(field_label("folder"))
        self.roots = QListWidget()
        self.roots.setObjectName("Panel")
        self.roots.setFont(fonts.mono(13))
        self.roots.setMaximumHeight(170)
        folders.lay.addWidget(self.roots)
        row = QHBoxLayout()
        self.add_btn = Button("add_folder", "folder", size="small")
        self.remove_btn = Button("remove", "cancel", size="small")
        for b in (self.add_btn, self.remove_btn):
            row.addWidget(b)
        row.addStretch(1)
        folders.lay.addLayout(row)
        self.entire = QCheckBox(tr("entire_computer") + ("   (all drives)" if WINDOWS else "   ( / )"))
        folders.lay.addWidget(self.entire)
        self.sniff = QCheckBox(tr("sniff"))
        folders.lay.addWidget(self.sniff)
        lay.addWidget(folders)

        ex = Card()
        ex_head = QHBoxLayout()
        ex_head.addWidget(field_label("excluded"))
        ex_head.addStretch(1)
        ex_head.addWidget(muted("one_per_line", wrap=False, px=12))
        ex.lay.addLayout(ex_head)
        self.excludes = QPlainTextEdit()
        self.excludes.setFont(fonts.mono(13))
        ex.lay.addWidget(self.excludes, 1)
        lay.addWidget(ex, 1)

        save_row = QHBoxLayout()
        self.reset_btn = Button("reset_defaults", "reset", variant="ghost")
        save_row.addWidget(self.reset_btn)
        save_row.addStretch(1)
        self.save_btn = Button("save", "check", variant="primary")
        save_row.addWidget(self.save_btn)
        lay.addLayout(save_row)

        self.add_btn.clicked.connect(self._add)
        self.remove_btn.clicked.connect(lambda: [self.roots.takeItem(self.roots.row(i)) for i in self.roots.selectedItems()])
        self.reset_btn.clicked.connect(self.resetRequested)
        self.entire.toggled.connect(lambda on: self.roots.setEnabled(not on))
        self.save_btn.clicked.connect(self.save)
        self.load()

    def load(self):
        s = self.settings
        self.roots.clear()
        self.roots.addItems(s["roots"] if s["roots"] is not None else default_roots())
        self.title_sub.set_subtitle(f"{tr('default_locations')}: "
                                    f"{', '.join(short_path(r) for r in default_roots())}")
        self.entire.setChecked(bool(s["entire_computer"]))
        self.sniff.setChecked(bool(s["sniff_unknown"]))
        self.excludes.setPlainText("\n".join(s.excludes()))

    def _add(self):
        d = QFileDialog.getExistingDirectory(self, tr("add_folder"), os.path.expanduser("~"))
        if d and not self.roots.findItems(d, Qt.MatchFlag.MatchExactly):
            self.roots.addItem(d)

    def save(self):
        roots = [self.roots.item(i).text() for i in range(self.roots.count())]
        self.settings["roots"] = None if roots == default_roots() else roots
        self.settings["entire_computer"] = self.entire.isChecked()
        self.settings["sniff_unknown"] = self.sniff.isChecked()
        ex = [line.strip() for line in self.excludes.toPlainText().splitlines() if line.strip()]
        self.settings["excludes"] = None if ex == DEFAULT_EXCLUDES else ex
        self.settings.save()
        self.saved.emit()


class PlaceholderPage(QWidget):
    def __init__(self, key: str, parent=None):
        super().__init__(parent)
        lay = QVBoxLayout(self)
        lay.setContentsMargins(28, 22, 28, 18)
        lay.addWidget(SectionTitle(key, subtitle="coming_soon", px=26))
        lay.addStretch(1)


# --------------------------------------------------------------------------- scan summary
class SummaryDialog(QDialog):
    """Shown after each scan: what was found and how much space can be freed."""

    def __init__(self, result, parent=None):
        super().__init__(parent)
        self.setWindowTitle(tr("summary_report"))
        self.setMinimumWidth(500)
        lay = QVBoxLayout(self)
        lay.setContentsMargins(26, 24, 26, 20)
        lay.setSpacing(14)
        top = QHBoxLayout()
        top.setSpacing(14)
        em = QLabel()
        em.setPixmap(art.logo(52, self.devicePixelRatioF()))
        top.addWidget(em, 0, Qt.AlignmentFlag.AlignTop)
        tot = result.totals
        top.addWidget(SectionTitle("summary_report", subtitle=datetime.datetime.now().strftime("%d %B %Y, %H:%M"),
                                   px=24), 1)
        lay.addLayout(top)

        hero = Card(padding=(20, 16, 20, 16), spacing=2)
        hero.lay.addWidget(field_label("space_reclaim"))
        big = QLabel()
        big.setPixmap(art.gradient_text_pixmap(human(tot["reclaim"]), fonts.heading(40, QFont.Weight.ExtraBold),
                                               self.devicePixelRatioF()))
        big.setAccessibleName(human(tot["reclaim"]))
        hero.lay.addWidget(big)
        hero.lay.addWidget(muted(f"{tot['duplicate_files']} {tr('dup_files').lower()} · "
                                 f"{tot['groups']} {tr('groups').lower()}", px=13.5))
        lay.addWidget(hero)

        rows = [("files_scanned", f"{result.files:,}".replace(",", " ")),
                ("skipped", str(result.skipped)),
                ("groups", str(tot["groups"])),
                ("dup_files", str(tot["duplicate_files"])),
                ("hard_link_short", str(tot["hard_links"])),
                ("time_taken", hms(result.seconds))]
        grid = QGridLayout()
        grid.setHorizontalSpacing(18)
        grid.setVerticalSpacing(8)
        for r, (key, value) in enumerate(rows):
            k = QLabel(tr(key))
            k.setProperty("role", "muted")
            v = QLabel(value)
            v.setFont(fonts.body(14.5, QFont.Weight.DemiBold))
            grid.addWidget(k, r, 0)
            grid.addWidget(v, r, 1, Qt.AlignmentFlag.AlignRight)
        lay.addLayout(grid)
        lay.addStretch(1)
        bottom = QHBoxLayout()
        bottom.addStretch(1)
        close = Button("continue", "chevron", variant="primary")
        close.clicked.connect(self.accept)
        close.setDefault(True)
        bottom.addWidget(close)
        lay.addLayout(bottom)
