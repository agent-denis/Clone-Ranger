"""Help menu: About Clone Ranger, and the keyboard-shortcut list (F1).

The shortcut list is built from the window's real menu actions (plus the keys that live inside the
lists and the viewer), so it can't drift out of step with the app.
"""
from __future__ import annotations

from PySide6.QtCore import Qt
from PySide6.QtGui import QColor, QFont, QKeySequence
from PySide6.QtWidgets import (QDialog, QFrame, QHBoxLayout, QHeaderView, QLabel, QSizePolicy, QTableWidget,
                               QTableWidgetItem, QVBoxLayout)

from .. import APP_ID, __version__
from ..theme import art, fonts
from ..theme.strings import tr
from ..theme.style import theme
from .widgets import Button, SectionTitle, field_label

SOURCE_URL = "https://github.com/agent-denis/clone-ranger"

# keys handled inside widgets (not menu actions): (keys, strings.py key)
EXTRA_KEYS = [
    ("← / →", "key_copies"),
    ("Enter / double-click", "key_open"),
    ("Esc", "key_close"),
]


def menu_shortcuts(window) -> list[tuple[str, str]]:
    """(keys, "Menu › Action") for every menu action that has a shortcut."""
    out = []
    for menu_action in window.menuBar().actions():
        menu = menu_action.menu()
        if menu is None:
            continue
        for act in menu.actions():
            seq = act.shortcut()
            if seq.isEmpty():
                continue
            label = act.text().replace("&", "")
            out.append((seq.toString(QKeySequence.SequenceFormat.NativeText),
                        f"{menu_action.text().replace('&', '')} › {label}"))
    return out


class ShortcutsDialog(QDialog):
    def __init__(self, window, parent=None):
        super().__init__(parent or window)
        self.setWindowTitle(tr("shortcuts"))
        self.resize(660, 660)
        lay = QVBoxLayout(self)
        lay.setContentsMargins(26, 22, 26, 20)
        lay.setSpacing(12)
        lay.addWidget(SectionTitle("shortcuts", px=24, subtitle="Everything you can do from the keyboard."))
        rows = menu_shortcuts(window)
        rows += [(keys, tr(key)) for keys, key in EXTRA_KEYS]
        self.table = QTableWidget(len(rows), 2)
        self.table.setObjectName("Panel")
        self.table.setShowGrid(False)
        self.table.setAlternatingRowColors(True)
        self.table.setHorizontalHeaderLabels([tr("keys"), tr("action_col")])
        self.table.verticalHeader().hide()
        self.table.verticalHeader().setDefaultSectionSize(34)
        self.table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        self.table.setSelectionMode(QTableWidget.SelectionMode.NoSelection)
        self.table.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.table.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeMode.ResizeToContents)
        self.table.horizontalHeader().setStretchLastSection(True)
        for r, (keys, what) in enumerate(rows):
            k = QTableWidgetItem(keys)
            k.setFont(fonts.mono(13, QFont.Weight.Bold))
            k.setForeground(QColor(theme().colors.accent_text))
            self.table.setItem(r, 0, k)
            self.table.setItem(r, 1, QTableWidgetItem(what))
        lay.addWidget(self.table, 1)
        lay.addWidget(field_label("viewer"))
        viewer = QLabel(tr("viewer_keys"))
        viewer.setWordWrap(True)
        viewer.setProperty("role", "muted")
        lay.addWidget(viewer)
        row = QHBoxLayout()
        row.addStretch(1)
        close = Button("close", None, variant="primary", size="large")
        close.clicked.connect(self.accept)
        row.addWidget(close)
        lay.addLayout(row)
        self.rows = rows


class AboutDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle(tr("about"))
        self.resize(580, 610)
        lay = QVBoxLayout(self)
        lay.setContentsMargins(32, 28, 32, 22)
        lay.setSpacing(10)
        dpr = self.devicePixelRatioF()
        logo = QLabel()
        logo.setPixmap(art.logo(104, dpr))
        logo.setAlignment(Qt.AlignmentFlag.AlignCenter)
        lay.addWidget(logo)
        name = QLabel()
        name.setPixmap(art.gradient_text_pixmap(tr("app_name"), fonts.logo(34), dpr))
        name.setAlignment(Qt.AlignmentFlag.AlignCenter)
        name.setAccessibleName(tr("app_name"))
        lay.addWidget(name)
        sub = QLabel(tr("app_subtitle"))
        sub.setProperty("role", "muted")
        sub.setFont(fonts.body(15))
        sub.setAlignment(Qt.AlignmentFlag.AlignCenter)
        lay.addWidget(sub)
        chips = QHBoxLayout()
        chips.addStretch(1)
        self.version = QLabel(f"{tr('version')} {__version__}")
        self.version.setFont(fonts.body(12.5, QFont.Weight.Bold))
        lic = QLabel("GPL-3.0-or-later")
        lic.setFont(fonts.body(12.5, QFont.Weight.Bold))
        self._chips = (self.version, lic)
        for chip in self._chips:
            chips.addWidget(chip)
        chips.addStretch(1)
        lay.addLayout(chips)
        lay.addSpacing(8)

        card = QFrame()
        card.setObjectName("Card")
        cl = QVBoxLayout(card)
        cl.setContentsMargins(18, 16, 18, 16)
        cl.setSpacing(10)
        for key in ("about_text", "license_text", "fonts_text"):
            lab = QLabel(tr(key))
            lab.setWordWrap(True)
            lab.setFont(fonts.body(13.5))
            if key != "about_text":
                lab.setProperty("role", "muted")
            lab.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
            lab.setSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Minimum)
            cl.addWidget(lab)
        lay.addWidget(card)
        link = QLabel(f'{tr("source_code")}: <a href="{SOURCE_URL}">{SOURCE_URL.removeprefix("https://")}</a>')
        link.setOpenExternalLinks(True)
        link.setTextFormat(Qt.TextFormat.RichText)
        link.setAlignment(Qt.AlignmentFlag.AlignCenter)
        lay.addWidget(link)
        appid = QLabel(APP_ID)
        appid.setFont(fonts.mono(11))
        appid.setProperty("role", "muted")
        appid.setAlignment(Qt.AlignmentFlag.AlignCenter)
        appid.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
        lay.addWidget(appid)
        lay.addStretch(1)
        row = QHBoxLayout()
        row.addStretch(1)
        close = Button("close", None, variant="primary", size="large")
        close.clicked.connect(self.accept)
        close.setDefault(True)
        row.addWidget(close)
        lay.addLayout(row)
        theme().changed.connect(self._restyle)
        self._restyle()

    def _restyle(self):
        c = theme().colors
        for chip in self._chips:
            chip.setStyleSheet(f"QLabel {{ background: {c.accent_soft}; color: {c.accent_text}; "
                               f"border: 1px solid {c.accent_soft}; border-radius: 11px; padding: 3px 12px; }}")
