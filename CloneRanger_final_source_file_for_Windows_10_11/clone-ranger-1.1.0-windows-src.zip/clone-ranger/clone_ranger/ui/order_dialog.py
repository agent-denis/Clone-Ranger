"""The confirmation dialog shown before every bulk file action ("Move 12 files to Trash?").

One dialog, three phases:
  1. preview  - exactly what will happen: action, file count, total size, destination, the file
                list (with "old → new" for moves / renames), warnings, and the confirm button
                (plus a typed confirmation for big permanent deletes, or a tick box for replacing files);
  2. running  - progress, the current file, and Cancel (stops between files);
  3. report   - a success (or "stopped") badge, the counts, and every file that was skipped or
                failed, with the reason.
Permanent deletion uses the rose "danger" colour for the icon tile and the confirm button.
"""
from PySide6.QtCore import QEasingCurve, QPropertyAnimation, QRectF, QSize, Qt, Property, Signal
from PySide6.QtGui import QColor, QFont, QPainter
from PySide6.QtWidgets import (QCheckBox, QDialog, QFrame, QGridLayout, QHBoxLayout, QLabel, QLineEdit, QListWidget,
                               QProgressBar, QSizePolicy, QVBoxLayout, QWidget)

from ..core.osinfo import TRASH_NAME
from ..theme import art, fonts
from ..theme.strings import tr
from ..theme.style import theme
from .widgets import Button, field_label, text_of

# icon + question for each action (n = number of files)
ACTION_ICON = {"move_to_trash": "trash", "delete_perm": "delete", "move": "move", "rename": "rename", "undo": "undo"}


def files_word(n: int) -> str:
    return f"{n} file" if n == 1 else f"{n} files"


def question(action_key: str, n: int) -> str:
    f = files_word(n)
    return {
        "move_to_trash": f"Move {f} to {TRASH_NAME}?",
        "delete_perm": f"Delete {f} permanently?",
        "move": f"Move {f}?",
        "rename": f"Rename {f}?",
        "undo": f"Undo and restore {f}?",
    }.get(action_key, f"{text_of(action_key)}: {f}?")


class IconTile(QWidget):
    """A rounded square with a white line icon: gradient (normal), rose (danger), green (done), amber (stopped).
    `scale` animates the little pop when the result arrives."""

    def __init__(self, icon: str, mode: str = "accent", size: int = 56, parent=None):
        super().__init__(parent)
        self.icon_name, self.mode, self._scale = icon, mode, 1.0
        self.setFixedSize(size, size)
        theme().changed.connect(self.update)

    def _get_scale(self):
        return self._scale

    def _set_scale(self, v):
        self._scale = v
        self.update()

    scale = Property(float, _get_scale, _set_scale)

    def set_mode(self, mode: str, icon: str):
        self.mode, self.icon_name = mode, icon
        self.update()

    def pop(self, animate=True):
        if not animate or theme().reduce_motion:
            self._set_scale(1.0)
            return
        self._anim = QPropertyAnimation(self, b"scale", self)
        self._anim.setDuration(240)
        self._anim.setStartValue(0.55)
        self._anim.setEndValue(1.0)
        self._anim.setEasingCurve(QEasingCurve.Type.OutBack)
        self._anim.start()

    def paintEvent(self, _):
        c = theme().colors
        p = QPainter(self)
        p.setRenderHints(QPainter.RenderHint.Antialiasing | QPainter.RenderHint.SmoothPixmapTransform)
        s = self.width() * self._scale
        r = QRectF((self.width() - s) / 2, (self.height() - s) / 2, s, s)
        p.setPen(Qt.PenStyle.NoPen)
        if self.mode == "danger":
            p.setBrush(QColor(c.danger))
        elif self.mode == "success":
            p.setBrush(QColor(c.success))
        elif self.mode == "warning":
            p.setBrush(QColor("#D97706"))
        elif theme().plain:
            p.setBrush(QColor(c.accent))
        else:
            p.setBrush(art.button_gradient(r))
        p.drawRoundedRect(r, s * .28, s * .28)
        ic = s * .5
        fg = c.on_brand if self.mode not in ("danger", "success", "warning") and not theme().plain else "#FFFFFF"
        pm = art.icon(self.icon_name, fg).pixmap(QSize(round(ic), round(ic)), self.devicePixelRatioF())
        p.drawPixmap(QRectF(r.center().x() - ic / 2, r.center().y() - ic / 2, ic, ic), pm, QRectF(pm.rect()))


class Notice(QFrame):
    """A tinted box for warnings (red) or notes (light blue)."""

    def __init__(self, lines: list[str], kind: str = "warning", parent=None):
        super().__init__(parent)
        self.kind = kind
        self.setObjectName("Notice")
        lay = QVBoxLayout(self)
        lay.setContentsMargins(14, 10, 14, 10)
        lay.setSpacing(4)
        self.labels = []
        for line in lines:
            lab = QLabel(("⚠  " if kind == "warning" else "") + line)
            lab.setWordWrap(True)
            lab.setFont(fonts.body(13, QFont.Weight.DemiBold if kind == "warning" else QFont.Weight.Normal))
            lay.addWidget(lab)
            self.labels.append(lab)
        theme().changed.connect(self._restyle)
        self._restyle()

    def _restyle(self):
        c = theme().colors
        if self.kind == "warning":
            tint, fg, edge = QColor(c.danger), c.danger_text, c.danger
        else:
            tint, fg, edge = QColor(c.accent), c.text, c.accent
        tint.setAlpha(34 if c.dark else 20)
        bg = f"rgba({tint.red()}, {tint.green()}, {tint.blue()}, {tint.alpha()})"
        self.setStyleSheet(f"QFrame#Notice {{ background: {bg}; border: 1px solid {edge}; border-radius: 12px; }}"
                           f"QFrame#Notice QLabel {{ color: {fg}; background: transparent; border: none; }}")


class OrderDialog(QDialog):
    """Confirmation for action #number. action_key is a strings.py key, e.g. 'move_to_trash'.

    signed:          the user confirmed - the caller starts the operation and calls
                     set_running() / set_progress() / show_report().
    cancelRequested: Cancel pressed while running.
    Unless `live` is set, confirming just shows the success state (demo mode).
    """
    signed = Signal()
    cancelRequested = Signal()

    def __init__(self, number: int, action_key: str, files: list[str], total_size: str, destination: str,
                 parent=None, note=None, warnings: list[str] | None = None, danger: bool = False,
                 confirm_word: str | None = None, count: int | None = None, confirm_check: str | None = None):
        super().__init__(parent)
        self.danger, self.phase, self.confirm_word = danger, "preview", confirm_word
        self.live = False    # True when the caller runs a real operation on `signed`
        self.action_key = action_key
        self.number = number
        n_files = count if count is not None else len(files)
        self.setWindowTitle(f"{tr('order_no', n=number)} · {tr(action_key)}")
        self.setModal(True)
        self.resize(660, 700 if warnings or confirm_word else 640)
        s = QVBoxLayout(self)
        s.setContentsMargins(26, 24, 26, 20)
        s.setSpacing(14)

        # header: icon tile + overline + question + note
        top = QHBoxLayout()
        top.setSpacing(16)
        self.tile = IconTile(ACTION_ICON.get(action_key, "sparkle"), "danger" if danger else "accent")
        top.addWidget(self.tile, 0, Qt.AlignmentFlag.AlignTop)
        head = QVBoxLayout()
        head.setSpacing(3)
        self.overline = QLabel(tr("order_no", n=number))
        self.overline.setFont(fonts.label(11))
        self.overline.setProperty("role", "danger" if danger else "accent")
        self.title = QLabel(question(action_key, n_files))
        self.title.setFont(fonts.heading(23))
        self.title.setProperty("role", "title")
        self.title.setWordWrap(True)
        head.addWidget(self.overline)
        head.addWidget(self.title)
        self.note = QLabel(text_of(note) if note is not None else "")
        self.note.setWordWrap(True)
        self.note.setFont(fonts.body(13.5))
        self.note.setProperty("role", "danger" if danger else "muted")
        self.note.setVisible(note is not None)
        head.addWidget(self.note)
        top.addLayout(head, 1)
        s.addLayout(top)

        # summary: Action · Files · Total size · Destination
        card = QFrame()
        card.setObjectName("Card")
        grid = QGridLayout(card)
        grid.setContentsMargins(18, 14, 18, 14)
        grid.setHorizontalSpacing(24)
        grid.setVerticalSpacing(2)
        rows = [("order_subject", tr(action_key)), ("file_count", str(n_files)),
                ("total_size", total_size), ("destination", destination)]
        self.values = {}
        for col, (k, value) in enumerate(rows):
            grid.addWidget(field_label(k), 0, col)
            v = QLabel(value)
            v.setFont(fonts.body(15, QFont.Weight.Bold if col < 3 else QFont.Weight.DemiBold))
            v.setProperty("role", "danger" if danger and col == 0 else "stat")
            v.setWordWrap(True)
            v.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
            grid.addWidget(v, 1, col, Qt.AlignmentFlag.AlignTop)
            self.values[k] = v
        grid.setColumnStretch(3, 1)
        s.addWidget(card)

        self.list_label = field_label("files_listed")
        s.addWidget(self.list_label)
        self.list = QListWidget()
        self.list.setObjectName("Panel")
        self.list.setFont(fonts.mono(12.5))
        self.list.addItems(files)
        self.list.setMinimumHeight(110)
        self.list.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.list.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        s.addWidget(self.list, 1)

        self.warning_box = Notice(list(warnings), "warning") if warnings else None
        self.warning_labels = self.warning_box.labels if self.warning_box else []
        if self.warning_box:
            s.addWidget(self.warning_box)

        self.confirm_edit = self.confirm_box = None
        if confirm_word is not None:
            cl = QLabel(tr("type_to_confirm", word=confirm_word))
            cl.setWordWrap(True)
            cl.setFont(fonts.body(13.5, QFont.Weight.DemiBold))
            s.addWidget(cl)
            self.confirm_edit = QLineEdit()
            self.confirm_edit.setPlaceholderText(confirm_word)
            self.confirm_edit.setAccessibleName(cl.text())
            self.confirm_edit.setFont(fonts.mono(15, QFont.Weight.Bold))
            self.confirm_edit.textChanged.connect(self._check_confirm)
            s.addWidget(self.confirm_edit)

        if confirm_check is not None:
            self.confirm_box = QCheckBox(text_of(confirm_check))
            self.confirm_box.setFont(fonts.body(13.5, QFont.Weight.DemiBold))
            self.confirm_box.toggled.connect(self._check_confirm)
            s.addWidget(self.confirm_box)

        # running phase
        self.progress = QProgressBar()
        self.progress.setRange(0, 100)
        self.progress.setTextVisible(False)
        self.progress.setFixedHeight(8)
        self.progress.hide()
        s.addWidget(self.progress)
        self.current = QLabel("")
        self.current.setFont(fonts.mono(12))
        self.current.setProperty("role", "muted")
        self.current.hide()
        s.addWidget(self.current)
        self.result_line = QLabel("")         # also shown as the header subtitle; kept for callers
        self.result_line.hide()

        btns = QHBoxLayout()
        btns.addStretch(1)
        self.cancel_btn = Button("cancel", None, size="large")
        self.sign_btn = Button(action_key, ACTION_ICON.get(action_key, "check"),
                               variant="danger" if danger else "primary", size="large")
        self.close_btn = Button("close", "check", variant="primary", size="large")
        self.close_btn.hide()
        self.cancel_btn.clicked.connect(self._cancel)
        self.sign_btn.clicked.connect(self._signed)
        self.close_btn.clicked.connect(self.accept)
        btns.addWidget(self.cancel_btn)
        btns.addWidget(self.sign_btn)
        btns.addWidget(self.close_btn)
        s.addLayout(btns)
        self.cancel_btn.setFocus()
        self._check_confirm()

    # ------------------------------------------------------------------ phases
    def _check_confirm(self, *_):
        ok = True
        if self.confirm_edit is not None:
            ok = self.confirm_edit.text().strip().casefold() == self.confirm_word.casefold()
        if self.confirm_box is not None:
            ok = ok and self.confirm_box.isChecked()
        self.sign_btn.setEnabled(ok)

    def _signed(self):
        if not self.sign_btn.isEnabled():
            return
        if not self.live:                        # demo: just show the success state
            self.show_done()
            return
        from .sounds import sounds
        sounds().play("type")
        self.signed.emit()

    def _cancel(self):
        if self.phase == "running":
            self.cancel_btn.setEnabled(False)
            self.current.setText(f"{tr('cancelling')}…")
            self.cancelRequested.emit()
        else:
            self.reject()

    def reject(self):
        if self.phase == "running":   # Esc / window close while running = ask to cancel, never abandon
            self._cancel()
            return
        super().reject()

    def set_running(self):
        self.phase = "running"
        self.sign_btn.hide()
        for w in (self.confirm_edit, self.confirm_box):
            if w is not None:
                w.setEnabled(False)
        self.progress.show()
        self.current.show()
        self.progress.setValue(0)
        self.cancel_btn.setFocus()

    def set_progress(self, fraction: float, text: str = ""):
        self.progress.setValue(int(round(100 * max(0.0, min(1.0, fraction)))))
        if text and self.cancel_btn.isEnabled():
            self.current.setText(text)

    def _finished_look(self, title: str, subtitle: str, ok: bool, animate: bool):
        self.tile.set_mode("success" if ok else "warning", "check" if ok else "cancel")
        self.tile.pop(animate)
        self.overline.setProperty("role", "success" if ok else "warning")
        self.overline.style().unpolish(self.overline)
        self.overline.style().polish(self.overline)
        self.title.setText(title)
        self.note.setText(subtitle)
        self.note.show()
        self.note.setProperty("role", "muted")
        self.note.style().unpolish(self.note)
        self.note.style().polish(self.note)
        if self.warning_box is not None:
            self.warning_box.hide()
        from .sounds import sounds
        sounds().play("stamp")

    def show_report(self, summary: str, problems: list[str], interrupted: bool = False, animate=True):
        """Phase 3: counts + every skipped/failed file with its reason."""
        self.phase = "report"
        self.progress.setValue(100)
        self.progress.hide()
        self.current.hide()
        self.cancel_btn.hide()
        self.sign_btn.hide()
        self.result_line.setText(summary)
        if problems:
            self.list_label.setText(tr("problems_listed"))
            self.list.clear()
            self.list.addItems(problems)
        self.close_btn.show()
        self.close_btn.setDefault(True)
        self.close_btn.setFocus()
        self._finished_look(tr("order_interrupted") if interrupted else tr("order_done"), summary,
                            not interrupted, animate)

    def show_done(self, animate=True):
        """Demo: the success state without running anything."""
        self.sign_btn.setEnabled(False)
        self.cancel_btn.setEnabled(False)
        self._finished_look(tr("order_done"), question(self.action_key, self.list.count()).rstrip("?"), True,
                            animate)
