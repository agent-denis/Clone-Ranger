"""Dummy duplicate groups for screenshots and demo mode (`python -m clone_ranger --demo`).

No real files are touched: the 'photos' are painted procedurally.
"""
import getpass
import os
import sys
import random
from functools import lru_cache

from PySide6.QtCore import QPointF, QRectF, Qt
from PySide6.QtGui import QColor, QImage, QLinearGradient, QPainter, QPainterPath, QPolygonF

from ..util import human  # noqa: F401  (re-exported for older imports)
from .viewmodel import UiCopy, UiGroup

if sys.platform == "win32":
    HOME = "C:/Users/" + getpass.getuser()
    MEDIA = "E:/BACKUP"
else:
    HOME = "/home/" + getpass.getuser()
    MEDIA = f"/run/media/{getpass.getuser()}/BACKUP"


def _hash(rnd):
    return "b3:" + "".join(rnd.choice("0123456789abcdef") for _ in range(64))


def demo_groups() -> list[UiGroup]:
    rnd = random.Random(42)
    P = f"{HOME}/Pictures"
    specs = [
        ("image", "Keep: in a preferred folder, oldest copy – in ~/Pictures/2023/Summer", [
            ("IMG_2041.jpg", f"{P}/2023/Summer", "2023-07-14 18:02", True, False),
            ("IMG_2041 (1).jpg", f"{HOME}/Downloads", "2024-01-03 09:41", False, True),
            ("IMG_2041.jpg", f"{MEDIA}/Photos/2023", "2024-02-11 21:15", False, True),
        ], 4_812_331, (4032, 3024), None),
        ("image", "Keep: in a preferred folder – in ~/Pictures/Family", [
            ("DSC_0193.jpg", f"{P}/Family", "2022-12-24 16:20", True, False),
            ("DSC_0193 - Copy.jpg", f"{HOME}/Desktop/old phone", "2023-03-02 11:05", False, True),
        ], 6_204_118, (6000, 4000), None),
        ("video", "Keep: not in Downloads/temp, name without “copy”/“(1)” – in ~/Videos", [
            ("VID_20240512_143022.mp4", f"{HOME}/Videos", "2024-05-12 14:30", True, False),
            ("VID_20240512_143022 (1).mp4", f"{HOME}/Downloads", "2024-05-13 08:12", False, True),
        ], 412_904_221, (1920, 1080), 84.0),
        ("image", "Keep: highest resolution – in ~/Pictures/Trips", [
            ("panorama_lake.png", f"{P}/Trips", "2021-08-02 10:11", True, False),
            ("panorama_lake.png", f"{MEDIA}/Photos/Trips", "2021-08-09 19:44", False, True),
            ("panorama_lake_2.png", f"{HOME}/Documents/print", "2022-01-15 12:00", False, True),
            ("panorama_lake.png", f"{P}/Archive 2021", "2022-06-30 17:25", False, False),
        ], 18_440_902, (8192, 2304), None),
        ("image", "Keep: in a protected folder – in ~/Documents/Personal", [
            ("passport_scan.jpg", f"{HOME}/Documents/Personal", "2020-04-17 08:55", True, False),
            ("passport_scan.jpg", f"{HOME}/Downloads", "2024-09-01 13:37", False, True),
        ], 1_204_330, (2480, 3508), None),
        ("image", "Keep: oldest copy – in ~/Pictures/Pets", [
            ("cat_on_roof.webp", f"{P}/Pets", "2022-05-01 07:30", True, False),
            ("cat_on_roof.webp", f"{P}/Pets/best", "2022-05-01 07:30", False, False),
        ], 845_221, (1600, 1200), None),
    ]
    import time
    groups = []
    ino = 1000
    for i, (kind, reason, copies, size, (w, h), dur) in enumerate(specs):
        g = UiGroup(number=42 + i * 7, kind=kind, hash=_hash(rnd), size=size, reason=reason, seed=rnd.randrange(10_000))
        for name, folder, created, keep, sel in copies:
            ino += 1
            ns = int(time.mktime(time.strptime(created, "%Y-%m-%d %H:%M")) * 1e9)
            g.copies.append(UiCopy(path=os.path.normpath(f"{folder}/{name}"), size=size, mtime_ns=ns, birth_ns=ns, kind=kind,
                                   inode=(1, ino), keep=keep, selected=sel, hash=g.hash, width=w, height=h,
                                   duration_s=dur, taken=created + ":00" if kind == "image" else "",
                                   has_meta=True, seed=g.seed))
        groups.append(g)
    groups[4].copies[0].protected = True                 # passport scan: protected folder
    cat = groups[5].copies
    cat[1].hard_link_of, cat[1].inode = cat[0].path, cat[0].inode   # hard link: no space wasted
    groups.sort(key=lambda g: -g.reclaim)
    return groups


@lru_cache(maxsize=64)
def fake_photo(seed: int, kind: str = "image", w: int = 400, h: int = 300) -> QImage:
    """A procedurally painted 'photo': sky, sun, hills, water. Same seed = same picture."""
    rnd = random.Random(seed)
    img = QImage(w, h, QImage.Format.Format_RGB32)
    p = QPainter(img)
    p.setRenderHint(QPainter.RenderHint.Antialiasing)
    hue = rnd.randrange(360)
    sky = QLinearGradient(0, 0, 0, h * .7)
    sky.setColorAt(0, QColor.fromHsv(hue, 120, 230))
    sky.setColorAt(1, QColor.fromHsv((hue + 30) % 360, 60, 250))
    p.fillRect(0, 0, w, h, sky)
    p.setPen(Qt.PenStyle.NoPen)
    p.setBrush(QColor.fromHsv((hue + 180) % 360, 90, 255))
    sr = rnd.uniform(.08, .14) * w
    p.drawEllipse(QPointF(rnd.uniform(.2, .8) * w, rnd.uniform(.15, .35) * h), sr, sr)
    for layer in range(3):
        base = h * (.45 + layer * .12)
        poly = QPolygonF([QPointF(0, h)])
        x = 0.0
        while x <= w:
            poly.append(QPointF(x, base - rnd.uniform(0, h * .22)))
            x += w / rnd.randrange(4, 9)
        poly.append(QPointF(w, h))
        p.setBrush(QColor.fromHsv((hue + 90 + layer * 15) % 360, 80 + layer * 40, 170 - layer * 45))
        p.drawPolygon(poly)
    water = QLinearGradient(0, h * .78, 0, h)
    water.setColorAt(0, QColor.fromHsv((hue + 200) % 360, 110, 170))
    water.setColorAt(1, QColor.fromHsv((hue + 210) % 360, 140, 110))
    p.fillRect(QRectF(0, h * .8, w, h * .2), water)
    if kind == "video":
        p.fillRect(0, 0, w, h, QColor(0, 0, 0, 60))
        path = QPainterPath()
        path.addRect(QRectF(0, 0, w, h * .08))
        path.addRect(QRectF(0, h * .92, w, h * .08))
        p.fillPath(path, QColor(0, 0, 0))
    p.end()
    return img
