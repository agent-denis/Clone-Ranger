"""Background threads so the window never freezes. Each opens its own SQLite connection."""
from __future__ import annotations

import time
import traceback

from PySide6.QtCore import QThread, Signal

from ..core import metadata
from ..core.control import Control
from ..core.duplicates import find_name_groups, groups_from_index
from ..core.index import Index
from ..core.pipeline import run
from ..core.scanner import ScanConfig


class ScanWorker(QThread):
    progress = Signal(dict)
    done = Signal(object)          # ScanResult
    failed = Signal(str)

    def __init__(self, db_path, cfg: ScanConfig, parent=None):
        super().__init__(parent)
        self.db_path, self.cfg = db_path, cfg
        self.control = Control()

    def run(self):
        try:
            idx = Index(self.db_path)
            try:
                res = run(idx, self.cfg, self.control, self.progress.emit)
            finally:
                idx.close()
            self.done.emit(res)
        except Exception:  # noqa: BLE001 - report, never crash the app
            self.failed.emit(traceback.format_exc())


class LoadWorker(QThread):
    """Rebuild results from the index without reading any file (start-up / mode switch)."""
    done = Signal(str, object, object)   # mode, groups, last_scan
    failed = Signal(str)

    def __init__(self, db_path, mode="content", ignore_case=True, ignore_ext=False, min_size=1, parent=None):
        super().__init__(parent)
        self.db_path, self.mode = db_path, mode
        self.ignore_case, self.ignore_ext, self.min_size = ignore_case, ignore_ext, min_size

    def run(self):
        try:
            idx = Index(self.db_path)
            try:
                last = idx.last_scan()
                if self.mode == "name":
                    groups = find_name_groups(idx, self.ignore_case, self.ignore_ext)
                else:
                    groups = groups_from_index(idx, self.min_size)
            finally:
                idx.close()
            self.done.emit(self.mode, groups, last)
        except Exception:  # noqa: BLE001
            self.failed.emit(traceback.format_exc())


class MetaWorker(QThread):
    """Read resolution / date taken / duration / creation date for copies that lack it."""
    batch = Signal(list)           # [(file_id, mtime_ns, Meta)]

    def __init__(self, items, parent=None):
        super().__init__(parent)
        self.items = items          # [(file_id, path, kind, mtime_ns)]
        self.stop = False

    def run(self):
        out, last = [], time.monotonic()
        for fid, path, kind, mtime_ns in self.items:
            if self.stop:
                break
            try:
                m = metadata.read(path, kind)
            except OSError as e:
                m = metadata.Meta(error=e.strerror or str(e))
            out.append((fid, mtime_ns, m))
            if len(out) >= 200 or time.monotonic() - last > 1.0:
                self.batch.emit(out)
                out, last = [], time.monotonic()
        if out:
            self.batch.emit(out)


class OpWorker(QThread):
    """Run one file operation (trash / delete / move / rename / undo) in the background.

    `job(engine) -> Report` is called in the thread with an Engine that has its own index
    connection, the action log, the protected folders, and this worker's Control (Cancel)."""
    progress = Signal(dict)
    done = Signal(object)          # operations.Report
    failed = Signal(str)

    def __init__(self, db_path, journal, protected, job, parent=None):
        super().__init__(parent)
        self.db_path, self.journal, self.protected, self.job = db_path, journal, list(protected or ()), job
        self.control = Control()

    def run(self):
        from ..core.operations import Engine
        try:
            idx = Index(self.db_path)
            try:
                eng = Engine(self.journal, idx, self.protected, self.control, self.progress.emit)
                rep = self.job(eng)
            finally:
                idx.close()
            self.done.emit(rep)
        except Exception:  # noqa: BLE001 - report, never crash the app
            self.failed.emit(traceback.format_exc())
