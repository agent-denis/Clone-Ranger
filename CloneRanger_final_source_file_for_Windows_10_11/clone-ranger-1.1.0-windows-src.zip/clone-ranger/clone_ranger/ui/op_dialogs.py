"""Dialogs that collect what an operation should do, BEFORE the confirmation preview:
Move (destination, folder structure, name conflicts), Rename (F2, one file) and
Bulk rename (all options with a live preview). None of them touches a file.
"""
from __future__ import annotations

import os

from PySide6.QtCore import Qt, QTimer
from PySide6.QtGui import QColor, QFont
from PySide6.QtWidgets import (QAbstractItemView, QButtonGroup, QCheckBox, QComboBox, QDialog, QFileDialog,
                               QGridLayout, QHBoxLayout, QHeaderView, QLabel, QLineEdit, QRadioButton, QSpinBox,
                               QTableWidget, QTableWidgetItem, QVBoxLayout, QWidget)

from ..core import bulk_rename
from ..theme import fonts
from ..theme.strings import tr
from ..theme.style import theme
from ..util import short_path
from .widgets import Button, SectionTitle, field_label


def _buttons(dlg, ok_key="continue", ok_icon="chevron"):
    row = QHBoxLayout()
    row.setSpacing(10)
    row.addStretch(1)
    cancel = Button("cancel", None, size="large")
    ok = Button(ok_key, ok_icon, variant="primary", size="large")
    cancel.clicked.connect(dlg.reject)
    ok.clicked.connect(dlg.accept)
    ok.setDefault(True)
    row.addWidget(cancel)
    row.addWidget(ok)
    return row, ok


# --------------------------------------------------------------------------- Move
class MoveDialog(QDialog):
    def __init__(self, paths: list[str], settings, parent=None):
        super().__init__(parent)
        self.paths = paths
        self.setWindowTitle(tr("move_title"))
        self.resize(640, 480)
        lay = QVBoxLayout(self)
        lay.setContentsMargins(26, 22, 26, 20)
        lay.setSpacing(10)
        lay.addWidget(SectionTitle("move_title", px=23,
                                   subtitle=f"{len(paths)} file{'s' if len(paths) != 1 else ''} · "
                                            "choose where they should go"))
        lay.addSpacing(4)
        lay.addWidget(field_label("destination"))
        row = QHBoxLayout()
        self.dest = QLineEdit(settings["last_move_dest"] or os.path.join(os.path.expanduser("~"), "Pictures"))
        self.dest.setAccessibleName(tr("destination"))
        row.addWidget(self.dest, 1)
        pick = Button("choose_folder", "folder", variant="soft")
        pick.clicked.connect(self._pick)
        row.addWidget(pick)
        lay.addLayout(row)

        dirs = [os.path.dirname(p) for p in paths]
        self.base = os.path.commonpath(dirs) if dirs else ""
        self.keep = QCheckBox(tr("keep_structure"))
        self.keep.setChecked(bool(settings["move_keep_structure"]))
        lay.addWidget(self.keep)
        self.base_label = QLabel(f"{tr('structure_from')}: {short_path(self.base)}")
        self.base_label.setProperty("role", "muted")
        self.base_label.setWordWrap(True)
        lay.addWidget(self.base_label)
        self.keep.toggled.connect(self._example)

        lay.addSpacing(6)
        lay.addWidget(field_label("on_conflict"))
        self.conflict = QButtonGroup(self)
        for key, label in (("skip", "skip"), ("number", "conflict_number"), ("overwrite", "conflict_overwrite")):
            rb = QRadioButton(tr(label))
            rb.setProperty("key", key)
            self.conflict.addButton(rb)
            lay.addWidget(rb)
            if key == (settings["move_conflict"] or "skip"):
                rb.setChecked(True)
        lay.addSpacing(6)
        lay.addWidget(field_label("preview"))
        self.example = QLabel("")
        self.example.setObjectName("Card")
        self.example.setFont(fonts.mono(12))
        self.example.setContentsMargins(12, 10, 12, 10)
        self.example.setWordWrap(True)
        self.example.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
        lay.addWidget(self.example)
        lay.addStretch(1)
        row, self.ok = _buttons(self, "move", "move")
        lay.addLayout(row)
        self.dest.textChanged.connect(self._example)
        self._example()

    def _pick(self):
        d = QFileDialog.getExistingDirectory(self, tr("choose_folder"), self.dest.text())
        if d:
            self.dest.setText(d)

    def _example(self):
        if not self.paths:
            return
        p = self.paths[0]
        d = self.destination
        if self.keep.isChecked():
            dst = os.path.join(d, os.path.relpath(os.path.dirname(p), self.base), os.path.basename(p))
        else:
            dst = os.path.join(d, os.path.basename(p))
        self.example.setText(f"{short_path(p)}\n→ {short_path(os.path.normpath(dst))}")
        self.base_label.setVisible(self.keep.isChecked())
        self.ok.setEnabled(bool(self.dest.text().strip()))

    @property
    def destination(self) -> str:
        return os.path.abspath(os.path.expanduser(self.dest.text().strip() or "."))

    @property
    def conflict_mode(self) -> str:
        b = self.conflict.checkedButton()
        return b.property("key") if b else "skip"


# --------------------------------------------------------------------------- Rename (F2)
class RenameDialog(QDialog):
    """Rename one file. The name without extension is pre-selected, like in Files."""

    def __init__(self, path: str, parent=None):
        super().__init__(parent)
        self.path = path
        self.setWindowTitle(tr("rename_file"))
        self.resize(580, 230)
        lay = QVBoxLayout(self)
        lay.setContentsMargins(26, 22, 26, 20)
        lay.setSpacing(10)
        lay.addWidget(SectionTitle("rename_file", px=22, subtitle=short_path(os.path.dirname(path)) + os.sep))
        self.edit = QLineEdit(os.path.basename(path))
        self.edit.setFont(fonts.mono(15))
        self.edit.setAccessibleName(tr("new_name"))
        lay.addWidget(self.edit)
        self.why = QLabel("")
        self.why.setProperty("role", "danger")
        lay.addWidget(self.why)
        row, self.ok = _buttons(self, "rename", "rename")
        lay.addLayout(row)
        stem, _ = bulk_rename.split_ext(os.path.basename(path))
        self.edit.setSelection(0, len(stem))
        self.edit.textChanged.connect(self._check)
        self._check()

    @property
    def new_name(self) -> str:
        return self.edit.text()

    def _check(self):
        name = self.edit.text()
        why = bulk_rename.check_name(name)
        target = os.path.join(os.path.dirname(self.path), name)
        if not why and name != os.path.basename(self.path) and os.path.lexists(target) \
                and not bulk_rename._same_file(target, self.path):
            why = "a file with this name already exists"
        self.why.setText(why)
        self.ok.setEnabled(not why and name != os.path.basename(self.path))


# --------------------------------------------------------------------------- Bulk rename
STATUS_KEYS = {"ok": "st_ok", "unchanged": "st_unchanged", "conflict": "st_conflict", "invalid": "st_invalid"}


class BulkRenameDialog(QDialog):
    def __init__(self, files: list[bulk_rename.File], parent=None):
        super().__init__(parent)
        self.files = files
        self.plan = bulk_rename.Plan()
        self.setWindowTitle(tr("bulk_rename"))
        self.resize(1080, 740)
        lay = QVBoxLayout(self)
        lay.setContentsMargins(26, 22, 26, 20)
        lay.setSpacing(12)
        lay.addWidget(SectionTitle("bulk_rename", px=23,
                                   subtitle=f"{len(files)} file{'s' if len(files) != 1 else ''} · the preview on the "
                                            "right updates as you type"))
        body = QHBoxLayout()
        body.setSpacing(18)
        lay.addLayout(body, 1)

        form = QWidget()
        form.setObjectName("Card")
        form.setAttribute(Qt.WidgetAttribute.WA_StyledBackground)
        form.setFixedWidth(450)
        g = QGridLayout(form)
        g.setContentsMargins(18, 16, 18, 16)
        g.setHorizontalSpacing(12)
        g.setVerticalSpacing(8)
        r = 0

        def add(key, w, span=1):
            nonlocal r
            g.addWidget(field_label(key), r, 0)
            g.addWidget(w, r, 1, 1, span)
            r += 1
            return w

        self.find = add("find", QLineEdit())
        self.replace = add("replace_with", QLineEdit())
        flags = QHBoxLayout()
        flags.setSpacing(18)
        self.regex = QCheckBox(tr("regex"))
        self.match_case = QCheckBox(tr("match_case"))
        self.include_ext = QCheckBox(tr("include_ext"))
        flags.addWidget(self.regex)
        flags.addWidget(self.match_case)
        flags.addStretch(1)
        g.addLayout(flags, r, 0, 1, 2)
        r += 1
        g.addWidget(self.include_ext, r, 0, 1, 2)
        r += 1
        self.prefix = add("prefix", QLineEdit())
        self.suffix = add("suffix", QLineEdit())

        self.numbering = QCheckBox(tr("numbering"))
        g.addWidget(self.numbering, r, 0, 1, 2)
        r += 1
        nums = QHBoxLayout()
        nums.setSpacing(8)
        nums.setContentsMargins(26, 0, 0, 0)
        self.num_start, self.num_step, self.num_digits = QSpinBox(), QSpinBox(), QSpinBox()
        self.num_start.setRange(0, 999999)
        self.num_start.setValue(1)
        self.num_step.setRange(1, 1000)
        self.num_digits.setRange(1, 9)
        self.num_digits.setValue(3)
        for key, w in (("num_start", self.num_start), ("num_step", self.num_step), ("num_digits", self.num_digits)):
            w.setAccessibleName(tr(key))
            lab = QLabel(tr(key))
            lab.setProperty("role", "muted")
            nums.addWidget(lab)
            nums.addWidget(w, 1)
        g.addLayout(nums, r, 0, 1, 2)
        r += 1
        numpos = QHBoxLayout()
        numpos.setSpacing(8)
        numpos.setContentsMargins(26, 0, 0, 0)
        self.num_pos = QComboBox()
        self.num_pos.addItem(tr("num_after"), "suffix")
        self.num_pos.addItem(tr("num_before"), "prefix")
        self.num_sep = QLineEdit("_")
        self.num_sep.setMaximumWidth(60)
        self.num_sep.setAccessibleName(tr("separator"))
        numpos.addWidget(self.num_pos, 1)
        sep_label = QLabel(tr("separator"))
        sep_label.setProperty("role", "muted")
        numpos.addWidget(sep_label)
        numpos.addWidget(self.num_sep)
        g.addLayout(numpos, r, 0, 1, 2)
        r += 1

        self.case = add("letter_case", QComboBox())
        for k, v in (("case_keep", "keep"), ("case_lower", "lower"), ("case_upper", "upper"), ("case_title", "title")):
            self.case.addItem(tr(k), v)

        self.date_name = QCheckBox(tr("date_name"))
        g.addWidget(self.date_name, r, 0, 1, 2)
        r += 1
        self.date_format = add("date_format", QLineEdit("%Y-%m-%d_%H-%M-%S"))
        self.date_fallback = QCheckBox(tr("date_fallback"))
        self.date_fallback.setChecked(True)
        g.addWidget(self.date_fallback, r, 0, 1, 2)
        r += 1

        ext = QHBoxLayout()
        self.ext = QComboBox()
        for k, v in (("ext_keep", "keep"), ("case_lower", "lower"), ("case_upper", "upper"), ("ext_change", "change")):
            self.ext.addItem(tr(k), v)
        self.new_ext = QLineEdit()
        self.new_ext.setPlaceholderText("jpg")
        self.new_ext.setMaximumWidth(80)
        self.new_ext.setAccessibleName(tr("ext_change"))
        ext.addWidget(self.ext, 1)
        ext.addWidget(self.new_ext)
        g.addWidget(field_label("extension"), r, 0)
        g.addLayout(ext, r, 1)
        r += 1
        self.auto_number = QCheckBox(tr("auto_number"))
        g.addWidget(self.auto_number, r, 0, 1, 2)
        r += 1
        g.setRowStretch(r, 1)
        body.addWidget(form)

        right = QVBoxLayout()
        right.setSpacing(8)
        right.addWidget(field_label("preview"))
        self.table = QTableWidget(0, 3)
        self.table.setObjectName("Panel")
        self.table.setShowGrid(False)
        self.table.setAlternatingRowColors(True)
        self.table.setHorizontalHeaderLabels([tr("old_name"), tr("new_name"), tr("status")])
        self.table.verticalHeader().hide()
        self.table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.table.setSelectionMode(QAbstractItemView.SelectionMode.NoSelection)
        self.table.setFont(fonts.mono(12))
        h = self.table.horizontalHeader()
        h.setSectionResizeMode(0, QHeaderView.ResizeMode.Stretch)
        h.setSectionResizeMode(1, QHeaderView.ResizeMode.Stretch)
        h.setSectionResizeMode(2, QHeaderView.ResizeMode.ResizeToContents)
        right.addWidget(self.table, 1)
        self.summary = QLabel("")
        self.summary.setFont(fonts.body(13.5, QFont.Weight.DemiBold))
        self.summary.setProperty("role", "accent")
        self.summary.setWordWrap(True)
        right.addWidget(self.summary)
        body.addLayout(right, 1)

        row, self.ok = _buttons(self, "continue", "rename")
        lay.addLayout(row)

        self._timer = QTimer(self, singleShot=True, interval=120)
        self._timer.timeout.connect(self.update_preview)
        for w in (self.find, self.replace, self.prefix, self.suffix, self.num_sep, self.date_format, self.new_ext):
            w.textChanged.connect(self._timer.start)
        for w in (self.regex, self.match_case, self.include_ext, self.numbering, self.date_name, self.date_fallback,
                  self.auto_number):
            w.toggled.connect(self._timer.start)
        for w in (self.num_start, self.num_step, self.num_digits):
            w.valueChanged.connect(self._timer.start)
        for w in (self.case, self.num_pos, self.ext):
            w.currentIndexChanged.connect(self._timer.start)
        self.update_preview()

    def options(self) -> bulk_rename.Options:
        return bulk_rename.Options(
            find=self.find.text(), replace=self.replace.text(), regex=self.regex.isChecked(),
            match_case=self.match_case.isChecked(), include_ext=self.include_ext.isChecked(),
            prefix=self.prefix.text(), suffix=self.suffix.text(), numbering=self.numbering.isChecked(),
            num_start=self.num_start.value(), num_step=self.num_step.value(), num_digits=self.num_digits.value(),
            num_position=self.num_pos.currentData(), num_sep=self.num_sep.text(), case=self.case.currentData(),
            date_name=self.date_name.isChecked(), date_format=self.date_format.text() or "%Y-%m-%d_%H-%M-%S",
            date_fallback="mtime" if self.date_fallback.isChecked() else "skip",
            ext=self.ext.currentData(), new_ext=self.new_ext.text(), auto_number_conflicts=self.auto_number.isChecked())

    def update_preview(self):
        self.plan = bulk_rename.plan(self.files, self.options())
        self.new_ext.setEnabled(self.ext.currentData() == "change")
        for w in (self.num_start, self.num_step, self.num_digits, self.num_pos, self.num_sep):
            w.setEnabled(self.numbering.isChecked())
        for w in (self.date_format, self.date_fallback):
            w.setEnabled(self.date_name.isChecked())
        c = theme().colors
        warn, good = QColor(c.danger_text), QColor(c.success_text)
        self.table.setUpdatesEnabled(False)
        self.table.setRowCount(len(self.plan.items))
        for row, it in enumerate(self.plan.items):
            st = tr(STATUS_KEYS[it.status]) + (f" – {it.reason}" if it.reason and it.status != "unchanged" else "")
            for col, text in enumerate((it.old_name, it.new_name, st)):
                cell = self.table.item(row, col)
                if cell is None:
                    cell = QTableWidgetItem()
                    self.table.setItem(row, col, cell)
                cell.setText(text)
                cell.setToolTip(it.path if col == 0 else text)
                if it.status in ("conflict", "invalid") and col != 0:
                    cell.setForeground(warn)
                elif it.status == "ok" and col == 2:
                    cell.setForeground(good)
                else:
                    cell.setData(Qt.ItemDataRole.ForegroundRole, None)
        self.table.setUpdatesEnabled(True)
        counts = {s: sum(1 for i in self.plan.items if i.status == s) for s in STATUS_KEYS}
        t = tr("rename_count", ok=counts["ok"], blocked=counts["conflict"] + counts["invalid"],
               same=counts["unchanged"])
        self.summary.setText((self.plan.error + "\n" if self.plan.error else "") + t)
        self.ok.setEnabled(bool(self.plan.ready) and not self.plan.error)
