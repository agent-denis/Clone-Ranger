"""Small themed building blocks used throughout Clone Ranger.

Texts: every widget takes either a key from theme/strings.py or literal text.
"""
from PySide6.QtCore import QEvent, QPointF, QRectF, QSize, Qt, Signal
from PySide6.QtGui import QColor, QFont, QFontMetricsF, QPainter, QPen
from PySide6.QtWidgets import (QAbstractButton, QButtonGroup, QFrame, QHBoxLayout, QLabel, QPushButton,
                               QSizePolicy, QVBoxLayout, QWidget)

from ..theme import art, fonts
from ..theme.strings import STRINGS, tr
from ..theme.style import theme


def text_of(text: str, **kw) -> str:
    """A strings.py key -> its text; anything else is literal text."""
    return tr(text, **kw) if text in STRINGS else text


def field_label(text: str) -> QLabel:
    """Small uppercase overline label above an input or value."""
    lab = QLabel(text_of(text))
    lab.setFont(fonts.label(11))
    lab.setProperty("role", "label")
    return lab


def muted(text: str, wrap: bool = True, px: int = 13) -> QLabel:
    lab = QLabel(text_of(text))
    lab.setProperty("role", "muted")
    lab.setFont(fonts.body(px))
    lab.setWordWrap(wrap)
    return lab


class Button(QPushButton):
    """A themed push button with a line icon.

    variant: None (outlined), "primary" (orange -> yellow gradient), "danger" (red), "soft" (pale blue), "ghost" (no border)
    size: "small" | "normal" | "large"
    """

    ICON = {"small": 16, "normal": 18, "large": 20}
    FONT = {"small": 13, "normal": 14, "large": 15.5}

    def __init__(self, text, icon: str | None = None, variant: str | None = None, size: str = "normal",
                 parent=None, checkable=False):
        super().__init__(parent)
        self.icon_name = icon
        self.variant = variant
        self.size_name = size if size in self.ICON else "normal"
        if variant:
            self.setProperty("variant", variant)
        self.setProperty("size", self.size_name)
        self.setCheckable(checkable)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setFocusPolicy(Qt.FocusPolicy.StrongFocus)
        self.setFont(fonts.body(self.FONT[self.size_name], QFont.Weight.DemiBold))
        self.setIconSize(QSize(self.ICON[self.size_name], self.ICON[self.size_name]))
        self.setSizePolicy(QSizePolicy.Policy.Maximum, QSizePolicy.Policy.Fixed)
        self.set_text(text)
        theme().changed.connect(self._refresh)
        self.toggled.connect(lambda _: self._refresh())
        self._refresh()

    def set_text(self, text, **kw):
        self.text_key = text
        label = text_of(text, **kw)
        self.setText(label.replace("&", "&&"))          # "&" would otherwise mark a keyboard mnemonic
        self.setAccessibleName(label)

    def set_icon(self, name):
        self.icon_name = name
        self._refresh()

    def changeEvent(self, e):
        if e.type() == QEvent.Type.EnabledChange:
            self._refresh()
        super().changeEvent(e)

    def _refresh(self):
        if not self.icon_name:
            return
        c = theme().colors
        if not self.isEnabled():
            color = c.text_muted
        elif theme().plain:
            color = c.danger_text if self.variant == "danger" else c.text
        elif self.variant == "primary":
            color = c.on_brand
        elif self.variant == "danger":
            color = c.on_danger
        elif self.variant == "soft" or self.isChecked():
            color = c.accent_text
        else:
            color = c.text
        self.setIcon(art.icon(self.icon_name, color))



class Segmented(QWidget):
    """A pill-shaped group of exclusive, checkable buttons (view switch: Cards | List | Grid)."""
    selected = Signal(str)

    def __init__(self, items, parent=None):
        """items: [(id, text, icon), ...]"""
        super().__init__(parent)
        self.setObjectName("Segmented")
        self.setAttribute(Qt.WidgetAttribute.WA_StyledBackground)
        lay = QHBoxLayout(self)
        lay.setContentsMargins(3, 3, 3, 3)
        lay.setSpacing(2)
        self.group = QButtonGroup(self)
        self.buttons: dict[str, Button] = {}
        for key, text, icon in items:
            b = Button(text, icon, size="small", checkable=True)
            self.group.addButton(b)
            self.buttons[key] = b
            lay.addWidget(b)
            b.clicked.connect(lambda _=False, k=key: self.selected.emit(k))

    def set_current(self, key):
        if key in self.buttons:
            self.buttons[key].setChecked(True)


class Card(QFrame):
    """A rounded surface with a border (styled by the theme)."""

    def __init__(self, parent=None, padding=(18, 16, 18, 16), spacing=10):
        super().__init__(parent)
        self.setObjectName("Card")
        self.setAttribute(Qt.WidgetAttribute.WA_StyledBackground)
        self.lay = QVBoxLayout(self)
        self.lay.setContentsMargins(*padding)
        self.lay.setSpacing(spacing)


class AccentBar(QWidget):
    """A thin strip of the brand gradient along the top of the window."""

    def __init__(self, parent=None, height=4):
        super().__init__(parent)
        self.setFixedHeight(height)

    def paintEvent(self, _):
        p = QPainter(self)
        if theme().plain:
            p.fillRect(self.rect(), QColor(theme().colors.accent))
            return
        p.fillRect(self.rect(), art.gradient(QRectF(self.rect()), diagonal=False))



class SectionTitle(QWidget):
    """A page title with an optional muted subtitle underneath."""

    def __init__(self, text, parent=None, subtitle: str | None = None, px=24, stacked=None):
        super().__init__(parent)
        lay = QVBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(2)
        self.title = QLabel(text_of(text))
        self.title.setProperty("role", "title")
        self.title.setFont(fonts.heading(px))
        lay.addWidget(self.title)
        self.subtitle = QLabel(text_of(subtitle) if subtitle else "")
        self.subtitle.setProperty("role", "muted")
        self.subtitle.setFont(fonts.body(13.5))
        self.subtitle.setWordWrap(True)
        self.subtitle.setVisible(bool(subtitle))
        lay.addWidget(self.subtitle)

    @property
    def en(self):                      # compatibility with older call sites
        return self.title

    def set_text(self, text, **kw):
        self.title.setText(text_of(text, **kw))

    def set_subtitle(self, text):
        self.subtitle.setText(text_of(text) if text else "")
        self.subtitle.setVisible(bool(text))


class Stat(QFrame):
    """A stat card: small uppercase label over a big number. accent=True paints the number in brand colour."""

    def __init__(self, value: str, text, parent=None, accent=False, icon: str | None = None):
        super().__init__(parent)
        self.setObjectName("Card")
        self.setAttribute(Qt.WidgetAttribute.WA_StyledBackground)
        self.icon_name = icon
        lay = QHBoxLayout(self)
        lay.setContentsMargins(14, 10, 18, 10)
        lay.setSpacing(12)
        self.icon = QLabel()
        self.icon.setFixedSize(34, 34)
        self.icon.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.icon.setVisible(bool(icon))
        lay.addWidget(self.icon)
        col = QVBoxLayout()
        col.setSpacing(0)
        self.label = QLabel(text_of(text))
        self.label.setFont(fonts.label(10.5))
        self.label.setProperty("role", "label")
        self.value = QLabel(value)
        self.value.setFont(fonts.number(22))
        self.value.setProperty("role", "accent" if accent else "stat")
        # long values (e.g. the scan step) may be cut rather than widening the whole window
        self.value.setSizePolicy(QSizePolicy.Policy.Ignored, QSizePolicy.Policy.Preferred)
        self.value.setMinimumWidth(60)
        col.addWidget(self.label)
        col.addWidget(self.value)
        lay.addLayout(col, 1)
        self.setSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Fixed)
        theme().changed.connect(self._restyle)
        self._restyle()

    def _restyle(self):
        if not self.icon_name:
            return
        c = theme().colors
        self.icon.setStyleSheet(f"background: {c.accent_soft}; border-radius: 10px;")
        self.icon.setPixmap(art.icon(self.icon_name, c.accent_text).pixmap(QSize(18, 18), self.devicePixelRatioF()))


class NavItem(QAbstractButton):
    """A sidebar navigation entry: icon + label + optional count. Checked = gradient pill with white text."""

    def __init__(self, text, icon: str, count: str = "", parent=None):
        super().__init__(parent)
        self.label = text_of(text)
        self.icon_name = icon
        self.count = count
        self.setCheckable(True)
        self.setAccessibleName(self.label)
        self.setToolTip(self.label)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setFocusPolicy(Qt.FocusPolicy.StrongFocus)
        self.setMinimumHeight(42)
        self.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
        theme().changed.connect(self.update)

    @property
    def pair(self):                    # compatibility: .pair.en
        class _P:
            en = self.label
        return _P

    def sizeHint(self):
        return QSize(200, 42)

    def paintEvent(self, _):
        c = theme().colors
        p = QPainter(self)
        p.setRenderHints(QPainter.RenderHint.Antialiasing | QPainter.RenderHint.TextAntialiasing)
        r = QRectF(self.rect()).adjusted(2, 2, -2, -2)
        on = self.isChecked()
        if on:
            if theme().plain:
                p.setBrush(QColor(c.accent))
            else:
                p.setBrush(art.button_gradient(r))
            p.setPen(Qt.PenStyle.NoPen)
            p.drawRoundedRect(r, 11, 11)
            fg = c.on_accent if theme().plain else c.on_brand
        else:
            if self.underMouse():
                p.setPen(Qt.PenStyle.NoPen)
                p.setBrush(QColor(c.surface_alt))
                p.drawRoundedRect(r, 11, 11)
            fg = c.text
        ic = art.icon(self.icon_name, fg).pixmap(QSize(20, 20), self.devicePixelRatioF())
        p.drawPixmap(QPointF(r.left() + 12, r.center().y() - 10), ic)
        p.setFont(fonts.body(14, QFont.Weight.DemiBold if on else QFont.Weight.Medium))
        p.setPen(QColor(fg))
        text_r = r.adjusted(42, 0, -10, 0)
        if self.count:
            f = fonts.body(12, QFont.Weight.Bold)
            w = QFontMetricsF(f).horizontalAdvance(self.count) + 16
            badge = QRectF(r.right() - w - 8, r.center().y() - 11, w, 22)
            p.save()
            p.setPen(Qt.PenStyle.NoPen)
            p.setBrush(QColor(255, 255, 255, 110) if on else QColor(c.accent_soft))
            p.drawRoundedRect(badge, 11, 11)
            p.setFont(f)
            p.setPen(QColor(fg if on else c.accent_text))
            p.drawText(badge, Qt.AlignmentFlag.AlignCenter, self.count)
            p.restore()
            text_r.setRight(badge.left() - 6)
        p.drawText(text_r, Qt.AlignmentFlag.AlignVCenter | Qt.AlignmentFlag.AlignLeft,
                   QFontMetricsF(p.font()).elidedText(self.label, Qt.TextElideMode.ElideRight, text_r.width()))
        if self.hasFocus():
            p.setPen(QPen(QColor(c.accent), 2))
            p.setBrush(Qt.BrushStyle.NoBrush)
            p.drawRoundedRect(r.adjusted(-1, -1, 1, 1), 12, 12)

    def enterEvent(self, e):
        self.update()
        super().enterEvent(e)

    def leaveEvent(self, e):
        self.update()
        super().leaveEvent(e)



class StatusBar(QWidget):
    """Bottom status line: small rounded chips (selection, index state, messages)."""

    clicked = Signal()

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setFixedHeight(34)
        self.parts: list[str] = []
        theme().changed.connect(self.update)

    def set_parts(self, parts: list[str]):
        self.parts = parts
        self.setAccessibleName(" · ".join(parts))
        self.update()

    def paintEvent(self, _):
        c = theme().colors
        p = QPainter(self)
        p.setRenderHints(QPainter.RenderHint.Antialiasing | QPainter.RenderHint.TextAntialiasing)
        p.fillRect(self.rect(), QColor(c.surface))
        p.setPen(QPen(QColor(c.line), 1))
        p.drawLine(0, 0, self.width(), 0)
        f = fonts.body(12.5, QFont.Weight.Medium)
        fm = QFontMetricsF(f)
        p.setFont(f)
        x = 12.0
        for i, part in enumerate(self.parts):
            w = fm.horizontalAdvance(part) + 20
            if x + w > self.width() - 8:
                break
            chip = QRectF(x, 6, w, self.height() - 12)
            p.setPen(Qt.PenStyle.NoPen)
            p.setBrush(QColor(c.accent_soft if i == 0 else c.surface_alt))
            p.drawRoundedRect(chip, chip.height() / 2, chip.height() / 2)
            p.setPen(QColor(c.accent_text if i == 0 else c.text_muted))
            p.drawText(chip, Qt.AlignmentFlag.AlignCenter, part)
            x += w + 8

