"""Reset to defaults / Clear history & cache - one dialog, two starting points.

    mode="reset": "Search settings" is ticked; history, cache and other settings are optional extras.
    mode="clear": "History" and "Cache" are ticked; resetting settings is optional.

The dialog only collects the choice (`choices()`); MainWindow.perform_reset() carries it out.
"""
from __future__ import annotations

from PySide6.QtCore import Qt
from PySide6.QtGui import QFont
from PySide6.QtWidgets import QCheckBox, QDialog, QFrame, QHBoxLayout, QLabel, QVBoxLayout

from ..theme import art, fonts
from ..theme.strings import tr
from ..theme.style import theme
from ..util import human
from .widgets import Button, SectionTitle, muted


class Option(QFrame):
    """A clickable card: tick box, title, explanation, optional warning line."""

    def __init__(self, key: str, title: str, note: str, icon: str, parent=None):
        super().__init__(parent)
        self.key = key
        self.setObjectName("Card")
        self.setAttribute(Qt.WidgetAttribute.WA_StyledBackground)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        lay = QHBoxLayout(self)
        lay.setContentsMargins(14, 12, 16, 12)
        lay.setSpacing(12)
        self.check = QCheckBox()
        self.check.setAccessibleName(title)
        lay.addWidget(self.check, 0, Qt.AlignmentFlag.AlignTop)
        self.icon = QLabel()
        self.icon.setFixedSize(34, 34)
        self.icon.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.icon_name = icon
        lay.addWidget(self.icon, 0, Qt.AlignmentFlag.AlignTop)
        col = QVBoxLayout()
        col.setSpacing(2)
        self.title = QLabel(title)
        self.title.setFont(fonts.body(14.5, QFont.Weight.DemiBold))
        col.addWidget(self.title)
        self.note = muted(note, px=13)
        col.addWidget(self.note)
        self.warning = QLabel("")
        self.warning.setProperty("role", "warning")
        self.warning.setWordWrap(True)
        self.warning.setFont(fonts.body(12.5, QFont.Weight.DemiBold))
        self.warning.hide()
        col.addWidget(self.warning)
        lay.addLayout(col, 1)
        self.check.toggled.connect(self._sync)
        theme().changed.connect(self._restyle)
        self._restyle()

    def mouseReleaseEvent(self, e):
        if e.button() == Qt.MouseButton.LeftButton:
            self.check.toggle()
        super().mouseReleaseEvent(e)

    def set_warning(self, text: str):
        self.warning.setText(text)
        self._sync()

    def _sync(self, *_):
        self.warning.setVisible(bool(self.warning.text()) and self.check.isChecked())

    def _restyle(self):
        c = theme().colors
        self.icon.setStyleSheet(f"background: {c.accent_soft}; border-radius: 10px;")
        self.icon.setPixmap(art.icon(self.icon_name, c.accent_text).pixmap(18, 18))


class ResetDialog(QDialog):
    def __init__(self, mode: str = "reset", cache_bytes: int = 0, history_actions: int = 0,
                 undoable_actions: int = 0, parent=None):
        super().__init__(parent)
        self.mode = mode
        clear = mode == "clear"
        self.setWindowTitle(tr("clear_data_title" if clear else "reset_title"))
        self.setMinimumWidth(560)
        lay = QVBoxLayout(self)
        lay.setContentsMargins(24, 22, 24, 20)
        lay.setSpacing(12)
        head = QHBoxLayout()
        head.setSpacing(14)
        logo = QLabel()
        logo.setPixmap(art.logo(44, self.devicePixelRatioF()))
        head.addWidget(logo, 0, Qt.AlignmentFlag.AlignTop)
        head.addWidget(SectionTitle("clear_data_title" if clear else "reset_title",
                                    subtitle="clear_data_intro" if clear else "reset_intro", px=22), 1)
        lay.addLayout(head)
        lay.addSpacing(4)

        self.options: dict[str, Option] = {}
        for key, title, note, icon in (
                ("search", tr("reset_search"), tr("reset_search_note"), "search"),
                ("preferences", tr("reset_prefs"), tr("reset_prefs_note"), "settings"),
                ("history", f"{tr('clear_history')}  ·  {tr('n_actions', n=history_actions)}",
                 tr("clear_history_note"), "history"),
                ("cache", f"{tr('clear_cache')}  ·  {human(cache_bytes)}",
                 tr("clear_cache_note", size=human(cache_bytes)), "clear")):
            o = Option(key, title, note, icon)
            o.check.toggled.connect(self._update)
            self.options[key] = o
            lay.addWidget(o)
        if undoable_actions:
            self.options["history"].set_warning(tr("clear_undo_warn", n=undoable_actions))
        defaults = ("history", "cache") if clear else ("search",)
        for k in defaults:
            self.options[k].check.setChecked(True)

        self.hint = QLabel("")
        self.hint.setProperty("role", "muted")
        lay.addWidget(self.hint)
        btns = QHBoxLayout()
        btns.addStretch(1)
        self.cancel_btn = Button("cancel", "cancel")
        self.ok_btn = Button("clear_go" if clear else "reset_go", "clear" if clear else "reset", variant="primary")
        self.cancel_btn.clicked.connect(self.reject)
        self.ok_btn.clicked.connect(self.accept)
        btns.addWidget(self.cancel_btn)
        btns.addWidget(self.ok_btn)
        lay.addLayout(btns)
        self.ok_btn.setDefault(True)
        self._update()

    def choices(self) -> dict[str, bool]:
        return {k: o.check.isChecked() for k, o in self.options.items()}

    def set_choices(self, **kw):
        for k, on in kw.items():
            self.options[k].check.setChecked(bool(on))

    def _update(self, *_):
        if not hasattr(self, "ok_btn"):          # default ticks are set before the buttons exist
            return
        ch = self.choices()
        any_on = any(ch.values())
        self.ok_btn.setEnabled(any_on)
        self.hint.setText("" if any_on else tr("reset_nothing"))
        destructive = ch["history"] or ch["cache"]
        variant = "danger" if destructive else "primary"
        if self.ok_btn.property("variant") != variant:
            self.ok_btn.variant = variant
            self.ok_btn.setProperty("variant", variant)
            self.ok_btn.style().unpolish(self.ok_btn)
            self.ok_btn.style().polish(self.ok_btn)
            self.ok_btn._refresh()
