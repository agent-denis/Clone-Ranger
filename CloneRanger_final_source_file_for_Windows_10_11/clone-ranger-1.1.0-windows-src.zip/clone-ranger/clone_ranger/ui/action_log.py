"""History page: every action Clone Ranger carried out, every file it touched, and Undo."""
from __future__ import annotations

import time

from PySide6.QtCore import Qt, Signal
from PySide6.QtGui import QColor, QFont
from PySide6.QtWidgets import (QHBoxLayout, QHeaderView, QLabel, QStackedWidget, QTreeWidget, QTreeWidgetItem,
                               QVBoxLayout, QWidget)

from ..core.journal import Journal
from ..theme import art, fonts
from ..theme.strings import tr
from ..theme.style import theme
from ..util import short_path
from .widgets import Button, SectionTitle

OP_KEYS = {"trash": "move_to_trash", "delete": "delete_perm", "move": "move", "rename": "rename", "undo": "undo"}
OP_ICONS = {"trash": "trash", "delete": "delete", "move": "move", "rename": "rename", "undo": "undo"}
MAX_FILES_SHOWN = 500   # per action; the full list stays in the log file


def op_text(o) -> str:
    if o.op == "undo" and o.undoes is not None:
        return tr("undo_of", n=o.undoes)
    return tr(OP_KEYS.get(o.op, "action_col"))


class EmptyHistory(QWidget):
    """Shown when nothing has been done yet (or after the history was cleared)."""

    def __init__(self, parent=None):
        super().__init__(parent)
        lay = QVBoxLayout(self)
        lay.addStretch(2)
        self.icon = QLabel()
        self.icon.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.icon.setFixedSize(76, 76)
        row = QHBoxLayout()
        row.addStretch(1)
        row.addWidget(self.icon)
        row.addStretch(1)
        lay.addLayout(row)
        lay.addSpacing(10)
        title = QLabel(tr("log_empty"))
        title.setFont(fonts.heading(22))
        title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        lay.addWidget(title)
        body = QLabel(f"Every action you confirm – {tr('move_to_trash')}, Delete, Move, Rename – is listed here, "
                      "and most of them can be undone.")
        body.setProperty("role", "muted")
        body.setFont(fonts.body(14))
        body.setWordWrap(True)
        body.setAlignment(Qt.AlignmentFlag.AlignCenter)
        body.setFixedWidth(460)
        brow = QHBoxLayout()
        brow.addStretch(1)
        brow.addWidget(body)
        brow.addStretch(1)
        lay.addLayout(brow)
        lay.addStretch(3)
        theme().changed.connect(self._restyle)
        self._restyle()

    def _restyle(self):
        c = theme().colors
        self.icon.setStyleSheet(f"background: {c.accent_soft}; border-radius: 22px;")
        self.icon.setPixmap(art.icon("history", c.accent_text).pixmap(36, 36))


class ActionLogPage(QWidget):
    undoRequested = Signal(int)      # action number

    def __init__(self, journal: Journal, parent=None):
        super().__init__(parent)
        self.journal = journal
        lay = QVBoxLayout(self)
        lay.setContentsMargins(28, 22, 28, 18)
        lay.setSpacing(14)
        top = QHBoxLayout()
        self.title = SectionTitle("action_log", px=26, subtitle="Everything Clone Ranger did to your files. "
                                                                 "Pick an action and press Undo to reverse it.")
        top.addWidget(self.title, 1)
        self.undo_btn = Button("undo_order", "undo", variant="soft")
        self.undo_btn.setEnabled(False)
        self.undo_btn.clicked.connect(self._undo)
        top.addWidget(self.undo_btn, 0, Qt.AlignmentFlag.AlignBottom)
        lay.addLayout(top)

        self.stack = QStackedWidget()
        self.tree = QTreeWidget()
        self.tree.setObjectName("History")
        self.tree.setColumnCount(5)
        self.tree.setHeaderLabels([tr(k) for k in ("order_col", "time_col", "action_col", "result_col", "status")])
        self.tree.setFont(fonts.body(13))
        self.tree.setUniformRowHeights(True)
        self.tree.setTextElideMode(Qt.TextElideMode.ElideMiddle)   # keep the file names visible
        self.tree.setAlternatingRowColors(True)
        self.tree.setIndentation(18)
        h = self.tree.header()
        h.setSectionResizeMode(QHeaderView.ResizeMode.Interactive)
        h.setStretchLastSection(False)
        for col, w in enumerate((80, 150, 200)):
            self.tree.setColumnWidth(col, w)
        h.setSectionResizeMode(3, QHeaderView.ResizeMode.Stretch)          # result / file names take the rest
        h.setSectionResizeMode(4, QHeaderView.ResizeMode.ResizeToContents)  # status always fully visible
        self.tree.currentItemChanged.connect(self._current)
        self.empty_state = EmptyHistory()
        self.stack.addWidget(self.tree)
        self.stack.addWidget(self.empty_state)
        lay.addWidget(self.stack, 1)

        self.path_label = QLabel(short_path(journal.path))
        self.path_label.setProperty("role", "muted")
        self.path_label.setFont(fonts.mono(11.5))
        self.path_label.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
        self.path_label.setToolTip("The history file")
        lay.addWidget(self.path_label)
        # older callers / tests look for .empty
        self.empty = self.empty_state
        theme().changed.connect(self._restyle)
        self._restyle()

    def _restyle(self):
        c = theme().colors
        self.tree.setStyleSheet(
            f"QTreeWidget#History {{ background: {c.surface}; border: 1px solid {c.line}; border-radius: 14px; "
            f"padding: 6px; alternate-background-color: {c.surface_alt}; }}"
            f"QTreeWidget#History::item {{ padding: 5px 2px; }}"
            f"QTreeWidget#History::item:selected {{ background: {c.selection}; color: {c.selection_text}; }}")
        if self.isVisible():
            self.reload()

    def reload(self):
        """Re-read the history file (it may have been cleared or written by an action) and repaint."""
        orders = self.journal.orders()
        self.tree.clear()
        self.stack.setCurrentWidget(self.empty_state if not orders else self.tree)
        self.path_label.setVisible(bool(orders))
        c = theme().colors
        warn, ok, muted, amber = (QColor(c.danger_text), QColor(c.success_text), QColor(c.text_muted),
                                  QColor(c.warning_text))
        for o in reversed(orders):
            counts = o.counts()
            res = tr("result_summary", **counts)
            if o.undone_by is not None:
                status, color = tr("undone_by", n=o.undone_by), muted
            elif o.status == "incomplete":
                status, color = tr("incomplete"), amber
            elif o.status == "cancelled":
                status, color = tr("order_interrupted"), amber
            else:
                status, color = tr("order_done"), ok
            top = QTreeWidgetItem([f"#{o.n}", time.strftime("%Y-%m-%d %H:%M", time.localtime(o.time)),
                                   op_text(o), res, status])
            top.setData(0, Qt.ItemDataRole.UserRole, o.n)
            top.setIcon(2, art.icon(OP_ICONS.get(o.op, "sparkle"), c.accent_text))
            f = top.font(0)
            f.setWeight(QFont.Weight.DemiBold)
            for col in range(5):
                top.setFont(col, f)
            top.setForeground(4, color)
            if counts.get("failed") or counts.get("skipped"):
                top.setForeground(3, amber)
            if o.dest and o.op == "move":
                top.setToolTip(2, f"→ {o.dest}")
            for it in o.items[:MAX_FILES_SHOWN]:
                where = f"{short_path(it.src)}" + (f"  →  {short_path(it.dst)}" if it.dst and o.op != "trash" else "")
                child = QTreeWidgetItem(["", "", it.status, where, it.error])
                child.setToolTip(3, f"{it.src}\n→ {it.dst or ''}")
                child.setFont(3, fonts.mono(12))
                if it.status != "ok":
                    for col in (2, 4):
                        child.setForeground(col, warn)
                else:
                    child.setForeground(2, ok)
                top.addChild(child)
            if len(o.items) > MAX_FILES_SHOWN:
                top.addChild(QTreeWidgetItem(["", "", "…", f"+{len(o.items) - MAX_FILES_SHOWN}", ""]))
            self.tree.addTopLevelItem(top)
        self._current(self.tree.currentItem(), None)

    def showEvent(self, e):
        super().showEvent(e)
        self.reload()

    def _order_n(self, item):
        while item is not None and item.parent() is not None:
            item = item.parent()
        return item.data(0, Qt.ItemDataRole.UserRole) if item is not None else None

    def _current(self, item, _prev):
        n = self._order_n(item)
        o = self.journal.order(n) if n is not None else None
        self.undo_btn.setEnabled(bool(o and o.undoable))

    def _undo(self):
        n = self._order_n(self.tree.currentItem())
        if n is not None:
            self.undoRequested.emit(n)
