"""Right-hand details panel: the selected file's picture, facts and actions (incl. select / unselect)."""
import os
import sys
import subprocess

from PySide6.QtCore import QRectF, Qt, QUrl, Signal
from PySide6.QtGui import QColor, QDesktopServices, QFont, QGuiApplication, QPainter, QPen
from PySide6.QtWidgets import QGridLayout, QHBoxLayout, QLabel, QScrollArea, QSizePolicy, QVBoxLayout, QWidget

from ..theme import art, fonts
from ..theme.strings import tr
from ..theme.style import theme
from ..util import human
from .case_cards import paint_badges, paint_placeholder, unselect_reason
from .widgets import Button

FIELDS = ["f_name", "f_path", "f_size", "f_created", "f_taken", "f_resolution", "f_duration", "f_hash"]


def _breakable(text: str) -> str:
    for ch in "_-./":
        text = text.replace(ch, ch + "\u200b")
    return text


class ClippedPhoto(QWidget):
    """The file's whole picture (never cropped) in a rounded frame, with its status badges.
    Click: open the viewer."""
    clicked = Signal()

    def __init__(self, parent=None):
        super().__init__(parent)
        self.image = None
        self.kind = "image"
        self.error = None
        self.pending = False
        self.copy = None
        self.setFixedHeight(236)
        self.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        theme().changed.connect(self.update)

    def mouseReleaseEvent(self, e):
        if e.button() == Qt.MouseButton.LeftButton and self.rect().contains(e.position().toPoint()):
            self.clicked.emit()

    def set_image(self, image, kind, error=None, pending=False, copy=None):
        self.image, self.kind, self.error, self.pending, self.copy = image, kind, error, pending, copy
        self.update()

    def paintEvent(self, _):
        c = theme().colors
        p = QPainter(self)
        p.setRenderHints(QPainter.RenderHint.Antialiasing | QPainter.RenderHint.SmoothPixmapTransform)
        photo = QRectF(self.rect()).adjusted(0, 4, 0, -4)
        p.save()
        p.setClipPath(art.rounded(photo, 14))
        if self.image is not None:
            p.fillRect(photo, QColor(c.photo_bg))
            iw, ih = self.image.width(), self.image.height()
            scale = min(photo.width() / iw, photo.height() / ih)
            dw, dh = iw * scale, ih * scale
            p.drawImage(QRectF(photo.center().x() - dw / 2, photo.center().y() - dh / 2, dw, dh), self.image)
        elif self.error or self.pending:
            paint_placeholder(p, photo, self.kind, self.error, self.pending)
        else:
            p.fillRect(photo, QColor(c.surface_alt))
        p.restore()
        p.setPen(QPen(QColor(c.line), 1))
        p.setBrush(Qt.BrushStyle.NoBrush)
        p.drawRoundedRect(photo.adjusted(.5, .5, -.5, -.5), 14, 14)
        if self.copy is not None:
            paint_badges(p, photo, self.copy, 11)


class DossierPanel(QWidget):
    message = Signal(str)   # short status text for the status bar
    viewRequested = Signal(object, object)   # group, copy
    selectionToggled = Signal(object, object)   # group, copy - after copy.selected was flipped

    def __init__(self, thumbs, parent=None):
        super().__init__(parent)
        self.thumbs = thumbs
        self.group = self.copy = None
        self.setObjectName("Details")
        self.setAttribute(Qt.WidgetAttribute.WA_StyledBackground)
        self.setMinimumWidth(320)
        self.setMaximumWidth(420)
        outer = QVBoxLayout(self)
        outer.setContentsMargins(18, 16, 18, 14)
        outer.setSpacing(10)

        head = QHBoxLayout()
        self.title = QLabel(tr("file_dossier"))
        self.title.setFont(fonts.heading(19))
        self.title.setProperty("role", "title")
        head.addWidget(self.title)
        head.addStretch(1)
        self.position = QLabel("")
        self.position.setFont(fonts.label(10.5))
        self.position.setProperty("role", "label")
        head.addWidget(self.position)
        outer.addLayout(head)

        # everything below the title scrolls, so small screens still see the whole panel
        content = QWidget()
        content.setObjectName("DossierContent")
        body = QVBoxLayout(content)
        body.setContentsMargins(0, 0, 6, 0)
        body.setSpacing(12)
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QScrollArea.Shape.NoFrame)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        scroll.viewport().setAutoFillBackground(False)
        scroll.setObjectName("DossierScroll")
        scroll.setWidget(content)
        outer.addWidget(scroll, 1)

        self.photo = ClippedPhoto()
        body.addWidget(self.photo)

        # select / unselect - the one button that changes the selection; nothing here touches files
        self.buttons = {}
        sel = Button("select_file", "select", size="normal")
        sel.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
        sel.setEnabled(False)
        body.addWidget(sel)
        self.buttons["select"] = sel

        grid = QGridLayout()
        grid.setHorizontalSpacing(14)
        grid.setVerticalSpacing(9)
        self.values = {}
        for row, key in enumerate(FIELDS):
            lab = QLabel(tr(key))
            lab.setFont(fonts.label(10.5))
            lab.setProperty("role", "label")
            val = QLabel("—")
            val.setFont(fonts.mono(12.5) if key == "f_hash" else
                        fonts.body(13.5, QFont.Weight.DemiBold if key == "f_name" else QFont.Weight.Normal))
            val.setWordWrap(True)
            val.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
            val.setSizePolicy(QSizePolicy.Policy.Ignored, QSizePolicy.Policy.Preferred)
            grid.addWidget(lab, row, 0, Qt.AlignmentFlag.AlignTop | Qt.AlignmentFlag.AlignLeft)
            grid.addWidget(val, row, 1)
            self.values[key] = val
        grid.setColumnStretch(1, 1)
        facts = QWidget()
        facts.setObjectName("Facts")
        facts.setAttribute(Qt.WidgetAttribute.WA_StyledBackground)
        fl = QVBoxLayout(facts)
        fl.setContentsMargins(14, 12, 14, 12)
        fl.addLayout(grid)
        body.addWidget(facts)
        self.facts = facts

        btns = QVBoxLayout()
        btns.setSpacing(6)
        for key, icon in (("open_viewer", "eye"), ("copy_path", "copy"), ("open_folder", "folder"),
                          ("open_default", "external")):
            b = Button(key, icon, variant="ghost", size="small")
            b.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
            b.setStyleSheet("text-align: left;")
            btns.addWidget(b)
            self.buttons[key] = b
            b.setEnabled(False)
        body.addLayout(btns)
        body.addStretch(1)
        sel.clicked.connect(self._toggle_selection)
        self.buttons["open_viewer"].clicked.connect(self._view)
        self.photo.clicked.connect(self._view)
        self.buttons["copy_path"].clicked.connect(self._copy_path)
        self.buttons["open_folder"].clicked.connect(self._open_folder)
        self.buttons["open_default"].clicked.connect(self._open_default)
        thumbs.ready.connect(lambda _key: self.refresh())

        theme().changed.connect(self._restyle)
        self._restyle()

    def _restyle(self):
        c = theme().colors
        if theme().plain:
            self.facts.setStyleSheet("")
            self.setStyleSheet("#DossierScroll, #DossierScroll > QWidget, #DossierContent { background: transparent; }")
        else:
            self.setStyleSheet("#DossierScroll, #DossierScroll > QWidget, #DossierContent { background: transparent; }"
                               f"QWidget#Facts {{ background: {c.surface_alt}; border-radius: 12px; }}"
                               "QWidget#Facts QLabel { background: transparent; }")
        self.update()

    def show_copy(self, group, copy):
        """Show one copy. `copy` may be a UiCopy or its index in group.copies."""
        if isinstance(copy, int):
            copy = group.copies[copy]
        self.group, self.copy = group, copy
        for key, b in self.buttons.items():
            if key != "select":
                b.setEnabled(copy is not None)
        self.refresh()

    def clear(self):
        self.group = self.copy = None
        self.photo.set_image(None, "image")
        self.position.setText("")
        for v in self.values.values():
            v.setText("—")
        for b in self.buttons.values():
            b.setEnabled(False)
        self._update_select_button()

    def _update_select_button(self):
        b = self.buttons["select"]
        cp = self.copy
        if cp is not None and cp.selected:
            b.set_text("unselect_file")
            b.set_icon("unselect")
            b.variant = "soft"
            b.setProperty("variant", "soft")
        else:
            b.set_text("select_file")
            b.set_icon("select")
            b.variant = None
            b.setProperty("variant", None)
        b.style().unpolish(b)
        b.style().polish(b)
        reason = unselect_reason(cp) if cp is not None else ""
        b.setEnabled(cp is not None and cp.selectable)
        b.setToolTip(reason)

    def _toggle_selection(self):
        cp = self.copy
        if cp is None or not cp.selectable:
            return
        cp.selected = not cp.selected
        self._update_select_button()
        self.photo.update()
        self.selectionToggled.emit(self.group, cp)

    def refresh(self):
        cp = self.copy
        if cp is None:
            return
        self.photo.set_image(self.thumbs.image(cp), cp.kind, self.thumbs.error(cp), self.thumbs.is_pending(cp), cp)
        if self.group is not None and cp in self.group.copies:
            self.position.setText(tr("copy_n", i=self.group.copies.index(cp) + 1, n=len(self.group.copies)))
        h = (cp.hash or "").split(":")[-1]
        dash = "—"
        vals = {
            # zero-width spaces let long names / folders wrap after _ - . and /
            "f_name": _breakable(cp.name), "f_path": _breakable(cp.folder), "f_size": f"{human(cp.size)}  ({cp.size:,} bytes)".replace(",", " "),
            "f_created": cp.created or dash, "f_taken": cp.taken or dash, "f_resolution": cp.resolution or dash,
            "f_duration": cp.duration or dash,
            # zero-width spaces let the long hash wrap at any 8th character
            "f_hash": "​".join(h[i:i + 8] for i in range(0, len(h), 8)) or dash,
        }
        if not cp.has_meta and not cp.meta_error:
            for k in ("f_taken", "f_resolution", "f_duration"):
                vals[k] = "…"
        for k, v in vals.items():
            self.values[k].setText(v)
        self.values["f_path"].setToolTip(cp.path)
        self._update_select_button()

    # ---- actions (none of them changes any file)
    def _view(self):
        if self.copy is not None:
            self.viewRequested.emit(self.group, self.copy)

    def _copy_path(self):
        if self.copy:
            QGuiApplication.clipboard().setText(self.copy.path)
            self.message.emit(f"{tr('copied')}: {self.copy.path}")

    def _open_folder(self):
        """Show the file selected in the file manager (Files / Dolphin / File Explorer), else just open the folder."""
        if not self.copy:
            return
        if sys.platform == "win32":
            try:   # explorer.exe returns 1 even when it worked, so don't look at the exit code
                subprocess.Popen(["explorer.exe", "/select,", os.path.normpath(self.copy.path)])
                return
            except OSError:
                pass
            QDesktopServices.openUrl(QUrl.fromLocalFile(os.path.dirname(self.copy.path)))
            return
        uri = QUrl.fromLocalFile(self.copy.path).toString(QUrl.ComponentFormattingOption.FullyEncoded)
        uri = uri.replace("\\", "\\\\").replace("'", "\\'")   # quoting for the GVariant text below
        try:
            r = subprocess.run(["gdbus", "call", "--session", "--dest", "org.freedesktop.FileManager1",
                                "--object-path", "/org/freedesktop/FileManager1", "--method",
                                "org.freedesktop.FileManager1.ShowItems", f"['{uri}']", ""],
                               capture_output=True, timeout=5)
            if r.returncode == 0:
                return
        except (OSError, subprocess.TimeoutExpired):
            pass
        QDesktopServices.openUrl(QUrl.fromLocalFile(os.path.dirname(self.copy.path)))

    def _open_default(self):
        if self.copy:
            QDesktopServices.openUrl(QUrl.fromLocalFile(self.copy.path))
