"""Runs file operations for the main window:

  collect options (Move / Bulk rename dialog)  ->  confirmation preview (confirmed by the user)
  ->  background worker with progress + Cancel  ->  results report  ->  groups updated in place.

Which files: the selected copies; if none are selected, the copy shown in the details panel.
"""
from __future__ import annotations

import logging
import os

from PySide6.QtCore import QObject
from PySide6.QtWidgets import QDialog, QMessageBox

from ..core import bulk_rename
from ..core.journal import Journal
from ..core.operations import Engine, Step, lost_groups, plan_move
from ..theme.strings import tr
from ..util import human, short_path
from . import viewmodel
from .op_dialogs import BulkRenameDialog, MoveDialog, RenameDialog
from .order_dialog import OrderDialog
from .workers import OpWorker

log = logging.getLogger("clone_ranger")
TYPED_CONFIRM_OVER = 20     # permanent deletion of more files than this needs the word typed
MAX_WARNINGS = 6


def unique_size(pairs) -> int:
    """Bytes of the files, each inode counted once."""
    seen, total = set(), 0
    for _g, c in pairs:
        if c.inode not in seen:
            seen.add(c.inode)
            total += c.size
    return total


class OpsController(QObject):
    def __init__(self, win, journal: Journal | None = None):
        super().__init__(win)
        self.win = win
        self.journal = journal or Journal()
        self.worker: OpWorker | None = None
        self.last_report = None

    # ------------------------------------------------------------------ helpers
    @property
    def busy(self) -> bool:
        return self.worker is not None

    def operands(self):
        """Selected copies, or the copy shown in the details panel."""
        sel = self.win.results.selected()
        if sel:
            return sel
        d = self.win.dossier
        if d.copy is not None and d.group is not None and not d.copy.protected \
                and any(d.copy is c for c in d.group.copies):
            return [(d.group, d.copy)]
        return []

    def _check_ready(self, pairs) -> bool:
        if self.busy:
            self.win.flash(tr("busy"))
            return False
        if not pairs:
            self.win.flash(tr("nothing_selected"))
            return False
        return True

    def loss_warnings(self, pairs) -> list[str]:
        removing = {c.path for _, c in pairs}
        groups = list({id(g): g for g, _ in pairs}.values())
        dup = [g for g in groups if g.is_duplicate]
        out = [tr("lose_all", n=dup[i].number)
               for i in lost_groups([[c.path for c in g.copies] for g in dup], removing)]
        if len(out) > MAX_WARNINGS:
            out = out[:MAX_WARNINGS] + [f"… +{len(out) - MAX_WARNINGS}"]
        unique = sum(1 for g, _ in pairs if not g.is_duplicate)
        if unique:
            out.append(tr("not_duplicates", n=unique))
        return out

    def _protected(self):
        return self.win.settings["protected_folders"] or []

    # ------------------------------------------------------------------ running an action
    def run(self, dlg: OrderDialog, job, after=None):
        """Show the confirmation; when confirmed, run job(engine) in the background. Returns the Report."""
        if self.win.demo:
            dlg.exec()                 # demo data: the success state only, no file is touched
            return None
        dlg.live = True
        state = {}

        def start():
            dlg.set_running()
            w = OpWorker(self.win.db_path, self.journal, self._protected(), job, self)
            w.progress.connect(lambda e: self._progress(dlg, e, state))
            w.done.connect(lambda rep: self._done(dlg, rep, state))
            w.failed.connect(lambda tb: self._failed(dlg, tb, state))
            dlg.cancelRequested.connect(w.control.cancel)
            w.finished.connect(w.deleteLater)
            self.worker = w
            self.win.update_status()
            w.start()

        dlg.signed.connect(start)
        dlg.exec()
        if self.worker is not None:          # closed while running (shouldn't happen): finish safely
            self.worker.control.cancel()
            self.worker.wait()
            self.worker = None
        rep = state.get("report")
        self.last_report = rep
        if rep is not None and after:
            after(rep)
        return rep

    def _progress(self, dlg, e, state):
        if "done" in e:
            state["done"], state["total"] = e["done"], max(1, e["total"])
            state["current"] = e.get("current", "")
        text = f"{state.get('done', 0)}/{state.get('total', 0)}  {short_path(state.get('current', ''))}"
        if "bytes" in e and e.get("total_bytes"):
            text += f"   ({human(e['bytes'])} / {human(e['total_bytes'])})"
        dlg.set_progress(state.get("done", 0) / state.get("total", 1), text)

    def _done(self, dlg, rep, state):
        state["report"] = rep
        self.worker = None
        self.apply(rep.order)
        c = rep.counts
        problems = [f"{short_path(it.src)}  –  {it.error}" for it in rep.order.items if it.status != "ok"]
        dlg.show_report(tr("result_summary", **c), problems, interrupted=rep.cancelled or c["ok"] == 0)

    def _failed(self, dlg, tb, state):
        log.error(tb)
        self.worker = None
        # the log has every file that WAS done; show the window what's true on disk now
        self.win.reload_keep_selection()
        dlg.show_report("Something went wrong – the action stopped. Files already done are listed in "
                        "History.", [tb.strip().splitlines()[-1]], interrupted=True)

    def apply(self, order):
        """Update the window after an action, without a rescan."""
        win = self.win
        undone = self.journal.order(order.undoes) if order.op == "undo" and order.undoes else None
        if order.op == "undo" and (undone is None or undone.op == "trash"):
            win.reload_keep_selection()    # files came back from the Trash: re-read groups from the index
        else:
            r = win.results
            current = win.dossier.group
            groups, _touched = viewmodel.apply_order(r.all_groups, order)
            closed = len(r.all_groups) - len(groups)
            r.set_groups(groups, r.mode)
            win.sidebar.set_count("same_content" if r.mode == "content" else "same_name", len(groups))
            win.reselect(current)
            if closed:
                win.flash(f"{tr('case_closed')}: {closed}")
        win.update_status()
        win.update_undo()
        if win.stack.currentWidget() is win.log_page:
            win.log_page.reload()

    # ------------------------------------------------------------------ Move to Trash / Delete
    def trash(self):
        pairs = self.operands()
        if not self._check_ready(pairs):
            return None
        n = self.journal.next_number()
        dlg = OrderDialog(n, "move_to_trash", [short_path(c.path) for _, c in pairs], human(unique_size(pairs)),
                          tr("trash_dest"), self.win, note="trash_note_undo", warnings=self.loss_warnings(pairs))
        targets = [viewmodel.target(c) for _, c in pairs]
        return self.run(dlg, lambda eng: eng.trash(targets, n=n), after=self._offer_delete)

    def _offer_delete(self, rep):
        """Some files were on a drive without a Trash: they were left alone. Ask what to do."""
        if not rep.trash_missing:
            return
        reason = next((it.error for it in rep.order.items if it.src in rep.trash_missing), "")
        t = tr("no_trash_text", n=len(rep.trash_missing), reason=reason)
        box = QMessageBox(QMessageBox.Icon.Warning, tr("no_trash_title"), t, parent=self.win)
        delete = box.addButton(tr("delete_perm"), QMessageBox.ButtonRole.DestructiveRole)
        box.addButton(tr("skip"), QMessageBox.ButtonRole.RejectRole)
        box.setDetailedText("\n".join(rep.trash_missing))
        box.exec()
        if box.clickedButton() is delete:
            missing = set(rep.trash_missing)
            pairs = [(g, c) for g in self.win.results.all_groups for c in g.copies if c.path in missing]
            self.delete(pairs)

    def delete(self, pairs=None):
        pairs = pairs if pairs is not None else self.operands()
        if not self._check_ready(pairs):
            return None
        n = self.journal.next_number()
        dlg = OrderDialog(n, "delete_perm", [short_path(c.path) for _, c in pairs], human(unique_size(pairs)),
                          tr("delete_dest"), self.win, note="delete_note", warnings=self.loss_warnings(pairs),
                          danger=True, confirm_word=tr("delete_word") if len(pairs) > TYPED_CONFIRM_OVER else None)
        targets = [viewmodel.target(c) for _, c in pairs]
        return self.run(dlg, lambda eng: eng.delete(targets, n=n))

    # ------------------------------------------------------------------ Move
    def move(self, dest=None, keep_structure=None, conflict=None):
        pairs = self.operands()
        if not self._check_ready(pairs):
            return None
        s = self.win.settings
        if dest is None:
            md = MoveDialog([c.path for _, c in pairs], s, self.win)
            if md.exec() != QDialog.DialogCode.Accepted:
                return None
            dest, keep_structure, conflict = md.destination, md.keep.isChecked(), md.conflict_mode
        s["last_move_dest"], s["move_keep_structure"], s["move_conflict"] = dest, bool(keep_structure), conflict
        steps = plan_move([viewmodel.target(c) for _, c in pairs], dest, bool(keep_structure), conflict=conflict)
        live = [st for st in steps if st.status in ("ok", "overwrite")]
        if not live:
            self.win.flash(f"{tr('move')}: " + "; ".join(sorted({st.reason for st in steps}))[:200])
            return None
        lines = [f"{short_path(st.src)}  →  {short_path(st.dst)}" + ("  [!]" if st.status == "overwrite" else "")
                 for st in live]
        lines += [f"{short_path(st.src)}  –  {st.reason}" for st in steps if st not in live]
        warnings = []
        over = sum(1 for st in live if st.status == "overwrite")
        if over:
            warnings.append(tr("overwrite_warn", n=over))
        skipped = len(steps) - len(live)
        if skipped:
            warnings.append(tr("will_skip", n=skipped))
        n = self.journal.next_number()
        dlg = OrderDialog(n, "move", lines, human(sum(st.target.size or 0 for st in live)), short_path(dest),
                          self.win, note="move_note", warnings=warnings, count=len(live),
                          confirm_check=tr("confirm_overwrite") if over else None)
        return self.run(dlg, lambda eng: eng.move(steps, dest, n=n))

    # ------------------------------------------------------------------ Rename
    def rename(self):
        """Toolbar button: bulk rename for several selected files, otherwise rename one."""
        sel = self.win.results.selected()
        if len(sel) > 1:
            return self.bulk_rename(sel)
        return self.rename_one(sel[0] if sel else None)

    def rename_one(self, pair=None, new_name=None):
        """F2: rename the copy shown in the details panel (no confirmation for a single rename; undo with Ctrl+Z)."""
        if self.busy:
            self.win.flash(tr("busy"))
            return None
        if pair is None:
            d = self.win.dossier
            pair = (d.group, d.copy) if d.copy is not None else None
        if pair is None:
            self.win.flash(tr("nothing_selected"))
            return None
        g, c = pair
        if c.protected:
            self.win.flash(tr("protected"))
            return None
        if new_name is None:
            dlg = RenameDialog(c.path, self.win)
            if dlg.exec() != QDialog.DialogCode.Accepted:
                return None
            new_name = dlg.new_name
        if self.win.demo:
            return None
        step = Step(viewmodel.target(c), os.path.join(os.path.dirname(c.path), new_name))
        rep = Engine(self.journal, self.win.index(), self._protected()).rename([step])
        self.last_report = rep
        self.apply(rep.order)
        bad = [it for it in rep.order.items if it.status != "ok"]
        if bad:
            self.win.flash(f"{tr('rename')}: {bad[0].error}")
        else:
            self.win.flash(f"{tr('rename')}: {new_name} ✓")
        return rep

    def bulk_rename(self, pairs=None, options: bulk_rename.Options | None = None):
        pairs = pairs if pairs is not None else self.operands()
        if not self._check_ready(pairs):
            return None
        pairs = [(g, c) for g, c in pairs if not c.protected]
        by_path = {}
        for g, c in pairs:
            by_path.setdefault(c.path, c)
        files = [bulk_rename.File(c.path, c.taken, c.mtime_ns) for c in by_path.values()]
        if options is None:
            dlg = BulkRenameDialog(files, self.win)
            if dlg.exec() != QDialog.DialogCode.Accepted:
                return None
            plan = dlg.plan
        else:
            plan = bulk_rename.plan(files, options)
        ready = plan.ready
        if not ready:
            return None
        steps = [Step(viewmodel.target(by_path[it.path]), it.new_path) for it in ready]
        lines = [f"{it.old_name}  →  {it.new_name}" for it in ready]
        blocked = len(plan.blocked)
        warnings = [tr("will_skip", n=blocked)] if blocked else []
        n = self.journal.next_number()
        folders = {os.path.dirname(it.path) for it in ready}
        dest = short_path(folders.pop()) if len(folders) == 1 else f"{len(folders)} folders"
        dlg = OrderDialog(n, "rename", lines, human(sum(by_path[it.path].size for it in ready)), dest, self.win,
                          note="rename_note", warnings=warnings)
        return self.run(dlg, lambda eng: eng.rename(steps, n=n))

    # ------------------------------------------------------------------ Undo
    def undo_last(self):
        if self.busy:
            self.win.flash(tr("busy"))
            return None
        o = self.journal.last_undoable()
        if o is None:
            self.win.flash(tr("nothing_to_undo"))
            return None
        return self.undo(o.n)

    def undo(self, number: int):
        if self.busy:
            self.win.flash(tr("busy"))
            return None
        o = self.journal.order(number)
        if o is None or not o.undoable:
            self.win.flash(tr("nothing_to_undo"))
            return None
        if o.op == "trash":
            lines = [f"{tr('trash_dest')}  →  {short_path(it.src)}" for it in o.ok]
        else:
            lines = [f"{short_path(it.dst)}  →  {short_path(it.src)}" for it in o.ok]
        n = self.journal.next_number()
        dlg = OrderDialog(n, "undo", lines, human(sum(it.size for it in o.ok)), tr("undo_of", n=o.n), self.win,
                          note="undo_note")
        return self.run(dlg, lambda eng: eng.undo(o, n=n))
