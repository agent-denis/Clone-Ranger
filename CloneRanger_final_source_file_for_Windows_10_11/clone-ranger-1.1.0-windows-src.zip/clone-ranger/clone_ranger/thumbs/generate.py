"""Make a JPEG thumbnail of an image or video. No Qt here - runs in worker threads.

Images: Pillow (fast JPEG draft mode, EXIF rotation applied).
RAW:    Pillow if it can, otherwise the largest embedded JPEG preview in the file.
HEIC:   only if pillow-heif is installed (not yet available for Python 3.15).
Videos: one frame ~10% into the video via ffmpeg (if installed and the codec is supported).
Returns (jpeg_bytes, None) or (None, reason).
"""
from __future__ import annotations

import io
import os
import subprocess

from ..core import metadata
from ..core.osinfo import no_window

RAW_EXT = {".cr2", ".cr3", ".nef", ".arw", ".dng", ".orf", ".rw2", ".raf"}
MAX_RAW_SCAN = 48 * 1024 * 1024


def _encode(img, size: int) -> bytes:
    from PIL import Image, ImageOps
    img = ImageOps.exif_transpose(img)
    img.thumbnail((size, size))
    if img.mode not in ("RGB", "L"):
        bg = Image.new("RGB", img.size, (245, 240, 228))
        if img.mode in ("RGBA", "LA", "P"):
            img = img.convert("RGBA")
            bg.paste(img, mask=img.split()[-1])
            img = bg
        else:
            img = img.convert("RGB")
    out = io.BytesIO()
    img.save(out, "JPEG", quality=84, optimize=True)
    return out.getvalue()


def _embedded_jpeg(path: str):
    """Largest JPEG preview embedded in a RAW file (most cameras store one)."""
    from PIL import Image
    with open(path, "rb") as f:
        data = f.read(MAX_RAW_SCAN)
    best = None
    pos = data.find(b"\xff\xd8\xff")
    while pos != -1:
        end = data.find(b"\xff\xd9", pos + 3)
        if end == -1:
            break
        seg = data[pos:end + 2]
        if len(seg) > 20_000 and (best is None or len(seg) > len(best)):
            try:
                Image.open(io.BytesIO(seg)).verify()
                best = seg
            except Exception:  # noqa: BLE001
                pass
        pos = data.find(b"\xff\xd8\xff", pos + 3)
    return Image.open(io.BytesIO(best)) if best else None


def image_thumbnail(path: str, size: int) -> tuple[bytes | None, str | None]:
    from PIL import Image, UnidentifiedImageError
    ext = os.path.splitext(path)[1].lower()
    try:
        with Image.open(path) as img:
            if img.format == "JPEG":
                img.draft("RGB", (size * 2, size * 2))
            # some TIFF-based RAW files open as a tiny thumbnail; prefer the embedded preview then
            if ext in RAW_EXT and max(img.size) < size:
                raise UnidentifiedImageError("tiny")
            img.load()
            return _encode(img, size), None
    except (UnidentifiedImageError, OSError, ValueError, SyntaxError) as e:
        if ext in RAW_EXT:
            try:
                emb = _embedded_jpeg(path)
                if emb:
                    return _encode(emb, size), None
            except OSError:
                pass
            return None, "RAW file without a readable preview"
        if ext in (".heic", ".heif") and not metadata.HEIF:
            return None, "HEIC/HEIF previews need pillow-heif (not yet available for Python 3.15)"
        return None, f"cannot read image ({type(e).__name__})"
    except Exception as e:  # noqa: BLE001 - never crash on odd files
        return None, f"cannot read image ({type(e).__name__})"


def video_thumbnail(path: str, size: int, duration: float | None = None) -> tuple[bytes | None, str | None]:
    if not metadata.FFMPEG:
        return None, "ffmpeg is not installed"
    if duration is None:
        duration = metadata.video_meta(path).duration
    at = max(0.0, (duration or 0) * 0.10)
    cmd = [metadata.FFMPEG, "-v", "error", "-nostdin", "-ss", f"{at:.2f}", "-i", path, "-frames:v", "1",
           "-vf", f"scale='min({size},iw)':-2", "-f", "image2pipe", "-vcodec", "mjpeg", "-q:v", "4", "-"]
    try:
        r = subprocess.run(cmd, capture_output=True, timeout=30, **no_window())
    except subprocess.TimeoutExpired:
        return None, "ffmpeg took too long"
    if r.returncode != 0 or not r.stdout:
        err = r.stderr.decode(errors="replace").lower()
        if any(s in err for s in ("decoder", "no codec", "codec not", "unsupported codec")):
            return None, "video codec not supported by this ffmpeg (e.g. HEVC with ffmpeg-free)"
        return None, "could not decode a frame (codec not supported?)"
    return r.stdout, None


def make_thumbnail(path: str, kind: str, size: int = 320, duration: float | None = None):
    if kind == "video":
        return video_thumbnail(path, size, duration)
    return image_thumbnail(path, size)
