"""Background thumbnails with a disk cache (~/.cache/clone-ranger/thumbs) and a small memory cache.

Views call `image(copy)`: it returns a QImage right away if cached, otherwise
None and starts a background job; `ready(key)` fires when it's done.
"""
from __future__ import annotations

import hashlib
import os
from collections import OrderedDict

from PySide6.QtCore import QObject, QRunnable, QThreadPool, Signal
from PySide6.QtGui import QImage

from ..core import paths
from .generate import make_thumbnail

THUMB_SIZE = 320
MEMORY_ITEMS = 160          # ~ 160 x 300 KB = ~50 MB at most


def cache_key(path: str, size: int, mtime_ns: int) -> str:
    return hashlib.sha1(f"{path}\0{size}\0{mtime_ns}\0{THUMB_SIZE}".encode()).hexdigest()


class _Signals(QObject):
    done = Signal(str, QImage, str)   # key, image (null on failure), error


class _Job(QRunnable):
    def __init__(self, key, path, kind, duration, cache_file, signals):
        super().__init__()
        self.key, self.path, self.kind, self.duration = key, path, kind, duration
        self.cache_file, self.signals = cache_file, signals
        self.setAutoDelete(True)

    def run(self):
        img, err = QImage(), ""
        try:
            data, err = make_thumbnail(self.path, self.kind, THUMB_SIZE, self.duration)
            if data:
                img = QImage.fromData(data, "JPEG")
                try:
                    os.makedirs(os.path.dirname(self.cache_file), exist_ok=True)
                    tmp = self.cache_file + ".tmp"
                    with open(tmp, "wb") as f:
                        f.write(data)
                    os.replace(tmp, self.cache_file)
                except OSError:
                    pass
        except Exception as e:  # noqa: BLE001 - a broken file must never take the app down
            err = f"preview failed ({type(e).__name__})"
        self.signals.done.emit(self.key, img, err or "")


class ThumbService(QObject):
    ready = Signal(str)

    def __init__(self, parent=None, threads: int = 2):
        super().__init__(parent)
        self.dir = paths.thumbs_dir()
        self.pool = QThreadPool(self)
        self.pool.setMaxThreadCount(threads)
        self.mem: OrderedDict[str, QImage] = OrderedDict()
        self.errors: dict[str, str] = {}
        self.pending: set[str] = set()
        self._sig = _Signals()
        self._sig.done.connect(self._done)

    def key_for(self, c) -> str:
        return cache_key(c.path, c.size, c.mtime_ns)

    def _file(self, key: str) -> str:
        return str(self.dir / key[:2] / f"{key}.jpg")

    def image(self, c) -> QImage | None:
        """Thumbnail for a UiCopy, or None if not ready yet (or failed - see error())."""
        key = self.key_for(c)
        img = self.mem.get(key)
        if img is not None:
            self.mem.move_to_end(key)
            return img
        if key in self.errors or key in self.pending:
            return None
        f = self._file(key)
        if os.path.exists(f):
            img = QImage(f)
            if not img.isNull():
                self._remember(key, img)
                return img
        self.pending.add(key)
        self.pool.start(_Job(key, c.path, c.kind, c.duration_s, f, self._sig))
        return None

    def error(self, c) -> str | None:
        return self.errors.get(self.key_for(c))

    def is_pending(self, c) -> bool:
        return self.key_for(c) in self.pending

    def _remember(self, key, img):
        self.mem[key] = img
        self.mem.move_to_end(key)
        while len(self.mem) > MEMORY_ITEMS:
            self.mem.popitem(last=False)

    def _done(self, key, img, err):
        self.pending.discard(key)
        if img.isNull():
            self.errors[key] = err or "no preview"
        else:
            self._remember(key, img)
        self.ready.emit(key)

    def forget(self, c):
        key = self.key_for(c)
        self.mem.pop(key, None)
        self.errors.pop(key, None)

    def clear(self, timeout_ms: int = 5000):
        """Forget everything (used before the thumbnail cache folder is deleted): queued jobs are dropped and
        running ones are waited for, so none writes a file into the folder after it's gone."""
        self.pool.clear()
        self.pool.waitForDone(timeout_ms)
        self.mem.clear()
        self.errors.clear()
        self.pending.clear()


class DemoThumbs(QObject):
    """Thumbnails for the screenshot/demo mode: procedurally painted fake photos."""
    ready = Signal(str)

    def image(self, c):
        from ..ui.demo_data import fake_photo
        return fake_photo(c.seed, c.kind)

    def error(self, c):
        return None

    def is_pending(self, c):
        return False

    def key_for(self, c):
        return str(c.seed)

    def clear(self, timeout_ms: int = 0):
        pass
