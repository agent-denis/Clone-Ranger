; Inno Setup script for the Windows installer (CloneRanger-<version>-Setup.exe). Run by build.ps1:
;   ISCC.exe /DAppVersion=1.1.0 windows\clone-ranger.iss
; Installs for the current user only (no administrator rights needed) into
; %LOCALAPPDATA%\Programs\Clone Ranger, with a Start menu entry and an uninstaller.

#ifndef AppVersion
  #define AppVersion "0.0.0"
#endif

[Setup]
AppId={{88727090-70AC-4CB3-851C-F554C621A568}
AppName=Clone Ranger
AppVersion={#AppVersion}
AppVerName=Clone Ranger {#AppVersion}
AppPublisher=Denis
AppPublisherURL=https://github.com/agent-denis/clone-ranger
AppSupportURL=https://github.com/agent-denis/clone-ranger/issues
AppComments=Find and clean up duplicate photos and videos
DefaultDirName={autopf}\Clone Ranger
DefaultGroupName=Clone Ranger
DisableProgramGroupPage=yes
PrivilegesRequired=lowest
LicenseFile=..\LICENSE
OutputDir=..\dist-windows
OutputBaseFilename=CloneRanger-{#AppVersion}-Setup
SetupIconFile=clone-ranger.ico
UninstallDisplayIcon={app}\Clone Ranger.exe
UninstallDisplayName=Clone Ranger
Compression=lzma2/max
SolidCompression=yes
WizardStyle=modern
ArchitecturesAllowed=x64compatible
ArchitecturesInstallIn64BitMode=x64compatible
MinVersion=10.0.17763
CloseApplications=yes

[Languages]
Name: "english"; MessagesFile: "compiler:Default.isl"

[Tasks]
Name: "desktopicon"; Description: "{cm:CreateDesktopIcon}"; GroupDescription: "{cm:AdditionalIcons}"; Flags: unchecked

[InstallDelete]
; an upgrade replaces the whole program folder, so no files of the old version are left behind
Type: filesandordirs; Name: "{app}\_internal"
Type: filesandordirs; Name: "{app}\ffmpeg"

[Files]
Source: "..\dist-windows\Clone Ranger\*"; DestDir: "{app}"; Flags: ignoreversion recursesubdirs createallsubdirs

[Icons]
Name: "{autoprograms}\Clone Ranger"; Filename: "{app}\Clone Ranger.exe"
Name: "{autodesktop}\Clone Ranger"; Filename: "{app}\Clone Ranger.exe"; Tasks: desktopicon

[Run]
Filename: "{app}\Clone Ranger.exe"; Description: "{cm:LaunchProgram,Clone Ranger}"; Flags: nowait postinstall skipifsilent

[Code]
// On uninstall, ask whether to also remove settings, scan index, thumbnails and the action history
// (like uninstall.sh --purge on Linux). Photos and videos are never touched.
procedure CurUninstallStepChanged(CurUninstallStep: TUninstallStep);
begin
  if (CurUninstallStep = usPostUninstall) and not UninstallSilent then
    if MsgBox('Also delete Clone Ranger''s settings, scan index, thumbnails and action history?' + #13#10#13#10 +
              'Your photos and videos are not touched either way.', mbConfirmation, MB_YESNO or MB_DEFBUTTON2) = IDYES then
    begin
      DelTree(ExpandConstant('{userappdata}\Clone Ranger'), True, True, True);
      DelTree(ExpandConstant('{localappdata}\Clone Ranger'), True, True, True);
    end;
end;
