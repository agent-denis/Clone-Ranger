"""Entry point of the Windows app ("Clone Ranger.exe", built by build.ps1 with PyInstaller)."""
import multiprocessing
import sys

from clone_ranger.app import main

if __name__ == "__main__":
    multiprocessing.freeze_support()
    sys.exit(main())
