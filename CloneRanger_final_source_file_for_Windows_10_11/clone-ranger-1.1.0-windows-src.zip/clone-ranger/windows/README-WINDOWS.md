# Clone Ranger on Windows 10 / 11

## Building it (on your Windows PC)

1. Copy the project folder to the Windows PC, for example to `C:\Users\<you>\clone-ranger`.
   Either unzip `clone-ranger-windows-src.zip`, or `git clone` it once it's on GitHub.
2. Open the folder `windows` and double-click **`build.bat`**.
   Do *not* use "Run as administrator".
3. Wait. The first build downloads Python (if missing), PySide6, FFmpeg and Inno Setup,
   which takes about 5 to 15 minutes. Later builds are faster.
4. When it says **Done**, everything is in the folder `dist-windows`:

| File | What it is |
|---|---|
| `CloneRanger-1.0.0-Setup.exe` | The installer to give to your friends |
| `CloneRanger-1.0.0-portable.zip` | The same app without an installer: unzip it and start `Clone Ranger.exe` |
| `Clone Ranger\Clone Ranger.exe` | Start this to try the build right away |

If the build stops with **FAILED**, copy the text in the window and send it to Claude.

Options (in PowerShell: `powershell -ExecutionPolicy Bypass -File windows\build.ps1 -FullTests`):

| Option | Effect |
|---|---|
| `-FullTests` | Also run all ~150 tests, with the results saved in `full-tests.txt` (please send that file to Claude) |
| `-SkipTests` | Skip the Windows checks |
| `-NoFfmpeg` | No FFmpeg: videos are still found, but get no thumbnail or details |
| `-NoInstaller` | Only the portable zip, no Setup.exe |

## What to tell your friends

1. Run `CloneRanger-1.0.0-Setup.exe`. No administrator rights are needed; it installs only for that user.
2. Windows will probably show **"Windows protected your PC"**, because the app isn't signed.
   Click **More info** and then **Run anyway**. This happens only once, for the installer.
3. Start **Clone Ranger** from the Start menu.

To uninstall: **Settings → Apps → Installed apps → Clone Ranger → Uninstall**. It asks whether to
also delete Clone Ranger's own settings and history. Photos and videos are never touched.

## How Windows differs from Linux

| | Windows |
|---|---|
| Move to Trash | Called **Move to Recycle Bin**. Files show up in the normal Recycle Bin and can be restored from there or with Undo (Ctrl+Z). |
| USB sticks, memory cards, network drives | Have no Recycle Bin. Clone Ranger leaves the files alone and asks whether to delete them permanently instead, just like on Linux. |
| OneDrive | Files that are "online-only" (cloud icon) are skipped, so a scan never downloads your whole OneDrive. They're listed under skipped files. Files that are already on the PC are scanned normally. |
| Scan entire computer | All local disks and USB drives. `C:\Windows`, `Program Files`, `ProgramData` and `AppData` are excluded. |
| Default folders | Your user folder (`C:\Users\<you>`) plus any USB sticks and memory cards that are plugged in |
| Settings | `%APPDATA%\Clone Ranger\settings.json` |
| Scan index, thumbnails | `%LOCALAPPDATA%\Clone Ranger\cache\` |
| Action history, log | `%LOCALAPPDATA%\Clone Ranger\state\` |
| Run as administrator | Refused, for the same reason Linux refuses root |
| Shared copies (Btrfs reflinks) | Not detected. Windows' normal NTFS drives don't have them. |

## Licences

Clone Ranger is GPL-3.0-or-later. The Windows build also contains Python (PSF licence),
Qt / PySide6 (LGPL-3.0), Pillow (MIT-CMU), BLAKE3 (Apache-2.0/CC0), pillow-heif / libheif (BSD/LGPL),
the Inter font (OFL-1.1) and FFmpeg (GPL-3.0, with notes in `ffmpeg\README.txt`). All of them allow
giving the app to friends for free. If someone asks for the source code, point them to the GitHub page.
