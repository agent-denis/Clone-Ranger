<#
Build Clone Ranger for Windows 10/11 (run this ON a Windows PC, not as administrator).

    Double-click windows\build.bat, or in PowerShell:
    powershell -ExecutionPolicy Bypass -File windows\build.ps1 [-SkipTests] [-FullTests] [-NoFfmpeg] [-NoInstaller]

What it does:
  1. finds Python 3.13 (installs it for your user with winget if it's missing)
  2. makes a private Python environment in .venv-win and installs PySide6, Pillow, BLAKE3, pillow-heif, PyInstaller
  3. runs the Windows checks (tests\core\test_windows*.py); -FullTests also runs the whole suite into full-tests.txt
  4. downloads FFmpeg (video thumbnails and details) from gyan.dev and checks its SHA-256
  5. builds dist-windows\Clone Ranger\Clone Ranger.exe with PyInstaller
  6. packs dist-windows\CloneRanger-<version>-portable.zip and, with Inno Setup, CloneRanger-<version>-Setup.exe
Nothing outside this project folder is changed, except installing Python / Inno Setup with winget if missing.
#>
param([switch]$SkipTests, [switch]$FullTests, [switch]$NoFfmpeg, [switch]$NoInstaller)

$ErrorActionPreference = "Stop"
$ProgressPreference = "SilentlyContinue"          # makes Invoke-WebRequest many times faster
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

$Root = Split-Path -Parent $PSScriptRoot
Set-Location $Root
$Version = (Select-String -Path "clone_ranger\__init__.py" -Pattern '__version__ = "(.+)"').Matches[0].Groups[1].Value
$Dist = Join-Path $Root "dist-windows"
$Work = Join-Path $Root "build-windows"

function Say($msg) { Write-Host "==> $msg" -ForegroundColor Cyan }
function Fail($msg) { Write-Host ""; Write-Host "FAILED: $msg" -ForegroundColor Red; exit 1 }
function Run($exe, [string[]]$argList) {
    & $exe @argList
    if ($LASTEXITCODE -ne 0) { Fail "$exe $($argList -join ' ') (exit code $LASTEXITCODE)" }
}

Say "Building Clone Ranger $Version for Windows in $Root"

# ------------------------------------------------------------------ 1. Python
function Find-Python {
    $ErrorActionPreference = "Continue"     # "py -3.13" complains on stderr when that version is missing
    foreach ($v in @("3.13", "3.12")) {
        try {
            $p = & py "-$v" -c "import sys; print(sys.executable)" 2>$null
            if ($LASTEXITCODE -eq 0 -and $p) { return $p.Trim() }
        } catch { }
        $guess = Join-Path $env:LOCALAPPDATA ("Programs\Python\Python" + $v.Replace(".", "") + "\python.exe")
        if (Test-Path $guess) { return $guess }
    }
    return $null
}
$Python = Find-Python
if (-not $Python) {
    Say "Python 3.13 not found: installing it for your user with winget"
    winget install -e --id Python.Python.3.13 --scope user --accept-package-agreements --accept-source-agreements
    $Python = Find-Python
    if (-not $Python) { Fail "Python is still missing. Install Python 3.13 from https://www.python.org/downloads/ and run this again." }
}
Say "Python: $Python"

# ------------------------------------------------------------------ 2. environment
$Venv = Join-Path $Root ".venv-win"
$VPy = Join-Path $Venv "Scripts\python.exe"
if (-not (Test-Path $VPy)) {
    Say "Creating .venv-win"
    Run $Python @("-m", "venv", $Venv)
}
Say "Installing PySide6, Pillow, BLAKE3, PyInstaller (first time: a few minutes)"
Run $VPy @("-m", "pip", "install", "--quiet", "--upgrade", "pip")
Run $VPy @("-m", "pip", "install", "--quiet", "--upgrade", "-r", "requirements.txt", "pytest", "pyinstaller")
$ErrorActionPreference = "Continue"        # Windows PowerShell 5 treats any stderr text as an error otherwise
& $VPy -m pip install --quiet --only-binary=:all: pillow-heif 2>$null
$heif = $LASTEXITCODE
$ErrorActionPreference = "Stop"
if ($heif -eq 0) { Say "HEIC/HEIF (iPhone photos): supported" }
else { Write-Host "    pillow-heif is not available for this Python: HEIC photos are found but get no preview" -ForegroundColor Yellow }

# ------------------------------------------------------------------ 3. tests
if (-not $SkipTests) {
    Say "Running the Windows checks"
    & $VPy -m pytest -q -p no:cacheprovider "tests\core\test_windows.py" "tests\core\test_windows_real.py"
    if ($LASTEXITCODE -ne 0) { Fail "the Windows checks failed. Copy the text above and send it to Claude." }
}
if ($FullTests) {
    Say "Running the full test suite (results in full-tests.txt; failures here don't stop the build)"
    $ErrorActionPreference = "Continue"
    & $VPy -m pytest -q -p no:cacheprovider --tb=short tests 2>&1 | Tee-Object -FilePath (Join-Path $Root "full-tests.txt")
    $ErrorActionPreference = "Stop"
}

# ------------------------------------------------------------------ 4. FFmpeg
$FFDir = Join-Path $Work "ffmpeg"
if (-not $NoFfmpeg -and -not (Test-Path (Join-Path $FFDir "ffprobe.exe"))) {
    Say "Downloading FFmpeg (about 100 MB) from gyan.dev"
    New-Item -ItemType Directory -Force -Path $Work | Out-Null
    $zip = Join-Path $Work "ffmpeg.zip"
    $url = "https://www.gyan.dev/ffmpeg/builds/ffmpeg-release-essentials.zip"
    # gyan.dev is sometimes briefly unavailable (e.g. "503 Server Unavailable"): try a few times before giving up
    $expected = $null
    for ($try = 1; $try -le 4; $try++) {
        try {
            Invoke-WebRequest -UseBasicParsing -Uri $url -OutFile $zip
            $expected = (Invoke-WebRequest -UseBasicParsing -Uri "$url.sha256").Content
            break
        } catch {
            Write-Host "    Download failed ($($_.Exception.Message))" -ForegroundColor Yellow
            if ($try -lt 4) { Write-Host "    Trying again in 30 seconds ($try of 3)..." -ForegroundColor Yellow; Start-Sleep -Seconds 30 }
        }
    }
    if ($null -eq $expected) {
        Fail "could not download FFmpeg from gyan.dev (the site may be down). Wait a while and run build.bat again."
    }
    if ($expected -is [byte[]]) { $expected = [Text.Encoding]::ASCII.GetString($expected) }
    $expected = $expected.Trim().Split(" ")[0]
    $actual = (Get-FileHash -Algorithm SHA256 $zip).Hash
    if ($actual -ne $expected.ToUpper()) { Fail "FFmpeg download is damaged (SHA-256 $actual, expected $expected)" }
    $unz = Join-Path $Work "ffmpeg-unzipped"
    if (Test-Path $unz) { Remove-Item -Recurse -Force $unz }
    Expand-Archive -Path $zip -DestinationPath $unz
    $top = Get-ChildItem $unz -Directory | Select-Object -First 1
    New-Item -ItemType Directory -Force -Path $FFDir | Out-Null
    Copy-Item (Join-Path $top.FullName "bin\ffmpeg.exe"), (Join-Path $top.FullName "bin\ffprobe.exe") $FFDir
    Copy-Item (Join-Path $top.FullName "LICENSE") (Join-Path $FFDir "LICENSE.txt")
    Set-Content -Encoding ASCII -Path (Join-Path $FFDir "README.txt") -Value @(
        "FFmpeg ($($top.Name)), used by Clone Ranger for video thumbnails and video details.",
        "Windows build by Gyan Doshi: https://www.gyan.dev/ffmpeg/builds/",
        "FFmpeg is free software under the GNU GPL version 3 (see LICENSE.txt).",
        "Source code: https://ffmpeg.org/download.html and https://github.com/GyanD/codexffmpeg")
    Remove-Item -Recurse -Force $unz, $zip
}

# ------------------------------------------------------------------ 5. PyInstaller
Say "Building Clone Ranger.exe"
$App = Join-Path $Dist "Clone Ranger"
if (Test-Path $App) { Remove-Item -Recurse -Force $App }
Run $VPy @("-m", "PyInstaller", "--noconfirm", "--clean", "--log-level", "WARN", "--distpath", $Dist,
           "--workpath", (Join-Path $Work "pyinstaller"), "windows\clone-ranger.spec")
if (-not $NoFfmpeg) { Copy-Item -Recurse $FFDir (Join-Path $App "ffmpeg") }

# ------------------------------------------------------------------ 6. zip + installer
$Portable = Join-Path $Dist "CloneRanger-$Version-portable.zip"
if (Test-Path $Portable) { Remove-Item -Force $Portable }
Say "Packing $Portable"
Compress-Archive -Path $App -DestinationPath $Portable

if (-not $NoInstaller) {
    $iscc = @("${env:ProgramFiles(x86)}\Inno Setup 6\ISCC.exe", "$env:ProgramFiles\Inno Setup 6\ISCC.exe",
              "$env:LOCALAPPDATA\Programs\Inno Setup 6\ISCC.exe") | Where-Object { Test-Path $_ } | Select-Object -First 1
    if (-not $iscc) {
        Say "Inno Setup not found: installing it with winget"
        winget install -e --id JRSoftware.InnoSetup --scope user --accept-package-agreements --accept-source-agreements
        $iscc = @("${env:ProgramFiles(x86)}\Inno Setup 6\ISCC.exe", "$env:ProgramFiles\Inno Setup 6\ISCC.exe",
                  "$env:LOCALAPPDATA\Programs\Inno Setup 6\ISCC.exe") | Where-Object { Test-Path $_ } | Select-Object -First 1
    }
    if ($iscc) {
        Say "Building the installer"
        Run $iscc @("/Q", "/DAppVersion=$Version", "windows\clone-ranger.iss")
    } else {
        Write-Host "    Inno Setup is missing, so no Setup.exe was made (the portable zip works)." -ForegroundColor Yellow
        Write-Host "    Install it from https://jrsoftware.org/isdl.php and run this again." -ForegroundColor Yellow
    }
}

Write-Host ""
Say "Done. In $Dist :"
Get-ChildItem $Dist -File | ForEach-Object { Write-Host ("    {0}  ({1:N0} MB)" -f $_.Name, ($_.Length / 1MB)) }
Write-Host "    Clone Ranger\Clone Ranger.exe   (start it directly to try it)"
