@echo off
rem Double-click to build Clone Ranger for Windows (see build.ps1 and README-WINDOWS.md).
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0build.ps1" %*
echo.
pause
