# PyInstaller recipe for the Windows app. Run by build.ps1:
#   python -m PyInstaller --noconfirm --clean --distpath dist-windows windows\clone-ranger.spec
# Result: dist-windows\Clone Ranger\Clone Ranger.exe (+ _internal\ with Python, Qt and the app's files).
import os

ROOT = os.path.abspath(os.path.join(SPECPATH, ".."))   # noqa: F821 - SPECPATH is set by PyInstaller
THEME = os.path.join(ROOT, "clone_ranger", "theme")

datas = [(os.path.join(THEME, d), os.path.join("clone_ranger", "theme", d)) for d in ("fonts", "svg", "sounds")]
datas += [(os.path.join(ROOT, f), ".") for f in ("LICENSE", "README.txt", "PRIVACY.txt")]

a = Analysis(  # noqa: F821
    [os.path.join(SPECPATH, "launch.py")],  # noqa: F821
    pathex=[ROOT],
    datas=datas,
    hiddenimports=["blake3", "pillow_heif"],
    excludes=["tkinter", "PySide6.QtWebEngineCore", "PySide6.QtWebEngineWidgets", "PySide6.QtWebEngineQuick",
              "PySide6.Qt3DCore", "PySide6.Qt3DRender", "PySide6.QtCharts", "PySide6.QtDataVisualization",
              "PySide6.QtGraphs", "PySide6.QtBluetooth", "PySide6.QtSerialPort"],
    noarchive=False,
)
pyz = PYZ(a.pure)  # noqa: F821
exe = EXE(  # noqa: F821
    pyz, a.scripts, [],
    exclude_binaries=True,
    name="Clone Ranger",
    icon=os.path.join(SPECPATH, "clone-ranger.ico"),  # noqa: F821
    console=False,          # a window app: no black console window
    upx=False,
)
coll = COLLECT(exe, a.binaries, a.datas, name="Clone Ranger", upx=False)  # noqa: F821
