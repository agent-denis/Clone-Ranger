@echo off
rem Double-click to build Clone Ranger for Windows WITHOUT running the checks first.
rem Output: dist-windows\CloneRanger-<version>-Setup.exe (copy it to a USB drive and run it on any Windows 10/11 PC).
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0build.ps1" -SkipTests %*
echo.
pause
