CLONE RANGER
============

Round up your duplicate photos and videos.
Find exact duplicates by their content, see them side by side, and free the
space safely.

[Screenshot: Clone Ranger: duplicates side by side, with a suggestion of which
copy to keep – docs/screenshots/main-light.png]

Clone Ranger looks through your folders and external drives for photos and
videos that exist more than once, even under different names. It shows each set
of identical copies as a group, suggests which copy to keep, and lets you move
the rest to the Trash, delete, move or rename them. Nothing happens to a file
until you confirm, and almost everything can be undone.

INSTALL
-------

Fedora (RPM)
~~~~~~~~~~~~

    sudo dnf install clone-ranger          # once it is in the Fedora repositories

Until then, build the RPM yourself (see packaging/clone-ranger.spec) or use the
installer below. The RPM uses Fedora's own PySide6, Pillow and Inter font
packages.

Windows 10 / 11
~~~~~~~~~~~~~~~

Run CloneRanger-1.1.0-Setup.exe (no administrator rights needed), or unzip the
portable version and start Clone Ranger.exe. The app isn't code-signed, so on
first start Windows SmartScreen asks: choose More info → Run anyway. To build it
yourself, see windows/README-WINDOWS.md.

Any Linux, for your user only
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

    git clone https://github.com/agent-denis/clone-ranger.git
    cd clone-ranger
    ./install.sh

install.sh needs Python 3.11 or newer and no root rights. It builds a private
Python environment in ~/.local/share/clone-ranger/, adds Clone Ranger to the app
menu (Graphics) and adds the clone-ranger command. Run it again to upgrade; your
settings, scan index and history are kept. Remove it with ./uninstall.sh (add
--purge to also remove settings, cache and history).

For video thumbnails and durations install FFmpeg: sudo dnf install ffmpeg-free.

FIRST RUN
---------

  1. Press Scan. By default Clone Ranger looks through your home folder and any
     external drives. Change this under Scan locations.
  2. While it scans you see progress, files found and time left. Nothing is
     changed while scanning: files are only read.
  3. Afterwards a summary shows how much space you can free. Each set of
     identical files is a group.

[Screenshot: Scanning – docs/screenshots/scan-light.png]

Try it without touching any file: clone-ranger --demo, or Demo from the app menu
entry's right-click menu.

GROUPS AND VIEWS
----------------

Every group shows its copies, how much space removing the extra copies frees,
and a suggestion of which copy to keep. Three views share the same data and
selection (Ctrl+1/2/3):

  - Cards: one card per group, copies side by side, with Keep / Remove badges.
  - List: a sortable table of every copy.
  - Grid: thumbnails only, with an adjustable size.

[Screenshot: Grid view, dark theme – docs/screenshots/grid-dark.png]

The Details panel on the right (F9) shows the selected copy: preview, folder,
size, dates, resolution, duration and fingerprint, plus View, Copy path, Show in
folder and Open with default app.

Same name finds files that share a name but may have different content
(optionally ignoring case or extension). Nothing is pre-selected there. Filters
narrow the list by type, size, folder and date; the search box filters by file
or folder name.

SELECTING AND UNSELECTING
-------------------------

After a scan the extra copies in every group are selected for removal; the
suggested copy to keep never is. You decide what actually happens:

  - Unselect all (button above the results, or Ctrl+Shift+A) clears the whole
    selection at once, in every group, including groups hidden by a filter.
    Select all (Ctrl+A) selects every duplicate again.
  - Unselect one file: click its tick box on the card or grid tile, press
    Unselect this file in the Details panel (Ctrl+U), or right-click a copy →
    Unselect this file / Unselect this group.
  - The selection bar always shows how many files are selected and how much
    space that is.

The kept copy, files in protected folders and hard links of the kept copy can't
be selected; the Details panel says why.

WHICH COPY TO KEEP
------------------

The suggestion comes from rules you can reorder and switch on or off in Settings
→ Which copy to keep: in a protected folder (always first), in a preferred
folder, not in Downloads/Desktop/temp folders, a name without "copy" / "(1)" /
"_2", highest resolution, oldest, newest, shortest path, deepest folder.
Changing the rules updates the suggestions at once, without a rescan. Groups you
changed by hand keep your choice.

ACTING ON DUPLICATES
--------------------

  - Move to Trash (Delete): restorable from Files. Drives without a usable Trash
    are never deleted from silently; Clone Ranger asks.
  - Delete permanently (Shift+Delete): typing DELETE is required for more than
    20 files.
  - Move…: optionally keeping the folder structure; across drives each file is
    copied, verified against its fingerprint, and only then removed.
  - Rename (F2) and Bulk rename (Ctrl+F2) with a live preview: find/replace,
    regular expressions, prefix/suffix, numbering, letter case, names from the
    date taken.
  - Undo (Ctrl+Z) for move, rename and Move to Trash, and a History page listing
    every action.

Every bulk action shows a preview of exactly what will happen first:

[Screenshot: Confirmation before every action – docs/screenshots/confirm-trash-
light.png]

SAFETY
------

  - Duplicates are byte-for-byte identical: same size, same quick check, same
    full fingerprint (BLAKE3, or BLAKE2b). Hard links and Btrfs reflinks are
    recognised and don't count as space to free.
  - Files that changed since the scan are skipped. Protected folders are refused
    by every action, even if asked directly.
  - A warning appears when an action would leave no copy of a group, or when
    files only share a name.
  - Clone Ranger refuses to run as root, never follows symbolic links, and never
    empties the Trash.

THE VIEWER
----------

Double-click a copy or press F3. Compare (F4) shows two copies side by side with
locked zoom; facts that differ are highlighted, and Tab flickers between A and
B. Grid compare (Shift+F4) shows up to nine copies; Slideshow (F11) plays the
group. Videos play inside the viewer, also in compare mode.

[Screenshot: Compare two copies – docs/screenshots/viewer-compare-dark.png]

SETTINGS
--------

  - Appearance: System (follows your desktop's light/dark setting), Light, Dark
    or Plain (the standard system look); reduce motion; sounds.
  - Which copy to keep, preferred folders and protected folders (see above).
  - History & cache: how much Clone Ranger remembers, with Clear history &
    cache… and Reset to defaults….

[Screenshot: Settings – docs/screenshots/settings-light.png]

RESET TO DEFAULTS, CLEAR HISTORY & CACHE
----------------------------------------

Both open the same dialog (also in the File menu, and Reset to defaults… on the
Scan locations page), where you choose exactly what to reset:

  - Search settings: Scan locations, excluded folders, filters, search text and
    same-name options go back to their defaults.
  - All other settings: Theme, keep rules, preferred and protected folders,
    sounds and layout.
  - History: Forgets past actions (they can no longer be undone), empties the
    app log and forgets remembered folders.
  - Cache: Deletes the scan index and thumbnails. The next scan starts from
    scratch.

Reset to defaults… starts with only Search settings ticked; Clear history &
cache… starts with History and Cache ticked. Tick everything to start completely
from scratch. Your photos and videos are never touched, and the dialog warns you
if past actions could still be undone.

[Screenshot: Clear history & cache – docs/screenshots/reset-clear-light.png]

KEYBOARD SHORTCUTS
------------------

Help → Keyboard shortcuts (F1) shows the full list. The most used ones:

  Keys                       Action
  ------------------------   --------------------------------------------
  F5                         Scan
  Ctrl+1 / 2 / 3             Cards / List / Grid
  ← / →                      Previous / next copy in a group
  Enter, double-click        Open in the viewer
  F3 / F4 / Shift+F4 / F11   Viewer / compare / grid compare / slideshow
  Delete / Shift+Delete      Move to Trash / delete permanently
  F2 / Ctrl+F2               Rename / bulk rename
  Ctrl+Z                     Undo
  Ctrl+A / Ctrl+Shift+A      Select all duplicates / unselect all
  Ctrl+U                     Unselect the file shown in the Details panel
  F9                         Show / hide the Details panel
  Ctrl+E                     Export CSV

WHERE THINGS ARE STORED
-----------------------

  - Settings: ~/.config/clone-ranger/settings.json (cleared by: Reset to
    defaults)
  - Scan index, thumbnails (the cache): ~/.cache/clone-ranger/ (cleared by:
    Clear cache)
  - History (Undo), app log: ~/.local/state/clone-ranger/ (cleared by: Clear
    history)
  - Program (installer only): ~/.local/share/clone-ranger/ (cleared by:
    ./uninstall.sh)
  - Trashed files: the normal Trash (cleared by: Empty it from Files)

TROUBLESHOOTING
---------------

  - HEIC photos show "no preview". Run ./install.sh again; it adds pillow-heif
    when a build exists for your Python. The RPM has no HEIC support, because
    Fedora doesn't package pillow-heif.
  - Videos have no thumbnail. Fedora's ffmpeg-free can't decode some codecs
    (such as HEVC from phones). Playback in the viewer uses Qt's own FFmpeg and
    still works.
  - "This drive has no Trash". Some drives can't hold a Trash folder. Clone
    Ranger leaves those files alone and asks whether to delete them permanently.
  - clone-ranger: command not found. ~/.local/bin isn't in your PATH. Start
    Clone Ranger from the app menu, or run ~/.local/bin/clone-ranger.
  - Something went wrong. Details go to ~/.local/state/clone-ranger/clone-
    ranger.log.
  - Results look stale or odd. File → Clear history & cache… with only Cache
    ticked, then scan again.

COMMAND LINE
------------

A read-only command line, for scripts and for checking results:

    clone-ranger --version
    python3 -m clone_ranger.core.cli scan ~/Pictures --list
    python3 -m clone_ranger.core.cli names --ignore-case      # same name, other folders
    python3 -m clone_ranger.core.cli report --csv duplicates.csv
    python3 -m clone_ranger.core.cli skipped                  # what couldn't be read

(With install.sh, use ~/.local/share/clone-ranger/venv/bin/python instead of
python3.) It uses the same index as the app, ~/.cache/clone-ranger/index.sqlite
(--db FILE for another one).

DEVELOPMENT
-----------

    python3 -m venv .venv && .venv/bin/pip install -r requirements-dev.txt   # first time only
    .venv/bin/python -m clone_ranger --demo     # demo data, touches no files
    .venv/bin/python -m pytest                  # every file operation is locked to a temporary folder

  - tools/make_sample_library.py DIR: small demo library with known duplicates
    (+ manifest.json)
  - tools/make_perf_library.py DIR --files N: large synthetic library for
    performance tests
  - tools/perf_test.py DIR: scan / load / window timings and memory, checked
    against the manifest
  - tools/screenshots.py: render docs/screenshots/ from demo data
  - tools/export_text.py: write README.txt (plain-text README) and clone-ranger-
    source.txt (all source code in one text file)
  - tools/make_assets.py · make_icons.py · make_sounds.py: regenerate the logo
    and icons, the app icons, the sounds
  - python -m clone_ranger.theme.palettes: print WCAG contrast ratios for both
    themes

Code layout: clone_ranger/core/ (scanning, hashing, the index, file operations,
reset/clear; no Qt), clone_ranger/ui/ (the window), clone_ranger/viewer/ and
clone_ranger/ui/viewer/ (the viewer), clone_ranger/theme/ (colours, strings,
fonts, artwork) and packaging/ (desktop file, AppStream metadata, icons, RPM
spec). Releasing on GitHub and getting into Fedora is described in
docs/PUBLISHING.md.

PRIVACY
-------

Clone Ranger works entirely offline: no internet connections, no telemetry, no
accounts. Everything it stores (settings, scan index, thumbnails, history) stays
in your home folder and can be deleted with File → Clear history & cache…. The
full statement is in PRIVACY.txt.

LICENCE AND CREDITS
-------------------

Clone Ranger is free software: you can redistribute it and/or modify it under
the terms of the GNU General Public License version 3 or (at your option) any
later version (see LICENSE). This is a copyleft licence: anyone who shares a
modified version must share its source code under the same terms.

The Inter font is © The Inter Project Authors, under the SIL Open Font License
1.1 (clone_ranger/theme/fonts/inter/OFL.txt). The logo, icons and sounds are
original work made for this project and are covered by the GPL.

(Plain-text version of README.md, made by tools/export_text.py.)
